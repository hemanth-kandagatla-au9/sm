"use client";

import { useState } from "react";
import { ProfileAvatar } from "./profile-avatar";
import {
  Collapse,
  List,
  ListItemAvatar,
  ListItemButton,
  ListItemIcon,
  ListItemText,
} from "@mui/material";
import { ChevronDown, ChevronUp, LogOut } from "lucide-react";

type DashboardHeaderProps = {
  displayName: string;
  displayRole: string;
  photoUrl?: string | null;
  onLogout: () => void | Promise<void>;
};
const listStyle = {
  padding: "6px",
  backgroundColor: "white",
  borderRadius: 2,
  width: "220px"
};
const listItemButtonStyle = {
  padding: "6px 12px",
  borderRadius: 2,
  border: "1px solid #e5e7eb",
};

export function DashboardHeader({
  displayName,
  displayRole,
  photoUrl,
  onLogout,
}: DashboardHeaderProps) {
  const [open, setOpen] = useState(false);
  const sanitizedDisplayName = displayName.split("[")[0].trim();

  const handleClick = () => {
    setOpen(!open);
  };
  return (
    <header className="flex items-center justify-between border-b border-black/6 bg-white pr-2 pl-6 py-1">
      <div>
        <h1 style={{ fontSize: "24px", color: "black",fontWeight:"500" ,fontFamily: "var(--app-font-display)" }}>
          AI SDLC Orchestration
        </h1>
      </div>
      <div className="relative" style={{ width: 240 }}>
        <List sx={listStyle}>
          <ListItemButton sx={listItemButtonStyle} onClick={handleClick}>
            <ListItemAvatar sx={{ minWidth: 45 }}>
              <ProfileAvatar
                displayName={displayName}
                photoUrl={photoUrl}
                className="size-8"
              />
            </ListItemAvatar>
            <ListItemText
              sx={{ margin: 0 }}
              primary={
                <span style={{ fontSize: "14px", color: "black", fontFamily: "var(--app-font-display)" }}>
                  {sanitizedDisplayName}
                </span>
              }
              secondary={
                <span className="text-xs font-display text-gray-700">
                  {displayRole}
                </span>
              }
            />
            {open ? <ChevronUp /> : <ChevronDown />}
          </ListItemButton>
        </List>

        <Collapse
          in={open}
          timeout="auto"
          unmountOnExit
          sx={{
            position: "absolute",
            left: 0,
            right: 0,
            zIndex: 50,
          }}
        >
          <List sx={listStyle}>
            <ListItemButton
              sx={listItemButtonStyle}
              onClick={() => void onLogout()}
            >
              <ListItemIcon sx={{ minWidth: 30 }}>
                <LogOut className="size-5 text-[#eb1700]" />
              </ListItemIcon>
              <ListItemText
                primary={
                  <span className="text-sm font-semibold text-[#eb1700]">
                    Logout
                  </span>
                }
              />
            </ListItemButton>
          </List>
        </Collapse>
      </div>
    </header>
  );
}
