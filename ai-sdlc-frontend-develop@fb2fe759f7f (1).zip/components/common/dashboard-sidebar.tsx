"use client";

import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useRouter, usePathname } from "next/navigation";
import {
  LayoutDashboard,
  MessageSquareMore,
  Settings2,
  MonitorCog,
  ChevronsLeft,
  ChevronsRight,
} from "lucide-react";
import { getVisibleNavItems } from "@/lib/auth/roles";
import JNJLogo from "../icons/JNJLogo";

export type ActiveTab =
  | "Dashboard"
  | "Projects"
  | "Messages"
  | "Monitoring"
  | "Setup";

export const NAV_ITEMS: {
  icon: React.ElementType;
  label: ActiveTab;
  route: string;
}[] = [
  { icon: LayoutDashboard, label: "Dashboard", route: "/dashboard" },
  { icon: Settings2, label: "Setup", route: "/admin-setup" },
  { icon: MessageSquareMore, label: "Projects", route: "/messages" },
  { icon: MonitorCog, label: "Monitoring", route: "/monitoring" },
];

type DashboardSidebarProps = {
  isExpanded: boolean;
  onToggle: () => void;
};

export function DashboardSidebar({
  isExpanded,
  onToggle,
}: DashboardSidebarProps) {
  const router = useRouter();
  const pathname = usePathname();

  const isActive = (route: string) =>
    pathname === route || pathname.startsWith(route + "/");

  const visibleNavItems = getVisibleNavItems(NAV_ITEMS);

  return (
    <aside
      className={cn(
        "relative z-20 flex flex-col overflow-visible border-r border-black/6 bg-white transition-[width] duration-300",
        isExpanded ? "w-52" : "w-22",
      )}
    >
      <div className="relative flex h-20 items-center border-b border-black/6 px-4">
        {!isExpanded ? (
          <JNJLogo />
        ) : (
          <p className="truncate text-[18px] text-[#eb1700] font-bold px-1">
            Johnson &amp; Johnson
          </p>
        )}
        <Button
          type="button"
          variant="outline"
          size="icon"
          onClick={onToggle}
          className="absolute top-1/3 -right-4 z-30 size-8 shrink-0 rounded-full border-black/8 bg-white px-0 text-[#8f8d89] shadow-[0_8px_24px_rgba(17,24,39,0.08)] hover:border-(--jnj-red)/20 hover:bg-white hover:text-(--jnj-red)"
        >
          {isExpanded ? (
            <ChevronsLeft className="size-5" />
          ) : (
            <ChevronsRight className="size-5" />
          )}
        </Button>
      </div>

      <nav className="flex flex-col gap-2 px-2 py-3">
        {visibleNavItems.map((item) => {
          const active = isActive(item.route);
          return (
            <button
              key={item.label}
              title={isExpanded ? item.label : undefined}
              onClick={() => router.push(item.route)}
              className={cn(
                "flex items-center gap-3 rounded-lg transition-all duration-150 px-3 h-10",
                isExpanded ? "justify-start" : "justify-center",
                active
                  ? "bg-[#fce8e4] text-[#e8472a]"
                  : "text-muted-foreground hover:bg-accent hover:text-foreground",
              )}
            >
              <div className="flex items-center justify-center">
                <item.icon className="w-5 h-5" />
              </div>

              {isExpanded && (
                <span className="text-[14px] font-medium">{item.label}</span>
              )}
            </button>
          );
        })}
      </nav>
    </aside>
  );
}
