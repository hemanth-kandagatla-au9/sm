import type { Dispatch, SetStateAction } from "react";
import TableSearchBar from "@/components/resuable-components/TableSearchBar";
import { Button } from "@mui/material";
import { primaryButtonSx } from "./Helper";

type TableHeaderProps = {
  title: string;
  globalSearch?: string;
  setGlobalSearch?: Dispatch<SetStateAction<string>>;
  showSearch?: boolean;
  rightContent?: React.ReactNode;
  haveActionsButton?: boolean;
  buttonText?: string;
  buttonIcon?: React.ReactNode;
  onButtonClick?: () => void;
};

const TableHeader = ({
  title,
  globalSearch,
  setGlobalSearch,
  showSearch = true,
  rightContent,
  haveActionsButton = false,
  buttonText,
  buttonIcon,
  onButtonClick,
}: TableHeaderProps) => {
  //to check if global search are passed or not.
  const shouldRenderSearch =
    showSearch && globalSearch !== undefined && setGlobalSearch !== undefined;

  return (
    <div className="flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
      <div className="flex w-full flex-col gap-2 sm:flex-row sm:items-center sm:gap-3 md:w-auto md:shrink-0">
        <h1 style={{ fontSize: "1.4rem", color: "#5c534c", fontWeight: "500", fontFamily: "var(--app-font-display)" }}>
          {title}
        </h1>
      </div>

      <div className="flex w-full min-w-0 flex-wrap items-center justify-start gap-2 sm:justify-end md:w-auto md:flex-nowrap md:justify-end">
        {rightContent}
        {shouldRenderSearch ? (
          <TableSearchBar
            globalSearch={globalSearch}
            setGlobalSearch={setGlobalSearch}
          />
        ) : null}
        {haveActionsButton && (
          <Button
            startIcon={buttonIcon}
            sx={primaryButtonSx}
            onClick={onButtonClick}
          >
            {buttonText}
          </Button>
        )}
      </div>
    </div>
  );
};

export default TableHeader;
