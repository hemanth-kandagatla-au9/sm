"use client";

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { extractInitials } from "@/lib/auth/user-helper";
import { cn } from "@/lib/utils";

type ProfileAvatarProps = {
  displayName: string;
  photoUrl?: string | null;
  className?: string;
  fallbackClassName?: string;
};

export function ProfileAvatar({
  displayName,
  photoUrl,
  className,
  fallbackClassName,
}: ProfileAvatarProps) {
  const initials =
    extractInitials(displayName) ||
    displayName.slice(0, 2).toUpperCase() ||
    "?";

  return (
    <Avatar className={className}>
      {photoUrl ? <AvatarImage src={photoUrl} alt={displayName} /> : null}
      <AvatarFallback className={cn(fallbackClassName)}>
        {initials}
      </AvatarFallback>
    </Avatar>
  );
}
