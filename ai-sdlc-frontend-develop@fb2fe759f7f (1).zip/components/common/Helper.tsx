import Chip from "@mui/material/Chip";
import { Workflow as WorkflowIcon } from "lucide-react";

export const DATA_GRID_CHIP_COLOR: Record<
  string,
  { bg: string; color: string; border?: string }
> = {
  Login: { bg: "#69C44533", color: "#0B7929" },
  Logout: { bg: "#FFE7E580", color: "#FF301A" },
  CREATE: { bg: "#0C92F81F", color: "#2684FF" },
  UPDATE: { bg: "#FBEFD980", color: "#DC9B21" },
  DELETE: { bg: "#FFE7E580", color: "#FF301A" },
  Completed: { bg: "#69C44533", color: "#0B7929" },
  Failed: { bg: "#FFE7E580", color: "#FF301A" },
  Awaiting: { bg: "#FBEFD980", color: "#DC9B21" },
  True: { bg: "#E0FFDB80", color: "#18A800" },
  False: { bg: "#FFE7E580", color: "#FF301A" },
  
};

export const renderDataGridChip = (
  value: string | number | boolean | null | undefined,
) => {
  const normalized =
    value == null || value === ""
      ? ""
      : typeof value === "boolean"
        ? value
          ? "True"
          : "False"
        : String(value);
  if (!normalized) return <span>--</span>;

  const style = DATA_GRID_CHIP_COLOR[normalized] ?? { bg: "#0C92F81F", color: "#2684FF" };

  return (
    <Chip
      label={normalized}
      size="small"
      sx={{ backgroundColor: style.bg, color: style.color, fontSize: "14px", height: 22 }}
    />
  );
};

export const gridSx = {
  fontFamily: "var(--font-johnson-text)",
  fontSize: "14px",
  "& .MuiDataGrid-cell:focus": { outline: "none" },
  "& .MuiDataGrid-cell:focus-within": { outline: "none" },
  "& .MuiDataGrid-columnHeader:focus-within, & .MuiDataGrid-columnHeader:focus": { outline: "none" },
  "& .MuiDataGrid-columnHeaderTitle": { fontWeight: "bold", color: "#4C5463", fontSize: "14px" },
  "& ::-webkit-scrollbar": { width: "4px", height: "4px" },
  "& ::-webkit-scrollbar-track": { backgroundColor: "#f1f1f1", borderRadius: "10px" },
  "& ::-webkit-scrollbar-thumb": { backgroundColor: "#bdbdbd", borderRadius: "10px" },
  "& ::-webkit-scrollbar-thumb:hover": { backgroundColor: "#999" },
};

export const primaryButtonSx = {
  width: "auto",
  height: "35px",
  background: "linear-gradient(90deg, #FF5D4C 0%, #F72812 100%)",
  color: "#ffffff",
  padding: "8px 12px",
  textTransform: "none",
  fontSize: "14px",
  fontFamily: "var(--app-font-text)",
  fontWeight: "400",
  borderRadius: "8px",
  "&:hover": { background: "#FAE7CB", color: "#F72812", border: "1px solid #F72812" },
  "&.Mui-disabled": { background: "#E5E7EB", color: "#9CA3AF", border: "1px solid #D1D5DB" },
};

type ResourceTypeCellProps = {
  value?: string | null;
};

export const ResourceTypeCell = ({ value }: ResourceTypeCellProps) => {
  const displayValue = String(value ?? "");
  const isWorkflow = displayValue.includes("WORKFLOW") || displayValue.includes("Workflow");

  return (
    <span className={isWorkflow ? `inline-flex items-center gap-2 ${displayValue.includes("WORKFLOW") ? `text-[#4C5463]` : `text-black`}` : ""}>
      {isWorkflow && <WorkflowIcon className="h-4 w-4 text-[#FC9619]" />}
      {displayValue}
    </span>
  );
};

export const fieldInputSx = {
  "& .MuiInputLabel-root": { fontSize: "14px", fontFamily: "var(--app-font-text)" },
  "& .MuiInputLabel-root.Mui-focused": { color: "#312c2a" },
  "& .MuiOutlinedInput-root": {
    borderRadius: "10px",
    "& fieldset": { borderColor: "#d1d5db" },
    "&:hover fieldset": { borderColor: "#9ca3af" },
    "&.Mui-focused fieldset": { borderColor: "#787673", borderWidth: 2 },
  },
  "& .MuiInputBase-input": { fontSize: "14px", fontFamily: "var(--app-font-text)" },
  "& .MuiFormHelperText-root": { fontSize: "12px", fontFamily: "var(--app-font-text)" },
};

export const fieldDropdownListSx = {
  maxHeight: "280px",
  "& .MuiAutocomplete-option": { fontSize: "16px", fontFamily: "var(--app-font-text)" },
  "& .MuiMenuItem-root": { fontSize: "16px", fontFamily: "var(--app-font-text)" },
};