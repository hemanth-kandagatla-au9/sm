import toast from "react-hot-toast";

type Resp = {
  status: boolean; //apis response field to determine success or error of the api call
  message: string;
};

const toastBaseStyle = {
  minHeight: "60px",
  padding: "14px 16px",
  borderRadius: "10px",
  fontSize: "14px",
};

const successToastStyle = {
  ...toastBaseStyle,
  background: "#439963",
  color: "#ffffff",
};

const errorToastStyle = {
  ...toastBaseStyle,
  background: "#c03232",
  color: "#ffffff",
};

const warningToastStyle = {
  ...toastBaseStyle,
  background: "#f59e0b",
  color: "#111827",
};

const loadingToastStyle = {
  ...toastBaseStyle,
  background: "#1f2937",
  color: "#ffffff",
};


const showRespToast = (resp: Resp) => {
  if (resp.status) {
    toast.success(resp.message, {
      style: successToastStyle,
    });
  } else if (!resp.status) {
    toast.error(resp.message, {
      style: errorToastStyle,
    });
  } else {
    toast(resp?.message, {
      style: warningToastStyle,
    });
  }
};

const warningToast = (message: string) => {
  toast(message, {
    icon: "⚠️",
    style: warningToastStyle,
  });
};

export const promiseLoadingToastStyle = {
  loading: {
    style: loadingToastStyle,
  },
};

const ToastHelper = { showRespToast, warningToast };
export default ToastHelper;