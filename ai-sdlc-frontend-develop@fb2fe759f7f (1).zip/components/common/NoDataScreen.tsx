import { Button } from "@mui/material";
import NoDataScreenIcon from "../icons/NoDataScreenIcon";
import { primaryButtonSx } from "./Helper";

type NoDataScreenProps = {
  primaryText: string;
  secondaryText: string;
  buttonText?: string;
  buttonIcon?: React.ReactNode;
  onButtonClick?: () => void;
};

const NoDataScreen = ({
  primaryText,
  secondaryText,
  buttonText,
  buttonIcon,
  onButtonClick,
}: NoDataScreenProps) => {
  return (
    <div className="flex min-h-[calc(100vh-230px)] w-full items-center justify-center">
      <div className="flex flex-col items-center gap-4 text-center">
        <NoDataScreenIcon />
        <div className="space-y-1">
          <p className="text-[34px] text-[#eb1700]">{primaryText}</p>
          <p className="text-[20px] text-[#6b7280]">{secondaryText}</p>
        </div>
        <Button
          startIcon={buttonIcon}
          sx={primaryButtonSx}
          onClick={onButtonClick}
        >
          {buttonText}
        </Button>
      </div>
    </div>
  );
};

export default NoDataScreen;