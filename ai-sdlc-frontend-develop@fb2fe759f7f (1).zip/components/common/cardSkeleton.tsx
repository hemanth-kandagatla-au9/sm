import { Card, CardContent, Skeleton, Stack} from "@mui/material";

const CardSkeleton = () => {
    return (
        <Card
            elevation={0}
            sx={{
                borderRadius: 3,
                border: "1px solid #e5e7eb",
                height: "100%",
            }}
        >
            <CardContent>
                <Stack spacing={1.5}>
                    <Skeleton variant="text" width="75%" height={40} />
                    <Skeleton variant="text" width="100%" height={20} />
                </Stack>
            </CardContent>
        </Card>
    );
};

export default CardSkeleton;