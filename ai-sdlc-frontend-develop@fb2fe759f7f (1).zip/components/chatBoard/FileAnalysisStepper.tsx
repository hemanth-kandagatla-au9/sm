"use client";
import Box from "@mui/material/Box";
import Stepper from "@mui/material/Stepper";
import Step from "@mui/material/Step";
import StepLabel from "@mui/material/StepLabel";
import StepContent from "@mui/material/StepContent";
import Typography from "@mui/material/Typography";
import { useState, useEffect, useRef } from "react";

const STEP_DURATION_MS = 2000; 
const STEP_1_MIN_MS = 6000; 

const stepStyles = {
  "& .MuiCollapse-root .MuiTypography-root": {
    fontSize: "0.8rem",
    fontFamily: "var(--app-font-sans)",
    color: "#564C47",
  },
  "& .MuiStepLabel-root": {
    padding: 0,
  },
  "& .MuiStepLabel-label": {
    fontSize: "0.9rem",
    fontWeight: 600,
    fontFamily: "var(--app-font-sans)", ////in global css it has Jonshon text is defined as font-san
    color: "#000",
  },
  "& .MuiStepContent-root": {
    marginLeft: "8px",
    paddingLeft: "16px",
  },
  "& .MuiStepConnector-line": {
    borderLeft: "2px solid #bdbdbd",
    minHeight: "12px",
    marginLeft: "-4px",
  },
  //for changing the icon size
  "& .MuiStepIcon-root": {
    fontSize: "1rem",
  },
  "& .MuiStepIcon-root.Mui-active": {
    color: "black",
  },
  "& .MuiStepIcon-root.Mui-completed": {
    color: "green",
  },
  "& .MuiStepConnector-root.Mui-active .MuiStepConnector-line, & .MuiStepConnector-root.Mui-completed .MuiStepConnector-line":
    {
      borderColor: "green",
    },
  "& .MuiStep-root.Mui-completed .MuiStepContent-root": {
    borderColor: "green",
  },
};

const steps = [
  {
    label: "Analyzing your input…",
    description: `Working with iWand MCP.`,
  },
  {
    label: "Generating Meeting Transcript",
    description: "Generating Text...",
  },
  {
    label: "Meeting Transcript Generated",
    description: `Requirements Generated successfully!`,
  },
];

interface FileUploadStepperProps {
  onComplete?: () => void;

  onError?: () => void;
 
  conversationPromise?: Promise<boolean>;
}

export default function FileAnalysisStepper({
  onComplete,
  onError,
  conversationPromise,
}: FileUploadStepperProps) {
  const [activeStep, setActiveStep] = useState(0);
  const [visible, setVisible] = useState(true);
  const hasCompletedRef = useRef(false);

  // ── Dummy auto-advance mode (no conversationPromise) ──────────────────────
  useEffect(() => {
    if (conversationPromise) return; // controlled by real API flow below
    if (activeStep >= steps.length) return;

    const timer = window.setTimeout(() => {
      setActiveStep((prev) => prev + 1);
    }, STEP_DURATION_MS);

    return () => window.clearTimeout(timer);
  }, [activeStep, conversationPromise]);

  // ── Real API-driven mode (conversationPromise provided) ───────────────────
  useEffect(() => {
    const promise = conversationPromise;
    if (!promise) return;

    let cancelled = false;

    // Step 0 → Step 1: after STEP_1_MIN_MS (6 s)
    const step1Timer = window.setTimeout(() => {
      if (!cancelled) setActiveStep(1);
    }, STEP_1_MIN_MS);

    Promise.all([
      new Promise<void>((resolve) => window.setTimeout(resolve, STEP_1_MIN_MS)),
      promise,
    ]).then(([, success]) => {
      if (cancelled) return;
      if (success) {
        setActiveStep(steps.length); 
      } else {
       
        if (onError) {
          onError();
        } else {
          setVisible(false);
        }
      }
    });

    return () => {
      cancelled = true;
      window.clearTimeout(step1Timer);
    };
  }, [conversationPromise]);

  // ── Trigger onComplete once all steps are done ────────────────────────────
  useEffect(() => {
    if (activeStep === steps.length && !hasCompletedRef.current) {
      hasCompletedRef.current = true;
      onComplete?.();
    }
  }, [activeStep, onComplete]);

  if (!visible) return null;

  return (
    <Box>
      <Stepper activeStep={activeStep} orientation="vertical" sx={stepStyles}>
        {steps.map((step, index) => (
          <Step key={step.label} expanded>
            <StepLabel>{step.label}</StepLabel>
            <StepContent
              sx={{
                borderLeft:
                  index === steps.length - 1 ? "none" : "2px solid #bdbdbd",
              }}>
              <Typography>{step.description}</Typography>
            </StepContent>
          </Step>
        ))}
      </Stepper>
    </Box>
  );
}
