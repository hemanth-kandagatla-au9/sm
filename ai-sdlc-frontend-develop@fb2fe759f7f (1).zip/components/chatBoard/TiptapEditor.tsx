"use client";
import React, { useCallback, useEffect } from "react";
import { useEditor, EditorContent } from "@tiptap/react";
import type { Content } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import Underline from "@tiptap/extension-underline";
import Link from "@tiptap/extension-link";
import Image from "@tiptap/extension-image";
import {
  Bold,
  Italic,
  Strikethrough,
  Underline as UnderlineIcon,
  List,
  ListOrdered,
  Undo2,
  Redo2,
  AlignLeft,
  ChevronDown,
  Link as LinkIcon,
  Image as ImageIcon,
  Code2,
  Code,
  Eraser,
} from "lucide-react";
import { useChatStore } from "@/store/useChatStore";
import { CollapsibleSection } from "./tiptap/CollapsibleSection";

/**
 * If the API returns a TipTap document whose sole child is a `codeBlock`
 * containing a raw HTML string (iWand meeting-notes pattern), extract that
 * HTML text so TipTap can parse and render it properly instead of showing
 * the raw markup as plain text.
 */
function normalizeDocument(doc: Content): Content {
  if (
    doc &&
    typeof doc === "object" &&
    !Array.isArray(doc) &&
    (doc as Record<string, unknown>).type === "doc"
  ) {
    const nodes = (doc as { content?: unknown[] }).content;
    if (Array.isArray(nodes) && nodes.length === 1) {
      const node = nodes[0] as {
        type?: string;
        content?: { type?: string; text?: string }[];
      };
      if (
        node.type === "codeBlock" &&
        Array.isArray(node.content) &&
        node.content.length === 1 &&
        node.content[0].type === "text" &&
        typeof node.content[0].text === "string" &&
        node.content[0].text.trimStart().startsWith("<")
      ) {
        // Return the raw HTML string – TipTap's setContent accepts HTML natively
        return node.content[0].text;
      }
    }
  }
  return doc;
}

type ToolbarButtonProps = {
  onClick: () => void;
  isActive?: boolean;
  children: React.ReactNode;
  title?: string;
};

const ToolbarButton: React.FC<ToolbarButtonProps> = ({
  onClick,
  isActive,
  children,
  title,
}) => (
  <button
    type="button"
    title={title}
    onClick={onClick}
    className={`p-1.5 rounded transition-colors hover:bg-gray-100 flex items-center justify-center ${isActive ? "bg-gray-200 text-gray-900" : "text-gray-500"}`}>
    {children}
  </button>
);

const Spacer = () => <span className="w-2" />;

const TiptapEditor: React.FC = () => {
  const { tiptapDocument } = useChatStore();

  const editor = useEditor({
    extensions: [
      StarterKit,
      Underline,
      Link.configure({ openOnClick: false }),
      Image,
      CollapsibleSection,
    ],
    content: tiptapDocument
      ? normalizeDocument(tiptapDocument as Content)
      : "<p>No content yet.</p>",
    immediatelyRender: false,
    editable: false,
  });

  // Sync editor content whenever the store document changes
  useEffect(() => {
    if (editor && tiptapDocument) {
      editor.commands.setContent(normalizeDocument(tiptapDocument as Content));
    }
  }, [editor, tiptapDocument]);

  const setLink = useCallback(() => {
    if (!editor) return;
    const previousUrl = editor.getAttributes("link").href;
    const url = window.prompt("URL", previousUrl);

    if (url === null) return;
    if (url === "") {
      editor.chain().focus().extendMarkRange("link").unsetLink().run();
      return;
    }
    editor.chain().focus().extendMarkRange("link").setLink({ href: url }).run();
  }, [editor]);

  const addImage = useCallback(() => {
    if (!editor) return;
    const url = window.prompt("Image URL");
    if (url) {
      editor.chain().focus().setImage({ src: url }).run();
    }
  }, [editor]);

  if (!editor) return null;

  return (
    <div className="bg-white rounded-lg border border-gray-200 shadow p-3 min-h-[95vh]">
      <div className="flex flex-wrap items-center gap-1 mb-3 border-b border-gray-100 pb-2 text-gray-600">
        <ToolbarButton
          title="Undo"
          onClick={() => editor.chain().focus().undo().run()}>
          <Undo2 className="w-4 h-4" />
        </ToolbarButton>
        <ToolbarButton
          title="Redo"
          onClick={() => editor.chain().focus().redo().run()}>
          <Redo2 className="w-4 h-4" />
        </ToolbarButton>

        <Spacer />

        <ToolbarButton title="Text Format" onClick={() => {}}>
          <div className="flex items-center gap-0.5">
            <AlignLeft className="w-4 h-4" />
            <ChevronDown className="w-3 h-3" />
          </div>
        </ToolbarButton>

        <Spacer />

        <ToolbarButton
          title="Bullet List"
          onClick={() => editor.chain().focus().toggleBulletList().run()}
          isActive={editor.isActive("bulletList")}>
          <List className="w-4 h-4" />
        </ToolbarButton>
        <ToolbarButton
          title="Ordered List"
          onClick={() => editor.chain().focus().toggleOrderedList().run()}
          isActive={editor.isActive("orderedList")}>
          <ListOrdered className="w-4 h-4" />
        </ToolbarButton>

        <Spacer />

        <ToolbarButton
          title="Link"
          onClick={setLink}
          isActive={editor.isActive("link")}>
          <LinkIcon className="w-4 h-4" />
        </ToolbarButton>
        <ToolbarButton
          title="Image"
          onClick={addImage}
          isActive={editor.isActive("image")}>
          <ImageIcon className="w-4 h-4" />
        </ToolbarButton>
        <ToolbarButton
          title="Code Block"
          onClick={() => editor.chain().focus().toggleCodeBlock().run()}
          isActive={editor.isActive("codeBlock")}>
          <Code2 className="w-4 h-4" />
        </ToolbarButton>

        <Spacer />

        <ToolbarButton
          title="Bold"
          onClick={() => editor.chain().focus().toggleBold().run()}
          isActive={editor.isActive("bold")}>
          <Bold className="w-4 h-4" />
        </ToolbarButton>
        <ToolbarButton
          title="Italic"
          onClick={() => editor.chain().focus().toggleItalic().run()}
          isActive={editor.isActive("italic")}>
          <Italic className="w-4 h-4" />
        </ToolbarButton>
        <ToolbarButton
          title="Underline"
          onClick={() => editor.chain().focus().toggleUnderline().run()}
          isActive={editor.isActive("underline")}>
          <UnderlineIcon className="w-4 h-4" />
        </ToolbarButton>
        <ToolbarButton
          title="Strikethrough"
          onClick={() => editor.chain().focus().toggleStrike().run()}
          isActive={editor.isActive("strike")}>
          <Strikethrough className="w-4 h-4" />
        </ToolbarButton>

        <Spacer />

        <ToolbarButton
          title="Inline Code"
          onClick={() => editor.chain().focus().toggleCode().run()}
          isActive={editor.isActive("code")}>
          <Code className="w-4 h-4" />
        </ToolbarButton>
        <ToolbarButton
          title="Clear Formatting"
          onClick={() =>
            editor.chain().focus().unsetAllMarks().clearNodes().run()
          }>
          <Eraser className="w-4 h-4" />
        </ToolbarButton>
      </div>

      <div className="prose max-w-none focus:outline-none mt-4">
        <EditorContent editor={editor} />
      </div>
    </div>
  );
};

export default TiptapEditor;
