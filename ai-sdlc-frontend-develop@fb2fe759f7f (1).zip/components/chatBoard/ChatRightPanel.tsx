"use client";
import React from "react";
import dynamic from "next/dynamic";
const TiptapEditor = dynamic(() => import("./TiptapEditor"), { ssr: false });

interface ChatRightPanelProps {
  isOpen: boolean;
  toggle: () => void;
}

const ChatRightPanel: React.FC<ChatRightPanelProps> = ({ isOpen, toggle }) => {
  return (
    <div
      className={`h-full flex-shrink-0 overflow-hidden transition-all duration-300 ease-in-out ${
        isOpen ? "w-[33%] opacity-100" : "w-0 opacity-0"
      }`}
      style={{
        background: "#F2F5F8",
        boxShadow: isOpen ? "-2px 0 8px rgba(0,0,0,0.04)" : undefined,
        minWidth: isOpen ? "320px" : "0px",
      }}>
      {isOpen && (
        <div className=" h-full overflow-y-auto min-w-[320px]">
          <TiptapEditor />
        </div>
      )}
    </div>
  );
};

export default ChatRightPanel;
