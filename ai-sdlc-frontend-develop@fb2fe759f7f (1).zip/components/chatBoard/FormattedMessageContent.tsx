import { isHtmlContent, sanitizeHtml } from "@/lib/utils/richText";
import ReactMarkdown from 'react-markdown';

interface FormattedMessageContentProps {
  content: string;
  className?: string;
}

export default function FormattedMessageContent({
  content,
  className = "",
}: FormattedMessageContentProps) {
  if (isHtmlContent(content)) {
    return (
      <div
        className={`rich-message text-[14px] md:text-[15px] text-[#0f172a] font-normal mb-3 [&_p]:mb-2 [&_ul]:list-disc [&_ul]:pl-5 [&_ol]:list-decimal [&_ol]:pl-5 [&_a]:text-blue-600 [&_a]:underline ${className}`}
        dangerouslySetInnerHTML={{ __html: sanitizeHtml(content) }}
      />
    );
  }

  return (
    <div
      className={`text-[14px] md:text-[15px] text-[#0f172a] font-normal mb-3 ${className} markdown`}>
      <ReactMarkdown>{content}</ReactMarkdown>
    </div>
  );
}
