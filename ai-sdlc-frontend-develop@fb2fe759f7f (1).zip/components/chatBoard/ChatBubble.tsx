import React, { ReactNode, useState } from "react";
import {
  Bot,
  Info,
  Copy,
  Check,
  ThumbsUp,
  ThumbsDown,
  RefreshCw,
  Loader2,
} from "lucide-react";
import Image from "next/image";
import { ProfileAvatar } from "../common/profile-avatar";
import ToastHelper from "@/components/common/ToastHelper";
import FormattedMessageContent from "./FormattedMessageContent";
import type { ClickableOption } from "@/services/chat/types";
import {
  copyFormattedText,
  htmlToPlainText,
  isHtmlContent,
  plainTextToHtml,
  sanitizeHtml,
} from "@/lib/utils/richText";
import ChatPrompts from "./ChatPrompts";

interface ChatBubbleProps {
  type: "user" | "bot";
  title?: string;
  content?: ReactNode;
  isLoading?: boolean;
  loadingText?: string;
  timestamp?: string;
  userName?: string;
  userPhotoUrl?: string | null;
  options?: string[];
  suggestedPrompts?: string[];
  clickableOptions?: ClickableOption[];
  onSuggestedPromptClick?: (prompt: string) => void;
  onClickableOptionClick?: (option: ClickableOption) => void;
  onRegenerate?: () => void;
  actionsDisabled?: boolean;
  onMessageFeedback?: (userChoice: boolean) => Promise<void>;
  messageId?: number;
  userChoice?: boolean | null;
  metrics?: {
    time: string;
    token: number;
    cost: string;
  };
}

export default function ChatBubble({
  type,
  title,
  content,
  isLoading,
  loadingText = "Thinking...",
  timestamp,
  userName = "Guest",
  userPhotoUrl,
  options,
  suggestedPrompts,
  clickableOptions,
  onSuggestedPromptClick,
  onClickableOptionClick,
  onRegenerate,
  actionsDisabled = false,
  onMessageFeedback,
  messageId,
  userChoice,
  metrics,
}: ChatBubbleProps) {
  const isBot = type === "bot";
  const [copied, setCopied] = useState(false);
  const [likeState, setLikeState] = useState<boolean | null>(
    userChoice ?? null,
  );
  const [likeLoading, setLikeLoading] = useState<"like" | "dislike" | null>(
    null,
  );

  const handleCopy = async () => {
    if (typeof content !== "string" && typeof content !== "number") {
      return;
    }

    const raw = String(content);
    const plain = isHtmlContent(raw) ? htmlToPlainText(raw) : raw;
    const html = isHtmlContent(raw) ? sanitizeHtml(raw) : plainTextToHtml(raw);

    try {
      await copyFormattedText({ text: plain, html });
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error("Copy failed:", err);
      try {
        await navigator.clipboard.writeText(plain);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      } catch {
        ToastHelper.showRespToast({
          status: false,
          message: "Failed to copy message.",
        });
      }
    }
  };

  const handleLike = async (value: boolean) => {
    if (likeLoading || !onMessageFeedback || messageId == null) return;
    setLikeLoading(value ? "like" : "dislike");
    try {
      await onMessageFeedback(value);
      setLikeState(value);
    } catch (err) {
      console.error("Like/dislike failed:", err);
      ToastHelper.showRespToast({
        status: false,
        message: "Failed to submit your feedback. Please try again.",
      });
    } finally {
      setLikeLoading(null);
    }
  };

  const handleRegenerate = () => {
    onRegenerate?.();
  };

  return (
    <div
      className={`flex w-full ${isBot ? "justify-start" : "justify-end"} items-end gap-1 mb-4`}>
      {isBot && (
        <div className="w-8 h-8 rounded-full bg-[#ffeded] flex items-center justify-center flex-shrink-0 shadow-sm z-10 mb-1">
          <Bot className="w-4 h-4 text-[#ef4444]" />
        </div>
      )}

      <div className="relative flex max-w-[75%] md:max-w-[60%] drop-shadow-[0_2px_8px_rgba(0,0,0,0.04)]">
        {isBot && (
          <svg
            width="20"
            height="20"
            viewBox="0 0 28 28"
            className="absolute bottom-0 -left-[16px] fill-white">
            <path d="M28 0 C28 14 14 28 0 28 L28 28 Z" />
          </svg>
        )}

        <div
          className={`
          bg-white p-3 md:p-4 w-full z-10
          ${isBot ? "rounded-[16px] rounded-bl-none" : "rounded-[16px] rounded-br-none"}
        `}>
          {isLoading && isBot ? (
            <div className="flex items-center gap-2 text-gray-500 text-sm">
              <Image
                src="/assets/thinking.svg"
                alt="Loading..."
                width={20}
                height={20}
              />
              <span className="animate-pulse">{loadingText}</span>
            </div>
          ) : (
            <div className="flex flex-col w-full">
              {!isBot && (
                <>
                  {title && (
                    <h2 className="text-[16px] md:text-[18px] font-semibold text-[#475569] mb-2">
                      {title}
                    </h2>
                  )}
                  {content &&
                    (typeof content === "string" ||
                    typeof content === "number" ? (
                      <FormattedMessageContent
                        content={String(content)}
                        className="text-[#475569] mb-2"
                      />
                    ) : (
                      <div className="text-[14px] md:text-[15px] text-[#475569] mb-2">
                        {content}
                      </div>
                    ))}
                  <hr className="border-t border-gray-100 my-2" />
                  <div className="flex items-center gap-2 text-[11px] text-[#8b95a5] font-medium">
                    <span>{timestamp}</span>
                    <span className="text-gray-200">|</span>
                    <span>{userName}</span>
                  </div>
                </>
              )}

              {isBot && (
                <>
                  {typeof content === "string" ||
                  typeof content === "number" ? (
                    <div className="overflow-x-auto">
                      <FormattedMessageContent content={String(content)} />
                    </div>
                  ) : (
                    content && (
                      <div className="mb-3 overflow-x-auto">{content}</div>
                    )
                  )}

                  {clickableOptions && clickableOptions.length > 0 && (
                    <ChatPrompts
                      options={clickableOptions}
                      onOptionClick={(option) =>
                        onClickableOptionClick?.(option)
                      }
                      disabled={actionsDisabled}
                      className="mt-3 mb-3"
                    />
                  )}

                  {suggestedPrompts && suggestedPrompts.length > 0 && (
                    <div className="flex flex-col gap-2 mb-3">
                      {suggestedPrompts.map((prompt) => (
                        <button
                          key={prompt}
                          type="button"
                          onClick={() => onSuggestedPromptClick?.(prompt)}
                          className="px-3 py-1.5 border border-gray-200 rounded-2xl text-[12px] font-medium text-[#475569] bg-white hover:bg-gray-50 transition-colors shadow-sm w-max">
                          {prompt}
                        </button>
                      ))}
                    </div>
                  )}

                  {options && options.length > 0 && (
                    <div className="flex flex-col gap-2 mb-3">
                      {options.map((opt, idx) => (
                        <button
                          key={idx}
                          type="button"
                          className="px-4 py-1.5 border border-gray-200 rounded-full text-[13px] font-medium text-[#475569] w-max hover:bg-gray-50 transition-colors shadow-sm">
                          {opt}
                        </button>
                      ))}
                    </div>
                  )}

                  <hr className="border-t border-gray-100 my-3" />

                  <div className="w-full flex flex-wrap items-center justify-between gap-2 text-[11px] text-[#8b95a5] font-medium">
                    {!isLoading && (
                      <div className="flex items-center">
                        <button
                          type="button"
                          onClick={handleCopy}
                          title={copied ? "Copied!" : "Copy"}
                          className="flex items-center gap-1 px-2 py-1 rounded-md text-[11px] text-gray-400 hover:text-gray-700 hover:bg-gray-100 transition-colors">
                          {copied ? (
                            <Check className="w-3.5 h-3.5 text-green-500" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                          <span>{copied ? "Copied" : "Copy"}</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => handleLike(true)}
                          title="Like"
                          disabled={likeLoading !== null}
                          className={`flex items-center gap-1 px-2 py-1 rounded-md text-[11px] transition-colors hover:bg-gray-100 disabled:cursor-not-allowed ${likeState === true ? "text-green-600" : "text-gray-400 hover:text-green-600"}`}>
                          {likeLoading === "like" ? (
                            <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          ) : (
                            <ThumbsUp className="w-3.5 h-3.5" />
                          )}
                        </button>
                        <button
                          type="button"
                          onClick={() => handleLike(false)}
                          title="Dislike"
                          disabled={likeLoading !== null}
                          className={`flex items-center gap-1 px-2 py-1 rounded-md text-[11px] transition-colors hover:bg-gray-100 disabled:cursor-not-allowed ${likeState === false ? "text-red-500" : "text-gray-400 hover:text-red-500"}`}>
                          {likeLoading === "dislike" ? (
                            <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          ) : (
                            <ThumbsDown className="w-3.5 h-3.5" />
                          )}
                        </button>
                        <button
                          type="button"
                          onClick={handleRegenerate}
                          title="Regenerate"
                          disabled={actionsDisabled}
                          className="flex items-center gap-1 px-2 py-1 rounded-md text-[11px] text-gray-400 hover:text-blue-500 hover:bg-gray-100 transition-colors disabled:cursor-not-allowed disabled:opacity-50 disabled:hover:text-gray-400 disabled:hover:bg-transparent">
                          <RefreshCw className="w-3.5 h-3.5" />
                          <span>Regenerate</span>
                        </button>
                      </div>
                    )}
                    <div className="flex w-full justify-between gap-1">
                      <div className="flex gap-2">
                        {timestamp && <span>{timestamp}</span>}

                        {metrics?.time && (
                          <span>
                            Processing Time:{" "}
                            <strong className="text-[#0f172a]">
                              {metrics.time}
                            </strong>
                          </span>
                        )}
                      </div>
                      <div className="flex gap-1">
                        {typeof metrics?.token === "number" && (
                          <span className="border border-gray-200/80 rounded-full px-2 py-0.5">
                            Token:{" "}
                            <strong className="text-[#0f172a]">
                              {metrics.token}
                            </strong>
                          </span>
                        )}

                        {metrics?.cost && (
                          <span className="border border-gray-200/80 rounded-full px-2 py-0.5">
                            Cost:{" "}
                            <strong className="text-[#0f172a]">
                              {metrics.cost}
                            </strong>
                          </span>
                        )}

                        {(timestamp || metrics) && (
                          <button
                            type="button"
                            className="text-gray-400 hover:text-gray-600 transition-colors ml-1"
                            aria-label="Info">
                            <Info className="w-3 h-3" />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </>
              )}
            </div>
          )}
        </div>

        {!isBot && (
          <svg
            width="20"
            height="20"
            viewBox="0 0 28 28"
            className="absolute bottom-0 -right-[16px] fill-white">
            <path d="M0 0 C0 14 14 28 28 28 L0 28 Z" />
          </svg>
        )}
      </div>

      {!isBot && !isLoading && (
        <ProfileAvatar
          displayName={userName}
          photoUrl={userPhotoUrl}
          className="size-8 flex-shrink-0 z-10 shadow-sm mb-1"
        />
      )}
    </div>
  );
}
