import React, { useRef, useState } from "react";
import ChatRichTextInput, {
  type ChatRichTextInputHandle,
  type RichTextSubmitPayload,
} from "./ChatRichTextInput";
import {
  Paperclip,
  ArrowRight,
  ChevronDown,
  ChevronUp,
  Search,
} from "lucide-react";
import ChatAttachmentChip from "./ChatAttachmentChip";
import ChatAttachmentMenu from "./ChatAttachmentMenu";
import {
  type AgentGroup,
} from "./agentsApiDataMappingHelper";

interface ChatInputProps {
  onFileUpload: (file: File) => void;
  onSendMessage?: (text: string, html?: string) => void;
  showAgentGroups?: boolean;
  onSuggestedPromptClick?: (prompt: string) => void;
  onAgentClick?: (
    promptKey: string,
    agentId: string,
    introMessage: string | null,
    agentName: string,
    agentWorkflowId?: string,
  ) => void;
  agentGroups?: AgentGroup[];
  isLoadingWorkflows?: boolean;
  disabled?: boolean;
  isAwaitingUpload?: boolean;
  showFileUpload?: boolean;
}

export default function ChatInput({
  onFileUpload,
  onSendMessage,
  showAgentGroups,
  onSuggestedPromptClick,
  onAgentClick,
  agentGroups = [],
  isLoadingWorkflows = false,
  disabled = false,
  isAwaitingUpload = false,
  showFileUpload = true,
}: ChatInputProps) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [attachedFile, setAttachedFile] = useState<File | null>(null);
  const [expandedGroups, setExpandedGroups] = useState<Record<string, boolean>>(
    {},
  );
  const [agentSearchQueries, setAgentSearchQueries] = useState<
    Record<string, string>
  >({});
  const fileInputRef = useRef<HTMLInputElement>(null);
  const richInputRef = useRef<ChatRichTextInputHandle>(null);
  const visibleAttachedFile = showFileUpload ? attachedFile : null;

  const toggleGroup = (groupId: string) => {
    setExpandedGroups((prev) => ({
      [groupId]: !prev[groupId],
    }));
  };

  const handlePaperclipClick = () => {
    if (!showFileUpload) return;
    setMenuOpen((prev) => !prev);
  };

  const handleAttachFile = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) setAttachedFile(file);
    e.target.value = "";
  };

  const handleRemoveFile = () => {
    setAttachedFile(null);
  };

  const sendRichText = ({ html, plainText }: RichTextSubmitPayload) => {
    if (disabled) return;
    onSendMessage?.(plainText, html);
  };

  const handleUploadFile = () => {
    if (disabled) return;
    if (showFileUpload && visibleAttachedFile) {
      onFileUpload(visibleAttachedFile);
      setAttachedFile(null);
      return;
    }
    const payload = richInputRef.current?.submit();
    if (payload) {
      sendRichText(payload);
    }
  };

  return (
    <div className="w-full  mx-auto p-4">
      {/* Agent Groups */}
      {showAgentGroups && (
        <div className="mb-4">
          {isLoadingWorkflows ? (
            <p className="text-sm text-gray-500 px-1 py-1">
              Loading workflows...
            </p>
          ) : (
            <>
              {/* Group headers */}
              <div className="flex flex-row flex-wrap gap-2">
                {agentGroups.map((group) => {
                  const GroupIcon = group.icon;
                  const isExpanded = !!expandedGroups[group.id];

                  const handleGroupClick = () => {
                    if (group.agents.length === 0 && group.promptKey) {
                      onSuggestedPromptClick?.(group.promptKey);
                    } else {
                      toggleGroup(group.id);
                    }
                  };

                  return (
                    <button
                      key={group.id}
                      onClick={handleGroupClick}
                      className="flex items-center gap-2 px-3 py-2 rounded-xl border border-gray-200 bg-white hover:bg-gray-50 hover:shadow-sm transition-all">
                      <div
                        className={`p-1 rounded-lg shrink-0 ${group.iconBg}`}>
                        <GroupIcon className="w-3.5 h-3.5 shrink-0" />
                      </div>
                      <span className="text-sm font-semibold text-gray-800">
                        {group.name}
                      </span>
                      {group.agents.length > 0 &&
                        (isExpanded ? (
                          <ChevronUp className="w-3.5 h-3.5 text-gray-400" />
                        ) : (
                          <ChevronDown className="w-3.5 h-3.5 text-gray-400" />
                        ))}
                    </button>
                  );
                })}
              </div>

              {/* Expanded agents */}
              {agentGroups.map((group) => {
                const isExpanded = !!expandedGroups[group.id];
                const searchQuery = agentSearchQueries[group.id] ?? "";
                const filteredAgents = group.agents.filter((a) =>
                  a.name.toLowerCase().includes(searchQuery.toLowerCase()),
                );
                return (
                  <div
                    key={group.id}
                    className={`overflow-hidden transition-all duration-300 ease-in-out ${
                      isExpanded && group.agents.length > 0
                        ? "max-h-64 opacity-100 mt-2"
                        : "max-h-0 opacity-0"
                    }`}>
                    <div className="rounded-xl border border-gray-100 bg-white shadow-xs p-2 flex flex-col gap-2">
                      {/* Search */}
                      {group.agents.length > 1 && (
                        <div className="relative">
                          <Search className="w-3.5 h-3.5 text-gray-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                          <input
                            type="text"
                            placeholder="Search agent..."
                            value={searchQuery}
                            onChange={(e) =>
                              setAgentSearchQueries((prev) => ({
                                ...prev,
                                [group.id]: e.target.value,
                              }))
                            }
                            className="w-full max-w-70 text-xs pl-7 pr-3 py-1.5 border border-gray-200 rounded-lg focus:outline-none focus:border-blue-400 text-gray-700 placeholder-gray-400"
                          />
                        </div>
                      )}
                      {/* Agents */}
                      <ul className="flex flex-wrap gap-1.5">
                        {filteredAgents.map((agent) => {
                          const AgentIcon = agent.icon;
                          return (
                            <li key={agent.id}>
                              <button
                                onClick={() => {
                                  if (!agent.promptKey) return;
                                  onAgentClick?.(
                                    agent.promptKey,
                                    group.id,
                                    agent.introMessage,
                                    agent.name,
                                    agent.id,
                                  );
                                }}
                                disabled={!agent.promptKey}
                                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border transition-colors text-sm ${
                                  agent.promptKey
                                    ? "border-gray-200 hover:border-indigo-300 hover:bg-indigo-50 cursor-pointer text-gray-700"
                                    : "border-gray-100 cursor-default text-gray-400"
                                }`}>
                                <AgentIcon
                                  className={`w-3.5 h-3.5 shrink-0 flex-none ${agent.iconColor}`}
                                />
                                <span className="font-medium">
                                  {agent.name}
                                </span>
                              </button>
                            </li>
                          );
                        })}
                        {filteredAgents.length === 0 && (
                          <li className="text-xs text-gray-400 px-2 py-1">
                            No agents found
                          </li>
                        )}
                      </ul>
                    </div>
                  </div>
                );
              })}
            </>
          )}
        </div>
      )}

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-2 flex flex-col gap-2">
        {showFileUpload && (
          <input
            ref={fileInputRef}
            type="file"
            accept=".mp4,.mov"
            className="hidden"
            onChange={handleFileChange}
          />
        )}
        <div className="flex flex-col gap-2 p-2">
          {visibleAttachedFile && (
            <ChatAttachmentChip
              fileName={visibleAttachedFile.name}
              onRemove={handleRemoveFile}
            />
          )}

          <ChatRichTextInput
            ref={richInputRef}
            onEnterSubmit={sendRichText}
            disabled={disabled || isAwaitingUpload}
            placeholder="Ask about Project, generate specifications, or ask me a task..."
          />
          <div
            className={`flex items-center gap-2 relative ${showFileUpload ? "justify-between" : "justify-end"}`}>
            {showFileUpload && (
              <>
                <button
                  onClick={handlePaperclipClick}
                  disabled={disabled}
                  className="p-2 bg-gray-100 hover:bg-gray-200 rounded-full transition-colors text-gray-500 disabled:cursor-not-allowed disabled:opacity-50 disabled:hover:bg-gray-100"
                  aria-label="Attach file">
                  <Paperclip className="w-5 h-5" />
                </button>

                {showFileUpload && menuOpen && (
                  <ChatAttachmentMenu
                    onAttachFile={handleAttachFile}
                    onClose={() => setMenuOpen(false)}
                  />
                )}
              </>
            )}

            <button
              onClick={handleUploadFile}
              disabled={disabled}
              className="px-5 py-2.5 bg-linear-to-r from-rose-400 to-indigo-500 text-white rounded-full shadow-md hover:opacity-90 transition-opacity flex items-center justify-end disabled:cursor-not-allowed disabled:opacity-50 disabled:hover:opacity-50">
              <ArrowRight className="w-10 h-5" />
            </button>
          </div>
        </div>

        {/* <div className="flex items-center gap-1 px-3 pb-1 text-xs text-gray-400">
          <Info className="w-3 h-3" />
          <span>file type: Pdf, Doc, Xls</span>
        </div> */}
      </div>
    </div>
  );
}
