import { Paperclip, CalendarDays, Link2, Globe } from "lucide-react";

interface ChatAttachmentMenuProps {
  onAttachFile: () => void;
  onClose: () => void;
}

export default function ChatAttachmentMenu({
  onAttachFile,
  onClose,
}: ChatAttachmentMenuProps) {
  const menuItems = [
    {
      icon: <Paperclip className="w-5 h-5 text-gray-500" />,
      label: "Supported formats: MP4, MOV (max. 1GB)",
      onClick: () => {
        onAttachFile();
        onClose();
      },
    },
    // {
    //   icon: <CalendarDays className="w-5 h-5 text-gray-500" />,
    //   label: "Calendar event",
    //   onClick: onClose,
    // },
    // {
    //   icon: <Link2 className="w-5 h-5 text-gray-500" />,
    //   label: "Link or URL",
    //   onClick: onClose,
    // },
    // {
    //   icon: <Globe className="w-5 h-5 text-gray-500" />,
    //   label: "Web Search",
    //   onClick: onClose,
    // },
  ];

  return (
    <>
      <div className="fixed inset-0 z-10" onClick={onClose} />
      <div className="absolute bottom-full left-0 mb-2 z-20 bg-white rounded-2xl shadow-lg border border-gray-100 py-2 min-w-55">
        {menuItems.map((item, idx) => (
          <button
            key={idx}
            onClick={item.onClick}
            className="w-full flex items-center gap-3 px-4 py-3 hover:bg-gray-50 transition-colors text-left"
          >
            {item.icon}
            <span className="text-sm text-gray-700 font-medium">
              {item.label}
            </span>
          </button>
        ))}
      </div>
    </>
  );
}
