"use client";

import { forwardRef, useEffect, useImperativeHandle, useState } from "react";
import { useEditor, EditorContent, type Editor } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import Underline from "@tiptap/extension-underline";
import Link from "@tiptap/extension-link";

export type RichTextSubmitPayload = { html: string; plainText: string };

export interface ChatRichTextInputHandle {
  submit: () => RichTextSubmitPayload | null;
  isEmpty: () => boolean;
}

interface ChatRichTextInputProps {
  placeholder?: string;
  className?: string;
  disabled?: boolean;
  onEnterSubmit?: (payload: RichTextSubmitPayload) => void;
}

const ChatRichTextInput = forwardRef<
  ChatRichTextInputHandle,
  ChatRichTextInputProps
>(function ChatRichTextInput(
  {
    placeholder = "Ask about Project, generate specifications, or ask me a task...",
    className = "",
    disabled = false,
    onEnterSubmit,
  },
  ref,
) {
  const [isEmpty, setIsEmpty] = useState(true);

  const editor = useEditor(
    {
      extensions: [
        StarterKit,
        Underline,
        Link.configure({ openOnClick: false }),
      ],
      content: "",
      immediatelyRender: false,
      editorProps: {
        attributes: {
          class: `flex-1 min-h-[24px] max-h-40 overflow-y-auto outline-none text-gray-700 px-2 ${className}`,
        },
      },
      onUpdate: ({ editor: ed }: { editor: Editor }) => {
        setIsEmpty(!ed.getText().trim());
      },
    },
    [className],
  );

  useImperativeHandle(
    ref,
    () => ({
      submit: () => {
        if (!editor) return null;
        const plainText = editor.getText().trim();
        if (!plainText) return null;
        const html = editor.getHTML();
        editor.commands.clearContent(true);
        setIsEmpty(true);
        return { html, plainText };
      },
      isEmpty: () => !editor?.getText().trim(),
    }),
    [editor],
  );

  useEffect(() => {
    if (!editor) return;
    editor.setEditable(!disabled);
  }, [editor, disabled]);

  useEffect(() => {
    if (!editor || disabled) return;

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key !== "Enter" || event.shiftKey) return;

      event.preventDefault();
      const plainText = editor.getText().trim();
      if (!plainText) return;

      const payload = { html: editor.getHTML(), plainText };
      editor.commands.clearContent(true);
      setIsEmpty(true);
      onEnterSubmit?.(payload);
    };

    const dom = editor.view.dom;
    dom.addEventListener("keydown", handleKeyDown);
    return () => dom.removeEventListener("keydown", handleKeyDown);
  }, [editor, onEnterSubmit, disabled]);

  if (!editor) {
    return (
      <div className="flex-1 min-h-[24px] px-2 text-gray-400 text-sm">
        {placeholder}
      </div>
    );
  }

  return (
    <div
      className={`chat-rich-input relative flex-1 min-h-[24px] ${disabled ? "opacity-50 cursor-not-allowed" : ""}`}
    >
      {isEmpty && (
        <span
          className="pointer-events-none absolute left-2 top-0 z-0 text-sm text-gray-400 select-none"
          aria-hidden
        >
          {placeholder}
        </span>
      )}
      <div className="relative z-10 [&_.ProseMirror]:outline-none [&_.ProseMirror]:min-h-[24px] [&_.ProseMirror]:max-h-40 [&_.ProseMirror]:overflow-y-auto">
        <EditorContent editor={editor} />
      </div>
    </div>
  );
});

export default ChatRichTextInput;
