import { Download, Eye } from "lucide-react";
import { useChatStore } from "@/store/useChatStore";

interface FilePreviewProps {
  fileName: string;
}

const buttonLabels = ["Meeting Notes", "User Stories", "Action Items", "KDDs"];

export function FilePreview({ fileName }: FilePreviewProps) {
  const openRightPanel = useChatStore((s) => s.openRightPanel);

  return (
    <div className="flex flex-col gap-4">
      <p className="text-[16px] md:text-[18px] text-[#0f172a] font-medium">
        Here is the extracted meeting transcript.
      </p>

      <div className="rounded-xl border border-gray-200 overflow-hidden text-sm">
        {/* Filename row */}
        <div className="px-4 py-2.5">
          <p className="text-[#475569] font-medium truncate">{fileName}</p>
        </div>
        <hr className="border-gray-200" />
        <div className="flex items-center justify-between px-4 py-2">
          <button
            type="button"
            className="inline-flex items-center gap-2 text-[#1d4ed8] hover:text-[#0834ac] font-medium"
            onClick={openRightPanel}>
            Review transcript
            <Eye className="w-4 h-4" />
          </button>

          <button
            type="button"
            className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-red-50 text-red-500 hover:bg-red-100 transition-colors"
            aria-label="Download transcript">
            <Download className="w-4 h-4" />
          </button>
        </div>
      </div>

      <p className="text-sm text-[#0f172a] font-medium">
        Which artifacts you want to generate?
      </p>

      <div className="flex flex-wrap gap-2">
        {buttonLabels.map((label) => (
          <button
            key={label}
            type="button"
            className="rounded-full border border-gray-200 bg-white px-3 py-1.5 text-xs font-medium text-[#475569] hover:bg-gray-50 transition-colors">
            {label}
          </button>
        ))}
      </div>
    </div>
  );
}
