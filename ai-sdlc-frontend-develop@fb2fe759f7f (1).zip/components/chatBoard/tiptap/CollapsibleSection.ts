import {
  Node as TiptapNode,
  mergeAttributes,
  type NodeViewRendererProps,
} from "@tiptap/core";

export interface CollapsibleSectionOptions {
  HTMLAttributes: Record<string, unknown>;
}

/**
 * A custom Tiptap block node that renders an expandable/collapsible section
 * using native `<details>` / `<summary>` elements.
 *
 * Attributes:
 *   - `title` → text shown in the clickable summary header (stored as an
 *     attribute rather than editable content so it stays out of the document flow)
 *   - `open`  → whether the section starts expanded
 *
 * The section body accepts any block content (`block+`), so the label/value
 * paragraphs produced from an `expandable_document` render inside it.
 */
export const CollapsibleSection = TiptapNode.create<CollapsibleSectionOptions>({
  name: "collapsibleSection",
  group: "block",
  content: "block+",
  defining: true,

  addOptions() {
    return { HTMLAttributes: {} };
  },

  addAttributes() {
    return {
      title: {
        default: "",
        parseHTML: (element) =>
          element.querySelector(":scope > summary")?.textContent ?? "",
        // Rendered inside <summary>, not as an attribute on <details>.
        renderHTML: () => ({}),
      },
      open: {
        default: false,
        parseHTML: (element) => element.hasAttribute("open"),
        renderHTML: (attributes) => (attributes.open ? { open: "open" } : {}),
      },
    };
  },

  parseHTML() {
    return [{ tag: "details[data-collapsible-section]" }];
  },

  renderHTML({ node, HTMLAttributes }) {
    const title = String(node.attrs.title ?? "") || "Section";
    return [
      "details",
      mergeAttributes(this.options.HTMLAttributes, HTMLAttributes, {
        "data-collapsible-section": "",
        class: "collapsible-section",
      }),
      ["summary", { class: "collapsible-section__summary" }, title],
      ["div", { class: "collapsible-section__content" }, 0],
    ];
  },

  addNodeView() {
    const nodeName = this.name;

    return ({ node }: NodeViewRendererProps) => {
      const details = document.createElement("details");
      details.setAttribute("data-collapsible-section", "");
      details.className = "collapsible-section";
      if (node.attrs.open) {
        details.setAttribute("open", "");
      }

      const summary = document.createElement("summary");
      summary.className = "collapsible-section__summary";
      summary.textContent = String(node.attrs.title ?? "") || "Section";
      details.appendChild(summary);

      const content = document.createElement("div");
      content.className = "collapsible-section__content";
      details.appendChild(content);

      // Deterministic toggle that is decoupled from ProseMirror state so it
      // works reliably in the read-only preview editor.
      summary.addEventListener("click", (event) => {
        event.preventDefault();
        if (details.hasAttribute("open")) {
          details.removeAttribute("open");
        } else {
          details.setAttribute("open", "");
        }
      });

      return {
        dom: details,
        contentDOM: content,
        ignoreMutation: (
          mutation: MutationRecord | { type: "selection"; target: Node },
        ) => {
          // Ignore the `open` attribute toggling and any summary changes so the
          // editor does not try to re-render / reset the section on interaction.
          if (mutation.type === "attributes") {
            return true;
          }
          return summary.contains(mutation.target);
        },
        update: (updatedNode) => {
          if (updatedNode.type.name !== nodeName) {
            return false;
          }
          summary.textContent =
            String(updatedNode.attrs.title ?? "") || "Section";
          return true;
        },
      };
    };
  },
});

export default CollapsibleSection;
