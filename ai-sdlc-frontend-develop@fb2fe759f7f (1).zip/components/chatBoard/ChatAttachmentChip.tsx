import React from "react";
import { FileText, Trash } from "lucide-react";

interface ChatAttachmentChipProps {
  fileName: string;
  onRemove ? : () => void;
}

export default function ChatAttachmentChip({ fileName, onRemove }: ChatAttachmentChipProps) {
  return (
    <div className="flex items-center gap-2 bg-white border border-gray-200 rounded-xl px-3 py-2 w-fit max-w-[220px] shadow-sm">
      <FileText className="w-4 h-4 text-blue-500 flex-shrink-0" />
      <span className="text-sm text-gray-700 font-medium truncate">{fileName}</span>
      <button
        onClick={onRemove}
        className="text-red-400 hover:text-red-600 transition-colors flex-shrink-0 ml-1"
        aria-label="Remove file"
      >
        <Trash className="w-4 h-4" />
      </button>
    </div>
  );
}