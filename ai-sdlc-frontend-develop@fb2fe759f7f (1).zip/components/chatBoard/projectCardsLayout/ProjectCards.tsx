"use client";

import React from "react";
import { Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { Project } from "@/services/chat/types";

interface ProjectCardProps {
  project: Project;
  onSelect: (id: number) => void;
  selected?: boolean;
  isLoadingRoles?: boolean;
  style?: React.CSSProperties;
}

export function ProjectCards({
  project,
  onSelect,
  selected,
  isLoadingRoles,
  style,
}: ProjectCardProps) {
  const isThisCardLoading = selected && isLoadingRoles;

  const handleClick = () => {
    if (isLoadingRoles) return;
    onSelect(project.project_id);
  };

  return (
    <div
      className={cn(
        "bg-white rounded-2xl border p-5 card-hover animate-fade-in",
        isThisCardLoading
          ? "cursor-wait border-[#e8472a]/30 ring-1 ring-[#e8472a]/20"
          : isLoadingRoles
            ? "cursor-not-allowed opacity-60 border-[#eeeef2]"
            : selected
              ? "cursor-pointer border-[#e8472a]/30 ring-1 ring-[#e8472a]/20"
              : "cursor-pointer border-[#eeeef2] hover:border-[#ddd]",
      )}
      style={style}
      onClick={handleClick}>
      <h3 className="text-[14px] font-semibold text-foreground mb-1.5 leading-snug">
        {project.project_name}
      </h3>
      <p className="text-[12px] text-muted-foreground leading-relaxed mb-4 line-clamp-2">
        {project.project_description}
      </p>
      {isThisCardLoading && (
        <div className="flex items-center gap-1.5 text-[11px] text-[#e8472a]">
          <Loader2 className="w-3 h-3 animate-spin" />
          <span>Loading roles...</span>
        </div>
      )}
    </div>
  );
}
