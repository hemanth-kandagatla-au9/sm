"use client";

import React, { useState, useMemo, useEffect } from "react";
import type { ProjectRole } from "@/services/chat/types";

interface RoleSelectionPopupProps {
  isOpen: boolean;
  onClose: () => void;
  onContinue: (selectedRole: ProjectRole) => void;
  roles: ProjectRole[];
  isLoadingRoles?: boolean;
}

export function RoleSelectionPopup({
  isOpen,
  onClose,
  onContinue,
  roles,
  isLoadingRoles,
}: RoleSelectionPopupProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedRole, setSelectedRole] = useState<ProjectRole | null>(null);

  const filteredRoles = useMemo(() => {
    return roles.filter((role) =>
      role.role_name.toLowerCase().includes(searchQuery.toLowerCase()),
    );
  }, [searchQuery, roles]);

  // Auto-select if only one role is available
  useEffect(() => {
    if (isOpen && roles.length === 1) {
      onContinue(roles[0]);
    }
  }, [isOpen, roles, onContinue]);

  const handleContinue = () => {
    if (selectedRole) {
      onContinue(selectedRole);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30 backdrop-blur-sm p-4">
      <div
        className="bg-white w-full max-w-md rounded-2xl shadow-xl flex flex-col"
        onClick={(e) => e.stopPropagation()}>
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-gray-100">
          <h2 className="text-lg font-semibold text-gray-800">
            Please select role to proceed
          </h2>
          <button
            onClick={onClose}
            className="p-1 rounded-full hover:bg-gray-100 transition-colors">
            <svg
              width="20"
              height="20"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="text-gray-500">
              <path d="M18 6 6 18" />
              <path d="m6 6 12 12" />
            </svg>
          </button>
        </div>

        {/* Content */}
        <div className="px-6 py-4 flex-1 flex flex-col min-h-0">
          {/* Search Bar */}
          <div className="relative mb-4">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <svg
                width="18"
                height="18"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="text-gray-400">
                <circle cx="11" cy="11" r="8" />
                <path d="m21 21-4.3-4.3" />
              </svg>
            </div>
            <input
              type="text"
              placeholder="Search Role"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 bg-white border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-gray-100 focus:border-gray-300 transition-all placeholder:text-gray-400"
            />
          </div>

          {/* Roles List */}
          <div className="overflow-y-auto max-h-[350px] pr-2 -mr-2 space-y-1">
            {isLoadingRoles ? (
              <p className="text-sm text-gray-500 text-center py-4">
                Loading roles...
              </p>
            ) : (
              <>
                {filteredRoles.map((role) => (
                  <label
                    key={role.project_role_id}
                    className="flex items-center space-x-3 px-2 py-2.5 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors">
                    <input
                      type="radio"
                      name="roleSelection"
                      value={role.ad_group_name}
                      checked={
                        selectedRole?.project_role_id === role.project_role_id
                      }
                      onChange={() => setSelectedRole(role)}
                      className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500 accent-[#eb1700]"
                    />
                    <span className="text-sm font-medium text-gray-700">
                      {role.role_name}
                    </span>
                  </label>
                ))}
                {filteredRoles.length === 0 && (
                  <p className="text-sm text-gray-500 text-center py-4">
                    No roles found.
                  </p>
                )}
              </>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 flex justify-end">
          <button
            onClick={handleContinue}
            disabled={!selectedRole}
            className="flex items-center space-x-2 bg-[#f45b5b] hover:bg-[#eb1700] disabled:opacity-50 disabled:hover:bg-[#f45b5b] text-white px-5 py-2.5 rounded-lg text-sm font-medium transition-colors">
            <span>Continue</span>
            <svg
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round">
              <path d="M5 12h14" />
              <path d="m12 5 7 7-7 7" />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
}
