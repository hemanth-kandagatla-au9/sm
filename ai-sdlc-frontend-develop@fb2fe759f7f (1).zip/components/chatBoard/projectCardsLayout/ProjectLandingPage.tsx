"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { ProjectCards } from "@/components/chatBoard/projectCardsLayout/ProjectCards";
import { Project, ProjectRole } from "@/services/chat/types";
import CardSkeleton from "@/components/common/cardSkeleton";
import axiosInstance from "@/lib/api/axiosInstance";
import ToastHelper from "@/components/common/ToastHelper";
import { RoleSelectionPopup } from "./RoleSelectionPopup";
import { useChatStore } from "@/store/useChatStore";
import { Search } from "lucide-react";

export function ProjectLandingPage() {
  const router = useRouter();
  const [projects, setProjects] = useState<Project[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  // Role modal state
  const [isRoleModalOpen, setIsRoleModalOpen] = useState(false);
  const [projectRoles, setProjectRolesLocal] = useState<ProjectRole[]>([]);
  const [isLoadingRoles, setIsLoadingRoles] = useState(false);

  // Zustand actions
  const setSelectedProjectId = useChatStore((s) => s.setSelectedProjectId);
  const setStoreProjectRoles = useChatStore((s) => s.setProjectRoles);
  const setSelectedProjectRole = useChatStore((s) => s.setSelectedProjectRole);
  const persistedProjectId = useChatStore((s) => s.selectedProjectId);

  // Initialize selectedId from persisted store value
  const [selectedId, setSelectedId] = useState<number | undefined>(
    persistedProjectId ?? undefined,
  );

  useEffect(() => {
    const fetchProjects = async () => {
      setIsLoading(true);
      try {
        const response = await axiosInstance.get("/sdlc/projects/accessible");
        setProjects(response.data.data ?? []);
      } catch {
        ToastHelper.showRespToast({
          status: false,
          message: "Failed to load Project List. Please try again.",
        });
        setProjects([]);
      } finally {
        setIsLoading(false);
      }
    };
    fetchProjects();
  }, []);

  const handleRoleContinue = (role: ProjectRole) => {
    setSelectedProjectRole(role);
    setIsRoleModalOpen(false);
    if (selectedId) {
      router.push(`/messages/${selectedId}`);
    }
  };

  const handleProjectSelect = async (id: number) => {
    setSelectedId(id);
    setSelectedProjectId(id);
    setIsLoadingRoles(true);
    setProjectRolesLocal([]);

    try {
      const response = await axiosInstance.get(
        `/sdlc/projects/${id}/roles/mine`,
      );
      const roles: ProjectRole[] = response.data.data ?? [];
      setProjectRolesLocal(roles);
      setStoreProjectRoles(roles);

      if (roles.length === 0) {
        ToastHelper.showRespToast({
          status: false,
          message: "You have no role assignments in this project.",
        });
      } else if (roles.length === 1) {
        handleRoleContinue(roles[0]);
      } else {
        setIsRoleModalOpen(true);
      }
    } catch {
      ToastHelper.showRespToast({
        status: false,
        message: "Failed to load roles. Please try again.",
      });
    } finally {
      setIsLoadingRoles(false);
    }
  };

  const normalizedSearchTerm = searchTerm.trim().toLowerCase();
  const filteredProjects = projects.filter((project) =>
    project.project_name.toLowerCase().includes(normalizedSearchTerm),
  );

  return (
    <div className="flex flex-col max-h-[calc(100vh-100px)] w-full bg-[#f7f7fa]">
      <div className="flex-1 overflow-y-auto px-6 py-5">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <h1 style={{ fontSize: "1.4rem", color: "#5c534c", fontWeight: "500", fontFamily: "var(--app-font-display)" }}>
            All Projects
            {!isLoading && (
              <span className="ml-2 text-[#EB1700]">({filteredProjects.length})</span>
            )}
          </h1>
          <div className="relative w-full sm:w-50">
            <Search
              size={16}
              className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-[#8d8d99]"
            />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by project name"
              className="h-10 w-full rounded-xl border border-[#d7d7e0] bg-white pl-9 pr-3 text-[14px] text-foreground outline-none transition-colors focus:border-[#b9b9c7]"
            />
          </div>
        </div>
        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-5 gap-4 mt-4">
            {Array.from({ length: 5 }).map((_, index) => (
              <CardSkeleton key={index} />
            ))}
          </div>
        ) : filteredProjects.length === 0 ? (
          <div className="flex min-h-[calc(100vh-400px)] flex-col items-center justify-center text-center">
            <div className="w-12 h-12 rounded-2xl bg-[#f0f0f5] flex items-center justify-center mb-3"></div>
            <p className="flex items-center justify-center text-[28px] text-[#eb1700]">
              {projects.length === 0
                ? "No projects found"
                : "No matching projects found"}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-5 gap-4 mt-4">
            {filteredProjects.map((project, i) => (
              <ProjectCards
                key={project.project_id}
                project={project}
                selected={selectedId === project.project_id}
                isLoadingRoles={isLoadingRoles}
                onSelect={handleProjectSelect}
                style={{ animationDelay: `${i * 80}ms` }}
              />
            ))}
          </div>
        )}
      </div>

      {/* Role Selection Modal */}
      <RoleSelectionPopup
        isOpen={isRoleModalOpen}
        onClose={() => setIsRoleModalOpen(false)}
        onContinue={handleRoleContinue}
        roles={projectRoles}
        isLoadingRoles={isLoadingRoles}
      />
    </div>
  );
}
