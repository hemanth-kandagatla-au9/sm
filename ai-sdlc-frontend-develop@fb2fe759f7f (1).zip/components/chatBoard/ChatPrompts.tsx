import { Button, Tooltip } from "@mui/material";
import type { ClickableOption } from "@/services/chat/types";

const PROMPT_BUTTON_WIDTH = 120;

interface ChatPromptsProps {
  options: ClickableOption[];
  onOptionClick: (option: ClickableOption) => void;
  className?: string;
  disabled?: boolean;
}

const chatPromptSx = {
  background: "#fff",
  border: "1px solid #F72812",
  color: "#1f2937",
  padding: "6px 12px",
  textTransform: "none",
  fontWeight: 500,
  fontSize: "13px",
  borderRadius: "8px",
  "&:hover": {
    background: "#FAE7CB",
    color: "#F72812",
    border: "1px solid #F72812",
  },
};

export default function ChatPrompts({
  options,
  onOptionClick,
  className = "",
  disabled = false,
}: ChatPromptsProps) {
  if (!options.length) return null;

  return (
    <div className={`flex flex-wrap gap-2 ${className}`}>
      {options.map((option) => (
        <Tooltip key={option.value} title={option.label} arrow>
          <Button
            type="button"
            disabled={disabled}
            onClick={() => onOptionClick(option)}
            sx={{
              ...chatPromptSx,
              width: PROMPT_BUTTON_WIDTH,
              minWidth: PROMPT_BUTTON_WIDTH,
              maxWidth: PROMPT_BUTTON_WIDTH,
            }}
          >
            <span className="block w-full truncate">{option.label}</span>
          </Button>
        </Tooltip>
      ))}
    </div>
  );
}
