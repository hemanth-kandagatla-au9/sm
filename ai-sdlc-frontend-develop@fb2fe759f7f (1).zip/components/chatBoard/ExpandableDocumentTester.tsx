"use client";

import React, { useCallback, useEffect, useState } from "react";
import dynamic from "next/dynamic";
import { useChatStore } from "@/store/useChatStore";
import {
  resolveExpandableDocument,
  resolveFlatDocument,
  sampleExpandablePayload,
  type ExpandableDocumentPayload,
} from "@/services/chat/expandableDocument";

// The editor relies on the browser, so load it client-side only.
const TiptapEditor = dynamic(
  () => import("@/components/chatBoard/TiptapEditor"),
  { ssr: false },
);

type PreviewMode = "expandable" | "flat";

/**
 * Standalone harness to preview how an `expandable_document` payload renders
 * inside the real Tiptap editor (the same component used in the chat right
 * panel). Paste any agent JSON on the left and hit "Render".
 */
export default function ExpandableDocumentTester() {
  const setTiptapDocument = useChatStore((s) => s.setTiptapDocument);

  const [jsonText, setJsonText] = useState(() =>
    JSON.stringify(sampleExpandablePayload, null, 2),
  );
  const [mode, setMode] = useState<PreviewMode>("expandable");
  const [error, setError] = useState<string | null>(null);

  const render = useCallback(
    (nextMode: PreviewMode = mode) => {
      try {
        const parsed = JSON.parse(jsonText) as
          | ExpandableDocumentPayload
          | unknown;

        if (nextMode === "flat") {
          const doc = resolveFlatDocument(parsed);
          if (!doc) {
            setError(
              "No `document` or `expandable_document` found to build a flat view.",
            );
            return;
          }
          setTiptapDocument(doc as unknown as Record<string, unknown>);
          setError(null);
          return;
        }

        const content = resolveExpandableDocument(parsed);
        if (!content) {
          setError(
            "No `expandable_document` array found in the JSON (or it is empty).",
          );
          return;
        }
        setTiptapDocument(content as unknown as Record<string, unknown>);
        setError(null);
      } catch (e) {
        setError(e instanceof Error ? e.message : "Invalid JSON.");
      }
    },
    [jsonText, mode, setTiptapDocument],
  );

  // Render the sample once on mount.
  useEffect(() => {
    render("expandable");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleModeChange = (nextMode: PreviewMode) => {
    setMode(nextMode);
    render(nextMode);
  };

  const loadSample = () => {
    setJsonText(JSON.stringify(sampleExpandablePayload, null, 2));
  };

  return (
    <div className="flex h-screen w-full flex-col gap-4 bg-[#F2F5F8] p-4">
      <div>
        <h1 className="text-xl font-semibold text-[#312c2a]">
          Expandable Document Tester
        </h1>
        <p className="text-sm text-gray-500">
          Paste an agent response (or a bare <code>expandable_document</code>{" "}
          array) and preview how it renders in the Tiptap editor.
        </p>
      </div>

      <div className="flex min-h-0 flex-1 gap-4">
        {/* Left: JSON input & controls */}
        <div className="flex w-1/2 min-w-[320px] flex-col gap-3">
          <div className="flex flex-wrap items-center gap-2">
            <div className="inline-flex overflow-hidden rounded-md border border-gray-300 bg-white">
              <button
                type="button"
                onClick={() => handleModeChange("expandable")}
                className={`px-3 py-1.5 text-sm transition-colors ${
                  mode === "expandable"
                    ? "bg-[#eb1700] text-white"
                    : "text-gray-600 hover:bg-gray-50"
                }`}>
                Expandable
              </button>
              <button
                type="button"
                onClick={() => handleModeChange("flat")}
                className={`px-3 py-1.5 text-sm transition-colors ${
                  mode === "flat"
                    ? "bg-[#eb1700] text-white"
                    : "text-gray-600 hover:bg-gray-50"
                }`}>
                Flat document
              </button>
            </div>

            <button
              type="button"
              onClick={() => render()}
              className="rounded-md bg-[#312c2a] px-4 py-1.5 text-sm text-white transition-colors hover:bg-black">
              Render
            </button>
            <button
              type="button"
              onClick={loadSample}
              className="rounded-md border border-gray-300 bg-white px-3 py-1.5 text-sm text-gray-600 transition-colors hover:bg-gray-50">
              Reset sample
            </button>
          </div>

          {error && (
            <p className="rounded-md bg-red-50 px-3 py-2 text-sm text-red-600">
              {error}
            </p>
          )}

          <textarea
            value={jsonText}
            onChange={(e) => setJsonText(e.target.value)}
            spellCheck={false}
            className="min-h-0 flex-1 resize-none rounded-lg border border-gray-200 bg-white p-3 font-mono text-xs leading-relaxed text-gray-800 shadow-sm focus:border-gray-400 focus:outline-none"
          />
        </div>

        {/* Right: live Tiptap preview */}
        <div className="w-1/2 min-w-[320px] overflow-y-auto rounded-lg">
          <TiptapEditor />
        </div>
      </div>
    </div>
  );
}
