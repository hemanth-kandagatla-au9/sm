"use client";

import React from "react";
import { ChatWidget } from "@/components/chat";
import ChatRightPanel from "./ChatRightPanel";
import { getLoggedInUser } from "@/lib/auth/user-helper";
import { useUserProfilePhoto } from "@/lib/auth/user-profile-context";
import { useChatStore } from "@/store/useChatStore";

interface ChatLayoutProps {
  workflowId?: string;
  projectId?: string;
  projectName?: string;
}

export default function ChatLayout({
  workflowId,
  projectId,
  projectName,
}: ChatLayoutProps) {
  const {
    isSidebarOpen,
    toggleSidebar,
    isRightPanelOpen,
    toggleRightPanel,
    tiptapDocument,
  } = useChatStore();

  const user = getLoggedInUser();
  const userPhotoUrl = useUserProfilePhoto();

  // Show the expand button only when the Tiptap editor actually has content.
  const hasTiptapContent = React.useMemo(() => {
    if (!tiptapDocument) return false;
    if (typeof tiptapDocument === "string") {
      return tiptapDocument.trim().length > 0;
    }
    return Object.keys(tiptapDocument).length > 0;
  }, [tiptapDocument]);

  return (
    <div className="flex h-[calc(100vh-100px)] w-full bg-white overflow-hidden font-sans relative">
      <ChatWidget
        projectId={projectId}
        workflowId={workflowId}
        projectName={projectName}
        userName={user?.name || "Guest"}
        userPhotoUrl={userPhotoUrl}
        showSidebar
        isSidebarOpen={isSidebarOpen}
        onToggleSidebar={toggleSidebar}
        panelSlot={
          <>
            {isRightPanelOpen && (
              <button
                className="absolute top-6 right-0 z-50 bg-white border border-gray-200 rounded-full shadow p-1.5 flex items-center justify-center hover:bg-gray-50 transition-colors"
                onClick={toggleRightPanel}
                aria-label="Close right panel">
                <span className="text-gray-500 text-xs">›</span>
              </button>
            )}
            {!isRightPanelOpen && hasTiptapContent && (
              <button
                className="absolute top-6 right-0 z-50 bg-white border border-gray-200 rounded-full shadow p-1.5 flex items-center justify-center hover:bg-gray-50 transition-colors"
                onClick={toggleRightPanel}
                aria-label="Expand right panel">
                <span className="text-gray-500 text-xs">‹</span>
              </button>
            )}
            <ChatRightPanel
              isOpen={isRightPanelOpen}
              toggle={toggleRightPanel}
            />
          </>
        }
      />
    </div>
  );
}
