import React, { useState } from "react";
import type { Conversation } from "@/services/chat/types";
import {
  ChevronsLeft,
  Search,
  ChevronDown,
  ChevronUp,
  ChevronsRight,
} from "lucide-react";
import { formatConversationDate } from "@/lib/utils";
import {
  filterAgentGroupsByGlobalQuery,
  type AgentGroup,
} from "./agentsApiDataMappingHelper";
import { Skeleton } from "@mui/material";

interface ChatSideBarProps {
  isOpen: boolean;
  toggleChatSidebar: () => void;
  onNewChat?: () => void;
  selectedWorkflowId?: string;
  loadingHistoryWorkflowId?: string | null;
  onConversationSelect?: (workflowId: string, title: string) => void;
  conversations?: Conversation[];
  isLoadingConversations?: boolean;
  onIntegrationFlowGovernanceClick?: () => void;
  isIntegrationFlowGovernanceActive?: boolean;
  onSuggestedPromptClick?: (prompt: string) => void;
  onAgentClick?: (
    promptKey: string,
    agentId: string,
    introMessage: string | null,
    agentName: string,
    agentWorkflowId?: string,
  ) => void;
  agentGroups?: AgentGroup[];
  isLoadingWorkflows?: boolean;
}

export default function ChatSideBar({
  isOpen,
  toggleChatSidebar,
  onNewChat,
  selectedWorkflowId,
  loadingHistoryWorkflowId,
  onConversationSelect,
  conversations = [],
  isLoadingConversations = false,
  // onIntegrationFlowGovernanceClick,
  // isIntegrationFlowGovernanceActive = false,
  onSuggestedPromptClick,
  onAgentClick,
  agentGroups = [],
  isLoadingWorkflows = false,
}: ChatSideBarProps) {
  const [expandedGroups, setExpandedGroups] = useState<Record<string, boolean>>(
    {},
  );
  const [globalSearchQuery, setGlobalSearchQuery] = useState("");

  const toggleGroup = (groupId: string) => {
    setExpandedGroups((prev) => ({ ...prev, [groupId]: !prev[groupId] }));
  };

  const normalizedGlobalSearchQuery = globalSearchQuery.trim().toLowerCase();
  const filteredGroups = filterAgentGroupsByGlobalQuery(
    agentGroups,
    globalSearchQuery,
  );

  return (
    <div className="relative h-full">
      <div
        className={`bg-white border-r border-gray-100 h-full flex flex-col transition-all duration-300 ease-in-out shrink-0 relative ${
          isOpen ? "w-72 opacity-100" : "w-0 opacity-0 overflow-hidden"
        }`}
      >
        <div className="flex-1 overflow-y-auto no-scrollbar pb-6 min-w-[18rem]">
          {/* Header / New Chat & Collapse Button */}
          <div className="p-4 pt-5 flex items-center justify-between border-b border-gray-50">
            <button
              onClick={onNewChat}
              className="flex items-center gap-2 py-5 px-4 border border-gray-200 rounded-xl hover:shadow-sm transition-all"
            >
              <span
                className="font-semibold text-sm bg-clip-text text-transparent"
                style={{
                  backgroundImage: "linear-gradient(to left, #71A8EF, #EB1700)",
                }}
              >
                New Chat
              </span>
              <svg
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <defs>
                  <linearGradient
                    id="sparklesGrad"
                    x1="0%"
                    y1="0%"
                    x2="100%"
                    y2="0%"
                  >
                    <stop offset="0%" stopColor="#2684FF" />
                    <stop offset="100%" stopColor="#EB1700" />
                  </linearGradient>
                </defs>
                <path
                  d="M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z"
                  stroke="url(#sparklesGrad)"
                />
                <path d="M20 3v4" stroke="url(#sparklesGrad)" />
                <path d="M22 5h-4" stroke="url(#sparklesGrad)" />
                <path d="M4 17v2" stroke="url(#sparklesGrad)" />
                <path d="M5 18H3" stroke="url(#sparklesGrad)" />
              </svg>
            </button>

            <button
              onClick={toggleChatSidebar}
              className="p-1.5 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-50 transition-colors"
              aria-label="Close sidebar"
            >
              <ChevronsLeft className="w-5 h-5" />
            </button>
          </div>

          {/* Applications Section */}
          {/* <div className="px-4 py-2 mt-2 border-t border-gray-50 pt-4">
            <h3 className="text-[13px] font-medium text-gray-400 mb-3 px-1">
              Applications
            </h3>

            <button
              type="button"
              onClick={onIntegrationFlowGovernanceClick}
              className={`w-full flex items-center gap-3 p-2 rounded-lg border transition-colors ${
                isIntegrationFlowGovernanceActive
                  ? "bg-blue-50 border-blue-100 text-blue-700"
                  : "border-gray-200 hover:bg-gray-50 text-gray-900"
              }`}
              style={{ textAlign: "left" }}
            >
              <div
                className={`p-1.5 rounded-lg ${
                  isIntegrationFlowGovernanceActive
                    ? "bg-blue-100 text-blue-600"
                    : "bg-slate-50 text-slate-600"
                }`}
              >
                <Link className="w-4 h-4" />
              </div>
              <span className="text-[15px] font-semibold">
                Integration Flow Governance
              </span>
            </button>
          </div> */}

          {/* Available Agents Section */}
          <div className="px-4 py-4">
            <h3 className="text-[13px] font-medium text-gray-600 mb-3 px-1">
              Available AI Applications
            </h3>

            {isLoadingWorkflows ? (
              <>
                <div className="flex items-center gap-2 mt-2">
                  <Skeleton
                    animation="wave"
                    variant="circular"
                    width={30}
                    height={30}
                  />
                  <div className="flex-1">
                    <Skeleton animation="wave" height={16} width="80%" />
                    <Skeleton animation="wave" height={18} width="70%" />
                  </div>
                </div>
              </>
            ) : (
              <>
                {filteredGroups.length > 0 ? (
                  <div className="relative mb-3 px-1">
                    <Search className="w-3.5 h-3.5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      placeholder="Search workflows"
                      value={globalSearchQuery}
                      onChange={(e) => setGlobalSearchQuery(e.target.value)}
                      className="w-full text-xs pl-8 pr-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:border-blue-500 text-gray-700 placeholder-gray-400"
                    />
                  </div>
                ) : (
                  <p className="text-sm text-gray-400 px-1 py-1">
                    No AI applications available. Please contact your
                    administrator to add workflows.
                  </p>
                )}

                <div className="space-y-2">
                  {filteredGroups.map((group) => {
                    const GroupIcon = group.icon as React.ElementType;
                    const isExpanded = !!expandedGroups[group.id];
                    const filteredAgents = group.agents;

                    const handleGroupClick = () => {
                      if (group.agents.length === 0 && group.promptKey) {
                        onSuggestedPromptClick?.(group.promptKey);
                      } else {
                        toggleGroup(group.id);
                      }
                    };

                    return (
                      <div key={group.id} className="flex flex-col">
                        {/* Group Header */}
                        <div className="flex items-center justify-between p-2 rounded-lg hover:bg-gray-50 transition-colors group">
                          <div
                            className="flex items-center gap-3 cursor-pointer flex-1"
                            onClick={handleGroupClick}
                          >
                            <div
                              className={`p-1.5 rounded-lg shrink-0 ${group.iconBg}`}
                            >
                              <GroupIcon className="w-4 h-4 shrink-0" />
                            </div>
                            <span className="text-[15px] font-semibold text-gray-900">
                              {group.name}
                            </span>
                          </div>

                          {/* Right Actions (Search Icon + Chevron) */}
                          {group.agents.length > 0 && (
                            <div className="flex items-center gap-1">
                              <button
                                onClick={() => toggleGroup(group.id)}
                                className="p-1 text-gray-400 hover:text-gray-600"
                              >
                                {isExpanded ? (
                                  <ChevronUp className="w-4 h-4" />
                                ) : (
                                  <ChevronDown className="w-4 h-4" />
                                )}
                              </button>
                            </div>
                          )}
                        </div>

                        {/* Expanded Content (Search Bar + Agents List) */}
                        <div
                          className={`overflow-hidden transition-all duration-300 ease-in-out ${
                            isExpanded
                              ? "max-h-96 opacity-100"
                              : "max-h-0 opacity-0"
                          }`}
                        >
                          <div className="mt-2 px-1 mb-2">
                            {/* Sub Agents */}
                            <ul className="space-y-1.5 pl-2">
                              {filteredAgents.map((agent) => {
                                const AgentIcon = agent.icon;
                                return (
                                  <li
                                    key={agent.id}
                                    onClick={() => {
                                      if (!agent.promptKey) return;
                                      onNewChat?.();
                                      onAgentClick?.(
                                        agent.promptKey,
                                        group.id,
                                        agent.introMessage,
                                        agent.name,
                                        agent.id,
                                      );
                                    }}
                                    className={`flex items-center gap-3 py-1.5 px-2 rounded-md hover:bg-gray-50 transition-colors ${
                                      agent.promptKey
                                        ? "cursor-pointer text-gray-800"
                                        : "cursor-default text-gray-400"
                                    }`}
                                  >
                                    <AgentIcon
                                      className={`w-4 h-4 shrink-0 flex-none ${agent.iconColor}`}
                                    />
                                    <span className="text-[14px] font-medium">
                                      {agent.name}
                                    </span>
                                  </li>
                                );
                              })}
                              {filteredAgents.length === 0 && (
                                <li className="text-xs text-gray-400 px-2 py-1">
                                  No agents found
                                </li>
                              )}
                            </ul>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                  {normalizedGlobalSearchQuery &&
                    filteredGroups.length === 0 && (
                      <p className="text-sm text-gray-400 px-2 py-1">
                        No agents found
                      </p>
                    )}
                </div>
              </>
            )}
          </div>

          {/* Recent Conversations Section */}
          <div className="px-4 py-2 border-t border-gray-50 pt-4">
            <h3 className="text-[13px] font-medium text-gray-600 mb-3 px-1">
              Recent Conversations
            </h3>

            <div className="space-y-2">
              {isLoadingConversations && (
                <p className="text-sm text-gray-400 px-1">
                  <Skeleton animation="wave"/>
                  <Skeleton animation="wave"/>
                  <Skeleton animation="wave"/>
                </p>
              )}
              {!isLoadingConversations && conversations.length === 0 && (
                <p className="text-sm text-gray-500 font-medium pl-1">
                  No chats yet
                </p>
              )}
              {!isLoadingConversations &&
                conversations.map((conversation) => {
                  const isSelected =
                    selectedWorkflowId === conversation.workflow_id;
                  const isLoadingHistory =
                    loadingHistoryWorkflowId === conversation.workflow_id;

                  return (
                    <div
                      key={conversation.id}
                      role="button"
                      tabIndex={0}
                      onClick={() =>
                        onConversationSelect?.(
                          conversation.workflow_id,
                          conversation.title,
                        )
                      }
                      onKeyDown={(e: React.KeyboardEvent) => {
                        if (e.key === "Enter" || e.key === " ") {
                          e.preventDefault();
                          onConversationSelect?.(
                            conversation.workflow_id,
                            conversation.title,
                          );
                        }
                      }}
                      className={`px-2 py-1.5 rounded-md cursor-pointer transition-colors ${
                        isSelected
                          ? "bg-blue-50 border border-blue-100"
                          : "hover:bg-gray-50"
                      }`}
                    >
                      <p
                        className={`text-[15px] font-semibold truncate ${
                          isSelected ? "text-blue-700" : "text-gray-900"
                        }`}
                      >
                        {conversation.title}
                      </p>
                      <p className="text-[11px] text-gray-400 font-medium mt-0.5">
                        {isLoadingHistory
                          ? "Loading..."
                          : formatConversationDate(conversation.created_at)}
                      </p>
                    </div>
                  );
                })}
            </div>
          </div>
        </div>
      </div>

      {/* Closed State Toggle Button */}
      {!isOpen && (
        <button
          onClick={toggleChatSidebar}
          className="absolute top-1 left-1 z-50 p-2 bg-white border border-gray-200 rounded-lg shadow-sm hover:text-gray-700 transition-all"
          aria-label="Open sidebar"
        >
          <ChevronsRight className="w-4 h-4 text-gray-500" />
        </button>
      )}
    </div>
  );
}
