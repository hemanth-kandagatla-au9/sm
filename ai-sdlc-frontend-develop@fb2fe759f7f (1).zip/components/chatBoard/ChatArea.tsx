"use client";

import React, { useEffect, useRef } from "react";
import ChatBubble from "./ChatBubble";
import ChatInput from "./ChatInput";
import { useUserStore, type UserStoreState } from "@/store/useUserStore";
import { useChatStore } from "@/store/useChatStore";
import type { ChatUiMessage } from "@/services/chat/types";
import { hasRichFormatting, htmlToPlainText } from "@/lib/utils/richText";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { ChevronDownIcon } from "lucide-react";
import type { AgentGroup } from "./agentsApiDataMappingHelper";

interface ChatAreaProps {
  userName: string | null;
  userPhotoUrl?: string | null;
  onNewChat?: () => void;
  title?: string;
  messages: ChatUiMessage[];
  isSendingMessage?: boolean;
  isAwaitingUpload?: boolean;
  inputDisabled?: boolean;
  showFileUpload?: boolean;
  onSuggestedPromptClick: (prompt: string) => void;
  onAgentClick: (
    promptKey: string,
    agentId: string,
    introMessage: string | null,
    agentName: string,
    agentWorkflowId?: string,
  ) => void;
  onFileUpload: (file: File) => void;
  onSendMessage?: (text: string, html?: string, displayText?: string) => void;
  onMessageFeedback?: (messageId: number, userChoice: boolean) => Promise<void>;
  showAgentGroups?: boolean;
  agentGroups?: AgentGroup[];
  isLoadingWorkflows?: boolean;
}

const ChatArea: React.FC<ChatAreaProps> = ({
  userName,
  userPhotoUrl,
  title = "New Chat",
  messages,
  onNewChat,
  isSendingMessage = false,
  isAwaitingUpload = false,
  inputDisabled = false,
  showFileUpload = true,
  onSuggestedPromptClick,
  onAgentClick,
  onFileUpload,
  onSendMessage,
  onMessageFeedback,
  showAgentGroups,
  agentGroups,
  isLoadingWorkflows,
}) => {
  const mainRef = useRef<HTMLDivElement>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const displayName = useUserStore((s: UserStoreState) => s.displayName);
  const selectedProjectRole = useChatStore((s) => s.selectedProjectRole);
  const projectRoles = useChatStore((s) => s.projectRoles);
  const setSelectedProjectRole = useChatStore((s) => s.setSelectedProjectRole);

  useEffect(() => {
    const timer = setTimeout(() => {
      bottomRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
    }, 100);
    return () => clearTimeout(timer);
  }, [messages]);

  return (
    <div className="flex-1 min-w-0 flex flex-col relative bg-[linear-gradient(90deg,#F3F4F6_0%,#E5E7EB_70%,#FDE2E4_100%)]">
      <header className="h-18 bg-white flex items-center px-6 justify-between border-b border-gray-100/50">
        <h1 className="text-base font-semibold text-gray-800 ml-10 truncate">
          {title}
        </h1>
        {selectedProjectRole && (
          <div className="flex gap-2 items-center border border-gray-100 rounded-lg p-2">
            <span>Role Selected</span>

            {projectRoles.length > 1 ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button className="flex items-center gap-1 font-medium bg-[#F5F9FF] text-black border border-gray-100 rounded-lg px-3 py-1 shrink-0 hover:bg-gray-100 transition-colors">
                    {selectedProjectRole.role_name}
                    <ChevronDownIcon className="size-3" />
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  {projectRoles.map((role) => (
                    <DropdownMenuItem
                      key={role.project_role_id}
                      onSelect={() => {
                        const isRoleChanged =
                          role.project_role_id !==
                          selectedProjectRole.project_role_id;
                        setSelectedProjectRole(role);
                        if (isRoleChanged) {
                          onNewChat?.();
                        }
                      }}
                      data-selected={
                        role.project_role_id ===
                        selectedProjectRole.project_role_id
                      }
                      className="data-[selected=true]:font-semibold data-[selected=true]:text-black">
                      {role.role_name}
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <span className="font-medium bg-[#F5F9FF] text-black border border-gray-100 rounded-lg px-3 py-1 shrink-0">
                {selectedProjectRole.role_name}
              </span>
            )}
          </div>
        )}
        {/* 
        <div className="flex items-center gap-3">
          <span className="font-medium text-gray-800 mr-2">
            Collaborator/ Owners
          </span>

          <div className="flex -space-x-2 mr-2">
            <img
              className="w-8 h-8 rounded-full border-2 border-white"
              src="https://i.pravatar.cc/150?u=1"
              alt="Avatar 1"
            />
            <img
              className="w-8 h-8 rounded-full border-2 border-white"
              src="https://i.pravatar.cc/150?u=2"
              alt="Avatar 2"
            />
          </div>

          <button className="w-8 h-8 rounded-full border border-gray-200 flex items-center justify-center text-gray-500 hover:bg-gray-50 transition-colors">
            <Settings className="w-6 h-6 text-blue-500" />
          </button>
          <button className="w-8 h-8 rounded-full border border-gray-200 flex items-center justify-center text-gray-500 hover:bg-gray-50 transition-colors">
            <ExternalLink className="w-6 h-6" />
          </button>
        </div> */}
      </header>

      <main
        ref={mainRef}
        className="flex-1 overflow-y-auto scroll-smooth p-6 md:p-10 flex flex-col">
        <div className="mx-auto w-full flex-1 pt-4">
          {messages.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full min-h-75 text-center select-none">
              <h2 className="text-3xl font-semibold text-gray-800 mb-2">
                Hello,
                <span className="text-[#eb1700] ">
                  {displayName ? ` ${displayName}` : ""}
                </span>
              </h2>
              <p className="text-gray-500 text-xl max-w-90">
                How can I assist your workflow today? Choose an agent or start
                typing.
              </p>
            </div>
          ) : (
            messages.map((m, index) => {
              const prevUserMessage =
                m.type === "bot"
                  ? [...messages]
                      .slice(0, index)
                      .reverse()
                      .find((msg) => msg.type === "user")
                  : undefined;

              const botMessageId = m.type === "bot" ? m.messageId : undefined;
              const botUserChoice = m.type === "bot" ? m.userChoice : undefined;
              const botSuggestedPrompts =
                m.type === "bot" ? m.suggestedPrompts : undefined;
              const botClickableOptions =
                m.type === "bot" ? m.clickableOptions : undefined;
              const botMetrics = m.type === "bot" ? m.metrics : undefined;
              const isLoadingBotMessage = m.type === "bot" && !!m.isLoading;
              const botLoadingText =
                m.type === "bot" ? m.loadingText : undefined;

              return (
                <ChatBubble
                  key={m.id}
                  type={m.type}
                  content={m.message}
                  isLoading={isLoadingBotMessage || undefined}
                  loadingText={botLoadingText}
                  actionsDisabled={isSendingMessage && !isLoadingBotMessage}
                  timestamp={m.timestamp}
                  suggestedPrompts={botSuggestedPrompts}
                  clickableOptions={botClickableOptions}
                  onClickableOptionClick={(option) =>
                    onSendMessage?.(option.value, undefined, option.label)
                  }
                  messageId={botMessageId}
                  userChoice={botUserChoice}
                  onMessageFeedback={
                    botMessageId != null && onMessageFeedback
                      ? (choice) => onMessageFeedback(botMessageId, choice)
                      : undefined
                  }
                  metrics={
                    botMetrics
                      ? {
                          time: botMetrics.processingTime,
                          token: botMetrics.token,
                          cost: botMetrics.cost,
                        }
                      : undefined
                  }
                  onSuggestedPromptClick={onSuggestedPromptClick}
                  onRegenerate={
                    prevUserMessage &&
                    typeof prevUserMessage.message === "string"
                      ? () => {
                          const msg = prevUserMessage.message as string;
                          const textToSend =
                            prevUserMessage.sentMessage ??
                            (hasRichFormatting(msg)
                              ? htmlToPlainText(msg)
                              : msg);
                          onSendMessage?.(
                            textToSend,
                            prevUserMessage.sentMessage
                              ? undefined
                              : hasRichFormatting(msg)
                                ? msg
                                : undefined,
                            prevUserMessage.sentMessage ? msg : undefined,
                          );
                        }
                      : undefined
                  }
                  userName={userName || "Guest"}
                  userPhotoUrl={userPhotoUrl}
                />
              );
            })
          )}
          <div ref={bottomRef} />
        </div>
      </main>

      <ChatInput
        onFileUpload={onFileUpload}
        onSendMessage={onSendMessage}
        showAgentGroups={showAgentGroups}
        onSuggestedPromptClick={onSuggestedPromptClick}
        onAgentClick={onAgentClick}
        agentGroups={agentGroups}
        isLoadingWorkflows={isLoadingWorkflows}
        disabled={isSendingMessage || inputDisabled}
        isAwaitingUpload={isAwaitingUpload}
        showFileUpload={showFileUpload}
      />
    </div>
  );
};

export default ChatArea;
