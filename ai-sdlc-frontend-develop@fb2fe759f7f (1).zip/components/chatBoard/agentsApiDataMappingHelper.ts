import {
  RefreshCcw,
  Wand2,
  ShieldCheck,
  FileText,
  CircleEllipsis,
} from "lucide-react";
import type { ElementType } from "react";

/* ──── TYPES */

export type AgentItem = {
  id: string;
  name: string;
  icon: ElementType;
  iconColor: string;
  promptKey: string | null;
  introMessage: string | null;
};

export type AgentGroup = {
  id: string;
  name: string;
  icon: ElementType;
  iconBg: string;
  promptKey: string | null;
  agents: AgentItem[];
};

/** Shape returned by `/sdlc/projects/:id/workflows` */
export type ApiWorkflow = {
  workflow_id: number;
  workflow_name: string;
  workflow_desc: string;
  version: string;
  type_name: string;
  intro_message: string | null;
  workflow_metadata: unknown;
  is_active: boolean;
  componets: []; //compontes data is not took into consideration for mapping
};

type GroupMeta = {
  groupName: string;
  groupIcon: ElementType;
  groupIconBg: string;
  agentIcon: ElementType;
  agentIconColor: string;
  opensRightPanel?: boolean;
};

//contract to show name and icon based on the
const TYPE_NAME_META: Record<string, GroupMeta> = {
  sasa: {
    groupName: "SASA",
    groupIcon: RefreshCcw,
    groupIconBg: "bg-blue-50 text-blue-500",
    agentIcon: FileText,
    agentIconColor: "text-blue-500",
  },
  "workshop assist mcp": {
    groupName: "Workshop Assist MCP",
    groupIcon: Wand2,
    groupIconBg: "bg-purple-50 text-purple-600",
    agentIcon: FileText,
    agentIconColor: "text-purple-500",
  },
  crco: {
    groupName: "CR/CO Agent",
    groupIcon: ShieldCheck,
    groupIconBg: "bg-green-50 text-green-600",
    agentIcon: FileText,
    agentIconColor: "text-green-500",
    opensRightPanel: true,
  },
};

//kept for other group which are not defined in the TYPE_NAME_META,
const DEFAULT_GROUP_META: GroupMeta = {
  groupName: "Other",
  groupIcon: CircleEllipsis,
  groupIconBg: "bg-yellow-50 text-yellow-500",
  agentIcon: FileText,
  agentIconColor: "text-yellow-500",
};

export function mapWorkflowsToAgentGroups(
  workflows: ApiWorkflow[],
): AgentGroup[] {
  const groupOrder: string[] = [];
  const groupMap = new Map<string, AgentGroup>();

  for (const wf of workflows) {
    if (!wf.is_active) continue;

    const typeName = wf.type_name.toLowerCase();
    const meta = TYPE_NAME_META[typeName] ?? {
      ...DEFAULT_GROUP_META,
      groupName: wf.type_name,
    };

    //crete group based on api type_name if not exists
    if (!groupMap.has(typeName)) {
      groupOrder.push(typeName);
      groupMap.set(typeName, {
        id: typeName,
        name: meta.groupName,
        icon: meta.groupIcon,
        iconBg: meta.groupIconBg,
        promptKey: null,
        agents: [],
      });
    }
    // pussing agent to respective group based on api type_name
    groupMap.get(typeName)!.agents.push({
      id: String(wf.workflow_id),
      name: wf.workflow_name,
      icon: meta.agentIcon,
      iconColor: meta.agentIconColor,
      promptKey: wf.workflow_name,
      introMessage: wf.intro_message,
    });
  }
  return groupOrder.map((id) => groupMap.get(id)!);
}

export const SASA_TYPE_NAME = "sasa";
export const IWAND_TYPE_NAME = "workshop assist mcp";
export const CRCO_TYPE_NAME = "crco";

/** Returns the clicked agent when it belongs to a workflow group with type_name "sasa". */
export function findSasaAgentByPromptKey(
  groups: AgentGroup[],
  promptKey: string,
): AgentItem | null {
  const sasaGroup = groups.find((group) => group.id === SASA_TYPE_NAME);
  if (!sasaGroup) return null;
  return (
    sasaGroup.agents.find((agent) => agent.promptKey === promptKey) ?? null
  );
}

export function deriveRightPanelFlowKeys(groups: AgentGroup[]): string[] {
  return groups
    .filter((g) => TYPE_NAME_META[g.id]?.opensRightPanel)
    .flatMap((g) => [
      ...(g.promptKey ? [g.promptKey] : []),
      ...g.agents
        .map((a) => a.promptKey)
        .filter((k): k is string => k !== null),
    ]);
}

/** Returns true when the given group id belongs to a right-panel flow (e.g. CR/CO). */
export function isRightPanelGroupId(groupId: string): boolean {
  return !!TYPE_NAME_META[groupId]?.opensRightPanel;
}

export function findAgentGroupByWorkflowId(
  groups: AgentGroup[],
  workflowId: string,
): AgentGroup | undefined {
  return groups.find((group) =>
    group.agents.some((agent) => agent.id === workflowId),
  );
}

/** Returns true when the active chat context is a CR/CO agent workflow. */
export function isCrcoAgentContext(
  groups: AgentGroup[],
  agentGroupId?: string | null,
  workflowId?: string | null,
): boolean {
  if (agentGroupId && isRightPanelGroupId(agentGroupId)) {
    return true;
  }

  if (workflowId) {
    const group = findAgentGroupByWorkflowId(groups, workflowId);
    return group ? isRightPanelGroupId(group.id) : false;
  }

  return false;
}

/**
 * Helper: applies one global query across all groups and returns only matching agents.
 * When query is empty, the original groups are returned unchanged.
 */
export function filterAgentGroupsByGlobalQuery(
  groups: AgentGroup[],
  query: string,
): AgentGroup[] {
  const normalizedQuery = query.trim().toLowerCase();
  if (!normalizedQuery) return groups;

  return groups
    .map((group) => ({
      ...group,
      agents: group.agents.filter((agent) =>
        agent.name.toLowerCase().includes(normalizedQuery),
      ),
    }))
    .filter((group) => group.agents.length > 0);
}


