"use client";

import Box from "@mui/material/Box";
import Tab from "@mui/material/Tab";
import TabContext from "@mui/lab/TabContext";
import TabList from "@mui/lab/TabList";
import TabPanel from "@mui/lab/TabPanel";
// import type { SxProps, Theme } from "@mui/material/styles";
import { ReactNode, useState } from "react";

export interface TabItem {
  id: string;
  label: string;
  component: ReactNode;
}

export interface TabsProps {
  tabs: TabItem[];
  value?: string;
  onChange?: (newValue: string) => void;
  showTabList?: boolean;
  showTabPanels?: boolean;
  // tabListSx?: SxProps<Theme>;
  // tabPanelSx?: SxProps<Theme>;
}

export default function CustomTab({
  tabs,
  value,
  onChange,
  showTabList = true,
  showTabPanels = true,
  // tabListSx,
  // tabPanelSx,
}: TabsProps) {
  const [internalValue, setInternalValue] = useState(tabs[0]?.id || "1");
  const selectedValue = value ?? internalValue;

  const handleChange = (_event: React.SyntheticEvent, newValue: string) => {
    if (onChange) {
      onChange(newValue);
      return;
    }

    setInternalValue(newValue);
  };

  return (
    <TabContext value={selectedValue}>
      {showTabList ? (
        <Box>
          <TabList
            onChange={handleChange}
            sx={{
              backgroundColor: "white",
              paddingLeft: 2,
              // ...tabListSx,
            }}
            slotProps={{
              indicator: {
                style: {
                  backgroundColor: "#eb1007",
                  height: 2,
                },
              },
            }}
          >
            {tabs.map((tab) => (
              <Tab
                sx={{
                  height: 60,
                  px: 4,
                  py: 2,
                  minWidth: 120,
                  fontSize: "16px",
                  color: "#4A5567",
                  fontFamily: "var(--app-font-text)",
                  textTransform: "none",
                  "&:hover": {
                    color: "#e8472a",
                  },
                  "&.Mui-selected": {
                    color: "#e8472a",
                    fontWeight: "500",
                  },
                }}
                key={tab.id}
                label={tab.label}
                value={tab.id}
              />
            ))}
          </TabList>
        </Box>
      ) : null}
      {showTabPanels
        ? tabs.map((tab) => (
            <TabPanel key={tab.id} value={tab.id} sx={{ p: "16px 24px" }}>
              {tab.component}
            </TabPanel>
          ))
        : null}
    </TabContext>
  );
}
