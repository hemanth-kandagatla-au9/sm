import { Search } from "lucide-react";
import { Dispatch, SetStateAction } from "react";

interface TableSearchBarProps {
  globalSearch: string;
  setGlobalSearch: Dispatch<SetStateAction<string>>;
}

const TableSearchBar = ({
  globalSearch,
  setGlobalSearch,
}: TableSearchBarProps) => {
  return (
    <div className="relative">
      <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
      <input
        type="text"
        placeholder="Search"
        value={globalSearch}
        onChange={(e) => setGlobalSearch(e.target.value)}
        className="pl-10 pr-3 h-9 w-40 text-[14px] placeholder:text-[#312c2a] rounded-lg border border-[#9ca3af] bg-white outline-none focus:outline-none focus:ring-0 focus:border-[#494949]"
      />
    </div>
  );
};

export default TableSearchBar;
