"use client";

export default function CircularProgress({ value, size = 36 }: { value: number; size?: number }) {
  const r = (size - 6) / 2;
  const circ = 2 * Math.PI * r;
  const filled = circ * (value / 100);
  const isEmpty = value === 0;

  const strokeColor =
    value >= 60 ? "#22c55e" : value >= 40 ? "#f97316" : "#e8472a";

  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg width={size} height={size} style={{ transform: "rotate(-90deg)" }}>
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke="#e8e8f0"
          strokeWidth={3}
        />
        {!isEmpty && (
          <circle
            cx={size / 2}
            cy={size / 2}
            r={r}
            fill="none"
            stroke={strokeColor}
            strokeWidth={3}
            strokeDasharray={`${filled} ${circ - filled}`}
            strokeLinecap="round"
          />
        )}
      </svg>
      <span
        className="absolute inset-0 flex items-center justify-center text-[10px] font-bold"
        style={{ color: isEmpty ? "#bbb" : strokeColor }}
      >
        {value}%
      </span>
    </div>
  );
}