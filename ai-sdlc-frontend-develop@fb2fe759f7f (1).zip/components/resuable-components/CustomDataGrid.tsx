"use client";
import { useEffect } from "react";
import {
  DataGrid,
  GridColDef,
  GridRowIdGetter,
  GridRowModel,
  GridRowsProp,
  useGridApiRef,
} from "@mui/x-data-grid";
import { SxProps, Theme } from "@mui/material/styles";
import { gridSx } from "../common/Helper";

interface CustomDataGridProps {
  data: GridRowsProp;
  columns: GridColDef[];
  getRowId?: GridRowIdGetter;
  searchValue?: string | number;
  loading?: boolean;
  gridCustomSx?: SxProps<Theme>;
  handleProcessRowUpdate?: (
    newRow: GridRowModel,
    oldRow: GridRowModel,
  ) => GridRowModel | Promise<GridRowModel>;
  defaultSortingField?: string;
}

const CustomDataGrid = ({
  data,
  columns,
  getRowId,
  searchValue = "",
  // filterModel,
  loading = false,
  gridCustomSx = {},
  handleProcessRowUpdate,
  defaultSortingField,
}: CustomDataGridProps) => {
  const apiRef = useGridApiRef();

   const defaultSortModel = defaultSortingField
    ? [{ field: defaultSortingField, sort: "asc" as const }]
    : [];

  useEffect(() => {
    if (apiRef.current) {
      apiRef.current.setQuickFilterValues([searchValue]);
    }
  }, [searchValue, apiRef]);

  return (
    <div className="w-full">
      <DataGrid
        loading={loading}
        getRowId={getRowId}
        apiRef={apiRef}
        rows={data}
        columns={columns}
        // getCellClassName={(params) =>
        //   params.field.endsWith("id") ? "grid-id-cell" : "grid-default-cell"
        // }
        rowHeight={35}
        columnHeaderHeight={45}
        processRowUpdate={handleProcessRowUpdate}
        // isCellEditable={(params) => params.row.status === "Info"} // used for conditional editing

        //props to diable default style and features of the data grid
        disableRowSelectionOnClick
        disableColumnSelector
        // disableColumnResize
        slotProps={{
          loadingOverlay: {
            variant: "linear-progress",
            noRowsVariant: "skeleton",
          },
          }}
        initialState={{
          pagination: { paginationModel: { pageSize: 25, page: 0 } },
           sorting: {
            sortModel: defaultSortModel,
          },
        }}
        sx={{ ...gridSx, ...gridCustomSx }}
      />
    </div>
  );
};

export default CustomDataGrid;
