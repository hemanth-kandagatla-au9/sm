import React from "react";
import { VRLevel } from "@/services/dashboardService/types";
import { formatCurrency, totalValue } from "@/services/dashboardService/dashboardHelper"
import {
  ShieldCheck,
  RefreshCcw,
  Wand2,
  Shield,
} from "lucide-react";

interface AgentValuesSectionProps {
  agentData: VRLevel[];
}

const AGENT_ICONS = {
  SASA: {
    icon: <ShieldCheck className="w-4 h-4 text-green-700" />,
    bg: "bg-green-100",
  },

  IWAND: {
    icon: <RefreshCcw className="w-4 h-4 text-blue-700" />,
    bg: "bg-blue-100",
  },

  CRCO: {
    icon: <Wand2 className="w-4 h-4 text-purple-700" />,
    bg: "bg-purple-100",
  },
};

const FALLBACKS = [
  {
    icon: <Shield className="w-4 h-4 text-gray-700" />,
    bg: "bg-gray-100",
  },
  {
    icon: <Shield className="w-4 h-4 text-orange-700" />,
    bg: "bg-orange-100",
  },
];


const getAgentMeta = (name: string) => {
  const upperName = name.toUpperCase();

  if (upperName.includes("SASA")) return AGENT_ICONS.SASA;
  if (upperName.includes("IWAND")) return AGENT_ICONS.IWAND;
  if (upperName.includes("CRCO")) return AGENT_ICONS.CRCO;

  return FALLBACKS[name.length % FALLBACKS.length];
};



const AgentValuesSection: React.FC<AgentValuesSectionProps> = ({
  agentData,
}) => {

  console.log("agentData:", agentData)
  return (
    <div className="bg-white rounded-xl px-6 py-5 shadow-sm border border-gray-100">
      <div className="flex items-center justify-between mb-5">
        <div>
          <h3 className="text-xl font-medium text-[#000000]">
            Value Delivered by Agents
          </h3>
          <p className="text-xs font-medium text-gray-700 mt-0.5">Business Value Metrics</p>
        </div>
        <div className="text-right flex justify-center gap-1 ">
          <span className="text-xl text-gray-700 block ">Total: </span>
          <span className="text-xl font-bold text-[#eb1700]">
            {formatCurrency(totalValue(agentData))}
          </span>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-4 gap-4">
        {agentData.map((v) => {
            const { icon, bg } = getAgentMeta(v.name);
          return (
            <div
              key={v.name}
              className="flex flex-col justify-center gap-6 p-4 rounded-lg bg-gray-50 border border-gray-100 min-h-[150px]"
            >
              <div className="flex justify-between items-start">
                <div className="flex justify-center items-center gap-2 min-w-0">
                  <div
                    className={`flex-shrink-0 w-7 h-7 rounded-md flex items-center justify-center ${bg}`}
                  >
                    {icon}
                  </div>
                  <span
                    className={`text-sm font-medium uppercase tracking-wide text-[#4C5463]`}
                  >
                    {v.name}
                  </span>
                </div>

                <span className="text-base font-semibold text-[#000000] flex-shrink-0">
                  {v.total_value_delivered > 0
                    ? formatCurrency(v.total_value_delivered)
                    : "--"}
                </span>
              </div>
              <div className="flex justify-between gap-2  border-gray-200 pt-2">
                {[
                  { label: "Experience", val: v.experience_value },
                  { label: "Effectiveness", val: v.effectiveness_value },
                  { label: "Efficiency", val: v.efficiency_value },
                ].map((item) => (
                  <div
                    key={item.label}
                    className="flex flex-col items-center gap-0.5"
                  >
                    <span className="text-[13px] 2xl:text-basefont-semibold text-[#000000]">
                      {item.val > 0 ? formatCurrency(item.val) : "--"}
                    </span>
                    <span className="text-[13px] 2xl:text-base text-gray-700">
                      {item.label}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default AgentValuesSection;
