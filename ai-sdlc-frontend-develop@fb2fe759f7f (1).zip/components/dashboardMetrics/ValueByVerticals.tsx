import React from "react";
import { VerticalValue } from "@/services/dashboardService/types";
import { formatCurrency,totalValue } from "@/services/dashboardService/dashboardHelper";

interface ValueByVerticalsProps {
  verticals: VerticalValue[];
}


const ValueByVerticals: React.FC<ValueByVerticalsProps> = ({
  verticals,
}) => {

  return (
    <div className="bg-white rounded-xl px-6 py-5 shadow-sm border border-gray-100">
      <div className="flex items-center justify-between mb-5">
        <div>
          <h3 className="text-xl font-medium text-[#000000]">
            Value Delivered by Verticals
          </h3>
          <p className="text-xs font-medium text-gray-700 mt-0.5">Business Value Metrics</p>
        </div>
        <div className="text-right flex justify-center gap-1 ">
          <span className="text-xl text-gray-700 block ">Total: </span>
          <span className="text-xl font-bold text-[#eb1700]">
            {formatCurrency(totalValue(verticals))}
          </span>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-4 gap-4">
        {verticals.map((v) => {

          return (
            <div
              key={v.vertical_name}
              className="flex flex-col justify-center gap-6 p-4 rounded-lg bg-gray-50 border border-gray-100 min-h-[150px]"
            >
              <div className="flex justify-between items-start">
                <span
                  className={`text-sm font-medium uppercase tracking-wide text-[#000000]`}
                >
                  {v.vertical_name}
                </span>

                <span className="text-base font-bold text-[#000000] flex-shrink-0">
                  {v.total_value_delivered > 0
                    ? formatCurrency(v.total_value_delivered)
                    : "--"}
                </span>
              </div>
              <div className="flex justify-between gap-2  border-gray-200 pt-2">
                {[
                  { label: "Experience", val: v.experience_value },
                  { label: "Effectiveness", val: v.effectiveness_value },
                  { label: "Efficiency", val: v.efficiency_value },
                ].map((item) => (
                  <div
                    key={item.label}
                    className="flex flex-col items-center gap-0.5"
                  >
                    <span className="text-[13px] 2xl:text-base font-bold text-[#000000]">
                      {item.val > 0 ? formatCurrency(item.val) : "--"}
                    </span>
                    <span className="text-[13px] 2xl:text-base text-gray-700">
                      {item.label}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default ValueByVerticals;
