"use client";

import React from "react";
import {
  FolderOpen,
  Bot,
  GitBranch,
  Users,
  AppWindowMac,
  Hourglass,
  TrendingUp,
  RefreshCw,
  AlertCircle,
} from "lucide-react";

import { useDashboard } from "@/services/dashboardService/useDashboard";
import MetricCard from "./MetricCard";
import ValueByVerticals from "./ValueByVerticals";
import AgentValuesSection from "./AgentValuesSection";
import DashboardSkeleton from "./DashboardSkeleton";
import { formatCompact, formatHours, formatPercent, getMetric } from "@/services/dashboardService/dashboardHelper";
import { getLoggedInUser } from "@/lib/auth/user-helper"

const iconProps = { size: 20, strokeWidth: 1.8, className: "text-white" };

const METRIC_ICONS = {
  projects: {
    icon: <FolderOpen {...iconProps} />,
    bg: "bg-teal-400",
  },
  agents: {
    icon: <Bot {...iconProps} />,
    bg: "bg-blue-400",
  },
  workflows: {
    icon: <GitBranch {...iconProps} />,
    bg: "bg-indigo-400",
  },
  users: {
    icon: <Users {...iconProps} />,
    bg: "bg-orange-400",
  },
  executions: {
    icon: <AppWindowMac {...iconProps} />,
    bg: "bg-pink-400",
  },
  hours: {
    icon: <Hourglass {...iconProps} />,
    bg: "bg-amber-400",
  },
  roi: {
    icon: <TrendingUp {...iconProps} />,
    bg: "bg-emerald-500",
  },
};


const ValueRealizationDashboard: React.FC = () => {
  const { data, isLoading, error, refetch } = useDashboard();
  const user = getLoggedInUser();
  const userName = user?.name
  const extractFirstName = (userName: string) => userName?.split(",")[1]?.trim().split(" ")[0] || "";

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-6">
        <div className="bg-white rounded-xl p-8 shadow-sm border border-red-100 max-w-md w-full text-center">
          <AlertCircle className="mx-auto mb-3 text-red-400" size={40} />
          <h2 className="text-lg font-semibold text-gray-800 mb-2">
            Failed to load dashboard
          </h2>
          <p className="text-sm text-gray-500 mb-5">{error}</p>
          <button
            onClick={() => refetch()}
            className="inline-flex items-center gap-2 px-4 py-2 bg-gray-900 text-white text-sm font-medium rounded-lg hover:bg-gray-700 transition-colors"
          >
            <RefreshCw size={14} /> Retry
          </button>
        </div>
      </div>
    );
  }

  const cards = data?.leadership_admin_metrics_cards ?? [];
  const totalProjects = getMetric(cards, "Projects");
  const agentsDeployed = getMetric(cards, "Agents Deployed");
  const orchestratedWorkflows = getMetric(cards, "Orchestrated Workflows");
  const activeUsersCurrent = getMetric(cards, "Active Users (Current Month)");
  const activeUsersPrev = getMetric(cards, "Active Users (Previous Month)");
  const momChange = cards.find(
    (c: any) => c.metric_name === "Active Users MoM Change %"
  );
  const agentExecutions = getMetric(cards, "Agent Executions");
  const hoursSaved = getMetric(cards, "Hours Saved");
  // const roi = getMetric(cards, "ROI %");

  const projectSubItems = data
    ? (() => {
      const verticals = data.value_delivered_by_verticals;
      return verticals
        .filter((v: any) => v.number_of_projects >= 0)
        .map((v: any) => ({ label: v.vertical_name, value: v.number_of_projects }));
    })()
    : [];

  return (
    <div className=" bg-gray-50 font-display">
      <div className="w-full px-4 sm:px-6 lg:px-8 py-2 flex flex-col gap-5  max-h-[calc(100vh-100px)]">
        <div className="flex flex-col gap-2 overflow-y-auto scrollbar-hide">
           <div className="flex items-center justify-between">
          <h1 className="text-3xl font-display font-medium text-red-500 tracking-tight ">
            Welcome, <span>{extractFirstName(userName || "Guest")}!</span>
          </h1>
        </div>
          {isLoading && <DashboardSkeleton />}
          {!isLoading && data && (
            <>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <MetricCard
                  title="Total Projects"
                  value={formatCompact(totalProjects ?? 0)}
                  icon={METRIC_ICONS.projects.icon}
                  iconBg={METRIC_ICONS.projects.bg}
                  subItems={projectSubItems}
                />
                <MetricCard
                  title="Agents Deployed"
                  value={formatCompact(agentsDeployed ?? 0)}
                  icon={METRIC_ICONS.agents.icon}
                  iconBg={METRIC_ICONS.agents.bg}
                  subItems={data.value_delivered_by_verticals
                    .filter((v: any) => v.number_of_agents >= 0)
                    .map((v: any) => ({ label: v.vertical_name, value: v.number_of_agents }))}
                />
                <MetricCard
                  title="Orchestrated Workflows"
                  value={formatCompact(orchestratedWorkflows ?? 0)}
                  icon={METRIC_ICONS.workflows.icon}
                  iconBg={METRIC_ICONS.workflows.bg}
                  subItems={data.value_delivered_by_verticals
                    .filter((v: any) => v.number_of_workflows >= 0)
                    .map((v: any) => ({
                      label: v.vertical_name,
                      value: v.number_of_workflows,
                    }))}
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <MetricCard
                  title="Active Users"
                  value={formatCompact(activeUsersCurrent ?? 0)}
                  icon={METRIC_ICONS.users.icon}
                  iconBg={METRIC_ICONS.users.bg}
                  subItems={[
                    {
                      label: "Last Month",
                      value: formatCompact(activeUsersPrev ?? 0),
                    },
                    {
                      label: "Current Month",
                      value: formatCompact(activeUsersCurrent ?? 0),
                    },
                    {
                      label: "MoM Change %",
                      value: momChange?.metric_value.available
                        ? formatPercent(momChange.metric_value.value ?? 0)
                        : "--",
                    },
                  ]}
                />
                <MetricCard
                  title="Agent Executed"
                  value={formatCompact(agentExecutions ?? 0)}
                  icon={METRIC_ICONS.executions.icon}
                  iconBg={METRIC_ICONS.executions.bg}
                  subItems={data.value_delivered_by_verticals
                    .filter((v: any) => v.number_of_executions >= 0)
                    .map((v: any) => ({
                      label: v.vertical_name,
                      value: v.number_of_executions,
                    }))}
                />
                <MetricCard
                  title="Hours Saved"
                  value={formatHours(hoursSaved ?? 0)}
                  icon={METRIC_ICONS.hours.icon}
                  iconBg={METRIC_ICONS.hours.bg}
                  subItems={data.value_delivered_by_verticals
                    .filter((v: any) => v.hours_saved >= 0)
                    .map((v: any) => ({
                      label: v.vertical_name,
                      value: formatHours(v.hours_saved),
                    }))}
                />
              </div>

              <ValueByVerticals
                verticals={data.value_delivered_by_verticals}
              />

              <AgentValuesSection
                agentData={data.agent_level_vr}
              />
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default ValueRealizationDashboard;
