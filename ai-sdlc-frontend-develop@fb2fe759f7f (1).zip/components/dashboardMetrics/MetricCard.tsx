import React from "react";

interface SubItem {
  label: string;
  value: string | number;
}

interface MetricCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  iconBg: string;
  subItems?: SubItem[];
  unavailable?: boolean;
}

const MetricCard: React.FC<MetricCardProps> = ({
  title,
  value,
  icon,
  iconBg,
  subItems,
  unavailable,
}) => {

  return (
    <div className="bg-white rounded-xl px-6 shadow-sm border border-gray-100 flex flex-col justify-center gap-10 min-w-0 min-h-[180px]">
      <div className="flex items-start justify-between gap-4">
        <div className="flex justify-center items-center gap-3 min-w-0">
          <div
            className={`flex-shrink-0 w-10 h-10 rounded-md flex items-center justify-center ${iconBg}`}
          >
            {icon}
          </div>
          <span className="text-[18px] 2xl:text-xl font-medium text-[#000000] truncate">{title}</span>
        </div>
        <span className="text-2xl 2xl:text-3xl font-bold text-[#070A13] leading-tight tracking-tight flex-shrink-0">
          {unavailable ? "--" : value}
        </span>
      </div>

      {subItems && subItems.length > 0 && (
        <div className="flex items-center justify-between gap-2 flex-wrap  border-gray-100 pt-3">
          {subItems.map((item, idx) => (
            <div key={idx} className="flex flex-col justify-center  items-center gap-0.5">
              <span className="text-[13px] 2xl:text-base font-bold text-[#000000]">
                {item.value}
              </span>
              <span className="text-[13px] 2xl:text-base text-gray-700">{item.label}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default MetricCard;
