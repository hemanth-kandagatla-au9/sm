import React from "react";

const SkeletonBlock: React.FC<{ className?: string }> = ({ className = "" }) => (
  <div className={`animate-pulse bg-gray-200 rounded-lg ${className}`} />
);

const DashboardSkeleton: React.FC = () => (
  <div className="flex flex-col gap-5">
   
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
      {[1, 2, 3].map((i) => (
        <div key={i} className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
          <div className="flex justify-between mb-4">
            <div className="flex flex-col gap-2">
              <SkeletonBlock className="h-8 w-16" />
              <SkeletonBlock className="h-4 w-28" />
            </div>
            <SkeletonBlock className="h-11 w-11 rounded-xl" />
          </div>
          <div className="flex gap-4 pt-2 border-t border-gray-50">
            {[1, 2, 3].map((j) => (
              <div key={j} className="flex flex-col gap-1">
                <SkeletonBlock className="h-4 w-10" />
                <SkeletonBlock className="h-3 w-14" />
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
   
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
      {[1, 2, 3].map((i) => (
        <div key={i} className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
          <div className="flex justify-between mb-4">
            <div className="flex flex-col gap-2">
              <SkeletonBlock className="h-8 w-16" />
              <SkeletonBlock className="h-4 w-28" />
            </div>
            <SkeletonBlock className="h-11 w-11 rounded-xl" />
          </div>
        </div>
      ))}
    </div>
   
    <SkeletonBlock className="h-56 w-full" />
   
    <SkeletonBlock className="h-72 w-full" />
  </div>
);

export default DashboardSkeleton;
