'use client';

import { DataGrid, GridColDef, useGridApiRef } from '@mui/x-data-grid';
import Tooltip from '@mui/material/Tooltip';
import { useChangeHistory } from '@/services/logServices/useChangeHistory';
import { gridSx, renderDataGridChip } from "../../../common/Helper";
import { useEffect } from "react";
import { formatConversationDate } from "@/lib/utils";
import JsonCell from './JsonCell';

interface Props {
  globalSearch: string;
}

const columns: GridColDef[] = [
  {
    field: "log_id",
    headerName: "Log ID",
    width: 180,
    type: "longText"
  },
  {
    field: "user_name_snapshot",
    headerName: "User Name",
    width: 220,
    type: "longText"
  },
  {
    field: "user_email_snapshot",
    headerName: "User ID",
    width: 220,
  },
  {
    field: "occurred_at",
    headerName: "Time",
    width: 180,
    renderCell: (params) =>
      formatConversationDate(params.value as string, true),
  },
  {
    field: "change_type",
    headerName: "Change Type",
    width: 130,
    renderCell: (params) => renderDataGridChip(params.value),
  },
  {
    field: "change_details",
    headerName: "Change Details",
    flex: 1,
    minWidth: 220,
    type: "longText"
  },
  {
    field: "entity_type",
    headerName: "Target",
    width: 150,
  },
  {
    field: "values_before",
    headerName: "Values Before",
    width: 120,
    renderCell: (params) => (
      <JsonCell value={params.value} />
    ),

  },
  {
    field: "values_after",
    headerName: "Values After",
    width: 120,
    renderCell: (params) => (
      <JsonCell value={params.value} />
    ),
  },
];

export default function ChangeHistoryTab({ globalSearch }: Props) {
  const apiRef = useGridApiRef();
  useEffect(() => {
    if (apiRef.current) {
      apiRef.current.setQuickFilterValues([globalSearch]);
    }
  }, [globalSearch, apiRef]);
  const { rows, total, page, pageSize, loading, setPage, setPageSize } = useChangeHistory();

  return (
    <div className="space-y-0">
      <DataGrid
        rows={rows}
        columns={columns}
        getRowId={(r) => r.log_id}
        apiRef={apiRef}
        loading={loading}
        rowCount={total}
        paginationMode="server"
        paginationModel={{ page, pageSize }}
        onPaginationModelChange={(model) => {
          setPage(model.page);
          setPageSize(model.pageSize);
        }}
        pageSizeOptions={[10, 25, 50]}
        rowHeight={35}
        columnHeaderHeight={45}
        disableRowSelectionOnClick
        disableColumnSelector
        disableColumnResize
        slotProps={{
          loadingOverlay: {
            variant: "linear-progress",
            noRowsVariant: "skeleton",
          },
        }}
        sx={{ ...gridSx, height: "calc(100vh - 305px)" }}
      />
    </div>
  );
}


