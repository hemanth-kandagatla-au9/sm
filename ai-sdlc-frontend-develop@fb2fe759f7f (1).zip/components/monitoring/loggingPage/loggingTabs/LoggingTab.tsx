"use client";

import Box from "@mui/material/Box";
import Tab from "@mui/material/Tab";
import TabContext from "@mui/lab/TabContext";
import TabList from "@mui/lab/TabList";
import TabPanel from "@mui/lab/TabPanel";
import { ReactNode } from "react";

export interface TabItem {
  id: string;
  label: string;
  component?: ReactNode;
}

export interface TabsProps {
  tabs: TabItem[];
  activeTab: string,
  onTabChange?: (tabId: string) => void;
  filters?: ReactNode;
}

export default function LoggingTab({ tabs, activeTab, onTabChange, filters }: TabsProps) {

  const handleChange = (_event: React.SyntheticEvent, newValue: string) => {
    onTabChange?.(newValue);
  };

  return (
    <TabContext value={activeTab}>
      <div className=" flex items-center justify-between gap-4">
        <Box>
          <TabList
            onChange={handleChange}
            sx={{
              backgroundColor: "white",
              display: "inline-flex",
              gap: 1,
              p: 0.5,
              borderRadius: "14px",
              minHeight: "unset",
              "& .MuiTabs-indicator": { display: "none" },
            }}
          >
            {tabs.map((tab) => (
              <Tab
                key={tab.id}
                label={tab.label}
                value={tab.id}
                disableRipple
                sx={{
                  minHeight: "unset",
                  height: 40,
                  px: 2,
                  py: 1.2,
                  minWidth: 140,
                  borderRadius: "12px",
                  fontSize: "14px",
                  fontWeight: 400,
                  textTransform: "none",
                  color: "#111827",
                  transition: "all 0.2s ease",
                  fontFamily: "var(--font-johnson-text)",
                  "&:hover": { backgroundColor: "#f8f5f2", color: "#e8472a" },
                  "&.Mui-selected": {
                    backgroundColor: "#f8f5f2",
                    color: "#d92d20",
                    fontWeight: 600,
                  },
                }}
              />
            ))}
          </TabList>
        </Box>
        {filters && (
          <div className=" flex items-center gap-3">
            {filters}
          </div>
        )}
      </div>
      <TabPanel value={activeTab} sx={{ p: 2, pl: 0 }}>
        {tabs.find((tab) => tab.id === activeTab)?.component}
      </TabPanel>
    </TabContext>
  );
}


