import { useState } from "react";
import { Popover, Box, IconButton, Typography } from "@mui/material";
import { X } from "lucide-react";
import { ChevronRight, ChevronDown } from "lucide-react";

interface JsonCellProps {
  value: any;
}

const JsonCell = ({ value }: JsonCellProps) => {
  const [anchorEl, setAnchorEl] = useState<HTMLButtonElement | null>(null);
  const [expanded, setExpanded] = useState(false);


  const isEmpty =
    !value ||
    (typeof value === "object" && Object.keys(value).length === 0);

  if (isEmpty) {
    return (
      <span className="text-gray-400 text-xs px-2">{">{}"}</span>
    );
  }

  const handleOpen = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.stopPropagation();
    setAnchorEl(e.currentTarget);
    setExpanded(!expanded);
  };

  const handleClose = () => {
    setExpanded(!expanded);
    setAnchorEl(null);
  }
  const open = Boolean(anchorEl);

  return (
    <>
      <IconButton
        size="small"
        onClick={handleOpen}
        sx={{
       
          fontSize: "12px",
          text:"text-gray-400",
        }}
      >
        {expanded ? (
          <ChevronDown size={12} />
        ) : (
          <ChevronRight size={12} />
        )}
        <span className="font-bold">{"{…}"}</span>
      </IconButton>

      <Popover
        open={open}
        anchorEl={anchorEl}
        onClose={handleClose}
        // anchorReference="anchorPosition"
        anchorOrigin={{ vertical: "bottom", horizontal: "left" }}
        // anchorPosition={{top: window.innerHeight / 2, left: window.innerWidth / 2}}
        transformOrigin={{ vertical: "top", horizontal: "left" }}
        slotProps={{
          paper: {
            sx: {
              borderRadius: "8px",
              boxShadow: "0 4px 20px rgba(0,0,0,0.15)",
              border: "1px solid #e5e7eb",

            },
          },
        }}
      >
        <Box sx={{ p: 1.5, minWidth: 260, maxWidth: 420 }}>
            <div className="flex justify-between items-center mb-1">
          <Typography
            variant="caption"
            sx={{ color: "#6b7280", fontWeight: 600, display: "block" }}
          >
            Values
          </Typography>
          <button onClick={handleClose}><X height="15px" width="15px" /></button>
          </div>
          <pre
            style={{
              margin: 0,
              padding: "10px 12px",
              borderRadius: 6,
              background: "#f8fafc",
              border: "1px solid #e2e8f0",
              fontSize: 12,
              lineHeight: 1.6,
              whiteSpace: "pre-wrap",
              wordBreak: "break-word",
              maxHeight: 320,
              overflowY: "auto",
              color: "#1e293b",
            }}
          >
            {JSON.stringify(value, null, 2)}
          </pre>
        </Box>
      </Popover>
    </>
  );
};

export default JsonCell;
