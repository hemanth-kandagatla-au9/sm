'use client';

import { DataGrid, GridColDef, useGridApiRef } from '@mui/x-data-grid';
import Chip from '@mui/material/Chip';
import Tooltip from '@mui/material/Tooltip';
import { gridSx } from '../../../common/Helper'
import { useEffect } from 'react';
import { useUnauthorisedActivity } from '@/services/logServices/useUnauthorisedAcitvity';
import { formatConversationDate } from "@/lib/utils";

interface Props {
  globalSearch: string
}

const columns: GridColDef[] = [
  {
    field: 'log_id',
    headerName: 'Log ID',
    width: 180,
    renderCell: (params) => (
      <Tooltip title={params.value as string}>
        <span className="text-[#4C5463] font-semibold truncate block max-w-[160px]">
          {(params.value as string)?.slice(0, 14)}…
        </span>
      </Tooltip>
    ),
  },
  {
    field: 'user_name',
    headerName: 'User Name',
    width: 200,
  },
  {
    field: 'user_email',
    headerName: 'User Email',
    width: 240,
    renderCell: (params) => (
      <Tooltip title={params.value as string}>
        <span className="truncate block">
          {params.value as string}
        </span>
      </Tooltip>
    ),
  },
  {
    field: 'occurred_at',
    headerName: 'Occurred At',
    width: 180,
    renderCell: (params) => formatConversationDate(params.value as string, true),
  },
  {
    field: 'resource_type',
    headerName: 'Resource Type',
    width: 160,
  },
  {
    field: 'resource_id',
    headerName: 'Resource ID',
    width: 180,
    renderCell: (params) => (
      <Tooltip title={params.value as string}>
        <span className="text-[#4C5463] truncate block max-w-[160px]">
          {(params.value as string)?.slice(0, 14)}…
        </span>
      </Tooltip>
    ),
  },
  {
    field: 'resource_name',
    headerName: 'Resource Name',
    width: 220,
    renderCell: (params) => (
      <Tooltip title={params.value as string}>
        <span className="truncate block">
          {params.value as string}
        </span>
      </Tooltip>
    ),
  },
  {
    field: 'project_id',
    headerName: 'Project ID',
    width: 180,
    renderCell: (params) => (
      <Tooltip title={params.value as string}>
        <span className="truncate block max-w-[160px]">
          {(params.value as string)?.slice(0, 14)}…
        </span>
      </Tooltip>
    ),
  },
  {
    field: 'attempted_action',
    headerName: 'Attempted Action',
    width: 180,
    renderCell: (params) => {
      const val = (params.value as string) ?? '';

      return (
        <Chip
          label={val}
          size="small"
          sx={{
            backgroundColor: '#EEF2FF',
            color: '#3730A3',
            border: '1px solid #C7D2FE',
            fontWeight: 600,
            fontSize: '12px',
            height: 22,
          }}
        />
      );
    },
  },
  {
    field: 'denial_reason',
    headerName: 'Denial Reason',
    flex: 1,
    minWidth: 250,
    renderCell: (params) => (
      <Tooltip title={params.value as string}>
        <span className="truncate block text-[#DC2626]">
          {params.value as string}
        </span>
      </Tooltip>
    ),
  },
  {
    field: 'request_path',
    headerName: 'Request Path',
    flex: 1,
    minWidth: 250,
    renderCell: (params) => (
      <Tooltip title={params.value as string}>
        <span className="truncate block text-gray-600">
          {params.value as string}
        </span>
      </Tooltip>
    ),
  },
];

export default function UnauthorizedActivityTab({ globalSearch }: Props) {

  const apiRef = useGridApiRef();
  useEffect(() => {
    if (apiRef.current) {
      apiRef.current.setQuickFilterValues([globalSearch]);
    }
  }, [globalSearch, apiRef]);

  const { rows, total, page, pageSize, loading, setPage, setPageSize } = useUnauthorisedActivity();
  return (
    <div className="space-y-0">
      <DataGrid
        rows={rows}
        columns={columns}
        getRowId={(r) => r.log_id}
        apiRef={apiRef}
        loading={loading}
        rowCount={total}
        paginationMode="server"
        paginationModel={{ page, pageSize }}
        onPaginationModelChange={(model) => {
          setPage(model.page);
          setPageSize(model.pageSize);
        }}
        pageSizeOptions={[10, 25, 50]}
        rowHeight={35}
        columnHeaderHeight={45}
        disableRowSelectionOnClick
        disableColumnSelector
        disableColumnResize
        slotProps={{
          loadingOverlay: { variant: 'linear-progress', noRowsVariant: 'skeleton' },
        }}
        sx={gridSx}
      />
    </div>
  );
}
