"use client";

import { DataGrid, GridColDef, useGridApiRef } from "@mui/x-data-grid";
import Tooltip from "@mui/material/Tooltip";
import { useSessionActivity } from "@/services/logServices/useSessionActivity";
import { gridSx, renderDataGridChip } from "../../../common/Helper";
import { useEffect } from "react";
import { formatConversationDate } from "@/lib/utils";

interface Props {
  globalSearch: string;
}

const columns: GridColDef[] = [
  {
    field: "log_id",
    headerName: "Log ID",
    minWidth: 180,
    flex: 1,
    type:"longText"
  },
  {
    field: "user_name_snapshot",
    headerName: "User Name",
    minWidth: 240,
    flex: 1,
    valueFormatter: (value) => value ?? "--",
  },
  {
    field: "user_email_snapshot",
    headerName: "User Email",
    minWidth: 220,
    flex: 1,
    valueFormatter: (value) => value ?? "--",
  },
  {
    field: "action",
    headerName: "Action",
    width: 110,
    renderCell: (params) => renderDataGridChip(params.value),
  },
  {
    field: "login_on",
    headerName: "Login Time",
    minWidth: 190,
    flex: 1,
    renderCell: (params) =>
      params.value == null
        ? "--"
        : formatConversationDate(params.value as string, true),
  },
  {
    field: "logout_on",
    headerName: "Logout Time",
    minWidth: 190,
    flex: 1,
    renderCell: (params) =>
      params.value == null
        ? "--"
        : formatConversationDate(params.value as string, true),
  },
  {
    field: "logout_type",
    headerName: "Logout Type",
    minWidth: 140,
    renderCell: (params) => renderDataGridChip(params.value),
  },
];

export default function SessionActivityTab({ globalSearch }: Props) {
  const apiRef = useGridApiRef();
  useEffect(() => {
    if (apiRef.current) {
      apiRef.current.setQuickFilterValues([globalSearch]);
    }
  }, [globalSearch, apiRef]);

  const { rows, total, page, pageSize, loading, setPage, setPageSize } =
    useSessionActivity();

  return (
    <div className="space-y-0">
      <DataGrid
        rows={rows}
        columns={columns}
        getRowId={(r) => r.log_id}
        apiRef={apiRef}
        loading={loading}
        rowCount={total}
        paginationMode="server"
        paginationModel={{ page, pageSize }}
        onPaginationModelChange={(model) => {
          setPage(model.page);
          setPageSize(model.pageSize);
        }}
        pageSizeOptions={[10, 25, 50]}
        rowHeight={35}
        columnHeaderHeight={45}
        disableRowSelectionOnClick
        disableColumnSelector
        disableColumnResize
        slotProps={{
          loadingOverlay: {
            variant: "linear-progress",
            noRowsVariant: "skeleton",
          },
        }}
        sx={{ ...gridSx, height: "calc(100vh - 325px)" }}
      />
    </div>
  );
}
