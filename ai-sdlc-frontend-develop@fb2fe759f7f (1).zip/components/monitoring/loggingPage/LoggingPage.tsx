"use client";

import { Download } from "lucide-react";
import { useCallback, useState } from "react";
import TableSearchBar from "@/components/resuable-components/TableSearchBar";
import LoggingTab from "./loggingTabs/LoggingTab";
import { TabItem } from "./loggingTabs/LoggingTab";
import ChangeHistoryTab from "./loggingTabs/ChangeHistoryTab";
import SessionActivityTab from "./loggingTabs/SessionActivityTab";
import UnauthorizedActivityTab from "./loggingTabs/UnauthorizedActivityTab";
import axiosInstance from "@/lib/api/axiosInstance";

const TAB_EXPORT_CONFIG: Record<
  string,
  {
    exportUrl: string;
    fileName: string;
  }
> = {
  "change-history": {
    exportUrl: "/logs/change-history/export",
    fileName: "change-history",
  },
  "session-activity": {
    exportUrl: "/logs/session-activity/export",
    fileName: "session-activity",
  },
  "unauthorized-activity": {
    exportUrl: "/logs/unauthorized-activity/export",
    fileName: "unauthorized-activity",
  },
};


const LoggingPage = () => {

  const [globalSearch, setGlobalSearch] = useState("");
  const [activeTab, setActiveTab] = useState("change-history");
  const [downloading, setDownloading] = useState(false);

  const handleDownload = useCallback(async () => {
    const currentTabConfig = TAB_EXPORT_CONFIG[activeTab];

    if (!currentTabConfig) return;

    setDownloading(true);

    try {
      const response = await axiosInstance.get(
        currentTabConfig.exportUrl,
        {
          responseType: "blob",
        }
      );

      const blob = new Blob([response.data]);
      const downloadUrl = window.URL.createObjectURL(blob);

      const link = document.createElement("a");

      link.href = downloadUrl;
      link.download = `${currentTabConfig.fileName
        }-${new Date().toISOString().slice(0, 10)}.csv`;

      document.body.appendChild(link);

      link.click();

      document.body.removeChild(link);

      window.URL.revokeObjectURL(downloadUrl);
    } catch (error) {
      console.error("File download failed:", error);
    } finally {
      setDownloading(false);
    }
  }, [activeTab]);


  const tabItems: TabItem[] = [
    {
      id: "change-history",
      label: "Change History",
      component:
        activeTab === "change-history" ? (
          <ChangeHistoryTab globalSearch={globalSearch} />
        ) : null,
    },
    {
      id: "session-activity",
      label: "Session Activity",
      component:
        activeTab === "session-activity" ? (
          <SessionActivityTab globalSearch={globalSearch} />
        ) : null,
    },
    // {
    //   id: "unauthorized-activity",
    //   label: "Unauthorized Activity",
    //   component:
    //     activeTab === "unauthorized-activity" ? (
    //       <UnauthorizedActivityTab globalSearch={globalSearch} />
    //     ) : null,
    // },
  ];

  return (
    <div className="space-y-3">
      <h1 style={{ fontSize: "1.4rem", color: "#5c534c", fontWeight: "500", fontFamily: "var(--app-font-display)" }}>
        Logs
      </h1>
      <LoggingTab
        tabs={tabItems}
        activeTab={activeTab}
        onTabChange={setActiveTab}
        filters={
          <>
            <button
              className="flex items-center gap-1.5 px-3 h-9 text-[14px]  font-[var(--font-johnson-text)] rounded-lg border border-gray-200 bg-white hover:bg-gray-50 text-[#000000] transition-colors"
              title="Export"
              onClick={handleDownload}
              disabled={downloading}
            >
              <Download className="w-3.5 h-3.5" />
              {downloading ? "Downloading..." : "Download"}
            </button>

            <TableSearchBar
              globalSearch={globalSearch}
              setGlobalSearch={setGlobalSearch}
            />
          </>
        }
      />
    </div>
  );
};

export default LoggingPage;