"use client";

import { Box } from "@mui/material";
import CustomTab, { TabItem } from "../resuable-components/CustomTab";
import LoggingPage from "./loggingPage/LoggingPage";
import MonitorPage from "./monitoringPage.tsx/MonitorPage";

const MonitoringLayout = () => {
  const tabItems: TabItem[] = [
    {
      id: "monitoring",
      label: "Monitoring",
      component: <MonitorPage />,
    },
    {
      id: "logs",
      label: "Logs",
      component: <LoggingPage />,
    },
    {
      id: "temporal",
      label: "Temporal UI",
      component: (
        <Box sx={{ height: "calc(100vh - 200px)", width: "100%" }}>
          <iframe
            title="Temporal UI"
            src={process.env.NEXT_PUBLIC_TEMPORAL_URL}
            className="w-full h-full border-0 bg-white"
          />
        </Box>
      ),
    },
  ];

  return <CustomTab tabs={tabItems} />;
};

export default MonitoringLayout;
