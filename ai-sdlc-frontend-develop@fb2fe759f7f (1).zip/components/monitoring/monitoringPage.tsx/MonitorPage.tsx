import { DataGrid, GridColDef } from "@mui/x-data-grid";
import {Download } from "lucide-react";
import { gridSx, renderDataGridChip, ResourceTypeCell } from "@/components/common/Helper";
import { useMonitoringLogs } from "@/services/logServices/useMonitoringLogs";
import axiosInstance from "@/lib/api/axiosInstance";
import { useCallback, useState } from "react";
import { formatConversationDate } from "@/lib/utils";

const columns: GridColDef[] = [
  {
    field: "runId",
    headerName: "Run ID",
    minWidth: 250,
    valueFormatter: (value) => value ?? "--",
    flex: 1,
    type:"longText"
  },
  {
    field: "resourceName",
    headerName: "Resource Name",
    minWidth: 200,
    valueFormatter: (value) => value ?? "--",
    flex: 0.8,
    type:"longText"
  },
  {
    field: "resourceType",
    headerName: "Resource Type",
    minWidth: 150,
    flex: 0.7,
    renderCell: (params) => (
      <ResourceTypeCell value={String(params.value ?? "--")} />
    ),
  },

  {
    field: "userId",
    headerName: "User ID",
    minWidth: 130,
    valueFormatter: (value) => {
      if (value === null || value === undefined || value === "") {
        return "--"
      }
      return value;
    },
    flex: 0.5
  },
  {
    field: "projectId",
    headerName: "Project ID",
    minWidth: 150,
    valueFormatter: (value) => value ?? "--",
  },
  {
    field: "roleName",
    headerName: "Role Name",
    minWidth: 150,
    valueFormatter: (value) => value ?? "--",
  },
  {
    field: "status",
    headerName: "Status",
    minWidth: 150,
    renderCell: (params) => renderDataGridChip(params.value),
  },
  {
    field: "startTime",
    headerName: "Start Time",
    minWidth: 180,
    renderCell: (params) =>
      params.value == null
        ? "--"
        : formatConversationDate(params.value as string, true),
    flex: 0.7
  },
  {
    field: "endTime",
    headerName: "End Date",
    minWidth: 250,
    renderCell: (params) =>
      params.value == null
        ? "--"
        : formatConversationDate(params.value as string, true),
    flex: 1,
  },
];

const MonitorPage = () => {
  const { rows, total, page, pageSize, loading, setPage, setPageSize } =
    useMonitoringLogs();
  const [downloading, setDownloading] = useState(false);

  const handleDownload = useCallback(async () => {
    setDownloading(true);

    try {
      const response = await axiosInstance.get("/monitoring/table/export", {
        responseType: "blob",
      });

      const blob = new Blob([response.data]);
      const downloadUrl = window.URL.createObjectURL(blob);

      const link = document.createElement("a");

      link.href = downloadUrl;
      link.download = `monitoring-logs-${new Date().toISOString().slice(0, 10)}.csv`;

      document.body.appendChild(link);

      link.click();

      document.body.removeChild(link);

      window.URL.revokeObjectURL(downloadUrl);
    } catch (error) {
      console.error("File download failed:", error);
    } finally {
      setDownloading(false);
    }
  }, []);

  return (
    <div>
      <div className=" flex justify-between mt-2">
        <h1 style={{ fontSize: "1.4rem", color: "#5c534c", fontWeight: "500", fontFamily: "var(--app-font-display)" }}>
          Monitoring
        </h1>
        <button
          className="flex items-center gap-1.5 px-3 h-9 text-[14px] rounded-lg border border-gray-200 bg-white text-[#000000] transition-colors"
          title="Export"
          onClick={handleDownload}
          disabled={downloading}>
          <Download className="w-3.5 h-3.5" />
          {downloading ? "Downloading..." : "Download"}
        </button>
      </div>
      <div className=" mt-4">

        <DataGrid
          rows={rows}
          columns={columns}
          getRowId={(r) => r.runId}
          loading={loading}
          rowCount={total}
          paginationMode="server"
          paginationModel={{ page, pageSize }}
          onPaginationModelChange={(model) => {
            setPage(model.page);
            setPageSize(model.pageSize);
          }}
          pageSizeOptions={[10, 25, 50]}
          rowHeight={35}
          columnHeaderHeight={45}
          disableRowSelectionOnClick
          disableColumnSelector
          disableColumnResize
          slotProps={{
            loadingOverlay: {
              variant: "linear-progress",
              noRowsVariant: "skeleton",
            },
          }}
          sx={{ ...gridSx, height: "calc(100vh - 250px)" }}
        />

      </div>
    </div>
  );
};

export default MonitorPage;
