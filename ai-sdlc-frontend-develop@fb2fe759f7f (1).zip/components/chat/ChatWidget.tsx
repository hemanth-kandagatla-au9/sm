"use client";

import React from "react";
import { useState } from "react";
import ChatArea from "@/components/chatBoard/ChatArea";
import ChatSideBar from "@/components/chatBoard/ChatSideBar";
import {
  useChatConversations,
  useChatSession,
} from "@/services/chat/useChatSession";
import type { ChatUiMessage } from "@/services/chat/types";

export type { ChatUiMessage };

export interface ChatWidgetProps {
  projectId?: string;
  workflowId?: string;
  projectName?: string;
  userName: string;
  userPhotoUrl?: string | null;
  /** Show conversation sidebar (default: true) */
  showSidebar?: boolean;
  isSidebarOpen?: boolean;
  onToggleSidebar?: () => void;
  /** Optional slot for panels beside the chat area (e.g. right panel) */
  panelSlot?: React.ReactNode;
}

export default function ChatWidget({
  projectId,
  workflowId,
  projectName,
  userName,
  userPhotoUrl,
  showSidebar = true,
  isSidebarOpen = true,
  onToggleSidebar,
  panelSlot,
}: ChatWidgetProps) {
  const [
    isIntegrationFlowGovernanceActive,
    setIsIntegrationFlowGovernanceActive,
  ] = useState(false);
  const {
    messages,
    agentGroups,
    isLoadingWorkflows,
    activeWorkflowId,
    showWelcomePrompts,
    loadingHistoryWorkflowId,
    isSendingMessage,
    isAwaitingUpload,
    iwandUploadDone,
    showFileUpload,
    sidebarRefreshTrigger,
    sasaIframeUrl,
    clearSasaIframe,
    handleConversationSelect,
    handleSuggestedPromptClick,
    handleAgentClick,
    handleFileUpload,
    handleNewChat,
    handleSendMessage,
    handleMessageFeedback,
  } = useChatSession({ projectId, initialWorkflowId: workflowId });

  const { conversations, isLoadingConversations } = useChatConversations(
    projectId,
    sidebarRefreshTrigger,
  );

  return (
    <div className="flex flex-1 w-full h-full min-w-0">
      {showSidebar && onToggleSidebar && (
        <ChatSideBar
          isOpen={isSidebarOpen}
          toggleChatSidebar={onToggleSidebar}
          onNewChat={() => {
            setIsIntegrationFlowGovernanceActive(false);
            clearSasaIframe();
            handleNewChat();
          }}
          selectedWorkflowId={activeWorkflowId}
          loadingHistoryWorkflowId={loadingHistoryWorkflowId}
          onConversationSelect={(id) => {
            setIsIntegrationFlowGovernanceActive(false);
            clearSasaIframe();
            handleConversationSelect(id);
          }}
          conversations={conversations}
          isLoadingConversations={isLoadingConversations}
          onIntegrationFlowGovernanceClick={() => {
            clearSasaIframe();
            setIsIntegrationFlowGovernanceActive(true);
          }}
          isIntegrationFlowGovernanceActive={isIntegrationFlowGovernanceActive}
          onSuggestedPromptClick={handleSuggestedPromptClick}
          onAgentClick={handleAgentClick}
          agentGroups={agentGroups}
          isLoadingWorkflows={isLoadingWorkflows}
        />
      )}
      <div className="flex-1 flex h-full min-w-0 relative pl-4">
        {sasaIframeUrl ? (
          <iframe
            title="SASA"
            src={sasaIframeUrl}
            className="w-full h-full border-0 bg-white"
          />
        ) : isIntegrationFlowGovernanceActive ? (
          <iframe
            title="Integration Flow Governance"
            src={process.env.NEXT_PUBLIC_INTEGRATION_FLOW_GOVERNANCE_URL}
            className="w-full h-full border-0 bg-white"
          />
        ) : (
          <>
            <ChatArea
              userName={userName}
              userPhotoUrl={userPhotoUrl}
              title={projectName}
              messages={messages}
              isSendingMessage={isSendingMessage}
              isAwaitingUpload={isAwaitingUpload}
              inputDisabled={iwandUploadDone}
              showFileUpload={showFileUpload}
              onSuggestedPromptClick={handleSuggestedPromptClick}
              onAgentClick={handleAgentClick}
              onFileUpload={handleFileUpload}
              onSendMessage={handleSendMessage}
              onMessageFeedback={handleMessageFeedback}
              showAgentGroups={showWelcomePrompts}
              agentGroups={agentGroups}
              isLoadingWorkflows={isLoadingWorkflows}
              onNewChat={() => {
                setIsIntegrationFlowGovernanceActive(false);
                clearSasaIframe();
                handleNewChat();
              }}
            />
            {panelSlot}
          </>
        )}
      </div>
    </div>
  );
}
