"use client";

import { Check, Circle } from "lucide-react";
import {
  DASHBOARD_CUSTOMIZATION_SECTIONS,
  type DashboardCustomizationKey,
  type DashboardCustomizationState,
} from "@/components/dashboard/role-admin/dashboard-data";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { Switch } from "@/components/ui/switch";

type DashboardCustomizeSheetProps = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  preferences: DashboardCustomizationState;
  onPreferenceChange: (
    key: DashboardCustomizationKey,
    checked: boolean,
  ) => void;
};

export function AdminDashboardCustomizeSheet({
  open,
  onOpenChange,
  preferences,
  onPreferenceChange,
}: DashboardCustomizeSheetProps) {
  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent
        side="right"
        className="inset-y-auto top-2 right-2 bottom-2 w-[calc(100vw-1rem)] rounded-[1.75rem] border border-black/8 bg-white p-0 shadow-[0_24px_70px_rgba(17,24,39,0.14)] sm:max-w-[360px]">
        <SheetHeader className="border-b border-[rgba(203,222,255,1)] px-5 pb-5 pt-5">
          <SheetTitle className="font-display text-[1.05rem] font-semibold text-[var(--jnj-ink)]">
            Customize Dashboard
          </SheetTitle>
          <SheetDescription className="pt-4 text-sm font-medium text-[#5f5d57]">
            Toggle to view and Pin your preferences for future
          </SheetDescription>
        </SheetHeader>

        <div className="space-y-7 overflow-y-auto px-5 py-5">
          {DASHBOARD_CUSTOMIZATION_SECTIONS.map((section) => (
            <div key={section.title} className="space-y-3.5">
              <h4 className="text-base font-normal text-[#999791]">
                {section.title}
              </h4>

              <div className="space-y-3">
                {section.items.map((item) => {
                  const checked = preferences[item.key];

                  return (
                    <div
                      key={item.key}
                      className="flex items-start justify-between gap-4">
                      <div className="flex items-start gap-3">
                        <span className="mt-0.5 flex size-5 items-center justify-center">
                          {checked ? (
                            <span className="flex size-5 items-center justify-center rounded-full bg-[#4b5563] text-white">
                              <Check className="size-3.5" />
                            </span>
                          ) : (
                            <Circle className="size-5 text-[#cfcac4]" />
                          )}
                        </span>

                        <div className="space-y-1">
                          <p className="font-display text-[0.95rem] font-medium text-[var(--jnj-ink)]">
                            {item.title}
                          </p>
                          {item.subtitle ? (
                            <p className="text-[13px] leading-5 text-[#a09e99]">
                              {item.subtitle}
                            </p>
                          ) : null}
                        </div>
                      </div>

                      <Switch
                        checked={checked}
                        onCheckedChange={(value) =>
                          onPreferenceChange(item.key, value)
                        }
                        className="data-checked:bg-[rgba(14,141,74,1)] data-unchecked:bg-[#d7d2cc]"
                      />
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </SheetContent>
    </Sheet>
  );
}
