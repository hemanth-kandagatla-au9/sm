"use client";

import { ArrowUpRight, ChevronDown, ChevronUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { ROI_DETAIL_ITEMS } from "@/components/dashboard/role-admin/dashboard-data";

type RoiAnalyticsCardProps = {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
};

export function AdminRoiAnalyticsCard({
  isOpen,
  onOpenChange,
}: RoiAnalyticsCardProps) {
  return (
    <Card className="gap-0 rounded-[1.75rem] bg-white py-0 shadow-[0px_4px_12px_0px_rgba(213,213,213,0.16)] ring-black/4">
      <CardHeader className="grid-cols-[1fr_auto] gap-y-3 px-5 pt-5 sm:px-6 sm:pt-6">
        <div>
          <CardTitle className="text-[1.05rem] font-semibold text-[var(--jnj-ink)]">
            Return On Investment
          </CardTitle>
          <CardDescription className="mt-1 text-[13px] text-[#5f5d57]">
            Business Value Metrics
          </CardDescription>
        </div>

        <div className="flex flex-col items-end gap-8">
          <div className="flex size-11 items-center justify-center rounded-2xl bg-[rgba(14,141,74,1)] text-white shadow-[0px_4px_12px_0px_rgba(213,213,213,0.16)]">
            <ArrowUpRight className="size-5" />
          </div>

          <div className="inline-flex items-center gap-1.5 rounded-full bg-white px-3 py-1 text-sm font-medium text-[rgba(14,141,74,1)] shadow-[0px_4px_12px_0px_rgba(213,213,213,0.16)]">
            <ArrowUpRight className="size-3.5" />
            15%
          </div>
        </div>
      </CardHeader>

      <CardContent className="px-5 pb-5 pt-3 sm:px-6 sm:pb-6">
        <p className="font-display text-[4rem] leading-none font-medium tracking-[-0.05em] text-[rgba(14,141,74,1)]">
          190%
        </p>
        <p className="mt-5 text-[15px] font-medium text-[#9a9892]">
          Current Month vs Previous Month
        </p>

        <Collapsible
          open={isOpen}
          onOpenChange={onOpenChange}
          className="mt-5 rounded-[1.2rem] bg-[#fbfbfa]"
        >
          <CollapsibleTrigger asChild>
            <Button
              type="button"
              variant="ghost"
              className="h-12 w-full justify-between rounded-[1.2rem] px-4 text-sm font-medium text-[#4b4a46] hover:bg-[#f5f4f2]"
            >
              {isOpen ? "View less details" : "View more details"}
              {isOpen ? (
                <ChevronUp className="size-4" />
              ) : (
                <ChevronDown className="size-4" />
              )}
            </Button>
          </CollapsibleTrigger>

          <CollapsibleContent className="data-[state=closed]:animate-out data-[state=open]:animate-in data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0">
            <div className="space-y-4 px-3 pb-3 pt-1">
              <div className="grid gap-3 md:grid-cols-3">
                {ROI_DETAIL_ITEMS.map((item) => (
                  <Card
                    key={item.label}
                    className="gap-0 rounded-[1.25rem] bg-white py-0 shadow-[0px_4px_12px_0px_rgba(213,213,213,0.12)] ring-black/5"
                  >
                    <CardContent className="px-4 py-4 text-center">
                      <p className="text-[2rem] leading-none font-medium tracking-[-0.03em] text-[var(--jnj-ink)]">
                        {item.value}
                      </p>
                      <p className="mt-3 text-[13px] font-medium text-[#7b7973]">
                        {item.label}
                      </p>
                    </CardContent>
                  </Card>
                ))}
              </div>

              <Card className="gap-0 rounded-[1.25rem] bg-white py-0 shadow-[0px_4px_12px_0px_rgba(213,213,213,0.1)] ring-black/5">
                <CardContent className="px-4 py-4">
                  <p className="text-sm font-medium text-[#8d8a84]">Calculation</p>
                  <p className="mt-3 text-lg font-medium text-[var(--jnj-ink)]">
                    (Hours Saved × $100/hr) ÷ Platform Cost
                  </p>
                </CardContent>
              </Card>
            </div>
          </CollapsibleContent>
        </Collapsible>
      </CardContent>
    </Card>
  );
}
