"use client";

import { CalendarDays } from "lucide-react";
import { AdminDashboardSelectMenu } from "@/components/dashboard/role-admin/AdminDashboardSelectMenu";
import {
  DATE_OPTIONS,
  SMALL_ANALYTICS_CARDS,
  type DashboardCustomizationState,
} from "@/components/dashboard/role-admin/dashboard-data";
import { AdminAccelerationGainCard } from "@/components/dashboard/role-admin/AdminAccelerationGainCard";
import { AdminHumanInterventionCard } from "@/components/dashboard/role-admin/AdminHumanInterventionCard";
import { AdminRoiAnalyticsCard } from "@/components/dashboard/role-admin/AdminRoiAnalyticsCard";
import { SmallAnalyticsCard } from "@/components/dashboard/role-admin/SmallAnalyticsCard";

type OverallAnalyticsSectionProps = {
  selectedDate: string;
  onDateChange: (option: string) => void;
  isRoiExpanded: boolean;
  onRoiOpenChange: (open: boolean) => void;
  preferences: DashboardCustomizationState;
};

export function OverallAnalyticsSection({
  selectedDate,
  onDateChange,
  isRoiExpanded,
  onRoiOpenChange,
  preferences,
}: OverallAnalyticsSectionProps) {
  const visibleSmallCards = SMALL_ANALYTICS_CARDS.filter(
    (card) => preferences[card.key],
  );

  return (
    <div className="flex flex-col gap-5">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <h3 className="text-[2rem] font-medium leading-none tracking-tight text-[var(--jnj-ink)]">
          Overall Analytics
        </h3>

        <AdminDashboardSelectMenu
          icon={CalendarDays}
          label={selectedDate}
          menuLabel="Date Range"
          options={DATE_OPTIONS}
          onSelect={onDateChange}
          triggerClassName="shadow-[0px_4px_12px_0px_rgba(213,213,213,0.16)]"
        />
      </div>

      {preferences.returnOnInvestment || preferences.humanIntervention ? (
        <div className="grid gap-5 xl:grid-cols-[minmax(0,0.92fr)_minmax(0,1.08fr)]">
          {preferences.returnOnInvestment ? (
            <AdminRoiAnalyticsCard
              isOpen={isRoiExpanded}
              onOpenChange={onRoiOpenChange}
            />
          ) : null}
          {preferences.humanIntervention ? <AdminHumanInterventionCard /> : null}
        </div>
      ) : null}

      {preferences.accelerationGain ? <AdminAccelerationGainCard /> : null}

      {visibleSmallCards.length > 0 ? (
        <div className="grid gap-5 md:grid-cols-2 2xl:grid-cols-4">
          {visibleSmallCards.map((card) => (
            <SmallAnalyticsCard
              key={card.title}
              title={card.title}
              subtitle={card.subtitle}
              value={card.value}
              description={card.description}
              delta={card.delta}
              icon={card.icon}
              iconBackground={card.iconBackground}
            />
          ))}
        </div>
      ) : null}
    </div>
  );
}
