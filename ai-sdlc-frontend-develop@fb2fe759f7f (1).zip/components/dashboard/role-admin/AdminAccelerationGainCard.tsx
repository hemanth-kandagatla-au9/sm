"use client";

import { Area, AreaChart, CartesianGrid, XAxis, YAxis } from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from "@/components/ui/chart";
import {
  ACCELERATION_GAIN_DATA,
  accelerationGainChartConfig,
} from "@/components/dashboard/role-admin/dashboard-data";

export function AdminAccelerationGainCard() {
  return (
    <Card className="gap-0 rounded-[1.75rem] bg-white py-0 shadow-[0px_4px_12px_0px_rgba(213,213,213,0.16)] ring-black/4">
      <CardHeader className="gap-4 px-5 pb-0 pt-5 sm:px-6 sm:pt-6">
        <CardTitle className="text-[1.05rem] font-semibold text-[var(--jnj-ink)]">
          Acceleration Gain Over Time
        </CardTitle>
      </CardHeader>

      <CardContent className="px-2 pb-3 pt-2 sm:px-4 sm:pb-4">
        <ChartContainer
          config={accelerationGainChartConfig}
          className="min-h-[300px] w-full">
          <AreaChart
            accessibilityLayer
            data={ACCELERATION_GAIN_DATA}
            margin={{ left: 4, right: 18, top: 16, bottom: 8 }}>
            <defs>
              <linearGradient id="accelerationFill" x1="0" y1="0" x2="0" y2="1">
                <stop
                  offset="0%"
                  stopColor="var(--color-delivery)"
                  stopOpacity={0.35}
                />
                <stop
                  offset="100%"
                  stopColor="var(--color-delivery)"
                  stopOpacity={0.04}
                />
              </linearGradient>
            </defs>
            <CartesianGrid vertical strokeDasharray="3 3" />
            <XAxis
              dataKey="month"
              tickLine={false}
              axisLine={false}
              tickMargin={10}
            />
            <YAxis
              tickLine={false}
              axisLine={false}
              tickMargin={10}
              width={42}
              domain={[0, 100]}
              tickFormatter={(value) => `${value}%`}
            />
            <ChartTooltip
              cursor={false}
              content={
                <ChartTooltipContent
                  indicator="line"
                  className="rounded-xl border-black/8 bg-white shadow-[0px_10px_24px_0px_rgba(17,24,39,0.12)]"
                />
              }
            />
            <Area
              dataKey="delivery"
              type="monotone"
              stroke="var(--color-delivery)"
              strokeWidth={2.5}
              fill="url(#accelerationFill)"
              style={{
                filter:
                  "drop-shadow(0px 3px 3px rgba(14, 141, 74, 0.5)) drop-shadow(0px 8px 18px rgba(14, 141, 74, 0.16))",
              }}
            />
          </AreaChart>
        </ChartContainer>
      </CardContent>
    </Card>
  );
}
