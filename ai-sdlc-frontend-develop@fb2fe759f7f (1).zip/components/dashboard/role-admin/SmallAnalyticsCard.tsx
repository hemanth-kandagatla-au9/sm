"use client";

import { ArrowUpRight, ChevronDown, ChevronUp, type LucideIcon } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { cn } from "@/lib/utils";

type SmallAnalyticsCardProps = {
  title: string;
  subtitle: string;
  value: string;
  description: string;
  delta: string;
  icon: LucideIcon;
  iconBackground: string;
};

export function SmallAnalyticsCard({
  title,
  subtitle,
  value,
  description,
  delta,
  icon: Icon,
  iconBackground,
}: SmallAnalyticsCardProps) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <Card className="gap-0 rounded-[1.6rem] bg-white py-0 shadow-[0px_4px_12px_0px_rgba(213,213,213,0.16)] ring-black/4">
      <CardHeader className="grid-cols-[1fr_auto] gap-y-3 px-5 pt-5 sm:px-6">
        <div>
          <CardTitle className="text-[1.05rem] font-semibold text-[var(--jnj-ink)]">
            {title}
          </CardTitle>
          <p className="mt-1 text-[13px] text-[#5f5d57]">{subtitle}</p>
        </div>

        <div
          className={cn(
            "flex size-11 items-center justify-center rounded-2xl text-white shadow-[0px_4px_12px_0px_rgba(213,213,213,0.16)]",
            iconBackground,
          )}
        >
          <Icon className="size-5" />
        </div>
      </CardHeader>

      <CardContent className="px-5 pb-5 pt-3 sm:px-6 sm:pb-6">
        <div className="flex items-start justify-between gap-4">
          <div>
            <p className="font-display text-[2.35rem] leading-none font-medium tracking-[-0.04em] text-[var(--jnj-ink)]">
              {value}
            </p>
            <p className="mt-4 text-[15px] font-medium text-[#9a9892]">
              {description}
            </p>
          </div>

          <div className="mt-1 inline-flex items-center gap-1.5 rounded-full bg-white px-3 py-1 text-sm font-medium text-[rgba(14,141,74,1)] shadow-[0px_4px_12px_0px_rgba(213,213,213,0.16)]">
            <ArrowUpRight className="size-3.5" />
            {delta}
          </div>
        </div>

        <Collapsible
          open={isOpen}
          onOpenChange={setIsOpen}
          className="mt-5 rounded-[1.2rem] bg-[#fbfbfa]"
        >
          <CollapsibleTrigger asChild>
            <Button
              type="button"
              variant="ghost"
              className="h-12 w-full justify-between rounded-[1.2rem] px-4 text-sm font-medium text-[#4b4a46] hover:bg-[#f5f4f2]"
            >
              {isOpen ? "View less details" : "View more details"}
              {isOpen ? (
                <ChevronUp className="size-4" />
              ) : (
                <ChevronDown className="size-4" />
              )}
            </Button>
          </CollapsibleTrigger>

          <CollapsibleContent className="data-[state=closed]:animate-out data-[state=open]:animate-in data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0">
            <div className="px-4 pb-4 pt-1 text-sm leading-6 text-[#6d6b65]">
              Metric details and drill-down content can continue in this card.
            </div>
          </CollapsibleContent>
        </Collapsible>
      </CardContent>
    </Card>
  );
}
