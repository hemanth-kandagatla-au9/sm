"use client";

// import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
// import { AuthGuard } from "@/components/auth/auth-guard";
import { AdminDashboardCustomizeSheet } from "@/components/dashboard/role-admin/AdminDashboardCustomizeSheet";
// import { DashboardHeader } from "@/components/dashboard/dashboard-header";
import { AdminDashboardHeroSection } from "@/components/dashboard/role-admin/AdminDashboardHeroSection";
import {
  CATEGORY_OPTIONS,
  DASHBOARD_CUSTOMIZATION_DEFAULTS,
  DATE_OPTIONS,
  type DashboardCustomizationKey,
  type DashboardCustomizationState,
} from "@/components/dashboard/role-admin/dashboard-data";
import { OverallAnalyticsSection } from "@/components/dashboard/role-admin/OverallAnalyticsSection";
// import { DashboardSidebar } from "@/components/dashboard/dashboard-sidebar";
import { getLoggedInUser } from "@/lib/auth/user-helper";

const DASHBOARD_PREFERENCES_KEY = "dashboard-customization:v1";

export function AdminDashboardContainer() {
  // const router = useRouter();
  // const [isSidebarExpanded, setIsSidebarExpanded] = useState(false);
  const [isCustomizeOpen, setIsCustomizeOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState(
    CATEGORY_OPTIONS[0]!,
  );
  const [selectedDate, setSelectedDate] = useState(DATE_OPTIONS[0]!);
  const [isRoiExpanded, setIsRoiExpanded] = useState(true);
  const [preferences, setPreferences] = useState<DashboardCustomizationState>(
    () => {
      if (typeof window === "undefined") {
        return DASHBOARD_CUSTOMIZATION_DEFAULTS;
      }

      try {
        const savedPreferences = window.localStorage.getItem(
          DASHBOARD_PREFERENCES_KEY,
        );

        return savedPreferences
          ? {
              ...DASHBOARD_CUSTOMIZATION_DEFAULTS,
              ...JSON.parse(savedPreferences),
            }
          : DASHBOARD_CUSTOMIZATION_DEFAULTS;
      } catch {
        return DASHBOARD_CUSTOMIZATION_DEFAULTS;
      }
    },
  );
  const user = getLoggedInUser();
  const displayName = user?.name ?? "Guest";
  const firstName = displayName.split(" ")[1] ?? "Guest";

  useEffect(() => {
    try {
      window.localStorage.setItem(
        DASHBOARD_PREFERENCES_KEY,
        JSON.stringify(preferences),
      );
    } catch {
      // Ignore local storage write failures.
    }
  }, [preferences]);

  const onPreferenceChange = (
    key: DashboardCustomizationKey,
    checked: boolean,
  ) => {
    setPreferences((current) => ({
      ...current,
      [key]: checked,
    }));
  };

  return (
    <main className="min-h-screen bg-[#f6f7f9] text-(--jnj-ink)">
      <AdminDashboardCustomizeSheet
        open={isCustomizeOpen}
        onOpenChange={setIsCustomizeOpen}
        preferences={preferences}
        onPreferenceChange={onPreferenceChange}
      />

      <div className="mx-auto flex w-full max-w-7xl flex-col gap-6">
        <AdminDashboardHeroSection
          firstName={firstName}
          selectedCategory={selectedCategory}
          onCategoryChange={setSelectedCategory}
          preferences={preferences}
          onOpenCustomize={() => setIsCustomizeOpen(true)}
        />

        <OverallAnalyticsSection
          selectedDate={selectedDate}
          onDateChange={setSelectedDate}
          isRoiExpanded={isRoiExpanded}
          onRoiOpenChange={setIsRoiExpanded}
          preferences={preferences}
        />
      </div>
    </main>
  );
}
