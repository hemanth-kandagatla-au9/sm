"use client";

import { ChevronDown, type LucideIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";

type DashboardSelectMenuProps = {
  icon?: LucideIcon;
  label: string;
  menuLabel: string;
  options: string[];
  onSelect: (option: string) => void;
  align?: "start" | "center" | "end";
  triggerClassName?: string;
  contentClassName?: string;
};

export function AdminDashboardSelectMenu({
  icon: Icon,
  label,
  menuLabel,
  options,
  onSelect,
  align = "end",
  triggerClassName,
  contentClassName,
}: DashboardSelectMenuProps) {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          type="button"
          variant="outline"
          className={cn(
            "h-11 rounded-2xl border-black/8 bg-white px-4 text-sm font-medium text-[var(--jnj-ink)] hover:bg-white",
            triggerClassName,
          )}
        >
          {Icon ? <Icon className="size-4 text-[#4b5563]" /> : null}
          <span className="text-[#4b5563]">{label}</span>
          <ChevronDown className="size-4 text-[#4b5563]" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align={align} className={cn("min-w-56", contentClassName)}>
        <DropdownMenuLabel>{menuLabel}</DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuGroup>
          {options.map((option) => (
            <DropdownMenuItem
              key={option}
              onClick={() => onSelect(option)}
              className={cn(label === option ? "bg-[#f6f4f1] text-[var(--jnj-ink)]" : "")}
            >
              {option}
            </DropdownMenuItem>
          ))}
        </DropdownMenuGroup>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
