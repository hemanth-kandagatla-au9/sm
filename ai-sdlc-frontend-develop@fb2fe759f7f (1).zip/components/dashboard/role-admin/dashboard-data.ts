import type { LucideIcon } from "lucide-react";
import {
  Bot,
  BriefcaseBusiness,
  CheckCheck,
  ClipboardList,
  Clock3,
  FolderClosed,
  FolderKanban,
  LayoutGrid,
  MessageSquareMore,
  Sparkles,
  Users,
  Zap,
} from "lucide-react";
import type { ChartConfig } from "@/components/ui/chart";

export type DashboardCustomizationKey =
  | "totalProjects"
  | "aiMaturity"
  | "totalAiAgents"
  | "returnOnInvestment"
  | "activeUsers"
  | "agentExecutions"
  | "successRate"
  | "timeSaved"
  | "humanIntervention"
  | "accelerationGain";

export type DashboardCustomizationState = Record<
  DashboardCustomizationKey,
  boolean
>;

type DashboardCustomizationSection = {
  title: string;
  items: Array<{
    key: DashboardCustomizationKey;
    title: string;
    subtitle?: string;
  }>;
};

export const NAV_ITEMS = [
  { label: "Overview", icon: LayoutGrid, active: true },
  { label: "Workflows", icon: ClipboardList },
  { label: "Programs", icon: FolderKanban },
  { label: "Agents", icon: Bot },
  { label: "Messages", icon: MessageSquareMore },
] satisfies Array<{
  label: string;
  icon: LucideIcon;
  active?: boolean;
}>;

export const CATEGORY_OPTIONS = [
  "Sort by Category",
  "Agent Performance",
  "Workflow Quality",
  "Risk Monitoring",
];

export const DASHBOARD_CUSTOMIZATION_DEFAULTS: DashboardCustomizationState = {
  totalProjects: true,
  aiMaturity: true,
  totalAiAgents: true,
  returnOnInvestment: true,
  activeUsers: true,
  agentExecutions: true,
  successRate: true,
  timeSaved: true,
  humanIntervention: true,
  accelerationGain: false,
};

export const HERO_METRICS = [
  {
    key: "totalProjects",
    value: "12",
    label: "Total Projects",
    description: "Total number of active initiatives currently running",
    icon: FolderClosed,
  },
  {
    key: "aiMaturity",
    value: "76%",
    label: "AI Maturity",
    description: "AI is embedded across the SDLC across all initiatives.",
    icon: Sparkles,
  },
  {
    key: "totalAiAgents",
    value: "132",
    label: "Total AI Agents",
    description: "Improvement in delivery speed driven by AI and automation",
    icon: Zap,
  },
] satisfies Array<{
  key: DashboardCustomizationKey;
  value: string;
  label: string;
  description: string;
  icon: LucideIcon;
}>;

export const DATE_OPTIONS = [
  "Sort by Date",
  "Last 30 Days",
  "Last Quarter",
  "Last 6 Months",
];

export const ROI_DETAIL_ITEMS = [
  { label: "Value Generated", value: "$248K" },
  { label: "Platform Cost", value: "$83K" },
  { label: "Net Savings", value: "$201K" },
];

export const INTERVENTION_DATA = [
  { month: "Jan", aiExecution: 50, manualProcess: 84 },
  { month: "Feb", aiExecution: 38, manualProcess: 62 },
  { month: "Mar", aiExecution: 56, manualProcess: 76 },
  { month: "Apr", aiExecution: 40, manualProcess: 30 },
  { month: "May", aiExecution: 56, manualProcess: 24 },
  { month: "Jun", aiExecution: 34, manualProcess: 43 },
  { month: "Jul", aiExecution: 88, manualProcess: 27 },
];

export const interventionChartConfig = {
  aiExecution: {
    label: "AI Driven Execution",
    color: "rgba(31, 92, 232, 1)",
  },
  manualProcess: {
    label: "Manual Process",
    color: "rgba(221, 106, 204, 1)",
  },
} satisfies ChartConfig;

export const ACCELERATION_GAIN_DATA = [
  { month: "Jan", delivery: 36 },
  { month: "Feb", delivery: 42 },
  { month: "Mar", delivery: 51 },
  { month: "Apr", delivery: 48 },
  { month: "May", delivery: 63 },
  { month: "Jun", delivery: 70 },
  { month: "Jul", delivery: 76 },
];

export const accelerationGainChartConfig = {
  delivery: {
    label: "Delivery Acceleration",
    color: "rgba(14, 141, 74, 1)",
  },
} satisfies ChartConfig;

export const SMALL_ANALYTICS_CARDS = [
  {
    key: "timeSaved",
    title: "Time Saved",
    subtitle: "Efficiency Gain",
    value: "2840 hrs",
    description: "90% faster than manual",
    delta: "8%",
    icon: Clock3,
    iconBackground: "bg-[linear-gradient(135deg,#8B5CF6_0%,#A855F7_100%)]",
  },
  {
    key: "agentExecutions",
    title: "Agent Executions",
    subtitle: "Platform Utilization",
    value: "13,678",
    description: "425 average per day",
    delta: "15%",
    icon: BriefcaseBusiness,
    iconBackground: "bg-[linear-gradient(135deg,#EC4899_0%,#D946EF_100%)]",
  },
  {
    key: "successRate",
    title: "Success Rate",
    subtitle: "Quality Metrics",
    value: "94.2%",
    description: "789 failed of 18,290 total",
    delta: "8%",
    icon: CheckCheck,
    iconBackground: "bg-[linear-gradient(135deg,#F59E0B_0%,#F59E0B_100%)]",
  },
  {
    key: "activeUsers",
    title: "Active Users",
    subtitle: "Adoption Indicator",
    value: "876",
    description: "78% of who have access",
    delta: "15%",
    icon: Users,
    iconBackground: "bg-[linear-gradient(135deg,#3B82F6_0%,#2563EB_100%)]",
  },
] satisfies Array<{
  key: DashboardCustomizationKey;
  title: string;
  subtitle: string;
  value: string;
  description: string;
  delta: string;
  icon: LucideIcon;
  iconBackground: string;
}>;

export const DASHBOARD_CUSTOMIZATION_SECTIONS: DashboardCustomizationSection[] = [
  {
    title: "KPI’s",
    items: [
      { key: "totalProjects", title: "Total Projects" },
      { key: "aiMaturity", title: "AI Maturity" },
      { key: "totalAiAgents", title: "Total AI Agents" },
    ],
  },
  {
    title: "Overall Analytics",
    items: [
      {
        key: "returnOnInvestment",
        title: "Return on Investment",
        subtitle: "Business Value Metrics",
      },
      {
        key: "activeUsers",
        title: "Active Users",
        subtitle: "Adoption Indicator",
      },
      {
        key: "agentExecutions",
        title: "Agent Executions",
        subtitle: "Platform Utilization",
      },
      {
        key: "successRate",
        title: "Success Rate",
        subtitle: "Quality Rate",
      },
      {
        key: "timeSaved",
        title: "Time Saved",
        subtitle: "Efficiency Gains",
      },
    ],
  },
  {
    title: "Graphs",
    items: [
      {
        key: "humanIntervention",
        title: "Human Intervention Over Time",
        subtitle: "View KPI- Total Projects, AI Maturity, Delivery",
      },
      {
        key: "accelerationGain",
        title: "Acceleration Gain Over Time",
        subtitle: "View KPI- Total Projects, AI Maturity, Delivery",
      },
    ],
  },
];
