"use client";

import {
  CartesianGrid,
  Line,
  LineChart,
  XAxis,
  YAxis,
} from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from "@/components/ui/chart";
import {
  INTERVENTION_DATA,
  interventionChartConfig,
} from "@/components/dashboard/role-admin/dashboard-data";

export function AdminHumanInterventionCard() {
  return (
    <Card className="gap-0 rounded-[1.75rem] bg-white py-0 shadow-[0px_4px_12px_0px_rgba(213,213,213,0.16)] ring-black/4">
      <CardHeader className="gap-4 px-5 pb-0 pt-5 sm:px-6 sm:pt-6">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <CardTitle className="font-display text-[1.05rem] font-semibold text-[var(--jnj-ink)]">
              Human Intervention Over Time
            </CardTitle>
          </div>

          <div className="flex flex-wrap items-center gap-4 text-xs font-medium">
            <LegendChip
              label="AI Driven Execution"
              color="rgba(31, 92, 232, 1)"
            />
            <LegendChip
              label="Manual Process"
              color="rgba(221, 106, 204, 1)"
            />
          </div>
        </div>
      </CardHeader>

      <CardContent className="px-2 pb-3 pt-2 sm:px-4 sm:pb-4">
        <ChartContainer
          config={interventionChartConfig}
          className="min-h-[320px] w-full"
        >
          <LineChart
            accessibilityLayer
            data={INTERVENTION_DATA}
            margin={{ left: 4, right: 18, top: 16, bottom: 8 }}
          >
            <CartesianGrid vertical strokeDasharray="3 3" />
            <XAxis
              dataKey="month"
              tickLine={false}
              axisLine={false}
              tickMargin={10}
            />
            <YAxis
              tickLine={false}
              axisLine={false}
              tickMargin={10}
              width={42}
              domain={[0, 100]}
              tickFormatter={(value) => `${value}%`}
            />
            <ChartTooltip
              cursor={false}
              content={
                <ChartTooltipContent
                  indicator="line"
                  className="rounded-xl border-black/8 bg-white shadow-[0px_10px_24px_0px_rgba(17,24,39,0.12)]"
                />
              }
            />
            <Line
              dataKey="aiExecution"
              type="monotone"
              stroke="var(--color-aiExecution)"
              strokeWidth={2.5}
              dot={{
                r: 3,
                fill: "#ffffff",
                stroke: "var(--color-aiExecution)",
                strokeWidth: 1.5,
              }}
              activeDot={{
                r: 5,
                fill: "#ffffff",
                stroke: "var(--color-aiExecution)",
                strokeWidth: 2,
              }}
              style={{
                filter:
                  "drop-shadow(0px 3px 3px rgba(31, 92, 232, 1)) drop-shadow(0px 6px 9px rgba(31, 92, 232, 0.35)) drop-shadow(0px 9px 18px rgba(31, 92, 232, 0.2))",
              }}
            />
            <Line
              dataKey="manualProcess"
              type="monotone"
              stroke="var(--color-manualProcess)"
              strokeWidth={2.5}
              dot={{
                r: 3,
                fill: "#ffffff",
                stroke: "var(--color-manualProcess)",
                strokeWidth: 1.5,
              }}
              activeDot={{
                r: 5,
                fill: "#ffffff",
                stroke: "var(--color-manualProcess)",
                strokeWidth: 2,
              }}
              style={{
                filter:
                  "drop-shadow(0px 3px 3px rgba(215, 113, 208, 1)) drop-shadow(0px 6px 9px rgba(208, 124, 215, 0.35)) drop-shadow(0px 9px 18px rgba(221, 106, 204, 0.22))",
              }}
            />
          </LineChart>
        </ChartContainer>
      </CardContent>
    </Card>
  );
}

function LegendChip({ label, color }: { label: string; color: string }) {
  return (
    <div className="inline-flex items-center gap-2 text-[#4e4c47]">
      <span className="size-3 rounded-full" style={{ backgroundColor: color }} />
      <span>{label}</span>
    </div>
  );
}
