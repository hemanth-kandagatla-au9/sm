"use client";

import type { LucideIcon } from "lucide-react";
import { SlidersHorizontal } from "lucide-react";
import { Button } from "@/components/ui/button";
import { AdminDashboardSelectMenu } from "@/components/dashboard/role-admin/AdminDashboardSelectMenu";
import {
  CATEGORY_OPTIONS,
  HERO_METRICS,
  type DashboardCustomizationState,
} from "@/components/dashboard/role-admin/dashboard-data";

type DashboardHeroSectionProps = {
  firstName: string;
  selectedCategory: string;
  onCategoryChange: (option: string) => void;
  preferences: DashboardCustomizationState;
  onOpenCustomize: () => void;
};

export function AdminDashboardHeroSection({
  firstName,
  selectedCategory,
  onCategoryChange,
  preferences,
  onOpenCustomize,
}: DashboardHeroSectionProps) {
  const visibleMetrics = HERO_METRICS.filter(
    (metric) => preferences[metric.key],
  );

  return (
    <>
      <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
        <h2 className="font-display text-[2.25rem] font-medium leading-none tracking-tight text-[#EB1700]">
          Welcome, {firstName}!
        </h2>

        <div className="flex flex-wrap items-center gap-3">
          <AdminDashboardSelectMenu
            label={selectedCategory}
            menuLabel="Categories"
            options={CATEGORY_OPTIONS}
            onSelect={onCategoryChange}
            triggerClassName="shadow-[0_10px_24px_rgba(17,24,39,0.04)]"
          />

          <Button
            type="button"
            variant="ghost"
            size="icon"
            aria-label="Filter categories"
            onClick={onOpenCustomize}
            className="size-11 rounded-2xl bg-[rgba(234,24,5,0.08)] text-[rgba(235,23,0,1)] hover:bg-[rgba(234,24,5,0.14)] hover:text-[rgba(235,23,0,1)]">
            <SlidersHorizontal className="size-5" />
          </Button>
        </div>
      </div>

      <div className="rounded-[20px] bg-[linear-gradient(90deg,hsla(209,95%,55%,1)_0%,hsla(6,87%,56%,1)_100%)] px-6 py-6 text-[#F8FAFC] shadow-[0_28px_60px_rgba(30,64,175,0.18)] sm:px-7 sm:py-7">
        <div className="grid gap-5 lg:grid-cols-2 lg:items-stretch">
          <div className="flex flex-col justify-center">
            <h3 className="font-display max-w-155 text-[1.75rem] font-medium">
              Explore how the Agents are Orchestrated across Enterprise SDLC
            </h3>
            <p className="mt-4 max-w-160 text-base leading-7 font-normal text-[#F8FAFC]">
              Orchestrate intelligent agents across the SDLC to drive speed,
              quality, and consistency.
            </p>
          </div>

          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
            {visibleMetrics.map((metric) => (
              <HeroMetricCard
                key={metric.key}
                value={metric.value}
                label={metric.label}
                description={metric.description}
                icon={metric.icon}
              />
            ))}
          </div>
        </div>
      </div>
    </>
  );
}

function HeroMetricCard({
  value,
  label,
  description,
  icon: Icon,
}: {
  value: string;
  label: string;
  description: string;
  icon: LucideIcon;
}) {
  return (
    <article
      className="rounded-[1.15rem] p-5 text-[#F8FAFC]"
      style={{
        background:
          "linear-gradient(rgba(212, 212, 212, 0.1), rgba(212, 212, 212, 0.1)) padding-box, linear-gradient(135deg, rgba(255, 255, 255, 0.25) 0%, rgba(255, 255, 255, 0.05) 50%) border-box",
        border: "2px solid transparent",
      }}>
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-[2.3rem] leading-none font-medium tracking-[-0.03em]">
            {value}
          </p>
          <p className="mt-4 text-sm font-medium text-[#F8FAFC]">{label}</p>
        </div>

        <div className="rounded-full bg-white/10 p-2.5 text-white/90">
          <Icon className="size-4" />
        </div>
      </div>

      <p className="mt-3 max-w-[240px] text-[13px] leading-5 text-[#E2E8F0]">
        {description}
      </p>
    </article>
  );
}
