"use client";
import Agents from "@/components/admin-setup/admin-resources/components/Agents";
import McpIntegrations from "@/components/admin-setup/admin-resources/components/McpIntegrations";
import Workflow from "@/components/admin-setup/admin-resources/components/Workflow";
import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import CardActionArea from "@mui/material/CardActionArea";
import CardContent from "@mui/material/CardContent";
import CardHeader from "@mui/material/CardHeader";
import Typography from "@mui/material/Typography";
import { Bot, Server, Workflow as WorkflowIcon } from "lucide-react";
import { useState } from "react";

const Resources = () => {
  const [selectedCard, setSelectedCard] = useState(0);

  const cards = [
    {
      id: 0,
      title: "Agents",
      description: "AI Orchestration Agents",
      icon: <Bot size={18} color="#ffffff" />,
      iconbackground: "#399AE4",
      component: <Agents />,
    },
    {
      id: 1,
      title: "MCP Integrations",
      description: "System Integrations",
      icon: <Server size={18} color="#ffffff" />,
      iconbackground: "#FC9619",
      component: <McpIntegrations />,
    },
    {
      id: 2,
      title: "Workflow",
      description: "Execute Pipelines",
      icon: <WorkflowIcon size={18} color="#ffffff" />,
      iconbackground: "#32BB57",
      component: <Workflow />,
    },
  ];

  return (
    <div className="flex w-full flex-col gap-4 overflow-x-hidden lg:flex-row">
      <div className="flex w-full flex-col gap-4 lg:basis-1/4 lg:max-w-[20%]">
        <h1 style={{ fontSize: "16px", color: "#5c534c", fontWeight: "500", fontFamily: "var(--app-font-text)", marginTop: "0.5rem" }}>
          Resource Selection
        </h1>
        {cards.map((card) => (
          <Card
            key={card.id}
            sx={{
              maxWidth: "300px",
              height: "auto",
              border: selectedCard === card.id ? "1px solid #EB170073" : "",
              borderRadius: 2,
            }}
          >
            <CardActionArea
              onClick={() => setSelectedCard(card.id)}
              sx={{
                height: "100%",
                // "&:hover": { backgroundColor: "#F9FDFE" },
              }}
            >
              <CardHeader
                avatar={
                  <Box
                    sx={{
                      backgroundColor: card.iconbackground,
                      borderRadius: 2,
                      width: 32,
                      height: 32,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    {card.icon}
                  </Box>
                }
                title={<Typography sx={{ fontSize: "20px", color: "#1a1817", fontWeight: "500", fontFamily: "var(--app-font-display)" }}>{card.title}</Typography>}
                sx={{ pb: 0 }}
              />
              <CardContent>
                <Typography sx={{ fontSize: "14px", color: "#4A5567", fontWeight: "500", fontFamily: "var(--app-font-text)" }}>
                  {card.description}
                </Typography>
              </CardContent>
            </CardActionArea>
          </Card>
        ))}
      </div>

      <div className="min-w-0 flex-1 overflow-x-auto lg:basis-3/4">
        {cards[selectedCard].component}
      </div>
    </div>
  );
};

export default Resources;