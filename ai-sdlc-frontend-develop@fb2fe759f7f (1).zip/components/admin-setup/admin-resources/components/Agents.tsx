"use client";
import TableHeader from "@/components/common/TableHeader";
import CustomDataGrid from "@/components/resuable-components/CustomDataGrid";
import ToastHelper, {
  promiseLoadingToastStyle,
} from "@/components/common/ToastHelper";
import axiosInstance from "@/lib/api/axiosInstance";
import { getSessionUserId } from "@/lib/auth/user-helper";
import { Plus } from "lucide-react";
import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import FieldBuilderModal from "@/components/admin-setup/forms/form-builder-wrapper/FormFieldBuilderModal";
import { agentColumns } from "../../utility/ColDef";
import { extractApiErrorMessage } from "@/services/chat/utils";
import { agentFormMetaData } from "@/components/admin-setup/forms/forms-meta-data/AgentFormMetaData";

type CreateResourceResponse<TData = unknown> = {
  success: boolean;
  data: TData | null;
  error: {
    message: string;
    error_type?: string | null;
    details?: unknown;
  } | null;
};


const Agents = () => {
  const [globalSearch, setGlobalSearch] = useState(""); //state for global search input
  const [agents, setAgents] = useState([]); //state to hold list of agents
  const [loading, setLoading] = useState(false); //state to handle loading state
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  const listAgents = async () => {
    setLoading(true);
    try {
      const response = await axiosInstance.get("/sdlc/agents");
      setAgents(response.data.data ?? []);
    } catch (err: unknown) {
      const errorMessage = extractApiErrorMessage(
        err,
        "Failed to load agents. Please try again.",
      );
      ToastHelper.showRespToast({ status: false, message: errorMessage });
      setAgents([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    listAgents();
  }, []);

  const handleCreateAgent = async (values: Record<string, string | number>) => {
    const result = await toast.promise(
      axiosInstance.post<CreateResourceResponse>(
        "/sdlc/agents",
        { ...values, created_by: getSessionUserId() },
      ),
      {
        loading: "Registering agent...",
        success: ({ data: resp }) => {
          ToastHelper.showRespToast({
            status: resp.success,
            message: resp.error?.message ?? "Agent registered successfully",
          });
          return null;
        },
        error: (err) => {
          const errorMessage = extractApiErrorMessage(err, "Failed to register agent");
          ToastHelper.showRespToast({ status: false, message: errorMessage });
          return null;
        },
      },
      promiseLoadingToastStyle,
    );
    if (result.data.success) {
      setIsAddModalOpen(false);
      await listAgents();
    }
  };

  const validateAgentForm = (values: Record<string, string | number>) => {
    const efficiency =
      typeof values.efficiency_weight === "number"
        ? values.efficiency_weight
        : Number(values.efficiency_weight ?? 0);
    const experience =
      typeof values.experience_weight === "number"
        ? values.experience_weight
        : Number(values.experience_weight ?? 0);
    const effectiveness =
      typeof values.effectiveness_weight === "number"
        ? values.effectiveness_weight
        : Number(values.effectiveness_weight ?? 0);

    const scoreTotal = efficiency + experience + effectiveness;

    if (scoreTotal !== 100) {
      return `Efficency + Experience + Effectiveness must equal 100 (current total: ${scoreTotal})`;
    }

    return null;
  };

  return (
    <div className="space-y-2">
      <TableHeader
        title="Agents"
        globalSearch={globalSearch}
        setGlobalSearch={setGlobalSearch}
        haveActionsButton
        buttonText="Register Agent"
        buttonIcon={<Plus size={16} />}
        onButtonClick={() => setIsAddModalOpen(true)}
      />
      <CustomDataGrid
        loading={loading}
        data={agents}
        columns={agentColumns}
        getRowId={(row) => row.agent_id}
        searchValue={globalSearch}
        gridCustomSx={{ height: "calc(100vh - 230px)" }}
        defaultSortingField="agent_id"
      />
      <FieldBuilderModal
        open={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        formMetaData={agentFormMetaData}
        mode="create"
        validate={validateAgentForm}
        handleResource={handleCreateAgent}
      />
    </div>
  );
};

export default Agents;