"use client";
import TableHeader from "@/components/common/TableHeader";
import CustomDataGrid from "@/components/resuable-components/CustomDataGrid";
import ToastHelper, {
  promiseLoadingToastStyle,
} from "@/components/common/ToastHelper";
import axiosInstance from "@/lib/api/axiosInstance";
import { getSessionUserId } from "@/lib/auth/user-helper";
import { Plus } from "lucide-react";
import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import FieldBuilderModal from "@/components/admin-setup/forms/form-builder-wrapper/FormFieldBuilderModal";
import { mcpColumns } from "../../utility/ColDef";
import { extractApiErrorMessage } from "@/services/chat/utils";
import { mcpFormMetaData } from "@/components/admin-setup/forms/forms-meta-data/McpFormMetaData";

type CreateResourceResponse<TData = unknown> = {
  success: boolean;
  data: TData | null;
  error: {
    message: string;
    error_type?: string | null;
    details?: unknown;
  } | null;
};

const McpIntegrations = () => {
  const [globalSearch, setGlobalSearch] = useState(""); //state for global search input
  const [mcpIntegrations, setMcpIntegrations] = useState([]); //state to hold list of MCP integrations
  const [loading, setLoading] = useState(false); //state to handle loading state
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  const fetchMcpIntegrations = async () => {
    setLoading(true);
    try {
      const response = await axiosInstance.get("/sdlc/mcps");
      setMcpIntegrations(response.data.data ?? []);
    } catch (err: unknown) {
      const errorMessage = extractApiErrorMessage(
        err,
        "Failed to load MCP integrations. Please try again.",
      );
      ToastHelper.showRespToast({ status: false, message: errorMessage });
      setMcpIntegrations([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMcpIntegrations();
  }, []);

  const handleCreateMcp = async (values: Record<string, string | number>) => {
    const result = await toast.promise(
      axiosInstance.post<CreateResourceResponse>(
        "/sdlc/mcps",
        { ...values, created_by: getSessionUserId() },
      ),
      {
        loading: "Registering MCP...",
        success: ({ data: resp }) => {
          ToastHelper.showRespToast({
            status: resp.success,
            message: resp.error?.message ?? "MCP registered successfully",
          });
          return null;
        },
        error: (err) => {
          const errorMessage = extractApiErrorMessage(
            err,
            "Failed to register MCP",
          );
          ToastHelper.showRespToast({ status: false, message: errorMessage });
          return null;
        },
      },
      promiseLoadingToastStyle,
    );
    if (result.data.success) {
      setIsAddModalOpen(false);
      await fetchMcpIntegrations();
    }
  };

  return (
    <div className="space-y-2">
      <TableHeader
        title="MCP"
        globalSearch={globalSearch}
        setGlobalSearch={setGlobalSearch}
        haveActionsButton
        buttonText="Register MCP"
        buttonIcon={<Plus size={16} />}
        onButtonClick={() => setIsAddModalOpen(true)}
      />
      <CustomDataGrid
        loading={loading}
        data={mcpIntegrations}
        columns={mcpColumns}
        getRowId={(row) => row.mcp_id}
        searchValue={globalSearch}
        gridCustomSx={{ height: "calc(100vh - 230px)" }}
        defaultSortingField="mcp_id"
      />
      <FieldBuilderModal
        open={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        formMetaData={mcpFormMetaData}
        mode="create"
        handleResource={handleCreateMcp}
      />
    </div>
  );
};

export default McpIntegrations;
