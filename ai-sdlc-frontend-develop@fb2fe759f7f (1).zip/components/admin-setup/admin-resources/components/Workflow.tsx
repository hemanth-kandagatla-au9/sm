"use client";
import TableHeader from "@/components/common/TableHeader";
import CustomDataGrid from "@/components/resuable-components/CustomDataGrid";
import ToastHelper, {
  promiseLoadingToastStyle,
} from "@/components/common/ToastHelper";
import axiosInstance from "@/lib/api/axiosInstance";
import { getSessionUserId } from "@/lib/auth/user-helper";
import { Plus } from "lucide-react";
import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import FieldBuilderModal from "@/components/admin-setup/forms/form-builder-wrapper/FormFieldBuilderModal";
import { workFlowColumns } from "../../utility/ColDef";
import { extractApiErrorMessage } from "@/services/chat/utils";
import { workflowFormMetaData } from "@/components/admin-setup/forms/forms-meta-data/WorkflowFormMetaData";

type CreateResourceResponse<TData = unknown> = {
  success: boolean;
  data: TData | null;
  error: {
    message: string;
    error_type?: string | null;
    details?: unknown;
  } | null;
};

const Workflow = () => {
  const [globalSearch, setGlobalSearch] = useState(""); //state for global search input
  const [workflows, setWorkflows] = useState([]); //state to hold list of workflows
  const [loading, setLoading] = useState(false); //state to handle loading state
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  const fetchWorkflows = async () => {
    setLoading(true);
    try {
      const response = await axiosInstance.get("/sdlc/workflows");
      setWorkflows(response.data.data ?? []);
    } catch (err: unknown) {
      const errorMessage = extractApiErrorMessage(
        err,
        "Failed to load workflows. Please try again.",
      );
      ToastHelper.showRespToast({ status: false, message: errorMessage });
      setWorkflows([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchWorkflows();
  }, []);

  const handleCreateWorkflow = async (
    values: Record<string, string | number>,
  ) => {
    const result = await toast.promise(
      axiosInstance.post<CreateResourceResponse>(
        "/sdlc/workflows",
        { ...values, created_by: getSessionUserId() },
      ),
      {
        loading: "Registering workflow...",
        success: ({ data: resp }) => {
          ToastHelper.showRespToast({
            status: resp.success,
            message: resp.error?.message ?? "Workflow registered successfully",
          });
          return null;
        },
        error: (err) => {
          const errorMessage = extractApiErrorMessage(
            err,
            "Failed to register workflow",
          );
          ToastHelper.showRespToast({ status: false, message: errorMessage });
          return null;
        },
      },
      promiseLoadingToastStyle,
    );
    if (result.data.success) {
      setIsAddModalOpen(false);
      await fetchWorkflows();
    }
  };

  return (
    <div className="space-y-2">
      <TableHeader
        title="Workflows"
        globalSearch={globalSearch}
        setGlobalSearch={setGlobalSearch}
        haveActionsButton
        buttonText="Register Workflow"
        buttonIcon={<Plus size={16} />}
        onButtonClick={() => setIsAddModalOpen(true)}
      />
      <CustomDataGrid
        loading={loading}
        data={workflows}
        columns={workFlowColumns}
        getRowId={(row) => row.workflow_id}
        searchValue={globalSearch}
        gridCustomSx={{ height: "calc(100vh - 230px)" }}
        defaultSortingField="workflow_id"
      />
      <FieldBuilderModal
        open={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        formMetaData={workflowFormMetaData}
        mode="create"
        handleResource={handleCreateWorkflow}
      />
    </div>
  );
};

export default Workflow;
