"use client";

import {
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  CircularProgress,
} from "@mui/material";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import {
  type FieldMetaData,
  type FormMetaData,
  type FormMode,
  isFieldEditable,
  isFieldRequired,
  type SelectOption,
} from "@/components/admin-setup/forms/forms-meta-data/FormMetaDataTypes";
import { primaryButtonSx } from "@/components/common/Helper";
import { X } from "lucide-react";
import FormFieldsRenderer from "@/components/admin-setup/forms/form-builder-wrapper/FormFieldsRenderer";

type FormValues = Record<string, string | number>;

type FieldChangeHelpers = {
  setValue: ReturnType<typeof useForm<FormValues>>["setValue"];
};

type FieldBuilderModalProps = {
  open: boolean;
  onClose: () => void;
  formMetaData: FormMetaData;
  mode?: FormMode;
  dropdownOptionsByField?: Record<string, SelectOption[]>;
  loading?: boolean;
  validate?: (values: FormValues) => string | null;
  onFieldValueChange?: (
    fieldName: string,
    value: string | number | boolean,
    helpers: FieldChangeHelpers,
  ) => void;
  handleResource: (values: FormValues) => void | Promise<void>;
};

const FieldBuilderModal = ({
  open,
  onClose,
  formMetaData,
  mode = "create",
  dropdownOptionsByField,
  loading = false,
  validate,
  onFieldValueChange,
  handleResource,
}: FieldBuilderModalProps) => {
  const [validationError, setValidationError] = useState<string | null>(null);
  const fields = formMetaData.fields;

  const {
    control,
    handleSubmit,
    reset,
    setValue,
    formState: { isSubmitting },
  } = useForm<FormValues>();

  // to prevent the modal form back drop ///////////////////////
  const handleBackdrop = (_event: never, reason: string) => {
    if (reason && reason === "backdropClick") return;
    setValidationError(null);
    onClose();
  };

  const handleClose = () => {
    setValidationError(null);
    onClose();
  };
  
  useEffect(() => {
    if (!open) {
      return;
    }

    const nextValues = Object.fromEntries(
      fields.map((field) => [field.fieldName, field.defaultValue ?? ""]),
    ) as FormValues;

    reset(nextValues);
  }, [open, fields, reset]);

  const handleFormSubmit = async (values: FormValues) => {
    const nextValidationError = validate?.(values) ?? null;
    setValidationError(nextValidationError);

    if (nextValidationError) {
      return;
    }

    await handleResource(values);
  };

  const submitText = mode === "create" ? formMetaData.title : "Save Changes";

  return (
    <Dialog
      open={open}
      onClose={handleBackdrop}
      fullWidth
      slotProps={{ paper: { sx: { borderRadius: 5, maxWidth: "700px" } } }}
    >
      <Box
        component="form"
        noValidate
        onSubmit={handleSubmit(handleFormSubmit)}
      >
        <DialogTitle sx={{ p: "16px 16px 2px 16px", fontFamily: "var(--app-font-display)", color: "#312c2a" }}>{submitText}</DialogTitle>
        <X
          size={16}
          onClick={handleClose}
          style={{
            cursor: "pointer",
            position: "absolute",
            top: 16,
            right: 16,
          }}
        />
        <DialogContent sx={{ overflowY: "visible", p: "12px 16px" }}>
          {loading ? (
            <Box
              sx={{
                minHeight: 220,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <CircularProgress size={35} sx={{ color: "#eb1700" }} />
            </Box>
          ) : (
            <FormFieldsRenderer
              fields={fields}
              mode={mode}
              control={control}
              setValue={setValue}
              isFieldRequired={(field, nextMode) =>
                isFieldRequired(field as FieldMetaData, nextMode)
              }
              isFieldEditable={(field, nextMode) =>
                isFieldEditable(field as FieldMetaData, nextMode)
              }
              dropdownOptionsByField={dropdownOptionsByField}
              getRules={(field) => {
                const baseRules: Record<string, unknown> = {
                  required: isFieldRequired(field as FieldMetaData, mode)
                    ? "This field is required"
                    : false,
                };

                if (field.type === "url") {
                  baseRules.validate = (value: unknown) => {
                    if (!value || typeof value !== "string") {
                      return true;
                    }

                    try {
                      const parsedUrl = new URL(value);
                      return (
                        parsedUrl.protocol === "http:" ||
                        parsedUrl.protocol === "https:" ||
                        "Enter a valid URL"
                      );
                    } catch {
                      return "Enter a valid URL";
                    }
                  };
                }

                if (field.type === "number") {
                  baseRules.validate = (value: unknown) => {
                    if (!value && value !== 0) {
                      return true;
                    }

                    const numValue = typeof value === "string" ? parseFloat(value) : value;
                    if (typeof numValue === "number" && numValue < 0) {
                      return "Only positive value allowed";
                    }

                    return true;
                  };
                }

                return baseRules;
              }}
              onFieldValueChange={onFieldValueChange}
            />
          )}
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          {validationError && (
            <span
              style={{
                color: "#d32f2f",
                fontSize: "0.8rem",
                marginRight: "auto",
              }}
            >
              {validationError}
            </span>
          )}
          <Button
            onClick={handleClose}
            disabled={isSubmitting}
            sx={primaryButtonSx}
          >
            Cancel
          </Button>
          <Button
            type="submit"
            disabled={isSubmitting}
            sx={primaryButtonSx}
          >
            {submitText}
          </Button>
        </DialogActions>
      </Box>
    </Dialog>
  );
};

export default FieldBuilderModal;
