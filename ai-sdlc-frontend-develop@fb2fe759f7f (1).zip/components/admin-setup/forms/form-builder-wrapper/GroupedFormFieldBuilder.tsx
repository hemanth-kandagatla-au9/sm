"use client";

import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Box,
  Button,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Divider,
  IconButton,
} from "@mui/material";

import { type SyntheticEvent, useEffect, useMemo, useState } from "react";
import { useForm, useWatch } from "react-hook-form";
import { ChevronDown, X } from "lucide-react";
import { primaryButtonSx } from "@/components/common/Helper";
import {
  type FormMode,
  getProjectFieldGroups,
  isProjectFieldEditable,
  isProjectFieldRequired,
  type ProjectFieldMetaData,
  type SelectOption,
} from "@/components/admin-setup/forms/forms-meta-data/ProjectFormMetaData";
import FormFieldsRenderer from "@/components/admin-setup/forms/form-builder-wrapper/FormFieldsRenderer";

type FormValues = Record<string, string | number | boolean | Date>;

type ProjectFormFieldBuilderDialogProps = {
  open: boolean;
  onClose: () => void;
  mode?: FormMode;
  handleProjectSubmit: (values: FormValues) => Promise<void>;
  initialFormData?: FormValues;
  dropdownOptionsByField: Record<string, SelectOption[]>;
  loading?: boolean;
};

const GroupedFormFieldBuilder = ({
  open,
  onClose,
  mode = "create",
  handleProjectSubmit,
  initialFormData,
  dropdownOptionsByField,
  loading = false,
}: ProjectFormFieldBuilderDialogProps) => {
  const groupedFields = useMemo(() => getProjectFieldGroups(), []);
  const isEditMode = mode === "edit";
  const dialogTitle = isEditMode ? "Edit Project" : "Create New Project";
  const submitText = isEditMode ? "Update" : "Create";
  const [expanded, setExpanded] = useState<number | false>(0);

  const handleChange =
    (panel: number) => (_: SyntheticEvent, newExpanded: boolean) => {
      setExpanded(newExpanded ? panel : false);
    };

  const {
    control,
    handleSubmit,
    reset,
    setValue,
    formState: { isSubmitting, errors },
  } = useForm<FormValues>();

  const startDateValue = useWatch({
    control,
    name: "start_date",
  });

  useEffect(() => {
    if (!open) {
      reset({});
      return;
    }
    //setting the initial values in the form when the dialog is opened in edit mode
    reset(initialFormData ?? {});
  }, [open, reset, initialFormData]);

  const handleBackdrop = (_event: never, reason: string) => {
    if (reason === "backdropClick") return;
    onClose();
  };

  const handleFormSubmit = async (values: FormValues) => {
    await handleProjectSubmit(values);
  };

  return (
    <Dialog open={open} onClose={handleBackdrop} fullWidth maxWidth="lg">
      <Box
        component="form"
        noValidate //needed to prevent native html validation error popups since we are handling validation through react-hook-form
        onSubmit={handleSubmit(handleFormSubmit)}
      >
        {loading ? (
          <div className="flex min-h-screen w-full items-center justify-center">
            <CircularProgress size={35} sx={{ color: "#eb1700" }} />
          </div>
        ) : (
          <>
            <Box
              sx={{
                px: 3,
                py: 2,
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
              }}
            >
              <DialogTitle sx={{ p: 0 }}>{dialogTitle}</DialogTitle>
              <DialogActions
                sx={{ p: 0, display: "flex", alignItems: "center", gap: 1 }}
              >
                {Object.keys(errors).length > 0 && (
                  <span style={{ color: "#d32f2f", fontSize: "0.8rem" }}>
                    Please fill all required fields and check for error(s).
                  </span>
                )}
                <Button
                  type="submit"
                  disabled={isSubmitting}
                  sx={primaryButtonSx}
                >
                  {submitText}
                </Button>
                <IconButton
                  onClick={onClose}
                  sx={{ ml: 0.5, backgroundColor: "#f3f4f6", "&:hover": { backgroundColor: "#e5e7eb" } }}
                >
                  <X size={18} />
                </IconButton>
              </DialogActions>
            </Box>
            <Divider sx={{ margin: "0 16px 0 16px" }} />
            <DialogContent>
              <div className="space-y-4">
                {groupedFields.map(({ group, fields }, index) => (
                  <Accordion
                    key={group.key}
                    expanded={expanded === index}
                    onChange={handleChange(index)}
                    disableGutters
                    sx={{
                      borderRadius: "15px",
                      border: "1px solid #e5e7eb",
                      boxShadow: "none",
                      "&:before": { display: "none" },
                    }}
                  >
                    <AccordionSummary
                      expandIcon={<ChevronDown />}
                      sx={{
                        height: 60,
                      }}
                    >
                      {group.label}
                    </AccordionSummary>
                    <Divider sx={{ margin: "0 12px 0 12px" }} />
                    <AccordionDetails sx={{ mt: 2 }}>
                      <FormFieldsRenderer
                        fields={fields}
                        mode={mode}
                        control={control}
                        setValue={setValue}
                        isFieldRequired={(field, nextMode) =>
                          isProjectFieldRequired(
                            field as ProjectFieldMetaData,
                            nextMode,
                          )
                        }
                        isFieldEditable={(field, nextMode) =>
                          isProjectFieldEditable(
                            field as ProjectFieldMetaData,
                            nextMode,
                          )
                        }
                        dropdownOptionsByField={dropdownOptionsByField}
                        getRules={(field) => {
                          const projectField = field as ProjectFieldMetaData;
                          const required = isProjectFieldRequired(
                            projectField,
                            mode,
                          );

                          return {
                            required: required
                              ? "This field is required"
                              : false,
                            ...(projectField.fieldName === "end_date" && {
                              validate: (value: unknown) => {
                                if (value && !startDateValue) {
                                  return "Start date is required when end date is selected";
                                }

                                if (!value || !startDateValue) {
                                  return true;
                                }

                                return (
                                  new Date(value as string) >
                                    new Date(startDateValue as string) ||
                                  "End date must be after start date"
                                );
                              },
                            }),
                          };
                        }}
                      />
                    </AccordionDetails>
                  </Accordion>
                ))}
              </div>
            </DialogContent>
          </>
        )}
      </Box>
    </Dialog>
  );
};

export default GroupedFormFieldBuilder;
