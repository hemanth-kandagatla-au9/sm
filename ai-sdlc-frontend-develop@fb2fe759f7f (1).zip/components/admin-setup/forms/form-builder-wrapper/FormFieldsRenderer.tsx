"use client";

import { fieldDropdownListSx, fieldInputSx } from "@/components/common/Helper";
import { Autocomplete, Grid, InputAdornment, TextField } from "@mui/material";
import { Controller } from "react-hook-form";
import type { Control, FieldValues, UseFormSetValue } from "react-hook-form";
import type { ReactNode } from "react";

type FieldOption = {
  label: string;
  value: string | boolean;
};

type FieldGridSpan = {
  xs?: number;
  sm?: number;
  md?: number;
  lg?: number;
  xl?: number;
};

type CommonField = {
  fieldName: string;
  label: string;
  type: string;
  placeholder?: string;
  endAdornment?: ReactNode;
  grid?: FieldGridSpan;
  options?: FieldOption[];
};

type FormFieldsRendererProps<TFormValues extends FieldValues> = {
  fields: CommonField[];
  mode: "create" | "edit";
  control: Control<TFormValues>;
  setValue: UseFormSetValue<TFormValues>;
  isFieldRequired: (field: CommonField, mode: "create" | "edit") => boolean;
  isFieldEditable: (field: CommonField, mode: "create" | "edit") => boolean;
  dropdownOptionsByField?: Record<string, FieldOption[]>;
  getRules?: (field: CommonField) => Record<string, unknown> | undefined;
  onFieldValueChange?: (
    fieldName: string,
    value: string | number | boolean,
    helpers: { setValue: UseFormSetValue<TFormValues> },
  ) => void;
};

const FormFieldsRenderer = <TFormValues extends FieldValues>({
  fields,
  mode,
  control,
  isFieldRequired,
  isFieldEditable,
  dropdownOptionsByField,
  getRules,
}: FormFieldsRendererProps<TFormValues>) => {
  return (
    <Grid container spacing={2}>
      {fields.map((field) => {
        const required = isFieldRequired(field, mode);
        const disabled = !isFieldEditable(field, mode);
        const grid = field.grid ?? { xs: 12 };
        const gridSize = {
          xs: grid.xs ?? 12,
          sm: grid.sm,
          md: grid.md,
          lg: grid.lg,
          xl: grid.xl,
        };
        const rules = getRules?.(field);

        if (field.type === "select") {
          const options =
            dropdownOptionsByField?.[field.fieldName] ?? field.options ?? [];

          return (
            <Grid key={field.fieldName} size={gridSize}>
              <Controller
                name={field.fieldName as never}
                control={control}
                defaultValue={"" as never}
                rules={rules}
                render={({ field: controlledField, fieldState }) => (
                  <Autocomplete
                    options={options}
                    getOptionLabel={(option) => option.label}
                    isOptionEqualToValue={(option, value) => String(option.value) === String(value.value)}
                    value={ options.find((opt) => String(opt.value) === String(controlledField.value)) || null }
                    onChange={(_, selectedOption) => {
                      controlledField.onChange(selectedOption?.value ?? "");
                    }}
                    disabled={disabled}
                    fullWidth
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        label={field.label}
                        placeholder={field.placeholder}
                        required={required}
                        error={!!fieldState.error}
                        helperText={fieldState.error?.message}
                        sx={fieldInputSx}
                      />
                    )}
                    slotProps={{
                      listbox: {
                        sx: fieldDropdownListSx,
                      },
                    }}
                  />
                )}
              />
            </Grid>
          );
        }

        return (
          <Grid key={field.fieldName} size={gridSize}>
            <Controller
              name={field.fieldName as never}
              control={control}
              defaultValue={"" as never}
              rules={rules}
              render={({ field: controlledField, fieldState }) => (
                <TextField
                  {...controlledField}
                  value={controlledField.value ?? ""}
                  fullWidth
                  label={field.label}
                  placeholder={field.placeholder}
                  type={field.type}
                  required={required}
                  disabled={disabled}
                  multiline={field.type === "textarea"}
                  //   minRows={field.type === "textarea" ? 2 : undefined}
                  sx={fieldInputSx}
                  error={!!fieldState.error}
                  helperText={fieldState.error?.message}
                  slotProps={{
                    input: {
                      endAdornment: (
                        <InputAdornment position="end">
                          {field.endAdornment}
                        </InputAdornment>
                      ),
                    },
                    inputLabel:
                      field.type === "date"
                        ? {
                            shrink: true,
                          }
                        : undefined,
                  }}
                  onChange={(event) => {
                    const nextValue =
                      field.type === "number"
                        ? event.target.value === ""
                          ? ""
                          : Number(event.target.value)
                        : event.target.value;

                    controlledField.onChange(nextValue);
                  }}
                />
              )}
            />
          </Grid>
        );
      })}
    </Grid>
  );
};

export default FormFieldsRenderer;
