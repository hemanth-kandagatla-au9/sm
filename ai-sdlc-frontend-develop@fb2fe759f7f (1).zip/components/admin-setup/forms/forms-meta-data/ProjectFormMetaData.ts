import type { ReactNode } from "react";

export type FormMode = "create" | "edit";

export type ProjectFieldType = "text" | "textarea" | "select" | "date";

export type SelectOption = {
  label: string;
  value: string | boolean;
};

export type FieldGridSpan = {
  xs?: number;
  sm?: number;
  md?: number;
  lg?: number;
  xl?: number;
};

export type FieldGroup = {
  key: string;
  label: string;
};

export type ProjectFieldMetaData = {
  fieldName: string;
  label: string;
  type: ProjectFieldType;
  placeholder?: string;
  endAdornment?: ReactNode;
  group: FieldGroup;
  grid?: FieldGridSpan;
  requiredIn?: FormMode[];
  editableIn?: FormMode[];
  options?: SelectOption[];
};

export type ProjectFormMetaData = {
  title: string;
  fields: ProjectFieldMetaData[];
};

export const projectFieldGroups = {
  details: { key: "project-details", label: "Project Details" },
  compliance: { key: "business-compliance", label: "Business & Compliance" },
  finance: { key: "finance-costing", label: "Finance & Costing" },
  // timeline: { key: "data-classifications-timelines", label: "Data Classifications & Timelines" },
  vertical_classification: { key: "project-classification",label: "Vertical Classification" }, //erp,data(other vertical),non erp, mll
  sector_classification: { key: "sector-classification", label: "Sector Classification" }, //mt, im, cbt, 
};
export const gridBreakpoint = { xs: 12, sm: 6, md: 4, lg: 4, xl: 3 };
const booleanSelectOptions: SelectOption[] = [
  { label: "True", value: "true" },
  { label: "False", value: "false" },
];

export const projectFormMetaData: ProjectFormMetaData = {
  title: "Add Project",
  fields: [
    {
      fieldName: "project_name",
      label: "Project Name",
      type: "text",
      placeholder: "Project name",
      group: projectFieldGroups.details,
      grid: gridBreakpoint,
      requiredIn: ["create", "edit"],
      editableIn: ["create", "edit"],
    },
    {
      fieldName: "project_description",
      label: "Project Description",
      type: "textarea",
      placeholder: "Project description",
      group: projectFieldGroups.details,
      grid: { xs: 12, sm: 6, md: 8, lg: 8, xl: 9 },
      requiredIn: ["create", "edit"],
      editableIn: ["create", "edit"],
    },
    {
      fieldName: "atlassian_project_id",
      label: "Atlassian Project ID",
      type: "text",
      placeholder: "Atlassian project id",
      group: projectFieldGroups.details,
      grid: gridBreakpoint,
      requiredIn: [],
      editableIn: ["create", "edit"],
    },
    {
      fieldName: "asas_id",
      label: "SASA ID",
      type: "text",
      placeholder: "SASA id",
      group: projectFieldGroups.details,
      grid: gridBreakpoint,
      requiredIn: [],
      editableIn: ["create", "edit"],
    },
    // {
    //   fieldName: "project_owner_user_id",
    //   label: "Project Owner",
    //   type: "select",
    //   group: projectFieldGroups.details,
    //   grid: gridBreakpoint,
    //   requiredIn: ["create", "edit"],
    //   editableIn: ["create", "edit"],
    // },
    // {
    //   fieldName: "compliance_id",
    //   label: "Compliance",
    //   type: "select",
    //   group: projectFieldGroups.compliance,
    //   grid: gridBreakpoint,
    //   requiredIn: [],
    //   editableIn: ["create", "edit"],
    // },
    // {
    //   fieldName: "region_id",
    //   label: "Region",
    //   type: "select",
    //   group: projectFieldGroups.compliance,
    //   grid: gridBreakpoint,
    //   requiredIn: [],
    //   editableIn: ["create", "edit"],
    // },
    // {
    //   fieldName: "sector_id",
    //   label: "Sector",
    //   type: "select",
    //   group: projectFieldGroups.compliance,
    //   grid: gridBreakpoint,
    //   requiredIn: [],
    //   editableIn: ["create", "edit"],
    // },
    // {
    //   fieldName: "bu_approver",
    //   label: "BU Approver",
    //   type: "select",
    //   group: projectFieldGroups.compliance,
    //   grid: gridBreakpoint,
    //   requiredIn: [],
    //   editableIn: [],
    // },
    // {
    //   fieldName: "bu_finance",
    //   label: "BU Finance",
    //   type: "select",
    //   group: projectFieldGroups.compliance,
    //   grid: gridBreakpoint,
    //   requiredIn: [],
    //   editableIn: [],
    // },
    {
      fieldName: "zcode",
      label: "Z Code",
      type: "text",
      group: projectFieldGroups.finance,
      grid: gridBreakpoint,
      requiredIn: [],
      editableIn: ["create", "edit"],
    },
    {
      fieldName: "company_code",
      label: "Company Code",
      type: "text",
      group: projectFieldGroups.finance,
      grid: gridBreakpoint,
      requiredIn: [],
      editableIn: ["create", "edit"],
    },
    {
      fieldName: "acar_number",
      label: "ACAR Number",
      type: "text",
      group: projectFieldGroups.finance,
      grid: gridBreakpoint,
      requiredIn: [],
      editableIn: ["create", "edit"],
    },
    {
      fieldName: "capital_cost_element",
      label: "Capital Cost Element",
      type: "text",
      group: projectFieldGroups.finance,
      grid: gridBreakpoint,
      requiredIn: [],
      editableIn: ["create", "edit"],
    },
    {
      fieldName: "expense_cost_element",
      label: "Expense Cost Element",
      type: "text",
      group: projectFieldGroups.finance,
      grid: gridBreakpoint,
      requiredIn: [],
      editableIn: ["create", "edit"],
    },
    {
      fieldName: "expense_cost_center",
      label: "Expense Cost Center",
      type: "text",
      group: projectFieldGroups.finance,
      grid: gridBreakpoint,
      requiredIn: [],
      editableIn: ["create", "edit"],
    },
    {
      fieldName: "capital_internal_order",
      label: "Capital Internal Order",
      type: "text",
      group: projectFieldGroups.finance,
      grid: gridBreakpoint,
      requiredIn: [],
      editableIn: ["create", "edit"],
    },
    {
      fieldName: "expense_internal_order",
      label: "Expense Internal Order",
      type: "text",
      group: projectFieldGroups.finance,
      grid: gridBreakpoint,
      requiredIn: [],
      editableIn: ["create", "edit"],
    },
    // {
    //   fieldName: "data_type_id",
    //   label: "Data Type & Format",
    //   type: "select",
    //   group: projectFieldGroups.timeline,
    //   grid: gridBreakpoint,
    //   requiredIn: [],
    //   editableIn: ["create", "edit"],
    // },
    {
      fieldName: "start_date",
      label: "Start Date",
      type: "date",
      group: projectFieldGroups.details,
      grid: gridBreakpoint,
      requiredIn: [],
      editableIn: ["create", "edit"],
    },
    {
      fieldName: "end_date",
      label: "End Date",
      type: "date",
      group: projectFieldGroups.details,
      grid: gridBreakpoint,
      requiredIn: [],
      editableIn: ["create", "edit"],
    },
    {
      fieldName: "ERP_flag",
      label: "ERP",
      type: "select",
      group: projectFieldGroups.vertical_classification,
      grid: gridBreakpoint,
      requiredIn: [],
      editableIn: ["create", "edit"],
      options: booleanSelectOptions,
    },
    {
      fieldName: "Non_ERP_flag",
      label: "Non ERP",
      type: "select",
      group: projectFieldGroups.vertical_classification,
      grid: gridBreakpoint,
      requiredIn: [],
      editableIn: ["create", "edit"],
      options: booleanSelectOptions,
    },
    {
      fieldName: "MLL_flag",
      label: "MLL",
      type: "select",
      group: projectFieldGroups.vertical_classification,
      grid: gridBreakpoint,
      requiredIn: [],
      editableIn: ["create", "edit"],
      options: booleanSelectOptions,
    },
    {
      fieldName: "MT_flag",
      label: "MT",
      type: "select",
      group: projectFieldGroups.sector_classification,
      grid: gridBreakpoint,
      requiredIn: [],
      editableIn: ["create", "edit"],
      options: booleanSelectOptions,
    },
    {
      fieldName: "IM_flag",
      label: "IM",
      type: "select",
      group: projectFieldGroups.sector_classification,
      grid: gridBreakpoint,
      requiredIn: [],
      editableIn: ["create", "edit"],
      options: booleanSelectOptions,
    },
    {
      fieldName: "CBT_flag",
      label: "CBT",
      type: "select",
      group: projectFieldGroups.sector_classification,
      grid: gridBreakpoint,
      requiredIn: [],
      editableIn: ["create", "edit"],
      options: booleanSelectOptions,
    },
    {
      fieldName: "Other_Vertical_flag",
      label: "Data",
      type: "select",
      group: projectFieldGroups.vertical_classification,
      grid: gridBreakpoint,
      requiredIn: [],
      editableIn: ["create", "edit"],
      options: booleanSelectOptions,
    },
  ],
};

export type ProjectFieldGroupWithFields = {
  group: FieldGroup;
  fields: ProjectFieldMetaData[];
};

const groupOrder: FieldGroup[] = [
  projectFieldGroups.details,
  projectFieldGroups.compliance,
  projectFieldGroups.finance,
  // projectFieldGroups.timeline,
  projectFieldGroups.vertical_classification,
  projectFieldGroups.sector_classification,

];

export const getProjectFieldsByGroup = (
  groupKey: string,
): ProjectFieldMetaData[] =>
  projectFormMetaData.fields.filter((field) => field.group.key === groupKey);

export const getProjectFieldGroups = (): ProjectFieldGroupWithFields[] => {
  return groupOrder
    .map((group) => ({
      group,
      fields: getProjectFieldsByGroup(group.key),
    }))
    .filter((section) => section.fields.length > 0);
};

export const isProjectFieldRequired = (
  field: ProjectFieldMetaData,
  mode: FormMode,
): boolean => (field.requiredIn ? field.requiredIn.includes(mode) : false);

export const isProjectFieldEditable = (
  field: ProjectFieldMetaData,
  mode: FormMode,
): boolean => (field.editableIn ? field.editableIn.includes(mode) : true);

export default projectFormMetaData;
