import type { FormMetaData } from "@/components/admin-setup/forms/forms-meta-data/FormMetaDataTypes";

export const mcpFormMetaData: FormMetaData = {
  title: "Register MCP",
  fields: [
    {
      fieldName: "mcp_name",
      label: "MCP Name",
      placeholder: "Enter MCP name",
      type: "text",
      grid: { xs: 12, sm: 6 },
      requiredIn: ["create"],
      editableIn: ["create"],
    },
    {
      fieldName: "endpoint_url",
      label: "Endpoint URL",
      type: "url",
      placeholder: "https://mcp.example.com/jira",
      grid: { xs: 12, sm: 6 },
      requiredIn: ["create"],
      editableIn: ["create"],
    },
    {
      fieldName: "transport_type",
      label: "Transport Type",
      type: "select",
      grid: { xs: 12, sm: 6 },
      requiredIn: ["create"],
      editableIn: ["create"],
      options: [
        { label: "HTTP", value: "http" },
        { label: "SSE", value: "sse" },
        { label: "STDIO", value: "stdio" },
      ],
    },
    {
      fieldName: "mcp_desc",
      label: "MCP Description",
      type: "textarea",
      placeholder: "Enter MCP description",
      grid: { xs: 12 },
      requiredIn: ["create"],
      editableIn: ["create"],
    },
  ],
};
