import type { FormMetaData } from "@/components/admin-setup/forms/forms-meta-data/FormMetaDataTypes";

export const permissionFormMetaData: FormMetaData = {
  title: "Add Resource",
  fields: [
    {
      fieldName: "resource_type",
      label: "Resource Type",
      type: "text",
      defaultValue: "WORKFLOW",
      requiredIn: ["create"],
      editableIn: [],
      grid: { xs: 12, sm: 6 },
    },
    {
      fieldName: "resource_name",
      label: "Resource Name",
      type: "select",
      requiredIn: ["create"],
      editableIn: ["create"],
      grid: { xs: 12, sm: 6 },
    },
  ],
};
