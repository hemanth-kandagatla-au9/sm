import type { ReactNode } from "react";

export type FormMode = "create" | "edit";

export type FieldType = "text" | "textarea" | "number" | "url" | "select";

export type SelectOption = {
  label: string;
  value: string;
};

export type FieldGridSpan = {
  xs?: number;
  sm?: number;
  md?: number;
  lg?: number;
  xl?: number;
};

export type FieldGroup = {
  key: string;
  label?: string;
};

export type FieldMetaData = {
  fieldName: string;
  label: string;
  type: FieldType;
  placeholder?: string;
  endAdornment?: ReactNode;
  defaultValue?: string | number;
  group?: FieldGroup;
  grid?: FieldGridSpan;
  requiredIn?: FormMode[];
  editableIn?: FormMode[];
  visibleIn?: FormMode[];
  options?: SelectOption[];
};

export type FormMetaData = {
  title: string;
  fields: FieldMetaData[];
};

export const isFieldRequired = (
  field: FieldMetaData,
  mode: FormMode,
): boolean => {
  return field.requiredIn ? field.requiredIn.includes(mode) : false;
};

export const isFieldEditable = (
  field: FieldMetaData,
  mode: FormMode,
): boolean => {
  return field.editableIn ? field.editableIn.includes(mode) : true;
};
