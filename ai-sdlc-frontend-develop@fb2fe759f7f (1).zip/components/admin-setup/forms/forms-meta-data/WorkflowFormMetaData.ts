import type { FormMetaData } from "@/components/admin-setup/forms/forms-meta-data/FormMetaDataTypes";

export const workflowFormMetaData: FormMetaData = {
  title: "Register Workflow",
  fields: [
    {
      fieldName: "workflow_name",
      label: "Workflow Name",
      type: "text",
      placeholder: "Enter workflow name",
      grid: { xs: 12, sm: 6 },
      requiredIn: ["create"],
      editableIn: ["create"],
    },
    {
      fieldName: "version",
      label: "Version",
      type: "text",
      placeholder: "e.g. 1.1.0",
      grid: { xs: 12, sm: 6 },
      requiredIn: ["create"],
      editableIn: ["create"],
    },
    {
      fieldName: "workflow_desc",
      label: "Workflow Description",
      type: "textarea",
      placeholder: "Enter workflow description",
      grid: { xs: 12 },
      requiredIn: ["create"],
      editableIn: ["create"],
    },
  ],
};
