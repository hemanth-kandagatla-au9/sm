"use client";
import TableHeader from "@/components/common/TableHeader";
import CustomDataGrid from "@/components/resuable-components/CustomDataGrid";
import axiosInstance from "@/lib/api/axiosInstance";
import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import ToastHelper, {
  promiseLoadingToastStyle,
} from "@/components/common/ToastHelper";
import { projectRoleCostColumns } from "./utility/ColDef";
import { GridRowModel } from "@mui/x-data-grid";
import { extractApiErrorMessage } from "@/services/chat/utils";

type ProjectRoleRow = {
  project_role_id: number;
  project_id: number;
  role_id: number;
  ad_group_name: string;
  ad_group_object_id: string | null;
  cost: number | null;
};

type UpdateRoleCostResponse = {
  success: boolean;
  data: ProjectRoleRow | null;
  error: {
    message: string;
    error_type?: string | null;
    details?: unknown;
  } | null;
};


const ProjectRoleMapping = () => {
  const [rows, setRows] = useState<ProjectRoleRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [globalSearch, setGlobalSearch] = useState("");

  useEffect(() => {
    const fetchProjectRoleMapping = async () => {
      setLoading(true);
      try {
        const response = await axiosInstance.get("/sdlc/projects/roles");
        setRows(response.data?.data ?? []);
      } catch (err: unknown) {
        const errorMessage = extractApiErrorMessage(
          err,
          "Failed to load project role mappings. Please try again.",
        );
        ToastHelper.showRespToast({ status: false, message: errorMessage });
        setRows([]);
      } finally {
        setLoading(false);
      }
    };

    fetchProjectRoleMapping();
  }, []);

  const handleRowDataUpdate = async (
    newRow: GridRowModel,
    oldRow: GridRowModel,
  ) => {
    const updatedRow = newRow as ProjectRoleRow;
    const previousRow = oldRow as ProjectRoleRow;
    const nextCost = Number(updatedRow.cost);

    if (updatedRow.cost === previousRow.cost) {
      return previousRow;
    }

    if (!Number.isNaN(nextCost) && nextCost < 0) {
      ToastHelper.showRespToast({
        status: false,
        message: "Cost must be greater than or equal to 0",
      });
      return previousRow;
    }

    try {
      const result = await toast.promise(
        axiosInstance.patch<UpdateRoleCostResponse>(
          `/sdlc/projects/${updatedRow.project_id}/roles/${updatedRow.project_role_id}`,
          { cost: updatedRow.cost },
        ),
        {
          loading: "Updating cost...",
          success: ({ data: resp }) => {
            ToastHelper.showRespToast({
              status: resp.success,
              message: resp.error?.message ?? "Cost updated successfully",
            });
            return null;
          },
          error: (err) => extractApiErrorMessage(err, "Failed to update cost"),
        },
        promiseLoadingToastStyle,
      );
      // Updating only the edited row locally after a successful API response to avoid a full refetch.
      if (result.data.success) {
        setRows((prevRows) =>
          prevRows.map((row) =>
            row.project_role_id === updatedRow.project_role_id
              ? ({
                  ...row,
                  ...updatedRow,
                  cost: updatedRow.cost,
                } as ProjectRoleRow)
              : row,
          ),
        );
      }
      // Returning a row commits the edit and exits cell edit mode in DataGrid otherwise it stay in edit mode
      return result.data.success
        ? ({ ...updatedRow, cost: updatedRow.cost } as ProjectRoleRow)
        : previousRow;
    } catch {
      return previousRow;
    }
  };

  return (
    <div className="space-y-2">
      <TableHeader
        title="Project Role Mapping"
        globalSearch={globalSearch}
        setGlobalSearch={setGlobalSearch}
      />
      <CustomDataGrid
        loading={loading}
        data={rows}
        columns={projectRoleCostColumns}
        getRowId={(row) => row.project_role_id}
        searchValue={globalSearch}
        gridCustomSx={{ height: "calc(100vh - 230px)" }}
        handleProcessRowUpdate={handleRowDataUpdate}
        defaultSortingField="project_id"
      />
    </div>
  );
};

export default ProjectRoleMapping;
