import { renderDataGridChip, ResourceTypeCell } from "@/components/common/Helper";
import { Clock3, Pencil, Trash2 } from "lucide-react";
import { GridColDef, GridRenderCellParams } from "@mui/x-data-grid";
import { formatConversationDate } from "@/lib/utils";

type ProjectRow = {
  project_id: string | number;
  project_name?: string;
  atlassian_project_id?: string;
  asas_id?: string;
  project_owner_user_id?: number;
  project_description?: string;
  created_by?: number;
  // compliance_id?: number;
  // region_id?: number;
  // sector_id?: number;
  // bu_approver_id?: number;
  // bu_finance_id?: number;
  zcode?: string;
  company_code?: string;
  acar_number?: string;
  capital_cost_element?: string;
  expense_cost_element?: string;
  expense_cost_center?: string;
  capital_internal_order?: string;
  expense_internal_order?: string;
  // data_type_id?: number;
  start_date?: string;
  end_date?: string;
  ERP_flag?: boolean;
  Non_ERP_flag?: boolean;
  MLL_flag?: boolean;
  Other_Vertical_flag?: boolean;
  MT_flag?: boolean;
  IM_flag?: boolean;
  CBT_flag?: boolean;
};

type PermissionRow = {
  permission_id: number;
  project_role_id: number;
  ad_group_name: string;
  resource_type: string;
  resource_id: number;
  resource_name: string;
  agent_proj_id: number | null;
  project_id: number;
  project_name: string;
  role_name: string;
};

const roleColumns: GridColDef[] = [
  { field: "id", headerName: "Role ID", minWidth: 150 },
  { field: "role_name", headerName: "Role Name", minWidth: 220, flex: 1.5 },
];

const projectColumns = (
  onEditProject: (row: ProjectRow) => void,
): GridColDef[] => [
  { field: "project_id", headerName: "Project ID", minWidth: 150 },
  { field: "project_name", headerName: "Project Name", minWidth: 200, flex: 1 },
  { field: "project_description", headerName: "Project Description", minWidth: 260, flex: 1.4, type: "longText" },
  { field: "atlassian_project_id", headerName: "Atlassian Project ID", minWidth: 190, flex: 1 },
  { field: "asas_id", headerName: "SASA ID", minWidth: 140, flex: 0.8 },
  // { field: "project_owner_user_id", headerName: "Project Owner User ID", minWidth: 210, flex: 1 },
  // { field: "compliance_id", headerName: "Compliance ID", minWidth: 150, flex: 0.8 },
  // { field: "region_id", headerName: "Region ID", minWidth: 130, flex: 0.8 },
  // { field: "sector_id", headerName: "Sector ID", minWidth: 130, flex: 0.8 },
  { field: "zcode", headerName: "Z Code", minWidth: 130, flex: 0.8 },
  { field: "company_code", headerName: "Company Code", minWidth: 150, flex: 0.9 },
  { field: "acar_number", headerName: "ACAR Number", minWidth: 170, flex: 0.9 },
  { field: "capital_cost_element", headerName: "Capital Cost Element", minWidth: 200, flex: 1 },
  { field: "expense_cost_element", headerName: "Expense Cost Element", minWidth: 220, flex: 1 },
  { field: "expense_cost_center", headerName: "Expense Cost Center", minWidth: 200, flex: 1 },
  { field: "capital_internal_order", headerName: "Capital Internal Order", minWidth: 210, flex: 1 },
  { field: "expense_internal_order", headerName: "Expense Internal Order", minWidth: 210, flex: 1 },
  // { field: "data_type_id", headerName: "Data Type ID", minWidth: 140, flex: 0.8 },
  { field: "start_date", headerName: "Start Date", minWidth: 140, flex: 0.8, renderCell: (params) => formatConversationDate(params.value, false,false) },
  { field: "end_date", headerName: "End Date", minWidth: 140, flex: 0.8, renderCell: (params) => formatConversationDate(params.value, false,false) },
  { field: "ERP_flag", headerName: "ERP", minWidth: 100, flex: 0.6,renderCell: (params) => renderDataGridChip(params.value),},
  { field: "Non_ERP_flag", headerName: "Non ERP", minWidth: 120, flex: 0.7, renderCell: (params) => renderDataGridChip(params.value),},
  { field: "MLL_flag", headerName: "MLL", minWidth: 100, flex: 0.6, renderCell: (params) => renderDataGridChip(params.value),},
  { field: "Other_Vertical_flag", headerName: "Data", minWidth: 150, flex: 0.8, renderCell: (params) => renderDataGridChip(params.value),},
  { field: "MT_flag", headerName: "MT", minWidth: 100, flex: 0.6, renderCell: (params) => renderDataGridChip(params.value),},
  { field: "IM_flag", headerName: "IM", minWidth: 100, flex: 0.6, renderCell: (params) => renderDataGridChip(params.value),},
  { field: "CBT_flag", headerName: "CBT", minWidth: 100, flex: 0.6, renderCell: (params) => renderDataGridChip(params.value),},
  { field: "created_at", headerName: "Created At", minWidth: 170, flex: 1,  renderCell: (params) => params.value =formatConversationDate(params.value),},
  {
    field: "actions",
    headerName: "Actions",
    minWidth: 180,
    renderCell: (params: GridRenderCellParams<ProjectRow>) => (
      <button
        type="button"
        className="inline-flex items-center justify-center p-1.5 text-[#6b7280] hover:text-[#EB1700] focus:outline-none"
        onClick={() => {
          onEditProject(params.row);
        }}
      >
        <Pencil size={18} />
      </button>
    ),
  },
];

const projectRoleCostColumns: GridColDef[] = [
  // {field: "project_role_id", headerName: "Project Role ID", flex: 0.7 },
  { field: "project_id", headerName: "Project ID", minWidth: 120, flex: 0.7 },
  { field: "project_name", headerName: "Project Name", minWidth: 200, flex: 1.1 },
  { field: "role_id", headerName: "Role ID", minWidth: 120, flex: 0.7 },
  { field: "role_name", headerName: "Role Name", minWidth: 170, flex: 1 },
  { field: "ad_group_name", headerName: "AD Group Name", minWidth: 300, flex: 1.7 },
  // { field: "ad_group_object_id", headerName: "AD Group Object ID", minWidth: 300, flex: 1.7 },
  {
    field: "cost",
    headerName: "Cost",
    minWidth: 120,
    flex: 0.7,
    editable: true,
    type: "number",
    headerAlign: "left",
    renderCell: (params) =>
      params.value !== null ? (
        `${params.value}`
      ) : (
        <div className="text-[gray]">Enter the cost</div>
      ),
  },
];

const agentColumns: GridColDef[] = [
  { field: "agent_id", headerName: "Agent ID", minWidth: 110, flex: 0.6 },
  { field: "agent_name", headerName: "Agent Name", minWidth: 200, flex: 1.1 },
  { field: "agent_desc", headerName: "Agent Description", type: "longText", minWidth: 320, flex: 1.8 },
  {
    field: "baseline_effort_hours",
    headerName: "Baseline Effort Hours",
    minWidth: 180,
    flex: 0.9,
    renderCell: (params) => (
      <div className="flex items-center gap-2">
        <Clock3 size={14} className="text-[#6b7280]" />
        <span>{params.value ?? "--"}</span>
      </div>
    ),
  },
  { field: "experience_weight", headerName: "Experience Weight", minWidth: 150, flex: 0.7, renderCell: (params) => (
      <div className="flex items-center gap-2">
        <span>{params.value != null ? `${params.value} %` : '--'}</span>
      </div>
    ),
  },
  { field: "effectiveness_weight", headerName: "Effectiveness Weight", minWidth: 150, flex: 0.7, renderCell: (params) => (
      <div className="flex items-center gap-2">
        <span>{params.value != null ? `${params.value} %` : '--'}</span>
      </div>
    ),
  },
  { field: "efficiency_weight", headerName: "Efficiency Weight", minWidth: 180, flex: 0.9, renderCell: (params) => (
      <div className="flex items-center gap-2">
       <span>{params.value != null ? `${params.value} %` : '--'}</span>
      </div>
    ),
  },
  { field: "is_active", headerName: "Is Active", minWidth: 110, flex: 0.6, renderCell: (params) => renderDataGridChip(params.value) },
];

const mcpColumns: GridColDef[] = [
  { field: "mcp_id", headerName: "MCP ID", minWidth: 100, flex: 0.6 },
  { field: "mcp_name", headerName: "MCP Name", minWidth: 180, flex: 1 },
  { field: "mcp_desc", headerName: "MCP Description", type: "longText", minWidth: 260, flex: 1.4 },
  { field: "endpoint_url", headerName: "Endpoint URL", minWidth: 260, type: "longText", flex: 1.3 },
  { field: "transport_type", headerName: "Transport Type", minWidth: 150, type: "longText", flex: 0.8 },
  { field: "is_active", headerName: "Is Active", minWidth: 120, flex: 0.6, renderCell: (params) => renderDataGridChip(params.value) },
];

const workFlowColumns: GridColDef[] = [
  { field: "workflow_id", headerName: "Workflow ID", minWidth: 120, flex: 0.6 },
  { field: "workflow_name", headerName: "Workflow Name", minWidth: 200, flex: 1.1 },
  { field: "workflow_desc", headerName: "Description", type: "longText", minWidth: 280, flex: 1.5 },
  { field: "version", headerName: "Version", minWidth: 120, flex: 0.6 },
  { field: "is_active", headerName: "Is Active", minWidth: 120, flex: 0.6, renderCell: (params) => renderDataGridChip(params.value) },
];

const permissionColumns = (
  onRevokePermission: (row: PermissionRow) => void,
): GridColDef[] => [
  { field: "project_name", headerName: "Project Name", minWidth: 170, flex: 1 },
  { field: "role_name", headerName: "Role Name", minWidth: 150, flex: 1 },
  { field: "ad_group_name", headerName: "AD Group Name", minWidth: 240, flex: 2 },
  {
    field: "resource_type",
    headerName: "Resource Type",
    minWidth: 180,
    flex: 0.9,
    renderCell: (params) => (
      <ResourceTypeCell value={String(params.value ?? "")} />
    ),
  },
  {
    field: "resource_name",
    headerName: "Resource Name",
    minWidth: 220,
    flex: 1.7,
  },

  {
    field: "actions",
    headerName: "Actions",
    minWidth: 150,
    flex: 0.7,
    renderCell: (params: GridRenderCellParams<PermissionRow>) => (
      <button type="button" onClick={() => onRevokePermission(params.row)}>
        <Trash2 size={18} className="text-[#6b7280] hover:text-[#EB1700]" />
      </button>
    ),
  },
];

export {
  roleColumns,
  agentColumns,
  mcpColumns,
  workFlowColumns,
  permissionColumns,
  projectRoleCostColumns,
  projectColumns,
};
export type { ProjectRow, PermissionRow };
