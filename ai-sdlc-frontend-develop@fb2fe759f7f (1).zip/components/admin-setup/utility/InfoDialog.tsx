"use client";

import CustomDataGrid from "@/components/resuable-components/CustomDataGrid";
import {
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Divider,
  Typography,
} from "@mui/material";
import { GridColDef } from "@mui/x-data-grid";
import { useMemo } from "react";
import { primaryButtonSx } from "../../common/Helper";
import { ArrowRight } from "lucide-react";

type AdPreviewRow = {
  role_id: number;
  role_name: string;
  ad_group_name: string;
};

type CreatedProjectResponse = {
  project_id?: string | number;
  project_name?: string;
  project_number?: string | number;
  ad_group_previews?: AdPreviewRow[];
  ad_preview?: AdPreviewRow[];
};

type InfoDialogProps = {
  open: boolean;
  onClose: () => void;
  createdProjectResp: CreatedProjectResponse | null;
};

const InfoDialog = ({ open, onClose, createdProjectResp }: InfoDialogProps) => {
  const previewRows = useMemo(
    () =>
      createdProjectResp?.ad_group_previews ??
      createdProjectResp?.ad_preview ??
      [],
    [createdProjectResp],
  );

  const columns: GridColDef[] = useMemo(
    () => [
      { field: "role_name", headerName: "Role", minWidth: 220, flex: 1 },
      {
        field: "ad_group_name",
        headerName: "AD Group",
        minWidth: 360,
        flex: 1.6,
      },
    ],
    [],
  );

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle sx={{ fontSize: "16px", color: "#1a1817", fontWeight: "500", fontFamily: "var(--app-font-display)", p: "16px" }}>Preview Project Role Created</DialogTitle>
      <Divider />
      <DialogContent sx={{ pt: 2 }}>
        <Box sx={{ mb: 2 }}>
          <Typography sx={{ fontSize: "16px", color: "#1a1817", fontFamily: "var(--app-font-text)" }}>
            Project ID: {createdProjectResp?.project_number ?? "-"}
          </Typography>
        </Box>

        <CustomDataGrid
          loading={false}
          data={previewRows}
          columns={columns}
          getRowId={(row) => row.role_id}
          gridCustomSx={{ height: 360 }}
        />
      </DialogContent>
      <DialogActions sx={{ px: 3, pb: 2 }}>
        <Button variant="contained" onClick={onClose} sx={primaryButtonSx} endIcon={<ArrowRight size={16} />}>
          Continue
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default InfoDialog;