"use client";

import TableHeader from "@/components/common/TableHeader";
import NoDataScreen from "@/components/common/NoDataScreen";
import CustomDataGrid from "@/components/resuable-components/CustomDataGrid";
import axiosInstance from "@/lib/api/axiosInstance";
import { CircularProgress } from "@mui/material";
import { useEffect, useState } from "react";
import { Plus } from "lucide-react";
import GroupedFormFieldBuilder from "../forms/form-builder-wrapper/GroupedFormFieldBuilder";
import { type FormMode } from "@/components/admin-setup/forms/forms-meta-data/ProjectFormMetaData";
import type { SelectOption } from "@/components/admin-setup/forms/forms-meta-data/ProjectFormMetaData";
import ToastHelper, {
  promiseLoadingToastStyle,
} from "@/components/common/ToastHelper";
import { getSessionUserId } from "@/lib/auth/user-helper";
import InfoDialog from "../utility/InfoDialog";
import { adGroupPreDevConfig } from "@/adgroupconfig/adpredevconfig";
import toast from "react-hot-toast";
import {
  buildRequestPayload,
  dropdownSources,
  mapRecordsToOptions,
  normalizeEditFormData,
} from "./projectFormUtils";
import { projectColumns, type ProjectRow } from "../utility/ColDef";
import { extractApiErrorMessage } from "@/services/chat/utils";

type AdPreviewRow = {
  role_id: number;
  role_name: string;
  ad_group_name: string;
};

type CreatedProjectResponse = {
  project_id?: string | number;
  project_name?: string;
  ad_group_previews?: AdPreviewRow[];
};

type ResourceResponse<TData = unknown> = {
  success: boolean;
  data: TData | null;
  error: {
    message: string;
    error_type?: string | null;
    details?: unknown;
  } | null;
};

const Projects = () => {
  const [projects, setProjects] = useState<ProjectRow[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isProjectDialogOpen, setIsProjectDialogOpen] = useState(false);
  const [projectDialogMode, setProjectDialogMode] =
    useState<FormMode>("create");
  const [selectedProjectId, setSelectedProjectId] = useState<
    string | number | undefined
  >(undefined);
  const [initialFormData, setInitialFormData] = useState<
    Record<string, string | number | boolean | Date> | undefined
  >(undefined);
  const [globalSearch, setGlobalSearch] = useState("");
  const [createdProjectResp, setCreatedProjectResp] =
    useState<CreatedProjectResponse | null>(null);
  const [dropdownOptionsByField, setDropdownOptionsByField] = useState<
    Record<string, SelectOption[]>
  >({});
  const [isFormLoading, setIsFormLoading] = useState(false);
  const [infoMessageDialog, setInfoMessageDialog] = useState(false);
  const showInitialLoader = isLoading && projects.length === 0;
  const showNoDataScreen = !isLoading && projects.length === 0;

  const loadFormDropdowns = async () => {
    setIsFormLoading(true);
    try {
      const results = await Promise.allSettled(
        dropdownSources.map((source) => axiosInstance.get(source.endpoint)),
      );

      const nextDropdownOptions: Record<string, SelectOption[]> = {};

      results.forEach((result, index) => {
        const source = dropdownSources[index];

        if (result.status !== "fulfilled") {
          nextDropdownOptions[source.fieldName] = [];
          return;
        }

        const records =
          (result.value.data.data as Record<string, unknown>[] | undefined) ??
          [];

        nextDropdownOptions[source.fieldName] = mapRecordsToOptions(
          records,
          source,
        );
      });

      setDropdownOptionsByField(nextDropdownOptions);
    } catch (err: unknown) {
      const errorMessage = extractApiErrorMessage(
        err,
        "Failed to load form dropdowns. Please try again.",
      );
      ToastHelper.showRespToast({ status: false, message: errorMessage });
      setDropdownOptionsByField({});
    } finally {
      setIsFormLoading(false);
    }
  };

  const fetchProjects = async () => {
    setIsLoading(true);
    try {
      const response = await axiosInstance.get("/sdlc/projects");
      setProjects(response.data.data ?? []);
    } catch (err: unknown) {
      const errorMessage = extractApiErrorMessage(
        err,
        "Failed to load projects. Please try again.",
      );
      ToastHelper.showRespToast({ status: false, message: errorMessage });
      setProjects([]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCreateProject = async (
    values: Record<string, string | number | boolean | Date>,
  ) => {
    const payload = buildRequestPayload(values);

    const createResult = await toast.promise(
      axiosInstance.post<ResourceResponse<CreatedProjectResponse>>("/sdlc/projects", {
        ...payload,
        created_by: getSessionUserId(),
      }),
      {
        loading: "Creating project...",
        success: ({ data: resp }) => {
          ToastHelper.showRespToast({
            status: resp.success,
            message: resp.error?.message ?? "Project created successfully.",
          });
          return null;
        },
        error: (err) => {
          const errorMessage = extractApiErrorMessage(
            err,
            "Failed to create project",
          );
          ToastHelper.showRespToast({ status: false, message: errorMessage });
          return null;
        },
      },
      promiseLoadingToastStyle,
    );

    if (!createResult.data.success) {
      return;
    }

    const responsePayload = createResult.data.data as CreatedProjectResponse;
    setCreatedProjectResp(responsePayload);

    // Extract unique ad_group_name values
    const adGroupsList = responsePayload?.ad_group_previews ?? [];
    const uniqueAdGroups = [
      ...new Set(adGroupsList.map(({ ad_group_name }) => ad_group_name)),
    ];

    setIsProjectDialogOpen(false);
    setInfoMessageDialog(true);

    // Call adgroups/create endpoint with extracted group names
    if (uniqueAdGroups.length > 0) {
      const adGroupPayload = {
        ...adGroupPreDevConfig,
        group_names: uniqueAdGroups,
      };

        await toast.promise(
          axiosInstance.post<ResourceResponse>(
            "/adgroups/create",
            adGroupPayload,
          ),
          {
            loading: "Creating AD groups...",
            success: ({ data: resp }) => {
              ToastHelper.showRespToast({
                status: resp.success,
                message:
                  resp.error?.message ?? "AD groups created successfully.",
              });
              return null;
            },
            error: (err) => {
              const errorMessage = extractApiErrorMessage(
                err,
                "Failed to create AD groups",
              );
              ToastHelper.showRespToast({ status: false, message: errorMessage });
              return null;
            },
          },
        promiseLoadingToastStyle,
      );
    }

    await fetchProjects();
  };

  const handleUpdateProject = async (
    values: Record<string, string | number | boolean | Date>,
  ) => {
    if (!selectedProjectId) {
      ToastHelper.showRespToast({
        status: false,
        message: "Project ID is missing for update.",
      });
      return;
    }

    const payload = buildRequestPayload(values);
      const updateResult = await toast.promise(
        axiosInstance.put<ResourceResponse>(`/sdlc/projects/${selectedProjectId}`, {
          ...payload,
          updated_by: getSessionUserId(),
        }),
        {
          loading: "Updating project...",
          success: ({ data: resp }) => {
            ToastHelper.showRespToast({
              status: resp.success,
              message: resp.error?.message ?? "Project updated successfully.",
            });
            return null;
        },
        error: (err) => {
          const errorMessage = extractApiErrorMessage(
            err,
            "Failed to update project",
          );
          ToastHelper.showRespToast({ status: false, message: errorMessage });
          return null;
        },
      },
      promiseLoadingToastStyle,
    );

      if (!updateResult.data.success) {
        return;
      }

      setIsProjectDialogOpen(false);
      resetProjectDialogState();
      await fetchProjects();
   };

  const handleProjectSubmit = async (
    values: Record<string, string | number | boolean | Date>,
  ) => {
    if (projectDialogMode === "edit") {
      await handleUpdateProject(values);
      return; //if this line is removed handleCreateProject will be called and ad provisining will be done again
    }

    await handleCreateProject(values);
  };

  const resetProjectDialogState = () => {
    setSelectedProjectId(undefined);
    setInitialFormData(undefined);
  };

  const openProjectDialog = ({
    mode,
    projectId,
    formData,
  }: {
    mode: FormMode;
    projectId?: string | number;
    formData?: Record<string, string | number | boolean | Date>;
  }) => {
    setProjectDialogMode(mode);
    setSelectedProjectId(projectId);
    setInitialFormData(formData);
    setIsProjectDialogOpen(true);
    void loadFormDropdowns();
  };

  const handleOpenCreateProjectDialog = () => {
    openProjectDialog({ mode: "create" });
  };

  const handleOpenEditProjectDialog = (row: ProjectRow) => {
    openProjectDialog({
      mode: "edit",
      projectId: row.project_id,
      formData: normalizeEditFormData(row),
    });
  };

  const handleCloseProjectDialog = () => {
    setIsProjectDialogOpen(false);
    resetProjectDialogState();
  };

  const columns = projectColumns(handleOpenEditProjectDialog);

  useEffect(() => {
    fetchProjects();
  }, []);

  return (
    <div className="space-y-2">
      <GroupedFormFieldBuilder
        open={isProjectDialogOpen}
        onClose={handleCloseProjectDialog}
        mode={projectDialogMode}
        handleProjectSubmit={handleProjectSubmit}
        initialFormData={initialFormData}
        dropdownOptionsByField={dropdownOptionsByField}
        loading={isFormLoading}
      />

      {showInitialLoader ? (
        <div className="flex min-h-[calc(100vh-230px)] w-full items-center justify-center">
          <CircularProgress size={35} sx={{ color: "#eb1700" }} />
        </div>
      ) : showNoDataScreen ? (
        <NoDataScreen
          primaryText="No projects found"
          secondaryText="Please add a new project to get started."
          buttonText="Add Project"
          buttonIcon={<Plus size={16} />}
          onButtonClick={handleOpenCreateProjectDialog}
        />
      ) : (
        <>
          <TableHeader
            title="Projects"
            globalSearch={globalSearch}
            setGlobalSearch={setGlobalSearch}
            haveActionsButton={true}
            buttonText="Add Projects"
            buttonIcon={<Plus size={16} />}
            onButtonClick={handleOpenCreateProjectDialog}
          />
          <CustomDataGrid
            loading={isLoading}
            data={projects}
            columns={columns}
            getRowId={(row) => row.project_id}
            searchValue={globalSearch}
            gridCustomSx={{ height: "calc(100vh - 230px)" }}
            defaultSortingField="project_id"
          />
        </>
      )}
      <InfoDialog
        open={infoMessageDialog}
        onClose={() => setInfoMessageDialog(false)}
        createdProjectResp={createdProjectResp}
      />
    </div>
  );
};

export default Projects;