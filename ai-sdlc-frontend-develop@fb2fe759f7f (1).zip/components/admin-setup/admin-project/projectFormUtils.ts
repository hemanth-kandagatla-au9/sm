import type { SelectOption } from "@/components/admin-setup/forms/forms-meta-data/ProjectFormMetaData";

export type DropdownSourceConfig = {
  fieldName: string;
  endpoint: string;
  idKey: string; //key to use for option value
  nameKey: string; //key to use for option label
  activeKey?: string; //key to filter the active one
};

export const dropdownSources: DropdownSourceConfig[] = [
  // {
  //   fieldName: "project_owner_user_id",
  //   endpoint: "/sdlc/users",
  //   idKey: "user_id",
  //   nameKey: "display_name",
  // },
  // {
  //   fieldName: "region_id",
  //   endpoint: "/sdlc/reference/regions",
  //   idKey: "region_id",
  //   nameKey: "name",
  //   activeKey: "is_active",
  // },
  // {
  //   fieldName: "compliance_id",
  //   endpoint: "/sdlc/reference/compliances",
  //   idKey: "compliance_id",
  //   nameKey: "name",
  //   activeKey: "is_active",
  // },
  // {
  //   fieldName: "sector_id",
  //   endpoint: "/sdlc/reference/sectors",
  //   idKey: "sector_id",
  //   nameKey: "name",
  //   activeKey: "is_active",
  // },
  // {
  //   fieldName: "data_type_id",
  //   endpoint: "/sdlc/reference/data-types",
  //   idKey: "data_type_id",
  //   nameKey: "name",
  //   activeKey: "is_active",
  // },
];

export const booleanFlagFields = [
  "ERP_flag",
  "Non_ERP_flag",
  "MLL_flag",
  "MT_flag",
  "IM_flag",
  "CBT_flag",
  "Other_Vertical_flag",
] as const;

type PayloadValue = string | number | boolean | Date | null;
type Payload = Record<string, PayloadValue>;

const isEmptySelection = (value: PayloadValue | undefined): boolean =>
  value === undefined || value === null || value === "";

const normalizeDropdownValue = (
  value: PayloadValue | undefined,
): PayloadValue => {
  if (value === undefined || value === "") {
    return null;
  }

  // for values like "0" which are valid but falsy for backend, checking if the conversion results in NaN
  const numericValue = Number(value);
  return Number.isNaN(numericValue) ? value : numericValue;
};

const normalizeBooleanFlagValue = (
  value: PayloadValue | undefined,
): boolean | null => {
  // covers undefined, null and empty string, default send to backend as false if not provided
  if (isEmptySelection(value)) {
    return false;
  }

  if (typeof value === "string") {
    const normalizedValue = value.trim().toLowerCase();

    if (normalizedValue === "true") {
      return true;
    }

    if (normalizedValue === "false") {
      return false;
    }
  }
  return null;
};

const normalizeNullableDateField = (
  payload: Payload,
  fieldName: "start_date" | "end_date",
) => {
  if (payload[fieldName] === "" || payload[fieldName] === undefined) {
    payload[fieldName] = null;
  }
};

const normalizeBooleanFlagValueForEdit = (
  value: PayloadValue | undefined,
): "true" | "false" | undefined => {
  if (isEmptySelection(value)) {
    return undefined;
  }

  const normalizedValue = normalizeBooleanFlagValue(value);

  if (typeof normalizedValue !== "boolean") {
    return undefined;
  }

  return normalizedValue ? "true" : "false";
};

export const mapRecordsToOptions = (
  records: Record<string, unknown>[],
  source: DropdownSourceConfig,
): SelectOption[] => {
  return records
    .filter((record) => {
      if (!source.activeKey) {
        return true;
      }

      return Boolean(record[source.activeKey]);
    })
    .map((record): SelectOption | null => {
      const value = record[source.idKey];
      const label = record[source.nameKey];

      if (value === undefined || value === null || !label) {
        return null;
      }

      return {
        value: String(value),
        label: String(label),
      };
    })
    .filter((option): option is SelectOption => option !== null);
};

export const buildRequestPayload = (
  values: Payload,
  sources: DropdownSourceConfig[] = dropdownSources,
): Payload => {
  const payload: Payload = {
    ...values,
  };

  sources.forEach((source) => {
    payload[source.fieldName] = normalizeDropdownValue(
      payload[source.fieldName],
    );
  });

  booleanFlagFields.forEach((fieldName) => {
    payload[fieldName] = normalizeBooleanFlagValue(payload[fieldName]);
  });

  normalizeNullableDateField(payload, "start_date");
  normalizeNullableDateField(payload, "end_date");

  return payload;
};

export const normalizeEditFormData = (
  row: Record<string, string | number | boolean | Date | null | undefined>,
  sources: DropdownSourceConfig[] = dropdownSources,
): Record<string, string | number | boolean | Date> => {
  const normalized = Object.entries(row).reduce<
    Record<string, string | number | boolean | Date>
  >((acc, [key, value]) => {
    if (value !== undefined && value !== null) {
      acc[key] = value;
    }

    return acc;
  }, {});

  sources.forEach((source) => {
    const valueToUse = row[source.fieldName];

    if (!isEmptySelection(valueToUse)) {
      normalized[source.fieldName] = String(valueToUse);
    }
  });

  booleanFlagFields.forEach((fieldName) => {
    const normalizedValue = normalizeBooleanFlagValueForEdit(row[fieldName]);

    if (normalizedValue !== undefined) {
      normalized[fieldName] = normalizedValue;
    }
  });

  return normalized;
};
