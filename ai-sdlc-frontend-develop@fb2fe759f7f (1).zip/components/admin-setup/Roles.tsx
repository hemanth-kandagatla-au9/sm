"use client";

import TableHeader from "@/components/common/TableHeader";
import CustomDataGrid from "@/components/resuable-components/CustomDataGrid";
import ToastHelper from "@/components/common/ToastHelper";
import axiosInstance from "@/lib/api/axiosInstance";
import type { ProjectRolePreview } from "@/services/types/rolePreviewTypes";
import { useEffect, useMemo, useState } from "react";
import { roleColumns } from "./utility/ColDef";
import { extractApiErrorMessage } from "@/services/chat/utils";

  const Roles = () => {
    const [globalSearch, setGlobalSearch] = useState(""); //state for global search input
    const [roles, setRoles] = useState<ProjectRolePreview[]>([]);
    const [isLoading, setIsLoading] = useState(false);

    useEffect(() => {
      const fetchPreviewRoles = async () => {
        setIsLoading(true);

        try {
          const response = await axiosInstance.get(
            "/sdlc/projects/preview-roles",
          );

          setRoles(response.data.data.roles ?? []);
        } catch (err: unknown) {
          const errorMessage = extractApiErrorMessage(
            err,
            "Failed to fetch preview project roles. Please try again.",
          );
          setRoles([]);
          ToastHelper.showRespToast({ status: false, message: errorMessage });
        } finally {
          setIsLoading(false);
        }
      };

      fetchPreviewRoles();
    }, []);

    //attaching an unique id to each row for data grid,
    const rows = useMemo(
      () => roles.map((role, index) => ({ ...role, id: index + 1 })),
      [roles],
    );

    return (
      <div className="space-y-2">
        <TableHeader
          title="Roles"
          globalSearch={globalSearch}
          setGlobalSearch={setGlobalSearch}
        />

        <CustomDataGrid
          loading={isLoading}
          data={rows}
          columns={roleColumns}
          getRowId={(row) => row.id}
          searchValue={globalSearch}
          gridCustomSx={{ height: "calc(100vh - 230px)" }}
          defaultSortingField="role_id"
        />
      </div>
    );
  };

export default Roles;
