"use client";
import { useEffect, useState } from "react";
import { Autocomplete, TextField } from "@mui/material";
import { fieldDropdownListSx, fieldInputSx } from "@/components/common/Helper";
import axiosInstance from "@/lib/api/axiosInstance";
import { Plus } from "lucide-react";
import TableHeader from "@/components/common/TableHeader";
import ToastHelper, { promiseLoadingToastStyle } from "@/components/common/ToastHelper";
import PermissionSelectionMessage from "./PermissionSelectionMessage";
import CustomDataGrid from "@/components/resuable-components/CustomDataGrid";
import { permissionColumns, PermissionRow } from "../utility/ColDef";
import toast from "react-hot-toast";
import FieldBuilderModal from "@/components/admin-setup/forms/form-builder-wrapper/FormFieldBuilderModal";
import { permissionFormMetaData } from "@/components/admin-setup/forms/forms-meta-data/PermissionFormMetaData";
import { type SelectOption } from "@/components/admin-setup/forms/forms-meta-data/FormMetaDataTypes";
import { extractApiErrorMessage } from "@/services/chat/utils";

type ApiItem = {
  project_role_id: number;
  project_id: number;
  project_name: string;
  role_id: number;
  role_name: string;
  ad_group_name: string;
  ad_group_object_id: string | null;
  cost: number;
};

type RoleDetail = {
  role_name: string;
};

type ProjectDetail = {
  project_id: number;
  project_name: string;
};

type WorkflowItem = {
  workflow_id: number;
  workflow_name: string;
  is_active: boolean;
};

const getActiveWorkflows = (workflows: WorkflowItem[]): WorkflowItem[] =>
  workflows.filter((workflow) => workflow.is_active);

const getUniqueProjects = (rows: ApiItem[]): ProjectDetail[] =>
  Array.from(
    new Map(
      rows.map((item) => [
        item.project_id,
        { project_id: item.project_id, project_name: item.project_name },
      ]),
    ).values(),
  );

const getUniqueRolesByName = (rows: ApiItem[]): RoleDetail[] =>
  Array.from(
    new Map(rows.map((item) => [item.role_name, { role_name: item.role_name }])).values(),
  );

const ProjectRoleDropdown = () => {
  const [globalSearch, setGlobalSearch] = useState("");
  const [isProjectRoleLoading, setIsProjectRoleLoading] = useState(false);
  const [isPermissionLoading, setIsPermissionLoading] = useState(false);
  const [apiData, setApiData] = useState<ApiItem[]>([]);
  const [roleDetail, setRoleDetail] = useState<RoleDetail[]>([]);
  const [projectDetail, setProjectDetail] = useState<ProjectDetail[]>([]);
  const [selectedRole, setSelectedRole] = useState<RoleDetail | null>(null);
  const [selectedProject, setSelectedProject] = useState<ProjectDetail | null>(null);
  const [permissionData, setPermissionData] = useState<PermissionRow[]>([]);
  const [reloadData, setReloadData] = useState(false);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [workflowOptions, setWorkflowOptions] = useState<SelectOption[]>([]);
  const [workflowOptionsLoading, setWorkflowOptionsLoading] = useState(false);
  const [selectedProjectRoleRecord, setSelectedProjectRoleRecord] =
    useState<ApiItem | null>(null);
  const loading = isProjectRoleLoading || isPermissionLoading;

  const loadWorkflowOptions = async () => {
    setWorkflowOptionsLoading(true);
    try {
      const workflowResponse = await axiosInstance.get("/sdlc/workflows");
      const workflowRows: WorkflowItem[] = workflowResponse.data?.data ?? [];
      const activeWorkflowRows = getActiveWorkflows(workflowRows);

      const resourceNameOptions: SelectOption[] = activeWorkflowRows.map(
        (workflow) => ({
          label: workflow.workflow_name,
          value: String(workflow.workflow_id),
        }),
      );

      setWorkflowOptions(resourceNameOptions);
    } catch (err: unknown) {
      const errorMessage = extractApiErrorMessage(
        err,
        "Failed to load workflows. Please try again.",
      );
      ToastHelper.showRespToast({
        status: false,
        message: errorMessage,
      });
      setWorkflowOptions([]);
    } finally {
      setWorkflowOptionsLoading(false);
    }
  };

  const handleOpenAddPermissionModal = () => {
    setIsAddModalOpen(true);
    void loadWorkflowOptions();
  };

  const handleCreatePermission = async (values: Record<string, string | number>) => {
    const projectId = selectedProjectRoleRecord?.project_id;
    if (!projectId) return;

    const payload = {
      project_role_id: selectedProjectRoleRecord?.project_role_id,
      resource_type: "WORKFLOW",
      resource_id: Number(values.resource_name),
      agent_proj_id: null,
    };

      await toast.promise(
        axiosInstance.post(`/sdlc/projects/${projectId}/permissions`, payload),
        {
          loading: "Granting permission...",
          success: ({ data: resp }) => {
            ToastHelper.showRespToast({
              status: resp.success,
              message: resp.error?.message ?? "Permission granted successfully.",
            });
            return null;
          },
          error: (err) => {
            const errorMessage = extractApiErrorMessage(
              err,
              "Failed to grant permission",
            );
            ToastHelper.showRespToast({
              status: false,
              message: errorMessage,
            });
            return null;
          },
        },
        promiseLoadingToastStyle,
      );
      setIsAddModalOpen(false);
      setReloadData((prev) => !prev);
  };

  useEffect(() => {
    const fetchProjectRoleData = async () => {
      setIsProjectRoleLoading(true);
      try {
        const apiResponse = await axiosInstance.get("/sdlc/projects/roles");
        const projectRoleRows: ApiItem[] = apiResponse.data?.data ?? [];
        setApiData(projectRoleRows);
        setProjectDetail(getUniqueProjects(projectRoleRows));
        setRoleDetail(getUniqueRolesByName(projectRoleRows));
      } catch (err: unknown) {
        const errorMessage = extractApiErrorMessage(
          err,
          "Failed to load project-role data. Please try again.",
        );
        ToastHelper.showRespToast({
          status: false,
          message: errorMessage,
        });
        setApiData([]);
        setProjectDetail([]);
        setRoleDetail([]);
      } finally {
        setIsProjectRoleLoading(false);
      }
    };

    fetchProjectRoleData();
  }, []);

  useEffect(() => {
    if (!selectedProject || !selectedRole) {
      setSelectedProjectRoleRecord(null);
      setPermissionData([]);
      return;
    }

    const matchingProjectRoleRecords = apiData.filter(
      (item) =>
        item.project_id === selectedProject.project_id &&
        item.role_name === selectedRole.role_name,
    );
    const matchedRecord = matchingProjectRoleRecords[0] ?? null;
    setSelectedProjectRoleRecord(matchedRecord);

    const fetchPermissionsForSelectedProjectRole = async () => {
      if (!matchedRecord) {
        setPermissionData([]);
        return;
      }

      setIsPermissionLoading(true);
      try {
        const permissionsResponse = await axiosInstance.get(
          `/sdlc/projects/${matchedRecord.project_id}/roles/${matchedRecord.project_role_id}/permissions`,
        );

        const permissionsRows = permissionsResponse.data?.data ?? [];
        const enrichedPermissionData: PermissionRow[] = permissionsRows.map(
          (permission: PermissionRow) => ({
            ...permission,
            project_name: selectedProject.project_name,
            project_id: selectedProject.project_id,
            role_name: selectedRole.role_name,
          }),
        );

        setPermissionData(enrichedPermissionData);
      } catch (err: unknown) {
        const errorMessage = extractApiErrorMessage(
          err,
          "Failed to load permissions for the selected project and role. Please try again.",
        );
        ToastHelper.showRespToast({
          status: false,
          message: errorMessage,
        });
        setPermissionData([]);
      } finally {
        setIsPermissionLoading(false);
      }
    };

    fetchPermissionsForSelectedProjectRole();
  }, [selectedProject, selectedRole, apiData, reloadData]);

  const handleRevokePermission = async (row: PermissionRow) => {
    await toast.promise(
      axiosInstance.delete(`/sdlc/projects/${row.project_id}/permissions/${row.permission_id}`),
      {
        loading: "Revoking permission...",
        success: ({ data: resp }) => {
          ToastHelper.showRespToast({
            status: resp.success,
            message: resp.error?.message ?? "Permission revoked successfully.",
          });
          return null;
        },
        error: (err) => extractApiErrorMessage(err, "Failed to revoke permission"),
      },
      promiseLoadingToastStyle,
    );
    setReloadData((prev) => !prev);
  };

  return (
    <div className="space-y-2">
      <TableHeader
        title="Permission"
        showSearch={true}
        globalSearch={globalSearch}
        setGlobalSearch={setGlobalSearch}
        haveActionsButton={Boolean(selectedProject && selectedRole)}
        buttonText={ selectedProject && selectedRole ? "Add Resource" : undefined }
        buttonIcon={ selectedProject && selectedRole ? <Plus size={16} /> : undefined }
        onButtonClick={ selectedProject && selectedRole ? handleOpenAddPermissionModal : undefined}
        rightContent={
          <>
            <Autocomplete
              size="small"
              loading={loading}
              key={"project-autocomplete"}
              options={projectDetail}
              value={selectedProject}
              onChange={(_, newValue) => setSelectedProject(newValue)}
              getOptionLabel={(option) => option.project_name}
              isOptionEqualToValue={(option, value) => option.project_id === value.project_id }
              sx={{ width: "200px", backgroundColor: "white", borderRadius: 2}}
              slotProps={{ listbox: { sx: fieldDropdownListSx } }}
              renderInput={(params) => (
                <TextField {...params} label="Select Project" size="small" sx={fieldInputSx}/>
              )}
            />

            <Autocomplete
              size="small"
              loading={loading}
              key={"role-autocomplete"}
              options={roleDetail}
              value={selectedRole}
              onChange={(_, newValue) => setSelectedRole(newValue)}
              getOptionLabel={(option) => option.role_name}
              sx={{ width: "200px", backgroundColor: "white", borderRadius: 2}}
              slotProps={{ listbox: { sx: fieldDropdownListSx } }}
              renderInput={(params) => (
                <TextField {...params} label="Select Role" size="small" sx={fieldInputSx} />
              )}
            />
          </>
        }
      />
      {!selectedProject ? (
        <PermissionSelectionMessage
          primaryText="No Project selected"
          secondaryText="Please select a project and a role to proceed"
        />
      ) : !selectedRole ? (
        <PermissionSelectionMessage
          primaryText="No Role selected"
          secondaryText="Please select a role to proceed"
        />
      ) : (
        <CustomDataGrid
          loading={loading}
          data={permissionData}
          columns={permissionColumns(handleRevokePermission)}
          getRowId={(row) => row.permission_id}
          searchValue={globalSearch}
          gridCustomSx={{ height: "calc(100vh - 230px)" }}
          defaultSortingField="ad_group_name"
        />
      )}
      <FieldBuilderModal
        open={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        mode="create"
        formMetaData={permissionFormMetaData}
        dropdownOptionsByField={{ resource_name: workflowOptions }}
        loading={workflowOptionsLoading}
        handleResource={handleCreatePermission}
      />
    </div>
  );
};

export default ProjectRoleDropdown;
