type PermissionSelectionMessageProps = {
  primaryText: string;
  secondaryText: string;
};

const PermissionSelectionMessage = ({
  primaryText,
  secondaryText,
}: PermissionSelectionMessageProps) => {
  return (
    <div className="flex min-h-[calc(100vh-230px)] w-full items-center justify-center">
      <div className="flex flex-col items-center gap-4 text-center">
        <div className="space-y-1">
          <p className="text-[34px] text-[#eb1700]">{primaryText}</p>
          <p className="text-[20px] text-[#6b7280]">{secondaryText}</p>
        </div>
      </div>
    </div>
  );
};

export default PermissionSelectionMessage;
