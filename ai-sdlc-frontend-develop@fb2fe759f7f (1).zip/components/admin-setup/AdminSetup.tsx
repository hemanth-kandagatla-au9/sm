import CustomTab, { TabItem } from "@/components/resuable-components/CustomTab";
import Resources from "@/components/admin-setup/admin-resources/Resources";
import Permission from "@/components/admin-setup/admin-permission/Permission";
import ProjectRoleMapping from "@/components/admin-setup/ProjectRoleMapping";
import Projects from "@/components/admin-setup/admin-project/Projects";
import Roles from "@/components/admin-setup/Roles";

const AdminSetup = () => {
  const tabItems: TabItem[] = [
    {
      id: "roles",
      label: "Roles",
      component: <Roles />,
    },
    {
      id: "project",
      label: "Projects",
      component: <Projects />,
    },
    {
      id: "project-role-mapping",
      label: "Project Role Mapping",
      component: <ProjectRoleMapping />,
    },
    {
      id: "resource",
      label: "Resources",
      component: <Resources />,
    },

    {
      id: "permission",
      label: "Permission",
      component: <Permission />,
    },
  ];
  return <CustomTab tabs={tabItems} />;
};

export default AdminSetup;
