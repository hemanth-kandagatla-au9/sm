"use client";

import { ReactNode } from "react";
import { EnabledAuthGuard } from "@/components/auth/enabled-auth";

type AuthGuardProps = {
  children: ReactNode;
};

export function AuthGuard({ children }: AuthGuardProps) {
  return <EnabledAuthGuard>{children}</EnabledAuthGuard>;
}
