"use client";

import Image from "next/image";
import { useState } from "react";
import { LoginRedirectWatcher } from "@/components/auth/enabled-auth";
import { Button } from "@/components/ui/button";
import { handleLogin } from "@/lib/auth/msal";

export function LoginPage() {
  const [isLoading, setIsLoading] = useState(false);

  const handleLoginClick = async () => {
    setIsLoading(true);
    await handleLogin();
  };

  return (
    <main
      className="relative min-h-screen overflow-hidden"
      style={{
        backgroundImage: "url('/assets/login-background.svg')",
        backgroundSize: "cover",
        backgroundRepeat: "no-repeat",
      }}
    >
      <LoginRedirectWatcher />
      <div className="relative flex min-h-screen items-center justify-center ">
        <section className="flex w-120 h-45 flex-col items-center gap-10 rounded-[16px] border border-[#E3E8EF] bg-white p-6 text-center opacity-100">
          <Image
            src="/assets/J&J.png"
            alt="JNJ"
            width={188}
            height={35.61}
            priority
          />
          <Button
            onClick={() => void handleLoginClick()}
            disabled={isLoading}
            className="w-108 h-12.5 font-sans font-medium text-base text-white text-center leading-[100%] tracking-[1%] rounded-[0.8rem] bg-[linear-gradient(135deg,#F72812,#FF5D4C)]"
          >
            {isLoading ? "Redirecting" : "Sign in via SSO"}
          </Button>
        </section>
        <footer className="absolute bottom-4 text-center text-sm text-[#6B7280]">
          &copy; {new Date().getFullYear()} Johnson & Johnson. All rights
          reserved. In case of any issues, please send us an{" "}
          <a
            href="mailto:DL-JJTS-AI-SDLC-Support@its.jnj.com"
            className="text-blue-500 underline"
          >
            email.
          </a>
        </footer>
      </div>
    </main>
  );
}
