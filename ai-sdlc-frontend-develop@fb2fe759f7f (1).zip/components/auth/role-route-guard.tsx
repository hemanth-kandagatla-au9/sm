"use client";

import { ReactNode, useEffect } from "react";
import { usePathname, useRouter } from "next/navigation";
import { canAccessRoute, getDefaultRoute } from "@/lib/auth/roles";

type RoleRouteGuardProps = {
  children: ReactNode;
};

export function RoleRouteGuard({ children }: RoleRouteGuardProps) {
  const pathname = usePathname();
  const router = useRouter();
  const isAllowed = canAccessRoute(pathname);

  useEffect(() => {
    if (!isAllowed) {
      router.replace(getDefaultRoute());
    }
  }, [isAllowed, router]);

  if (!isAllowed) {
    return null;
  }

  return <>{children}</>;
}
