import Image from "next/image";

type LoadingScreenProps = {
  label?: string;
};

export function LoadingScreen({
  label = "Preparing your workspace",
}: LoadingScreenProps) {
  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-(--jnj-ink) px-6 py-10 text-white">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,rgba(201,32,39,0.32),transparent_34%),linear-gradient(135deg,#111827_0%,#3f0d12_50%,#7f1d1d_100%)]" />
      <div className="absolute inset-0 opacity-30 bg-[linear-gradient(rgba(255,255,255,0.08)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.08)_1px,transparent_1px)] bg-size-[96px_96px]" />
      <div className="relative flex flex-col items-center gap-5 rounded-[2rem] border border-white/15 bg-white/8 px-10 py-12 text-center shadow-[0_24px_80px_rgba(0,0,0,0.35)] backdrop-blur-xl">
        <Image
          src="/assets/jnj-mark.svg"
          alt="JNJ"
          width={146}
          height={65}
          priority
          className="h-11 w-auto"
        />
        <div className="flex items-center gap-4">
          <span className="size-3 rounded-full bg-white/50 motion-safe:animate-pulse" />
          <span className="size-3 rounded-full bg-white/70 motion-safe:animate-pulse [animation-delay:120ms]" />
          <span className="size-3 rounded-full bg-(--jnj-red) motion-safe:animate-pulse [animation-delay:240ms]" />
        </div>
        <div className="space-y-1">
          <p className="text-3xl font-medium tracking-[0.08em] text-white">
            JNJ Secure Access
          </p>
          <p className="text-sm uppercase tracking-[0.28em] text-white/65">
            {label}
          </p>
        </div>
      </div>
    </div>
  );
}
