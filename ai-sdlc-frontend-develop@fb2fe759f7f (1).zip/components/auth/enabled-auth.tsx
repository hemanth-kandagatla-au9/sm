"use client";

import { useIsAuthenticated } from "@azure/msal-react";
import { useRouter } from "next/navigation";
import { ReactNode, useEffect } from "react";
import { LoadingScreen } from "@/components/auth/loading-screen";
import { useMsal } from "@azure/msal-react";
import { getDefaultRoute } from "@/lib/auth/roles";
import { setAuthSessionCookie } from "@/lib/auth/session-cookie";

// function getPostLoginRoute(): string {
//   // const lastRoute = sessionStorage.getItem("lastRoute");
//   // if (lastRoute && canAccessRoute(lastRoute)) {
//   //   return lastRoute;
//   // }
//   return getDefaultRoute();
// }

export function EnabledAuthGuard({ children }: { children: ReactNode }) {
  const { inProgress, accounts } = useMsal();
  const router = useRouter();

  const isAuthenticated = accounts.length > 0;

  useEffect(() => {
    if (inProgress === "none" && !isAuthenticated) {
      router.replace("/");
    }
  }, [inProgress, isAuthenticated, router]);

  if (inProgress !== "none") {
    return <LoadingScreen label="Checking authentication..." />;
  }

  if (!isAuthenticated) {
    return null;
  }

  return <>{children}</>;
}

function usePostLoginRedirect(isAuthenticated: boolean) {
  const router = useRouter();

  useEffect(() => {
    if (!isAuthenticated) {
      return;
    }

    let cancelled = false;
    async function redirectToApp() {
      await setAuthSessionCookie();
      if (!cancelled) {
        router.replace(getDefaultRoute());
      }
    }

    void redirectToApp();

    return () => {
      cancelled = true;
    };
  }, [isAuthenticated, router]);
}

export function CallbackRedirect() {
  const isAuthenticated = useIsAuthenticated();
  usePostLoginRedirect(isAuthenticated);

  return <LoadingScreen label="Completing JNJ sign-in" />;
}

export function LoginRedirectWatcher() {
  const isAuthenticated = useIsAuthenticated();
  usePostLoginRedirect(isAuthenticated);

  return null;
}
