"use client";

import { MsalProvider } from "@azure/msal-react";
import { ReactNode, useEffect, useState } from "react";
import { LoadingScreen } from "@/components/auth/loading-screen";
import { SessionSync } from "@/components/auth/session-sync";
import { getMsalInstance, initializeMsal } from "@/lib/auth/msal";

type AppProvidersProps = {
  children: ReactNode;
};

export function AppProviders({ children }: AppProvidersProps) {
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    let isMounted = true;

    async function setup() {
      try {
        await initializeMsal();
      } finally {
        if (isMounted) {
          setIsReady(true);
        }
      }
    }

    void setup();

    return () => {
      isMounted = false;
    };
  }, []);

  if (!isReady) {
    return <LoadingScreen label="Initializing secure workspace" />;
  }

  return (
    <MsalProvider instance={getMsalInstance()}>
      <SessionSync />
      {children}
    </MsalProvider>
  );
}
