"use client";

import { useAccount, useIsAuthenticated, useMsal } from "@azure/msal-react";
import { useEffect } from "react";
import {
  clearAuthSessionCookie,
  setAuthSessionCookie,
} from "@/lib/auth/session-cookie";

export function SessionSync() {
  const isAuthenticated = useIsAuthenticated();
  const account = useAccount();
  const { inProgress } = useMsal();

  useEffect(() => {
    if (inProgress !== "none") {
      return;
    }

    if (isAuthenticated && account) {
      void setAuthSessionCookie();
      return;
    }

    if (!isAuthenticated) {
      void clearAuthSessionCookie();
    }
  }, [account, isAuthenticated, inProgress]);

  return null;
}
