"use client";

import { CallbackRedirect } from "@/components/auth/enabled-auth";

export function AuthCallbackPage() {
  return <CallbackRedirect />;
}
