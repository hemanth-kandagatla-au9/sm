import localFont from "next/font/local";

export const johnsonText = localFont({
  src: [
    {
      path: "./fonts/JohnsonText-Light.woff2",
      weight: "300",
      style: "normal",
    },
    {
      path: "./fonts/JohnsonText-Regular.woff2",
      weight: "400",
      style: "normal",
    },
    {
      path: "./fonts/JohnsonText-Medium.woff2",
      weight: "500",
      style: "normal",
    },
    {
      path: "./fonts/JohnsonText-Bold.woff2",
      weight: "700",
      style: "normal",
    },
  ],
  variable: "--font-johnson-text",
  display: "swap",
});

export const johnsonDisplay = localFont({
  src: [
    {
      path: "./fonts/JohnsonDisplay-Regular.woff2",
      weight: "400",
      style: "normal",
    },
    {
      path: "./fonts/JohnsonDisplay-Medium.woff2",
      weight: "500",
      style: "normal",
    },
  ],
  variable: "--font-johnson-display",
  display: "swap",
});
