import { AuthCallbackPage } from "@/components/auth/auth-callback-page";

export default function CallbackPage() {
  return <AuthCallbackPage />;
}
