import AdminSetup from "@/components/admin-setup/AdminSetup";

const AdminSetupPage = () => {
  return (
    <div>
      <AdminSetup />
    </div>
  );
};

export default AdminSetupPage;
