import MonitoringLayout from "@/components/monitoring/MonitoringLayout";

const MonitoringPage = () => {
  return (
    <div><MonitoringLayout /></div>
  )
}

export default MonitoringPage;