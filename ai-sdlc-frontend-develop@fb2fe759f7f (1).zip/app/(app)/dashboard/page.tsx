import ValueRealizationDashboard from "@/components/dashboardMetrics/page";

export default function DashboardPage() {
  return <ValueRealizationDashboard />;
}
