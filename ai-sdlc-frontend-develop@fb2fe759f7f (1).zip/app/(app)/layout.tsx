"use client";

import React, { useState, useEffect } from "react";
import { usePathname } from "next/navigation";
import { DashboardSidebar } from "@/components/common/dashboard-sidebar";
import { AuthGuard } from "@/components/auth/auth-guard";
import { RoleRouteGuard } from "@/components/auth/role-route-guard";
import { DashboardHeader } from "@/components/common/dashboard-header";
import { canAccessRoute, getPrimaryRole } from "@/lib/auth/roles";
import { getLoggedInUser, getUserClaims } from "@/lib/auth/user-helper";
import { handleLogout } from "@/lib/auth/msal";
import {
  UserProfileProvider,
  useUserProfilePhoto,
} from "@/lib/auth/user-profile-context";
import { useUserStore } from "@/store/useUserStore";
import { Toaster } from "react-hot-toast";

function AppLayoutContent({ children }: { children: React.ReactNode }) {
  const pathName = usePathname();
  const [isSidebarExpanded, setIsSidebarExpanded] = useState(false);
  const user = getLoggedInUser();
  const roles = getUserClaims();
  const displayName = user?.name ?? "Guest";
  const displayRole = getPrimaryRole(roles);
  const photoUrl = useUserProfilePhoto();

  const setUser = useUserStore((s) => s.setUser);

  useEffect(() => {
    setUser({
      displayName,
      displayRole,
      email: user?.username ?? "",
      localAccountId: user?.localAccountId ?? "",
      tenantId: user?.tenantId ?? "",
      roles,
      photoUrl,
    });
  }, [
    displayName,
    displayRole,
    photoUrl,
    roles,
    setUser,
    user?.username,
    user?.localAccountId,
    user?.tenantId,
  ]);

  useEffect(() => {
    if (canAccessRoute(pathName)) {
      sessionStorage.setItem("lastRoute", pathName);
    }
  }, [pathName]);

  const onLogout = async () => {
    sessionStorage.removeItem("lastRoute");
    await handleLogout();
  };

  return (
    <AuthGuard>
      <RoleRouteGuard>
        <div className="min-h-screen bg-[#f6f7f9] text-(--jnj-ink)">
          <div className="flex min-h-screen">
            <DashboardSidebar
              isExpanded={isSidebarExpanded}
              onToggle={() => setIsSidebarExpanded((value) => !value)}
            />
            <main className="flex min-w-0 flex-1 flex-col">
              <DashboardHeader
                displayName={displayName}
                displayRole={displayRole}
                photoUrl={photoUrl}
                onLogout={onLogout}
              />
              <div className="flex-1">{children}</div>
            </main>
          </div>
          <Toaster
            position="top-right"
            containerStyle={{
              top: 90,
              right: 15,
            }}
          />
        </div>
      </RoleRouteGuard>
    </AuthGuard>
  );
}

export default function AppLayout({ children }: { children: React.ReactNode }) {
  return (
    <UserProfileProvider>
      <AppLayoutContent>{children}</AppLayoutContent>
    </UserProfileProvider>
  );
}
