"use client";

import { use } from "react";
import ChatLayout from "@/components/chatBoard/ChatLayout";

interface ChatPageProps {
  params: Promise<{ id: string }>;
}

export default function ChatPage({ params }: ChatPageProps) {
  const { id } = use(params);

  return (
    <div className="flex">
      <ChatLayout projectId={id} />
    </div>
  );
}
