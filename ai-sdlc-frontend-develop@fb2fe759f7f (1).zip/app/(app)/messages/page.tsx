import { ProjectLandingPage } from "@/components/chatBoard/projectCardsLayout/ProjectLandingPage";

export function ProjectPage() {
  return (
    <div className="flex ">
      <ProjectLandingPage />
    </div>
  );
}

export default ProjectPage;