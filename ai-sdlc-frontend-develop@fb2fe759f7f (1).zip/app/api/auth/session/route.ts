import { cookies } from "next/headers";
import { NextResponse } from "next/server";
import {
  AUTH_SESSION_COOKIE,
  authCookieOptions,
} from "@/lib/auth/feature-flags";

export async function POST() {
  const cookieStore = await cookies();

  cookieStore.set(AUTH_SESSION_COOKIE, "1", authCookieOptions);

  return NextResponse.json({ ok: true });
}

export async function DELETE() {
  const cookieStore = await cookies();

  cookieStore.delete(AUTH_SESSION_COOKIE);

  return NextResponse.json({ ok: true });
}
