import type { Metadata } from "next";
import "./globals.css";
import { johnsonDisplay, johnsonText } from "./fonts";
import { AppProviders } from "@/components/auth/app-providers";
import { AppRouterCacheProvider } from "@mui/material-nextjs/v15-appRouter";

export const metadata: Metadata = {
  title: "AI SDLC Orchestrator",
  description: "JNJ branded AI SDLC orchestration workspace",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className={`${johnsonText.variable} ${johnsonDisplay.variable}`}
    >
      <body className="antialiased">
        <AppRouterCacheProvider>
          <AppProviders>{children}</AppProviders>
        </AppRouterCacheProvider>
      </body>
    </html>
  );
}
