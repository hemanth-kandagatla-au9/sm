import ExpandableDocumentTester from "@/components/chatBoard/ExpandableDocumentTester";

export const metadata = {
  title: "Tiptap Expandable Document Tester",
};

export default function TiptapTestPage() {
  return <ExpandableDocumentTester />;
}
