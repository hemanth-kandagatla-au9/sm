export const adGroupPreDevConfig = {
  token: "",
  group_names: [] as string[],
  business_justification: "Required for project access control",
  expiry_days: 90,
  callback_url: "https://your-app.com/adgroups/sdlc/callback",
  // requester_email: "OAynur@its.jnj.com",
  // requester_user_uuid: "b703e26c-c306-41fc-9b29-18927dd09a8a",
  // requester_user_name: "oaynur",
  // requester_wwid:null,
};

export default adGroupPreDevConfig;
