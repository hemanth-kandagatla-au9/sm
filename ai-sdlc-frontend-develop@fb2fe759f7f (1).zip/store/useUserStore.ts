import { create } from "zustand";
import type { UserRole } from "@/lib/auth/roles";

/* ─────────────────────── TYPES ─────────────────────── */

export interface UserInfo {
  displayName: string;
  email: string;
  localAccountId: string;
  tenantId: string;
  roles: UserRole[];
  displayRole: string;
  photoUrl: string | null;
}

export interface UserStoreState extends UserInfo {
  setUser: (info: Partial<UserInfo>) => void;
}

/* ─────────────────────── STORE ─────────────────────── */

export const useUserStore = create<UserStoreState>()((set) => ({
  displayName: "",
  email: "",
  localAccountId: "",
  tenantId: "",
  roles: [],
  displayRole: "",
  photoUrl: null,
  setUser: (info: Partial<UserInfo>) =>
    set((s: UserStoreState) => ({ ...s, ...info })),
}));
