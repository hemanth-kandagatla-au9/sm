import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import type { ProjectRole } from "@/services/chat/types";

/* ─────────────────────── TYPES ─────────────────────── */

export interface ChatStoreState {
  // Sidebar
  isSidebarOpen: boolean;
  toggleSidebar: () => void;

  // Right panel (Tiptap editor)
  isRightPanelOpen: boolean;
  openRightPanel: () => void;
  closeRightPanel: () => void;
  toggleRightPanel: () => void;

  // TipTap document content received from the API
  tiptapDocument: string | Record<string, unknown> | null;
  setTiptapDocument: (doc: string | Record<string, unknown> | null) => void;

  // Selected agent flow
  selectedFlowName: string | null;
  setSelectedFlowName: (flowName: string | null) => void;
  clearSelectedFlowName: () => void;

  // Project & role selection
  selectedProjectId: number | null;
  setSelectedProjectId: (id: number | null) => void;

  projectRoles: ProjectRole[];
  setProjectRoles: (roles: ProjectRole[]) => void;

  selectedProjectRole: ProjectRole | null;
  setSelectedProjectRole: (role: ProjectRole | null) => void;
  clearProjectRole: () => void;
}

/* ─────────────────────── STORE ─────────────────────── */

export const useChatStore = create<ChatStoreState>()(
  persist(
    (set) => ({
      // Sidebar
      isSidebarOpen: true,
      toggleSidebar: () => set((s) => ({ isSidebarOpen: !s.isSidebarOpen })),

      // Right panel
      isRightPanelOpen: false,
      openRightPanel: () => set({ isRightPanelOpen: true }),
      closeRightPanel: () => set({ isRightPanelOpen: false }),
      toggleRightPanel: () =>
        set((s) => ({ isRightPanelOpen: !s.isRightPanelOpen })),

      // TipTap document
      tiptapDocument: null,
      setTiptapDocument: (doc) => set({ tiptapDocument: doc }),

      // Selected agent flow
      selectedFlowName: null,
      setSelectedFlowName: (flowName) => set({ selectedFlowName: flowName }),
      clearSelectedFlowName: () => set({ selectedFlowName: null }),

      // Project & role selection
      selectedProjectId: null,
      setSelectedProjectId: (id) => set({ selectedProjectId: id }),

      projectRoles: [],
      setProjectRoles: (roles) => set({ projectRoles: roles }),

      selectedProjectRole: null,
      setSelectedProjectRole: (role) => set({ selectedProjectRole: role }),
      clearProjectRole: () =>
        set({
          selectedProjectRole: null,
          projectRoles: [],
          selectedProjectId: null,
        }),
    }),
    {
      name: "chat-store",
      storage: createJSONStorage(() => localStorage),
      partialize: (state) => ({
        selectedProjectId: state.selectedProjectId,
        projectRoles: state.projectRoles,
        selectedProjectRole: state.selectedProjectRole,
      }),
    },
  ),
);
