
import { VerticalValue } from "@/services/dashboardService/types";
import { VRLevel } from "@/services/dashboardService/types"

export const formatCompact = (value: number): string => {
  if (value >= 1_000_000) return `${(value / 1_000_000).toFixed(1)}M`;
  if (value >= 1_000) return `${(value / 1_000).toFixed(1)}K`;
  return value.toLocaleString();
};

export const formatCurrency = (value: number): string => {
  if (value >= 1_000_000) return `$${(value / 1_000_000).toFixed(2)}M`;
  if (value >= 1_000) return `$${(value / 1_000).toFixed(1)}K`;
  return `$${value.toFixed(2)}`;
};


export const formatHours = (value: number): string =>
  `${value.toLocaleString(undefined, { maximumFractionDigits: 1 })}h`;

export const formatPercent = (value: number): string =>
  `${value.toLocaleString(undefined, { maximumFractionDigits: 1 })}%`;


export const getMetric = (
  cards: { metric_name: string; metric_value: { value?: number; available: boolean } }[],
  name: string
): number | null => {
  const card = cards.find((c) => c.metric_name === name);
  if (!card || !card.metric_value.available) return null;
  return card.metric_value.value ?? null;
};

export const totalValue = (
  vertical: VerticalValue[] | VRLevel[]
): number => {
  const total = vertical.reduce((sum, item) => {
    const cost = Number(String(item.total_value_delivered || "0").replace(/,/g, ""));
    return sum + cost;
  }, 0);

  return total;
};


