
export interface MetricValue {
  value?: number;
  formula: string;
  available: boolean;
  reason?: string;
  notes: string[];
}

export interface MetricCard {
  metric_name: string;
  metric_value: MetricValue;
}

export interface VRLevel {
  name: string;
  total_baseline_effort_hours: number;
  total_actual_effort_hours: number;
  total_effort_saved_hours: number;
  cost_per_hour: number;
  total_value_delivered: number;
  experience_value: number;
  effectiveness_value: number;
  efficiency_value: number;
  number_of_projects: number;
  number_of_agents: number;
  number_of_workflows: number;
  number_of_executions: number;
  notes_warnings: string[];
}



export interface VerticalValue {
  vertical_name: string;
  total_value_delivered: number;
  experience_value: number;
  effectiveness_value: number;
  efficiency_value: number;
  hours_saved: number;
  number_of_projects: number;
  number_of_agents: number;
  number_of_workflows: number;
  number_of_executions: number;
  notes_warnings: string[];
}



export interface ExecutiveSummary {
  highest_value_agent: string;
  highest_value_project: string;
  highest_value_workflow: string;
  highest_value_vertical: string;
  total_platform_value_delivered: number;
  total_hours_saved: number;
  overall_roi_pct: number;
  notes_warnings: string[];
}



export interface TimeRange {
  start_time: string;
  end_time: string;
}



export interface DashboardData {
  time_range: TimeRange;
  leadership_admin_metrics_cards: MetricCard[];
  agent_level_vr: VRLevel[];
  project_level_vr: VRLevel[];
  workflow_level_vr: VRLevel[];
  vertical_level_vr: VRLevel[];
  platform_level_vr: VRLevel[];
  value_delivered_by_verticals: VerticalValue[];
  executive_summary: ExecutiveSummary;
}

export interface DashboardApiResponse {
  success: boolean;
  data: DashboardData;
}


export interface DashboardQueryParams {
  start_time?: string;
  end_time?: string;
}
