import { useState, useEffect, useCallback } from "react";
import { dashboardService } from "./dashboardService";
import { DashboardData, DashboardQueryParams } from "./types";

interface UseDashboardReturn {
  data: DashboardData | null;
  isLoading: boolean;
  error: string | null;
  refetch: (params?: DashboardQueryParams) => Promise<void>;
}

export const useDashboard = (
  initialParams?: DashboardQueryParams
): UseDashboardReturn => {
  const [data, setData] = useState<DashboardData | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = useCallback(async (params?: DashboardQueryParams) => {
    try {
      setIsLoading(true);
      setError(null);
      const response = await dashboardService.getValueRealization(params);
      if (response.success) {
        setData(response.data);
      } else {
        setError("API returned an unsuccessful response.");
      }
    } catch (err: unknown) {
      const message =
        err instanceof Error ? err.message : "Failed to fetch dashboard data.";
      setError(message);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData(initialParams);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return { data, isLoading, error, refetch: fetchData };
};
