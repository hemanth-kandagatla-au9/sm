import { DashboardApiResponse, DashboardQueryParams } from "@/services/dashboardService/types";
import axiosInstance from "@/lib/api/axiosInstance";

export const dashboardService = {
  getValueRealization: async (
    params?: DashboardQueryParams
  ): Promise<DashboardApiResponse> => {
    const response = await axiosInstance.get<DashboardApiResponse>(
      "/monitor/value-realization",
      { params }
    );
    return response.data;
  },
};

