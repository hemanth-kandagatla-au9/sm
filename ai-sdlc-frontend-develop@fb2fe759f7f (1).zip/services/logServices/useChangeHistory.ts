'use client';
import { useState, useEffect, useCallback } from 'react';
import axiosInstance from '@/lib/api/axiosInstance';

export interface ChangeHistoryItem {
  log_id: string;
  user_id: number;
  user_name_snapshot: string;
  user_email_snapshot: string;
  change_type: string;
  entity_type: string;
  entity_id: string;
  project_id: number;
  change_details: string;
  values_before: Record<string, unknown>;
  values_after: Record<string, unknown>;
  values_difference: Record<string, unknown>;
  occurred_at: string;
}

interface UseChangeHistoryReturn {
  rows: ChangeHistoryItem[];
  total: number;
  page: number;
  pageSize: number;
  loading: boolean;
  error: string | null;
  setPage: (page: number) => void;
  setPageSize: (size: number) => void;
  refetch: () => void;
}

export function useChangeHistory(): UseChangeHistoryReturn {
  const [rows, setRows] = useState<ChangeHistoryItem[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState(25);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [tick, setTick] = useState(0);

  const refetch = useCallback(() => setTick((t) => t + 1), []);

 useEffect(() => {
  const controller = new AbortController();

  const fetchData = async () => {
    try {
      setLoading(true);
      setError(null);

      const res = await axiosInstance.get('/logs/change-history', {
        params: {
          page: page + 1,
          page_size: pageSize,
        },
        signal: controller.signal,
      });

      const data = res.data?.data;

      setRows(data?.items ?? []);
      setTotal(data?.total ?? 0);
    } catch (err: any) {
      if (
        err.name !== 'CanceledError' &&
        err.code !== 'ERR_CANCELED'
      ) {
        setError('Failed to load change history.');
      }
    } finally {
      if (!controller.signal.aborted) {
        setLoading(false);
      }
    }
  };

  fetchData();

  return () => controller.abort();
}, [page, pageSize, tick]);

  return { rows, total, page, pageSize, loading, error, setPage, setPageSize, refetch };
}
