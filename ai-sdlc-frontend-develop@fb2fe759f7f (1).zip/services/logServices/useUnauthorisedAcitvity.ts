'use client';
import { useState, useEffect, useCallback } from 'react';
import axiosInstance from '@/lib/api/axiosInstance';

export interface UnauthorisedActivityItem {
  log_id: string;
  user_name: string;
  user_email: string;
  occurred_at: string;
  resource_type: string;
  resource_id: string;
  resource_name: string;
  project_id: string;
  attempted_action: string;
  denial_reason: string;
  request_path: string;
}
interface UseUnauthorisedActivtyReturn {
  rows: UnauthorisedActivityItem[];
  total: number;
  page: number;
  pageSize: number;
  loading: boolean;
  error: string | null;
  setPage: (page: number) => void;
  setPageSize: (size: number) => void;
  refetch: () => void;
}

export function useUnauthorisedActivity(): UseUnauthorisedActivtyReturn {
  const [rows, setRows] = useState<UnauthorisedActivityItem[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState(10);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [tick, setTick] = useState(0);

  const refetch = useCallback(() => setTick((t) => t + 1), []);

useEffect(() => {
  const controller = new AbortController();

  const fetchUnauthorisedActivity = async () => {
    try {
      setLoading(true);
      setError(null);

      const res = await axiosInstance.get('/logs/unauthorized-activity', {
        params: {
          page: page + 1,
          page_size: pageSize,
        },
        signal: controller.signal,
      });

      const data = res.data?.data;

      setRows(data?.items ?? []);
      setTotal(data?.total ?? 0);
    } catch (err: any) {
      if (
        err.name !== 'CanceledError' &&
        err.code !== 'ERR_CANCELED'
      ) {
        setError('Failed to load session activity.');
      }
    } finally {
      if (!controller.signal.aborted) {
        setLoading(false);
      }
    }
  };

  fetchUnauthorisedActivity();

  return () => {
    controller.abort();
  };
}, [page, pageSize, tick]);

  return { rows, total, page, pageSize, loading, error, setPage, setPageSize, refetch };
}
