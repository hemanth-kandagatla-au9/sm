'use client';
import { useState, useEffect, useCallback } from 'react';
import axiosInstance from '@/lib/api/axiosInstance';

export interface MonitoringLogsItem {
  runId: string;
  resourceName: number;
  resourceType: string;
  userId: string;
  projectId: string;
  roleName: string;
  status: string;
  startTime: number;
  endTime: string;
}

interface UseMonitoringLogsReturn {
  rows: MonitoringLogsItem[];
  total: number;
  page: number;
  pageSize: number;
  loading: boolean;
  error: string | null;
  setPage: (page: number) => void;
  setPageSize: (size: number) => void;
  refetch: () => void;
}

export function useMonitoringLogs(): UseMonitoringLogsReturn {
  const [rows, setRows] = useState<MonitoringLogsItem[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState(25);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [tick, setTick] = useState(0);

  const refetch = useCallback(() => setTick((t) => t + 1), []);

 useEffect(() => {
  const controller = new AbortController();

  const fetchData = async () => {
    try {
      setLoading(true);
      setError(null);

      const res = await axiosInstance.get('/monitoring/table', {
        params: {
          page: page + 1,
          pageSize: pageSize,
        },
        signal: controller.signal,
      });

      const data = res.data?.data;

      setRows(data?.data ?? []);
      setTotal(data?.pagination?.totalItems ?? 0);
    } catch (err: any) {
      if (
        err.name !== 'CanceledError' &&
        err.code !== 'ERR_CANCELED'
      ) {
        setError('Failed to load change history.');
      }
    } finally {
      if (!controller.signal.aborted) {
        setLoading(false);
      }
    }
  };

  fetchData();

  return () => controller.abort();
}, [page, pageSize, tick]);

  return { rows, total, page, pageSize, loading, error, setPage, setPageSize, refetch };
}
