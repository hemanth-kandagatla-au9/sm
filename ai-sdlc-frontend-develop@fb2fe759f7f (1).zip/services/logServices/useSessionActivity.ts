'use client';
import { useState, useEffect, useCallback } from 'react';
import axiosInstance from '@/lib/api/axiosInstance';

export interface SessionActivityItem {
  log_id: string;
  user_id: number;
  user_name_snapshot: string;
  user_email_snapshot: string;
  login_on: string;
  logout_on: string | null;
  logout_type: string | null;
  action: string;
}

interface UseSessionActivityReturn {
  rows: SessionActivityItem[];
  total: number;
  page: number;
  pageSize: number;
  loading: boolean;
  error: string | null;
  setPage: (page: number) => void;
  setPageSize: (size: number) => void;
  refetch: () => void;
}

export function useSessionActivity(): UseSessionActivityReturn {
  const [rows, setRows] = useState<SessionActivityItem[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState(25);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [tick, setTick] = useState(0);

  const refetch = useCallback(() => setTick((t) => t + 1), []);

useEffect(() => {
  const controller = new AbortController();

  const fetchSessionActivity = async () => {
    try {
      setLoading(true);
      setError(null);

      const res = await axiosInstance.get('/logs/session-activity', {
        params: {
          page: page + 1,
          page_size: pageSize,
        },
        signal: controller.signal,
      });

      const data = res.data?.data;

      setRows(data?.items ?? []);
      setTotal(data?.total ?? 0);
    } catch (err: any) {
      if (
        err.name !== 'CanceledError' &&
        err.code !== 'ERR_CANCELED'
      ) {
        setError('Failed to load session activity.');
      }
    } finally {
      if (!controller.signal.aborted) {
        setLoading(false);
      }
    }
  };

  fetchSessionActivity();

  return () => {
    controller.abort();
  };
}, [page, pageSize, tick]);

  return { rows, total, page, pageSize, loading, error, setPage, setPageSize, refetch };
}
