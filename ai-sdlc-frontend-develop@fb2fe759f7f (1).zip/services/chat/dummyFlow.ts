import { formatConversationDate } from "@/lib/utils";

type DummyBotNode = {
  id: string;
  message: string;
  suggestedPrompts?: string[];
  timestamp?: string;
  metrics?: { processingTime: string; token: number; cost: string };
};

type Transition = {
  nextId: string;
  botReply?: string;
};

const NODES: Record<string, DummyBotNode> = {
  welcome: {
    id: "welcome",
    message: "Welcome! What would you like to do?",
    timestamp: formatConversationDate("2026-02-11T10:15:00Z"),
    suggestedPrompts: [
      "FDS generation",
      "TDS generation",
      "KDD generation",
    ],
    metrics: { processingTime: "30sec", token: 812, cost: "$0.02" },
  },
  fds: {
    id: "fds",
    message: "Connecting FDS with SASA...",
    timestamp: formatConversationDate("2026-02-11T10:26:00Z"),
    metrics: { processingTime: "1.00sec", token: 812, cost: "$0.02" },
  },
  tds: {
    id: "tds",
    message: "Connecting TDS with SASA...",
    timestamp: formatConversationDate("2026-02-11T10:27:00Z"),
    metrics: { processingTime: "1.00sec", token: 955, cost: "$0.03" },
  },
  iwand: {
    id: "iwand",
    message: "Connecting iWAND with SASA...",
    timestamp: formatConversationDate("2026-02-11T10:28:00Z"),
    metrics: { processingTime: "1.00sec", token: 420, cost: "$0.01" },
  },
  solman: {
    id: "solman",
    message: "How can I help you today?",
    timestamp: formatConversationDate("2026-02-11T10:29:00Z"),
    metrics: { processingTime: "0.50sec", token: 310, cost: "$0.01" },
  },
};

const TRANSITIONS: Record<string, Transition> = {
  "FDS generation": { nextId: "fds" },
  "TDS generation": { nextId: "tds" },
  "KDD generation": {
    nextId: "iwand",
    botReply: "Please upload a meeting recording to generate artifacts.",
  },
};

export const DUMMY_FLOW = {
  welcomeId: "welcome" as const,
  nodes: NODES,
  transitions: TRANSITIONS,
};

export function getDummyTransition(prompt: string) {
  return DUMMY_FLOW.transitions[prompt] ?? null;
}

export function getDummyNode(nodeId: string) {
  return DUMMY_FLOW.nodes[nodeId] ?? null;
}

/** Returns true for iwand-type workflows that expect a file before the first real message. */
export function promptRequiresFileUpload(prompt: string) {
  return prompt === "KDD generation";
}
