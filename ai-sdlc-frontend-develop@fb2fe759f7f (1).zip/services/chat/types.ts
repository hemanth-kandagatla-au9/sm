import type { ReactNode } from "react";

export interface Project {
  project_id: number;
  project_number: number;
  project_name: string;
  atlassian_project_id: string;
  project_description: string;
  status: string;
  start_date: string;
  end_date: string;
  created_at: string;
  is_active: boolean;
}

export interface ProjectRole {
  project_role_id: number;
  project_id: number;
  ad_group_name: string;
  ad_group_object_id: string | null;
  cost: number | null;
  role_id: number;
  role_name: string;
  role_description: string;
  ERP_flag: boolean;
  Non_ERP_flag: boolean;
  MLL_flag: boolean;
  Other_Vertical_flag: boolean;
  MT_flag: boolean;
  IM_flag: boolean;
  CBT_flag: boolean;
}

export interface Conversation {
  id: number;
  workflow_id: string;
  project_id: number;
  title: string;
  status: string;
  created_at: string;
}

export interface ClickableOption {
  label: string;
  value: string;
}

export interface HistoryMessage {
  id?: number;
  role: "user" | "assistant";
  content: string;
  user_choice?: boolean | null;
  clickable_options?: ClickableOption[];
  created_at?: string;
}

export type ChatUiMessage =
  | {
      id: string;
      type: "bot";
      message?: string | ReactNode;
      suggestedPrompts?: string[];
      clickableOptions?: ClickableOption[];
      isLoading?: boolean;
      loadingText?: string;
      timestamp?: string;
      messageId?: number;
      userChoice?: boolean | null;
      metrics?: { processingTime: string; token: number; cost: string };
    }
  | {
      id: string;
      type: "user";
      message: string | ReactNode;
      /** API payload when it differs from the displayed message (e.g. clickable option value). */
      sentMessage?: string;
      timestamp?: string;
    };

export interface SendMessageResult {
  workflowId: string;
  botReply: string;
  responseMessageId?: number;
}

export interface MessageChoiceParams {
  workflowId: string;
  messageId: number;
  userChoice: boolean;
}
