"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import ToastHelper from "@/components/common/ToastHelper";
import ChatAttachmentChip from "@/components/chatBoard/ChatAttachmentChip";
import FileAnalysisStepper from "@/components/chatBoard/FileAnalysisStepper";
import { FilePreview } from "@/components/chatBoard/FilePreview";
import { formatConversationDate } from "@/lib/utils";
import { chatApi } from "./chatApi";
import {
  getDummyNode,
  getDummyTransition,
  promptRequiresFileUpload,
} from "./dummyFlow";
import type { ChatUiMessage, Conversation } from "./types";
import { resolveDisplayMessage } from "@/lib/utils/richText";
import {
  extractApiErrorMessage,
  extractDocumentHtml,
  extractHistoryDocument,
  mapHistoryToUiMessages,
  parseAssistantContent,
} from "./utils";
import { resolveExpandableDocument } from "./expandableDocument";
import { useChatStore } from "@/store/useChatStore";
import {
  type AgentGroup,
  type ApiWorkflow,
  findSasaAgentByPromptKey,
  mapWorkflowsToAgentGroups,
  deriveRightPanelFlowKeys,
  isRightPanelGroupId,
  isCrcoAgentContext,
  IWAND_TYPE_NAME,
} from "@/components/chatBoard/agentsApiDataMappingHelper";
import axiosInstance from "@/lib/api/axiosInstance";

export interface UseChatWidgetOptions {
  projectId?: string;
  initialWorkflowId?: string;
}

export interface UseChatWidgetReturn {
  messages: ChatUiMessage[];
  agentGroups: AgentGroup[];
  isLoadingWorkflows: boolean;
  activeWorkflowId: string;
  showWelcomePrompts: boolean;
  welcomePrompts: string[];
  loadingHistoryWorkflowId: string | null;
  isSendingMessage: boolean;
  isAwaitingUpload: boolean;
  iwandUploadDone: boolean;
  showFileUpload: boolean;
  sidebarRefreshTrigger: number;
  sasaIframeUrl: string | null;
  clearSasaIframe: () => void;
  handleConversationSelect: (workflowId: string) => Promise<void>;
  handleSuggestedPromptClick: (prompt: string) => void;
  handleAgentClick: (
    promptKey: string,
    agentId: string,
    introMessage: string | null,
    agentName: string,
    agentWorkflowId?: string,
  ) => void;
  handleFileUpload: (file: File) => Promise<void>;
  handleNewChat: () => void;
  handleSendMessage: (
    text: string,
    html?: string,
    displayText?: string,
  ) => Promise<void>;
  handleMessageFeedback: (
    messageId: number,
    userChoice: boolean,
  ) => Promise<void>;
}

export function useChatConversations(projectId?: string, refreshTrigger = 0) {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (!projectId) return;

    const fetchConversations = async () => {
      setIsLoading(true);
      try {
        const res = await chatApi.listConversations(projectId);
        if (res.data.success) {
          setConversations(res.data.data);
        }
      } catch {
        ToastHelper.showRespToast({
          status: false,
          message: "Failed to load conversations. Please try again.",
        });
      } finally {
        setIsLoading(false);
      }
    };

    fetchConversations();
  }, [projectId, refreshTrigger]);

  return { conversations, isLoadingConversations: isLoading };
}

export function useChatSession({
  projectId,
  initialWorkflowId,
}: UseChatWidgetOptions): UseChatWidgetReturn {
  const {
    setSelectedFlowName,
    selectedFlowName,
    openRightPanel,
    closeRightPanel,
    selectedProjectRole,
    setTiptapDocument,
  } = useChatStore();
  const selectedFlowNameRef = useRef(selectedFlowName);
  useEffect(() => {
    selectedFlowNameRef.current = selectedFlowName;
  }, [selectedFlowName]);

  const selectedProjectRoleRef = useRef(selectedProjectRole);
  useEffect(() => {
    selectedProjectRoleRef.current = selectedProjectRole;
  }, [selectedProjectRole]);

  const selectedAgentIdRef = useRef<string | null>(null);
  const selectedAgentWorkflowIdRef = useRef<string | null>(null);
  const [selectedAgentGroupId, setSelectedAgentGroupId] = useState<
    string | null
  >(null);

  const [activeWorkflowId, setActiveWorkflowId] = useState(
    initialWorkflowId ?? "",
  );
  const [messages, setMessages] = useState<ChatUiMessage[]>([]);
  const [agentGroups, setAgentGroups] = useState<AgentGroup[]>([]);
  const [isLoadingWorkflows, setIsLoadingWorkflows] = useState(false);
  const [showWelcomePrompts, setShowWelcomePrompts] = useState(true);
  const [isAwaitingUpload, setIsAwaitingUpload] = useState(false);
  const [iwandUploadDone, setIwandUploadDone] = useState(false);
  const [loadingHistoryWorkflowId, setLoadingHistoryWorkflowId] = useState<
    string | null
  >(null);
  const [sidebarRefreshTrigger, setSidebarRefreshTrigger] = useState(0);
  const [sasaIframeUrl, setSasaIframeUrl] = useState<string | null>(null);
  const [isSendingMessage, setIsSendingMessage] = useState(false);
  const dummyTimeoutRef = useRef<number | null>(null);

  const clearSasaIframe = useCallback(() => {
    setSasaIframeUrl(null);
  }, []);

  // Fetch available workflows and map them to the AgentGroup shape.
  // Runs whenever the selected project/role changes.
  useEffect(() => {
    const fetchAgentGroups = async () => {
      if (
        !selectedProjectRole?.project_id ||
        !selectedProjectRole?.ad_group_name
      ) {
        setAgentGroups([]);
        setIsLoadingWorkflows(false);
        return;
      }
      setIsLoadingWorkflows(true);
      try {
        const res = await axiosInstance.post<{ data: ApiWorkflow[] }>(
          `/sdlc/projects/${selectedProjectRole.project_id}/workflows`,
          { ad_group_name: selectedProjectRole.ad_group_name },
        );
        setAgentGroups(mapWorkflowsToAgentGroups(res.data?.data ?? []));
      } catch {
        ToastHelper.showRespToast({
          status: false,
          message: "Failed to load workflows. Please try again.",
        });
      } finally {
        setIsLoadingWorkflows(false);
      }
    };
    fetchAgentGroups();
  }, [selectedProjectRole]);

  // Derive welcome prompt chips from the live agent groups
  const welcomePrompts = agentGroups.flatMap((g) =>
    g.agents.map((a) => a.promptKey).filter((k): k is string => k !== null),
  );

  useEffect(() => {
    if (initialWorkflowId) {
      setActiveWorkflowId(initialWorkflowId);
    }
  }, [initialWorkflowId]);

  const ensureWorkflowId = useCallback(async (): Promise<string> => {
    if (activeWorkflowId) return activeWorkflowId;

    const convRes = await chatApi.createConversation(
      projectId,
      selectedProjectRole?.project_role_id,
      selectedAgentIdRef.current ?? undefined,
      selectedAgentIdRef.current ?? undefined,
      selectedAgentWorkflowIdRef.current ?? undefined,
    );
    const workflowId = convRes.data?.data?.workflow_id ?? "";
    setActiveWorkflowId(workflowId);
    setSidebarRefreshTrigger((prev) => prev + 1);
    return workflowId;
  }, [activeWorkflowId, projectId]);

  const handleConversationSelect = useCallback(
    async (selectedWorkflowId: string) => {
      setSasaIframeUrl(null);
      setActiveWorkflowId(selectedWorkflowId);
      const workflowGroup = agentGroups.find((group) =>
        group.agents.some((agent) => agent.id === selectedWorkflowId),
      );
      selectedAgentIdRef.current = workflowGroup?.id ?? null;
      setSelectedAgentGroupId(workflowGroup?.id ?? null);
      setShowWelcomePrompts(false);
      setIsAwaitingUpload(false);
      setIwandUploadDone(false);
      setLoadingHistoryWorkflowId(selectedWorkflowId);

      const loadingId = `loading-history-${Date.now()}`;
      setMessages([{ id: loadingId, type: "bot", isLoading: true }]);

      try {
        const response = await chatApi.getHistory(selectedWorkflowId);
        const historyMessages = response.data?.data?.messages;

        if (historyMessages?.length) {
          setMessages(mapHistoryToUiMessages(historyMessages));
          // If this is a IWAND conversation that already has history,
          // lock the upload — the one-shot flow was already used.
          if (workflowGroup?.id === IWAND_TYPE_NAME) {
            setIwandUploadDone(true);
          }
          const historyDocument = extractHistoryDocument(historyMessages);
          if (historyDocument) {
            setTiptapDocument(historyDocument);
            openRightPanel();
          } else {
            closeRightPanel();
            setTiptapDocument(null);
          }
        } else {
          setMessages([]);
          closeRightPanel();
          setTiptapDocument(null);
        }
      } catch {
        ToastHelper.showRespToast({
          status: false,
          message: "Failed to load conversation history. Please try again.",
        });
        setMessages([]);
      } finally {
        setLoadingHistoryWorkflowId(null);
      }
    },
    [agentGroups, openRightPanel, closeRightPanel, setTiptapDocument],
  );

  const handleSuggestedPromptClick = useCallback(
    (prompt: string) => {
      setSasaIframeUrl(null);
      setSelectedFlowName(prompt);
      const transition = getDummyTransition(prompt);
      if (!transition) return;

      setShowWelcomePrompts(false);
      const requiresFileUpload = promptRequiresFileUpload(prompt);
      const loadingId = `loading-${Date.now()}`;
      const nextNode = getDummyNode(transition.nextId);
      if (!nextNode) return;

      setIsAwaitingUpload(requiresFileUpload);

      setMessages((prev) => [
        ...prev,
        {
          id: `user-${Date.now()}`,
          type: "user",
          message: prompt,
          timestamp: formatConversationDate(new Date().toISOString()),
        },
        { id: loadingId, type: "bot", isLoading: true },
      ]);

      if (dummyTimeoutRef.current) window.clearTimeout(dummyTimeoutRef.current);
      dummyTimeoutRef.current = window.setTimeout(() => {
        setMessages((prev) => {
          const withoutLoading = prev.filter((m) => m.id !== loadingId);
          return [
            ...withoutLoading,
            {
              id: `${nextNode.id}-${Date.now()}`,
              type: "bot",
              message: transition.botReply ?? nextNode.message,
              suggestedPrompts: nextNode.suggestedPrompts,
              timestamp: nextNode.timestamp,
              metrics: nextNode.metrics,
            },
          ];
        });
      }, 1000);
    },
    [setSelectedFlowName],
  );

  const handleAgentClick = useCallback(
    async (
      promptKey: string,
      agentId: string,
      introMessage: string | null,
      agentName: string,
      agentWorkflowId?: string,
    ) => {
      closeRightPanel();
      setTiptapDocument(null);
      selectedAgentIdRef.current = agentId;
      selectedAgentWorkflowIdRef.current = agentWorkflowId ?? null;
      setSelectedAgentGroupId(agentId);
      const sasaAgent = findSasaAgentByPromptKey(agentGroups, promptKey);
      if (sasaAgent) {
        const workflowId = sasaAgent.id;
        const project_id =
          selectedProjectRole?.project_id ??
          (projectId ? Number(projectId) : undefined);
        const role = selectedProjectRole?.role_name;

        if (!project_id || !role || !workflowId) {
          ToastHelper.showRespToast({
            status: false,
            message:
              "Missing project, role, or workflow details. Please try again.",
          });
          return;
        }

        setShowWelcomePrompts(false);
        const loadingId = `loading-sasa-${Date.now()}`;
        const timestamp = formatConversationDate(new Date().toISOString());

        setMessages((prev) => [
          ...prev,
          {
            id: `user-${Date.now()}`,
            type: "user",
            message: promptKey,
            timestamp,
          },
          { id: loadingId, type: "bot", isLoading: true },
        ]);

        const replaceLoadingWithBotMessage = (message: string) => {
          setMessages((prev) => {
            const withoutLoading = prev.filter((m) => m.id !== loadingId);
            return [
              ...withoutLoading,
              {
                id: `bot-sasa-${Date.now()}`,
                type: "bot",
                message,
                timestamp: formatConversationDate(new Date().toISOString()),
              },
            ];
          });
        };

        try {
          const response = await chatApi.launchSasa({
            project_id,
            role,
            workflow_type_id: workflowId,
          });
          const url = response.data?.data?.url;
          if (url) {
            replaceLoadingWithBotMessage(`Connected with **${agentName}**`);
            setSasaIframeUrl(url);
          } else {
            const errorMessage = `Failed to launch **${agentName}**. No URL returned.`;
            ToastHelper.showRespToast({
              status: false,
              message: errorMessage,
            });
            replaceLoadingWithBotMessage(errorMessage);
          }
        } catch (err: unknown) {
          const errorMessage = extractApiErrorMessage(
            err,
            `Failed to launch **${agentName}**. No URL returned.`,
          );
          ToastHelper.showRespToast({
            status: false,
            message: errorMessage,
          });
          replaceLoadingWithBotMessage(errorMessage);
        }
        return;
      }

      // iWand: show user message → loading → upload prompt (same pattern as KDD Generation, without dummyFlow)
      if (agentId === IWAND_TYPE_NAME) {
        setShowWelcomePrompts(false);
        setIwandUploadDone(false);
        const loadingId = `loading-iwand-${Date.now()}`;
        const timestamp = formatConversationDate(new Date().toISOString());

        setMessages((prev) => [
          ...prev,
          {
            id: `user-iwand-${Date.now()}`,
            type: "user",
            message: agentName,
            timestamp,
          },
          { id: loadingId, type: "bot", isLoading: true },
        ]);

        setIsAwaitingUpload(true);

        if (dummyTimeoutRef.current)
          window.clearTimeout(dummyTimeoutRef.current);
        dummyTimeoutRef.current = window.setTimeout(() => {
          setMessages((prev) => {
            const withoutLoading = prev.filter((m) => m.id !== loadingId);
            return [
              ...withoutLoading,
              {
                id: `bot-upload-${Date.now()}`,
                type: "bot",
                message: "Please upload the video in .mov or .mp4   format.",
                timestamp: formatConversationDate(new Date().toISOString()),
              },
            ];
          });
        }, 1000);
        return;
      }

      handleSuggestedPromptClick(promptKey);

      const hasDummyTransition = !!getDummyTransition(promptKey);
      if (!hasDummyTransition) {
        setShowWelcomePrompts(false);
        const greeting = introMessage?.trim() || `${agentName}`;
        setMessages((prev) => [
          ...prev,
          {
            id: `user-intro-${Date.now()}`,
            type: "user" as const,
            message: greeting,
            timestamp: formatConversationDate(new Date().toISOString()),
          },
        ]);
      }
    },
    [
      agentGroups,
      closeRightPanel,
      handleSuggestedPromptClick,
      projectId,
      selectedProjectRole,
      setTiptapDocument,
    ],
  );

  const handleFileUpload = useCallback(
    async (file: File) => {
      if (!isAwaitingUpload) return;

      const iwandNode = getDummyNode("iwand");
      const now = formatConversationDate(new Date().toISOString());
      const loadingId = `bot-uploading-${Date.now()}`;

      // Show user message + uploading indicator immediately
      setMessages((prev) => [
        ...prev,
        {
          id: `user-upload-${Date.now()}`,
          type: "user",
          message: <ChatAttachmentChip fileName={file.name} />,
          timestamp: now,
        },
        {
          id: loadingId,
          type: "bot",
          isLoading: true,
          loadingText: "Uploading...",
        },
      ]);
      setIsAwaitingUpload(false);

      try {
        const workflowId = await ensureWorkflowId();

        // transformRequest bypasses the instance-level JSON serializer so
        // FormData is sent as multipart/form-data (with boundary) correctly.
        const formData = new FormData();
        formData.append("workflow_id", workflowId);
        formData.append("transcript_source", "Generate from Video");
        formData.append("file", file);

        const uploadRes = await axiosInstance.post(
          "/chatbot/iwand/uploads",
          formData,
          {
            transformRequest: [(data: unknown) => data],
          },
        );

        const uploadId = (uploadRes.data?.data as { upload_id?: string } | null)
          ?.upload_id;

        // Create a promise that will be resolved based on the chatbot/conversations API result.
        // This drives step 2 of the stepper: true → final step, false → hide.
        let resolveConversation!: (success: boolean) => void;
        const conversationPromise = new Promise<boolean>((resolve) => {
          resolveConversation = resolve;
        });

        // Upload successful → replace loading bubble with stepper driven by conversationPromise
        const stepperId = `bot-stepper-${Date.now()}`;

        const handleStepperComplete = () => {
          setMessages((current) => [
            ...current,
            {
              id: `bot-transcript-${Date.now()}`,
              type: "bot",
              message: <FilePreview fileName={file.name} />,
              timestamp: formatConversationDate(new Date().toISOString()),
              metrics: iwandNode?.metrics,
            },
          ]);
        };

        const handleStepperError = () => {
          setMessages((prev) => prev.filter((m) => m.id !== stepperId));
        };

        setMessages((prev) => {
          const withoutLoading = prev.filter((m) => m.id !== loadingId);
          return [
            ...withoutLoading,
            {
              id: stepperId,
              type: "bot",
              message: (
                <FileAnalysisStepper
                  onComplete={handleStepperComplete}
                  onError={handleStepperError}
                  conversationPromise={conversationPromise}
                />
              ),
              timestamp: formatConversationDate(new Date().toISOString()),
              metrics: iwandNode?.metrics,
            },
          ];
        });

        // Call chatbot/conversations – the result drives the stepper's step 2 transition
        try {
          const msgRes = await chatApi.sendMessage(
            workflowId,
            "Please process the uploaded workshop video and return the final artifact.",
            selectedAgentIdRef.current,
            selectedProjectRoleRef.current?.project_role_id,
            uploadId,
          );
          const rawData = msgRes.data?.data;
          const botReply = rawData?.response
            ? parseAssistantContent(rawData.response)
            : "No response received.";
          const clickableOptions =
            rawData?.response?.result?.clickable_options ??
            rawData?.clickable_options;

          // Signal success → stepper advances to final step
          resolveConversation(true);

          setMessages((prev) => [
            ...prev,
            {
              id: `bot-reply-${Date.now()}`,
              type: "bot",
              message: botReply,
              messageId: rawData?.response_message_id,
              userChoice: rawData?.response_user_choice ?? null,
              ...(clickableOptions?.length && { clickableOptions }),
              timestamp: formatConversationDate(new Date().toISOString()),
            },
          ]);

          // One-shot upload complete — lock uploads until new chat
          setIwandUploadDone(true);

          const document = rawData?.response?.result?.document;
          const hasDocument =
            Array.isArray(document?.content) && document.content.length > 0;
          if (hasDocument) {
            setTiptapDocument(document as Record<string, unknown>);
            openRightPanel();
          }
        } catch (msgErr: unknown) {
          const errorMessage = extractApiErrorMessage(
            msgErr,
            "Failed to process the uploaded file. Please try again.",
          );
          ToastHelper.showRespToast({ status: false, message: errorMessage });
          // Signal failure → stepper hides
          resolveConversation(false);
          setMessages((prev) => [
            ...prev,
            {
              id: `bot-msg-error-${Date.now()}`,
              type: "bot",
              message: errorMessage,
              timestamp: formatConversationDate(new Date().toISOString()),
            },
          ]);
        }
      } catch (err: unknown) {
        // Upload failed → replace loading bubble with error message
        const errorMessage = extractApiErrorMessage(
          err,
          "File upload failed. Please try again.",
        );
        ToastHelper.showRespToast({ status: false, message: errorMessage });

        setMessages((prev) => {
          const withoutLoading = prev.filter((m) => m.id !== loadingId);
          return [
            ...withoutLoading,
            {
              id: `bot-upload-error-${Date.now()}`,
              type: "bot",
              message: errorMessage,
              timestamp: formatConversationDate(new Date().toISOString()),
            },
          ];
        });
      }
    },
    [isAwaitingUpload, ensureWorkflowId, openRightPanel, setTiptapDocument],
  );

  const handleNewChat = useCallback(() => {
    if (dummyTimeoutRef.current) {
      window.clearTimeout(dummyTimeoutRef.current);
      dummyTimeoutRef.current = null;
    }
    setSasaIframeUrl(null);
    closeRightPanel();
    setTiptapDocument(null);
    setIsAwaitingUpload(false);
    setIwandUploadDone(false);
    setMessages([]);
    setShowWelcomePrompts(true);
    setActiveWorkflowId("");
    selectedAgentIdRef.current = null;
    selectedAgentWorkflowIdRef.current = null;
    setSelectedAgentGroupId(null);
    setSidebarRefreshTrigger((prev) => prev + 1);
    setSelectedFlowName(null);
  }, [closeRightPanel, setSelectedFlowName, setTiptapDocument]);

  const handleSendMessage = useCallback(
    async (text: string, html?: string, displayText?: string) => {
      setSasaIframeUrl(null);
      setShowWelcomePrompts(false);
      const loadingId = `loading-${Date.now()}`;
      const userMessage = displayText ?? resolveDisplayMessage(text, html);

      setMessages((prev) => [
        ...prev,
        {
          id: `user-${Date.now()}`,
          type: "user",
          message: userMessage,
          ...(displayText != null && { sentMessage: text }),
          timestamp: formatConversationDate(new Date().toISOString()),
        },
        { id: loadingId, type: "bot", isLoading: true },
      ]);

      setIsSendingMessage(true);
      try {
        const workflowId = await ensureWorkflowId();
        const response = await chatApi.sendMessage(
          workflowId,
          text,
          selectedAgentIdRef.current,
          selectedProjectRoleRef.current?.project_role_id,
        );
        const rawData = response.data?.data;
        const botReply = rawData?.response
          ? parseAssistantContent(rawData.response)
          : "No response received.";
        const clickableOptions =
          rawData?.response?.result?.clickable_options ??
          rawData?.clickable_options;

        setMessages((prev) => {
          const withoutLoading = prev.filter((m) => m.id !== loadingId);
          return [
            ...withoutLoading,
            {
              id: `bot-${Date.now()}`,
              type: "bot",
              message: botReply,
              messageId: rawData?.response_message_id,
              userChoice: rawData?.response_user_choice ?? null,
              ...(clickableOptions?.length && {
                clickableOptions,
              }),
              timestamp: formatConversationDate(new Date().toISOString()),
            },
          ];
        });

        // If the response contains an expandable_document, render it as
        // collapsible accordion sections. Otherwise fall back to a non-empty
        // TipTap document (extracting/sanitizing HTML from its codeBlock).
        const expandableDocument =
          rawData?.response?.result?.expandable_document;
        const collapsibleContent = Array.isArray(expandableDocument)
          ? resolveExpandableDocument(expandableDocument)
          : null;
        if (collapsibleContent) {
          setTiptapDocument(collapsibleContent as Record<string, unknown>);
          openRightPanel();
        } else {
          const document = rawData?.response?.result?.document;
          const hasDocument =
            Array.isArray(document?.content) && document.content.length > 0;
          if (hasDocument) {
            const html = extractDocumentHtml(
              document as Record<string, unknown>,
            );
            setTiptapDocument(html ?? (document as Record<string, unknown>));
            openRightPanel();
          }
        }
      } catch (err: unknown) {
        const errorMessage = extractApiErrorMessage(err);
        ToastHelper.showRespToast({ status: false, message: errorMessage });

        setMessages((prev) => {
          const withoutLoading = prev.filter((m) => m.id !== loadingId);
          return [
            ...withoutLoading,
            {
              id: `bot-error-${Date.now()}`,
              type: "bot",
              message: errorMessage,
              timestamp: formatConversationDate(new Date().toISOString()),
            },
          ];
        });
      } finally {
        setIsSendingMessage(false);
      }
    },
    [ensureWorkflowId, agentGroups, openRightPanel, setTiptapDocument],
  );

  const handleMessageFeedback = useCallback(
    async (messageId: number, userChoice: boolean) => {
      if (!activeWorkflowId) {
        throw new Error("No active conversation");
      }

      try {
        await chatApi.submitMessageChoice({
          workflowId: activeWorkflowId,
          messageId,
          userChoice,
        });
      } catch (err) {
        console.error("Message feedback failed:", err);
        throw err;
      }
    },
    [activeWorkflowId],
  );

  return {
    messages,
    agentGroups,
    isLoadingWorkflows,
    activeWorkflowId,
    showWelcomePrompts,
    welcomePrompts,
    loadingHistoryWorkflowId,
    isSendingMessage,
    isAwaitingUpload,
    iwandUploadDone,
    showFileUpload:
      !isCrcoAgentContext(
        agentGroups,
        selectedAgentGroupId,
        activeWorkflowId,
      ) && !iwandUploadDone,
    sidebarRefreshTrigger,
    sasaIframeUrl,
    clearSasaIframe,
    handleConversationSelect,
    handleSuggestedPromptClick,
    handleAgentClick,
    handleFileUpload,
    handleNewChat,
    handleSendMessage,
    handleMessageFeedback,
  };
}
