import type { JSONContent } from "@tiptap/react";

/**
 * Shape of the `expandable_document` payload returned by the agent API.
 *
 * Each section renders as a collapsible/accordion block in the Tiptap editor:
 *   - `title`            → the clickable summary header
 *   - `default_expanded` → whether the block starts open
 *   - `fields`           → label/value rows shown inside the block
 */
export interface ExpandableDocumentField {
  label: string;
  value: string;
}

export interface ExpandableDocumentSection {
  id: string;
  title: string;
  default_expanded?: boolean;
  fields: ExpandableDocumentField[];
}

/** Full agent payload wrapper (as seen in the raw API response). */
export interface ExpandableDocumentPayload {
  chat_text?: string;
  document?: JSONContent;
  clickable_options?: Array<{ label: string; value: string }>;
  expandable_document?: ExpandableDocumentSection[];
}

/**
 * Converts a single `{ label, value }` field into a Tiptap paragraph node with
 * a bold label followed by its value. Empty text nodes are not allowed by
 * ProseMirror, so we guard against blank labels/values.
 */
function fieldToParagraph(field: ExpandableDocumentField): JSONContent {
  const label = field.label?.trim() ? `${field.label}: ` : "";
  const value = field.value ?? "";
  const content: JSONContent[] = [];

  if (label) {
    content.push({ type: "text", marks: [{ type: "bold" }], text: label });
  }
  if (value) {
    content.push({ type: "text", text: value });
  }

  return content.length
    ? { type: "paragraph", content }
    : { type: "paragraph" };
}

/**
 * Transforms the `expandable_document` array into a Tiptap document that uses
 * the custom `collapsibleSection` node so each section renders as an
 * expand/collapse accordion inside the editor.
 */
export function expandableDocumentToTiptapContent(
  sections: ExpandableDocumentSection[],
): JSONContent {
  return {
    type: "doc",
    content: sections.map((section) => ({
      type: "collapsibleSection",
      attrs: {
        title: section.title ?? "",
        open: section.default_expanded ?? false,
      },
      // `content: "block+"` requires at least one child block.
      content: section.fields?.length
        ? section.fields.map(fieldToParagraph)
        : [{ type: "paragraph" }],
    })),
  };
}

/**
 * Accepts either the full agent payload or a bare `expandable_document` array
 * and returns the Tiptap document content, or `null` if nothing usable is found.
 */
export function resolveExpandableDocument(
  input: ExpandableDocumentPayload | ExpandableDocumentSection[] | unknown,
): JSONContent | null {
  const sections = Array.isArray(input)
    ? (input as ExpandableDocumentSection[])
    : (input as ExpandableDocumentPayload)?.expandable_document;

  if (!Array.isArray(sections) || sections.length === 0) {
    return null;
  }

  return expandableDocumentToTiptapContent(sections);
}

/**
 * Flattens the `expandable_document` sections into a plain (non-collapsible)
 * Tiptap document: a bold H1 per section title followed by label/value
 * paragraphs. Mirrors the shape of the API's `document` field and is handy for
 * comparing the collapsible vs. flat rendering side by side.
 */
export function expandableDocumentToFlatContent(
  sections: ExpandableDocumentSection[],
): JSONContent {
  const content: JSONContent[] = [];

  for (const section of sections) {
    content.push({
      type: "heading",
      attrs: { level: 1 },
      content: [
        { type: "text", marks: [{ type: "bold" }], text: section.title ?? "" },
      ],
    });
    for (const field of section.fields ?? []) {
      content.push(fieldToParagraph(field));
    }
  }

  return { type: "doc", content };
}

/**
 * Returns the flat Tiptap document for a payload: prefers an explicit
 * `document` field, otherwise derives one from `expandable_document`.
 */
export function resolveFlatDocument(
  input: ExpandableDocumentPayload | ExpandableDocumentSection[] | unknown,
): JSONContent | null {
  if (!Array.isArray(input)) {
    const explicit = (input as ExpandableDocumentPayload)?.document;
    if (explicit && typeof explicit === "object") {
      return explicit;
    }
  }

  const sections = Array.isArray(input)
    ? (input as ExpandableDocumentSection[])
    : (input as ExpandableDocumentPayload)?.expandable_document;

  if (!Array.isArray(sections) || sections.length === 0) {
    return null;
  }

  return expandableDocumentToFlatContent(sections);
}

/**
 * Representative sample payload (trimmed from a real "Create CR draft" response)
 * used to pre-fill the Tiptap tester. Paste your own JSON into the tester to
 * preview any other `expandable_document`.
 */
export const sampleExpandablePayload: ExpandableDocumentPayload = {
  chat_text:
    'You\u2019ve created the CR draft for review. Please verify the details on the right panel, if you are satisfied with all the content please click on the "Create CR draft in SolMan" button.',
  clickable_options: [{ label: "Create CR draft in SolMan", value: "approve" }],
  expandable_document: [
    {
      id: "change_request",
      title: "Change Request",
      default_expanded: true,
      fields: [
        { label: "Reason for Change", value: "testing" },
        { label: "Description of Change", value: "location" },
        { label: "Additional Information", value: "\u2014" },
      ],
    },
    {
      id: "details",
      title: "Details",
      default_expanded: false,
      fields: [
        { label: "Transaction No.", value: "\u2014" },
        { label: "Created On", value: "\u2014" },
        { label: "Status", value: "\u2014" },
        { label: "Requestor", value: "\u2014" },
        { label: "Priority", value: "\u2014" },
        { label: "Risk", value: "\u2014" },
        { label: "Platform", value: "HMD" },
        { label: "Approval Status", value: "\u2014" },
        { label: "Process Type", value: "\u2014" },
      ],
    },
    {
      id: "validation_requirements",
      title: "Validation Requirements",
      default_expanded: false,
      fields: [
        { label: "User Requirements", value: "\u2014" },
        { label: "Functional Requirements", value: "\u2014" },
        { label: "Technical Design", value: "\u2014" },
        { label: "Functional Design", value: "\u2014" },
      ],
    },
    {
      id: "approval",
      title: "Approval",
      default_expanded: false,
      fields: [
        { label: "IT Lead", value: "\u2014" },
        { label: "Business Lead", value: "\u2014" },
      ],
    },
    {
      id: "parties_involved",
      title: "Parties Involved",
      default_expanded: false,
      fields: [
        { label: "Developer", value: "\u2014" },
        { label: "Implementer", value: "\u2014" },
      ],
    },
  ],
};
