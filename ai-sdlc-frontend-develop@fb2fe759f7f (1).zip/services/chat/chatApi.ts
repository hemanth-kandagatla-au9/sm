import axiosInstance from "@/lib/api/axiosInstance";
import type { Conversation, HistoryMessage } from "./types";

const CHATBOT_BASE = "chatbot/conversations";

export const chatApi = {
  listConversations(projectId: string) {
    return axiosInstance.get<{ success: boolean; data: Conversation[] }>(
      CHATBOT_BASE,
      { params: { project_id: projectId } },
    );
  },

  createConversation(
    projectId?: string,
    activeRoleId?: number,
    agentKey?: string,
    agentFamilyName?: string,
    workflowTypeId?: string,
  ) {
    return axiosInstance.post<{
      data?: { workflow_id?: string; active_role_id?: string | null };
    }>(CHATBOT_BASE, {
      project_id: projectId,
      active_role_id: activeRoleId != null ? String(activeRoleId) : null,
      ...(agentKey ? { agent_key: agentKey } : {}),
      ...(agentFamilyName ? { agent_family_name: agentFamilyName } : {}),
      ...(workflowTypeId ? { workflow_type_id: workflowTypeId } : {}),
    });
  },

  getHistory(workflowId: string) {
    return axiosInstance.post<{ data?: { messages?: HistoryMessage[] } }>(
      `${CHATBOT_BASE}/history`,
      { workflow_id: workflowId },
    );
  },

  sendMessage(
    workflowId: string,
    message: string,
    agentKey?: string | null,
    activeRoleId?: number,
    uploadId?: string,
  ) {
    return axiosInstance.post<{
      data?: {
        workflow_id?: string;
        message?: string;
        response?: {
          result?: {
            role?: string;
            content?: Array<{ text?: string }>;
            document?: {
              type?: string;
              content?: unknown[];
            };
            expandable_document?: Array<{
              id: string;
              title: string;
              default_expanded?: boolean;
              fields: Array<{ label: string; value: string }>;
            }>;
            clickable_options?: Array<{ label: string; value: string }>;
          };
        };
        response_message_id?: number;
        response_user_choice?: boolean | null;
        clickable_options?: Array<{ label: string; value: string }>;
      };
    }>(`${CHATBOT_BASE}/messages`, {
      message,
      workflow_id: workflowId,
      ...(agentKey ? { agent_key: agentKey } : {}),
      ...(activeRoleId != null ? { active_role_id: String(activeRoleId) } : {}),
      ...(uploadId ? { upload_id: uploadId } : {}),
    });
  },

  submitMessageChoice(params: {
    workflowId: string;
    messageId: number;
    userChoice: boolean;
  }) {
    return axiosInstance.post(`${CHATBOT_BASE}/messages/choice`, {
      workflow_id: params.workflowId,
      message_id: params.messageId,
      user_choice: params.userChoice,
    });
  },

  launchSasa(params: {
    project_id: number;
    role: string;
    workflow_type_id: string;
  }) {
    return axiosInstance.post<{
      success: boolean;
      data?: {
        url?: string;
        workflow_id?: string;
        project_id?: number;
        persona?: string;
      };
    }>("/sdlc/sasa", params);
  },
};
