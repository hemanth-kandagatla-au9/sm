import { formatConversationDate } from "@/lib/utils";
import { sanitizeHtml } from "@/lib/utils/richText";
import {
  resolveExpandableDocument,
  type ExpandableDocumentSection,
} from "./expandableDocument";
import type { ChatUiMessage, ClickableOption, HistoryMessage } from "./types";

type AssistantContent = {
  result?: {
    role?: string;
    content?: Array<{ text?: string }>;
    clickable_options?: ClickableOption[];
    document?: Record<string, unknown>;
    expandable_document?: ExpandableDocumentSection[];
  };
};

// Tries to parse assistant message content — handles both raw JSON strings and objects.
function parseAssistantPayload(
  content: string | AssistantContent,
): AssistantContent | null {
  try {
    return typeof content === "string" ? JSON.parse(content) : content;
  } catch {
    return null;
  }
}

// Extracts the display text from an assistant message (result.content[].text).
export function parseAssistantContent(
  content: string | AssistantContent,
): string {
  const parsed = parseAssistantPayload(content);
  const textContent = parsed?.result?.content;
  if (Array.isArray(textContent) && textContent.length > 0) {
    return textContent.map((c) => c.text ?? "").join("\n");
  }
  if (typeof content === "string") return content;
  return "";
}

// Pulls out clickable options from an assistant message if present.
export function parseAssistantClickableOptions(
  content: string | AssistantContent,
): ClickableOption[] | undefined {
  const options = parseAssistantPayload(content)?.result?.clickable_options;
  return options?.length ? options : undefined;
}

// Returns the Tiptap document object from result.document if it has content, otherwise null.
export function parseAssistantDocument(
  content: string | AssistantContent,
): Record<string, unknown> | null {
  const doc = parseAssistantPayload(content)?.result?.document;
  if (
    doc &&
    typeof doc === "object" &&
    Array.isArray((doc as Record<string, unknown>).content) &&
    ((doc as Record<string, unknown>).content as unknown[]).length > 0
  ) {
    return doc as Record<string, unknown>;
  }
  return null;
}

// Builds a collapsible Tiptap document from result.expandable_document if present,
// otherwise returns null. Each section renders as an expand/collapse accordion.
export function parseAssistantExpandableDocument(
  content: string | AssistantContent,
): Record<string, unknown> | null {
  const sections = parseAssistantPayload(content)?.result?.expandable_document;
  if (!Array.isArray(sections) || sections.length === 0) return null;
  const doc = resolveExpandableDocument(sections);
  return (doc as Record<string, unknown>) ?? null;
}

// Digs into a Tiptap document's codeBlock nodes and returns the sanitized HTML text inside.
export function extractDocumentHtml(
  doc: Record<string, unknown>,
): string | null {
  const content = doc.content as Array<Record<string, unknown>> | undefined;
  if (!Array.isArray(content)) return null;

  for (const node of content) {
    if (node.type === "codeBlock") {
      const innerContent = node.content as
        | Array<Record<string, unknown>>
        | undefined;
      if (Array.isArray(innerContent)) {
        const textNode = innerContent.find((n) => n.type === "text");
        const html = textNode?.text as string | undefined;
        if (html?.trim()) return sanitizeHtml(html);
      }
    }
  }
  return null;
}

// Scans history messages from the end and returns the most recent document.
// If the document wraps HTML inside a codeBlock, the sanitized HTML string is returned.
// Otherwise the native Tiptap JSON is returned as-is.
export function extractHistoryDocument(
  messages: HistoryMessage[],
): string | Record<string, unknown> | null {
  for (let i = messages.length - 1; i >= 0; i--) {
    const msg = messages[i];
    if (msg.role === "assistant") {
      // Prefer the collapsible expandable_document if the agent returned one.
      const expandable = parseAssistantExpandableDocument(msg.content);
      if (expandable) return expandable;
      const doc = parseAssistantDocument(msg.content);
      if (doc) return extractDocumentHtml(doc) ?? doc;
    }
  }
  return null;
}

// Converts raw history messages from the API into the UI message shape the chat renders.
export function mapHistoryToUiMessages(
  messages: HistoryMessage[],
): ChatUiMessage[] {
  return messages.map((msg, index) => {
    const isAssistant = msg.role === "assistant";
    const clickableOptions = isAssistant
      ? msg.clickable_options?.length
        ? msg.clickable_options
        : parseAssistantClickableOptions(msg.content)
      : undefined;

    return {
      id: `history-${index}-${msg.role}`,
      type: isAssistant ? "bot" : "user",
      message: isAssistant ? parseAssistantContent(msg.content) : msg.content,
      timestamp: formatConversationDate(
        msg.created_at ?? new Date().toISOString(),
      ),
      ...(isAssistant && {
        messageId: msg.id,
        userChoice: msg.user_choice ?? null,
        ...(clickableOptions?.length && { clickableOptions }),
      }),
    };
  });
}

// Pulls a readable error message out of an axios error response, falling back to a generic string.
export function extractApiErrorMessage(
  err: unknown,
  fallback = "Sorry, something went wrong. Please try again.",
): string {
  if (
    err &&
    typeof err === "object" &&
    "response" in err &&
    err.response &&
    typeof err.response === "object" &&
    "data" in err.response
  ) {
    const responseData = err.response.data as {
      error?: {
        message?: string;
        details?: Record<string, unknown>;
      };
    };

    const detailMessage = responseData?.error?.details
      ? Object.values(responseData.error.details).find(
          (value): value is string =>
            typeof value === "string" && value.trim().length > 0,
        )
      : undefined;

    if (detailMessage) {
      return detailMessage;
    }

    if (responseData?.error?.message) {
      return responseData.error.message;
    }
  }
  return fallback;
}
