export interface LoginResponse {
  success: boolean;
  data: {
    log_id: string;
    user_name_snapshot: string;
    user_email_snapshot: string;
    action: string;
    login_on: string;
    logout_on: string | null;
    user_id: number;
    logout_type: string | null;
    is_platform_admin?: boolean;
    is_project_owner?: boolean;
  };
}

export interface LogoutResponse {
  success: boolean;
  data: {
    log_id: string;
    action: string;
    login_on: string;
    logout_on: string;
  };
}
