export interface ProjectRolePreview {
	role_name: string;
	ad_group_name: string;
}

export interface PreviewProjectRolesResponse {
	success: boolean;
	data: {
		next_project_number: number;
		roles: ProjectRolePreview[];
	};
}
