folder('ai-sdlc-fe-jobs')
pipelineJob('ai-sdlc-fe-jobs/deploy-qa') {
    definition {
        cpsScm {
            scm {
                git {
                    branch('qa')
                    remote {
                        url('https://sourcecode.jnj.com/scm/asx-jjyy/ai-sdlc-frontend.git')
                        credentials('sourcecode-bitbucket')
                    }
                }
            }
        }
    }
}