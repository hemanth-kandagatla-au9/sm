folder('ai-sdlc-fe-jobs')
pipelineJob('ai-sdlc-fe-jobs/deploy-prod') {
    definition {
        cpsScm {
            scm {
                git {
                    branch('main')
                    remote {
                        url('https://sourcecode.jnj.com/scm/asx-jjyy/ai-sdlc-frontend.git')
                        credentials('sourcecode-bitbucket')
                    }
                }
            }
        }
    }
}