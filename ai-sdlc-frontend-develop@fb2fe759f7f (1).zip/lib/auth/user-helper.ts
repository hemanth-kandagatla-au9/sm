"use client";

import type { AccountInfo } from "@azure/msal-browser";
import { getMsalInstance } from "@/lib/auth/msal";
import {
  getUserRoles,
  hasRole,
  type UserRole,
} from "@/lib/auth/roles";

export function getLoggedInUser(): AccountInfo | null {
  return getMsalInstance().getActiveAccount();
}

export function getUserClaims(): UserRole[] {
  return getUserRoles();
}

export function isUserAllowed(requiredRole: UserRole, roles?: UserRole[]) {
  return hasRole(requiredRole, roles);
}

export function extractInitials(name: string | null | undefined): string {
  if (!name) {
    return "";
  }

  return name
    .replace(/\[.*?\]/g, "")
    .trim()
    .split(/\s+/)
    .map((part) => part[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();
}

export function getSessionUserId(): number | null {
  if (typeof window === "undefined") {
    return null;
  }

  const userId = sessionStorage.getItem("sessionUserId");
  if (!userId) {
    return null;
  }

  return Number(userId);
}
