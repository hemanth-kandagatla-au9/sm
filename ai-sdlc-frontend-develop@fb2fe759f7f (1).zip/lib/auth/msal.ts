import {
  AuthenticationResult,
  EventType,
  PublicClientApplication,
} from "@azure/msal-browser";
import { loginRequest, msalConfig } from "@/lib/auth/auth-config";
import {
  getCurrentToken,
  resetTokenFetcherState,
} from "@/lib/auth/token-fetcher";
import axiosInstance from "@/lib/api/axiosInstance";
import {
  clearUserRoles,
  persistUserRoles,
  rolesFromLoginData,
} from "@/lib/auth/roles";
import {
  clearAuthSessionCookie,
  setAuthSessionCookie,
} from "@/lib/auth/session-cookie";
import type {
  LoginResponse,
  LogoutResponse,
} from "@/services/types/authenticationTypes";
import toast from "react-hot-toast";
import { promiseLoadingToastStyle } from "@/components/common/ToastHelper";

let isInitialized = false;
let msalInstance: PublicClientApplication | null = null;

export function getMsalInstance() {
  if (!msalInstance) {
    msalInstance = new PublicClientApplication(msalConfig);
  }

  return msalInstance;
}

export async function initializeMsal() {
  if (isInitialized) {
    return;
  }

  const instance = getMsalInstance();

  await instance.initialize();
  const authResult = await instance.handleRedirectPromise();

  if (authResult && authResult.account) {
    resetTokenFetcherState();
    instance.setActiveAccount(authResult.account);
  }

  const accounts = instance.getAllAccounts();
  if (accounts.length > 0) {
    instance.setActiveAccount(accounts[0]);
  }

  const shouldRecordLogin =
    instance.getActiveAccount() &&
    (authResult?.account || !sessionStorage.getItem("sessionLogId"));

  if (shouldRecordLogin) {
    try {
      const loginResponse = await axiosInstance.post<LoginResponse>(
        "/sdlc/session/login",
      );
      const loginData = loginResponse.data?.data;
      if (loginData?.log_id) {
        sessionStorage.setItem("sessionLogId", loginData.log_id);
      }
      if (loginData?.user_id) {
        sessionStorage.setItem("sessionUserId", String(loginData.user_id));
      }
      persistUserRoles(rolesFromLoginData(loginData ?? {}));
    } catch (err) {
      throw new Error("Failed to record login event in backend: " + err);
    }
  }

  if (instance.getActiveAccount()) {
    await setAuthSessionCookie();
  } else {
    await clearAuthSessionCookie();
  }

  instance.addEventCallback((event) => {
    if (event.eventType === EventType.LOGIN_SUCCESS && event.payload) {
      resetTokenFetcherState();
      const payload = event.payload as AuthenticationResult;
      if (payload.account) {
        instance.setActiveAccount(payload.account);
      }
    }
  });

  isInitialized = true;
}

export async function getToken() {
  //  returning access token
  return getCurrentToken(getMsalInstance());
}

export async function handleLogin() {
  await getMsalInstance().loginRedirect(loginRequest);
}

export async function handleLogout() {
  const instance = getMsalInstance();

  try {
    const sessionLogId = sessionStorage.getItem("sessionLogId");
    const logoutResponsePromise = axiosInstance.post<LogoutResponse>(
      "/sdlc/session/logout",
      {
        log_id: sessionLogId,
      },
    );
    await toast.promise(
      logoutResponsePromise,
      {
        loading: "Logging out...",
        // success: () => "Logged out successfully",
        // error: () => "Failed to log out",
      },
      promiseLoadingToastStyle,
    );
    sessionStorage.removeItem("sessionLogId");
    sessionStorage.removeItem("sessionUserId");
    clearUserRoles();
  } catch (err) {
    throw new Error("Failed to record logout event in backend: " + err);
  }

  resetTokenFetcherState();
  await clearAuthSessionCookie();

  await instance.logoutRedirect({
    account: instance.getActiveAccount() ?? undefined,
    postLogoutRedirectUri: "/",
  });
}
