const CLIENT_ID = process.env.NEXT_PUBLIC_CLIENT_ID ?? "";
const TENANT_ID = process.env.NEXT_PUBLIC_AUTHORITY ?? "";
const API_SCOPE = process.env.NEXT_PUBLIC_API_SCOPE ?? "";

export { API_SCOPE };

export const msalConfig = {
  auth: {
    clientId: CLIENT_ID,
    authority: TENANT_ID
      ? `https://login.microsoftonline.com/${TENANT_ID}`
      : undefined,
    redirectUri: "/auth/callback",
    postLogoutRedirectUri: "/",
    navigateToLoginRequestUrl: false,
  },
  cache: {
    cacheLocation: "sessionStorage",
    storeAuthStateInCookie: false,
  },
};

export const loginRequest = {
  scopes: API_SCOPE ? [API_SCOPE] : [],
};

export const userDataLoginRequest = {
  scopes: ["User.Read"],
};

export const graphConfig = {
  graphMeEndpoint: "https://graph.microsoft.com/v1.0/me",
};
