"use client";

import {
  createContext,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from "react";
import { getUserPhotoAvatar } from "@/lib/auth/msal-graph";
import { getLoggedInUser } from "@/lib/auth/user-helper";

const UserProfilePhotoContext = createContext<string | null>(null);

export function UserProfileProvider({ children }: { children: ReactNode }) {
  const [photoUrl, setPhotoUrl] = useState<string | null>(null);

  useEffect(() => {
    if (!getLoggedInUser()) {
      return;
    }

    let objectUrl: string | null = null;
    let cancelled = false;

    const loadPhoto = async () => {
      const url = await getUserPhotoAvatar();
      if (cancelled) {
        if (url) {
          URL.revokeObjectURL(url);
        }
        return;
      }
      objectUrl = url;
      setPhotoUrl(url);
    };

    void loadPhoto();

    return () => {
      cancelled = true;
      if (objectUrl) {
        URL.revokeObjectURL(objectUrl);
      }
    };
  }, []);

  return (
    <UserProfilePhotoContext.Provider value={photoUrl}>
      {children}
    </UserProfilePhotoContext.Provider>
  );
}

export function useUserProfilePhoto() {
  return useContext(UserProfilePhotoContext);
}
