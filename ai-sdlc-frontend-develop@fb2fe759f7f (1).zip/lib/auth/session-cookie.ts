export async function setAuthSessionCookie(): Promise<void> {
  await fetch("/api/auth/session", {
    method: "POST",
    credentials: "same-origin",
  });
}

export async function clearAuthSessionCookie(): Promise<void> {
  await fetch("/api/auth/session", {
    method: "DELETE",
    credentials: "same-origin",
  });
}
