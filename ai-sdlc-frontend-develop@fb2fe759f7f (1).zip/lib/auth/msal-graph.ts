import { graphConfig, userDataLoginRequest } from "@/lib/auth/auth-config";
import { getMsalInstance } from "@/lib/auth/msal";

export async function getUserPhotoAvatar(): Promise<string | null> {
  const msalInstance = getMsalInstance();
  const account = msalInstance.getActiveAccount();

  if (!account) {
    return null;
  }

  try {
    const tokenResponse = await msalInstance.acquireTokenSilent({
      ...userDataLoginRequest,
      account,
    });

    const response = await fetch(
      `${graphConfig.graphMeEndpoint}/photo/$value`,
      {
        headers: {
          Authorization: `Bearer ${tokenResponse.accessToken}`,
        },
      },
    );

    if (!response.ok) {
      return null;
    }

    const blob = await response.blob();
    return URL.createObjectURL(blob);
  } catch {
    return null;
  }
}
