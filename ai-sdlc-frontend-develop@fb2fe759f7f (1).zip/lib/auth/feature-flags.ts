export const AUTH_SESSION_COOKIE = "jnj_sso_session";

export const authCookieOptions = {
  httpOnly: true,
  path: "/",
  sameSite: "lax" as const,
  secure: process.env.NODE_ENV === "production",
  maxAge: 60 * 60 * 8,
};

export function hasAccessCookie(cookieValue?: string) {
  return cookieValue === "1";
}
