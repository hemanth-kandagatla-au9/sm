import {
  InteractionRequiredAuthError,
  type PublicClientApplication,
} from "@azure/msal-browser";
import { API_SCOPE } from "@/lib/auth/auth-config";

/** Deduplicates concurrent token requests (e.g. parallel API calls). */
let tokenRefreshPromise: Promise<string | null> | null = null;

/** Ensures only one interactive redirect is started per page load. */
let interactiveRedirectStarted = false;

export function resetTokenFetcherState() {
  tokenRefreshPromise = null;
  interactiveRedirectStarted = false;
}

async function acquireToken(
  msalInstance: PublicClientApplication,
): Promise<string | null> {
  if (typeof window === "undefined") {
    return null;
  }

  const activeAccount = msalInstance.getActiveAccount();
  const fallbackAccount = msalInstance.getAllAccounts()[0];
  const account = activeAccount ?? fallbackAccount;

  if (!account) {
    return null;
  }

  const request = {
    scopes: API_SCOPE ? [API_SCOPE] : [],
    account,
  };

  try {
    const authResult = await msalInstance.acquireTokenSilent(request);
    return authResult.accessToken;
  } catch (error) {
    if (error instanceof InteractionRequiredAuthError) {
      // Never use acquireTokenPopup here — each failed API call would open a new window.
      if (!interactiveRedirectStarted) {
        interactiveRedirectStarted = true;
        await msalInstance.acquireTokenRedirect(request);
      }
      return null;
    }

    console.error("Error acquiring token", error);
    return null;
  }
}

export async function getCurrentToken(
  msalInstance: PublicClientApplication,
): Promise<string | null> {
  if (!tokenRefreshPromise) {
    tokenRefreshPromise = acquireToken(msalInstance).finally(() => {
      tokenRefreshPromise = null;
    });
  }

  return tokenRefreshPromise;
}
