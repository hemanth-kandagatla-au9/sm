import type { LoginResponse } from "@/services/types/authenticationTypes";

export const ROLES = {
  PLATFORM_ADMIN: "Platform Admin",
  PROJECT_OWNER: "Project Owner",
} as const;

export type UserRole = (typeof ROLES)[keyof typeof ROLES];

const SESSION_ROLES_KEY = "sessionUserRoles";

/** Routes visible to Project Owners (Platform Admins see all). */
export const PROJECT_OWNER_NAV_ROUTES = ["/dashboard", "/messages"] as const;

/** Routes visible when neither platform admin nor project owner. */
export const DEFAULT_NAV_ROUTES = ["/messages"] as const;

function matchesAllowedRoute(
  route: string,
  allowedRoutes: readonly string[],
): boolean {
  return allowedRoutes.some(
    (allowed) => route === allowed || route.startsWith(`${allowed}/`),
  );
}

export function rolesFromLoginData(
  data: Pick<
    LoginResponse["data"],
    "is_platform_admin" | "is_project_owner"
  >,
): UserRole[] {
  const roles: UserRole[] = [];

  if (data.is_platform_admin) {
    roles.push(ROLES.PLATFORM_ADMIN);
  }
  if (data.is_project_owner) {
    roles.push(ROLES.PROJECT_OWNER);
  }

  return roles;
}

export function persistUserRoles(roles: UserRole[]): void {
  if (typeof window === "undefined") {
    return;
  }
  sessionStorage.setItem(SESSION_ROLES_KEY, JSON.stringify(roles));
}

export function getUserRoles(): UserRole[] {
  if (typeof window === "undefined") {
    return [];
  }

  const raw = sessionStorage.getItem(SESSION_ROLES_KEY);
  if (!raw) {
    return [];
  }

  try {
    return JSON.parse(raw) as UserRole[];
  } catch {
    return [];
  }
}

export function clearUserRoles(): void {
  if (typeof window === "undefined") {
    return;
  }
  sessionStorage.removeItem(SESSION_ROLES_KEY);
}

export function getPrimaryRole(roles: UserRole[]): string {
  if (roles.includes(ROLES.PLATFORM_ADMIN)) {
    return ROLES.PLATFORM_ADMIN;
  }
  if (roles.includes(ROLES.PROJECT_OWNER)) {
    return ROLES.PROJECT_OWNER;
  }
  return "";
}

export function isPlatformAdmin(roles?: UserRole[]): boolean {
  return (roles ?? getUserRoles()).includes(ROLES.PLATFORM_ADMIN);
}

export function isProjectOwner(roles?: UserRole[]): boolean {
  return (roles ?? getUserRoles()).includes(ROLES.PROJECT_OWNER);
}

export function hasRole(requiredRole: UserRole, roles?: UserRole[]): boolean {
  return (roles ?? getUserRoles()).includes(requiredRole);
}

export function getAllowedRoutes(roles?: UserRole[]): readonly string[] {
  const userRoles = roles ?? getUserRoles();

  if (isPlatformAdmin(userRoles)) {
    return ["/dashboard"];
  }

  if (isProjectOwner(userRoles)) {
    return PROJECT_OWNER_NAV_ROUTES;
  }

  return DEFAULT_NAV_ROUTES;
}

export function getDefaultRoute(roles?: UserRole[]): string {
  return getAllowedRoutes(roles)[0] ?? "/messages";
}

export function canAccessRoute(route: string, roles?: UserRole[]): boolean {
  const userRoles = roles ?? getUserRoles();

  if (isPlatformAdmin(userRoles)) {
    return true;
  }

  if (isProjectOwner(userRoles)) {
    return matchesAllowedRoute(route, PROJECT_OWNER_NAV_ROUTES);
  }

  return matchesAllowedRoute(route, DEFAULT_NAV_ROUTES);
}

export function getVisibleNavItems<T extends { route: string }>(
  items: T[],
  roles?: UserRole[],
): T[] {
  const userRoles = roles ?? getUserRoles();

  if (isPlatformAdmin(userRoles)) {
    return items;
  }

  if (isProjectOwner(userRoles)) {
    return items.filter((item) =>
      matchesAllowedRoute(item.route, PROJECT_OWNER_NAV_ROUTES),
    );
  }

  return items.filter((item) =>
    matchesAllowedRoute(item.route, DEFAULT_NAV_ROUTES),
  );
}
