import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}


export function formatConversationDate(
  dateString: unknown,
  includeSeconds: boolean = false,
  includeTime: boolean = true,
) {
  if (dateString == null || dateString === "") {
    return "--";
  }

  const date = new Date(String(dateString));

  if (Number.isNaN(date.getTime())) {
    return "--";
  }

  const monthNames = [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec",
  ];

  const day = date.getDate();
  const month = monthNames[date.getMonth()];
  const year = date.getFullYear();
  const hours = String(date.getHours()).padStart(2, "0");
  const minutes = String(date.getMinutes()).padStart(2, "0");
  const seconds = String(date.getSeconds()).padStart(2, "0");

  if (!includeTime) {
    return `${day} ${month} ${year}`;
  }

  const timePart = includeSeconds
    ? `${hours}:${minutes}:${seconds}`
    : `${hours}:${minutes}`;

  return `${day} ${month} ${year}, ${timePart}`;
}
