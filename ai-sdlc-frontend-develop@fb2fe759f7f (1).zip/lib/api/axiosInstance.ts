import axios from "axios";
import { getMsalInstance } from "@/lib/auth/msal";
import { getCurrentToken } from "@/lib/auth/token-fetcher";

const axiosInstance = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL,
  headers: {
    "Content-Type": "application/json",
  },
});

axiosInstance.interceptors.request.use(async (config) => {
  const token = await getCurrentToken(getMsalInstance());

  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }

  return config;
});

axiosInstance.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      console.error("Unauthorized. Token is invalid or expired.");
    }
    return Promise.reject(error);
  },
);

export default axiosInstance;
