const ALLOWED_TAGS = new Set([
  "p",
  "br",
  "strong",
  "b",
  "em",
  "i",
  "u",
  "s",
  "strike",
  "ul",
  "ol",
  "li",
  "h1",
  "h2",
  "h3",
  "h4",
  "h5",
  "h6",
  "a",
  "code",
  "pre",
  "blockquote",
  "span",
  "div",
]);

const BLOCK_TAGS = new Set([
  "p",
  "div",
  "h1",
  "h2",
  "h3",
  "h4",
  "h5",
  "h6",
  "li",
  "pre",
  "blockquote",
]);

const RICH_FORMATTING_TAG =
  /<(strong|b|em|i|u|s|strike|ul|ol|li|h[1-6]|a|code|pre|blockquote)\b/i;

/** True when HTML includes meaningful formatting (not just a plain paragraph wrapper). */
export function hasRichFormatting(html: string): boolean {
  const trimmed = html.trim();
  if (!trimmed.startsWith("<")) {
    return false;
  }
  return RICH_FORMATTING_TAG.test(trimmed);
}

/** Use for rendering/copy — avoids treating plain text or code snippets as HTML. */
export function isHtmlContent(value: string): boolean {
  return hasRichFormatting(value);
}

/** Pick stored message content: plain text unless the user applied real formatting. */
export function resolveDisplayMessage(plainText: string, html?: string): string {
  const trimmedPlain = plainText.trim();
  if (!html?.trim() || !hasRichFormatting(html)) {
    return trimmedPlain;
  }
  return sanitizeHtml(html);
}

export function plainTextToHtml(text: string): string {
  const escaped = text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
  return `<p>${escaped.replace(/\n/g, "<br>")}</p>`;
}

export function sanitizeHtml(html: string): string {
  if (typeof document === "undefined") {
    return html;
  }

  const doc = new DOMParser().parseFromString(html, "text/html");
  const body = doc.body;

  const sanitizeNode = (node: Node): void => {
    const children = Array.from(node.childNodes);
    for (const child of children) {
      if (child.nodeType === Node.ELEMENT_NODE) {
        const el = child as HTMLElement;
        const tag = el.tagName.toLowerCase();

        if (!ALLOWED_TAGS.has(tag)) {
          while (el.firstChild) {
            el.parentNode?.insertBefore(el.firstChild, el);
          }
          el.remove();
          continue;
        }

        for (const attr of Array.from(el.attributes)) {
          if (tag === "a" && attr.name === "href") {
            continue;
          }
          if (attr.name === "class" || attr.name === "style") {
            continue;
          }
          el.removeAttribute(attr.name);
        }

        if (tag === "a") {
          const href = el.getAttribute("href");
          if (href?.startsWith("javascript:")) {
            el.removeAttribute("href");
          } else {
            el.setAttribute("rel", "noopener noreferrer");
            el.setAttribute("target", "_blank");
          }
        }

        sanitizeNode(el);
      } else if (child.nodeType === Node.COMMENT_NODE) {
        child.remove();
      }
    }
  };

  sanitizeNode(body);

  const normalized = Array.from(body.childNodes)
    .map((node) => {
      if (node.nodeType === Node.ELEMENT_NODE) {
        return (node as HTMLElement).outerHTML;
      }
      if (node.nodeType === Node.TEXT_NODE && node.textContent?.trim()) {
        return `<p>${node.textContent}</p>`;
      }
      return "";
    })
    .join("");

  return normalized || body.innerHTML;
}

export function htmlToPlainText(html: string): string {
  if (typeof document === "undefined") {
    return html;
  }

  const doc = new DOMParser().parseFromString(html, "text/html");
  const blocks: string[] = [];

  const walk = (node: Node) => {
    if (node.nodeType === Node.TEXT_NODE) {
      const text = node.textContent ?? "";
      if (text) blocks.push(text);
      return;
    }

    if (node.nodeType !== Node.ELEMENT_NODE) return;

    const el = node as HTMLElement;
    const tag = el.tagName.toLowerCase();

    if (tag === "br") {
      blocks.push("\n");
      return;
    }

    const isBlock = BLOCK_TAGS.has(tag);
    if (isBlock) blocks.push("");

    for (const child of Array.from(el.childNodes)) {
      walk(child);
    }

    if (isBlock) blocks.push("\n");
  };

  for (const child of Array.from(doc.body.childNodes)) {
    walk(child);
  }

  return blocks
    .join("")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

export async function copyFormattedText({
  text,
  html,
}: {
  text: string;
  html?: string;
}): Promise<void> {
  const htmlPayload = html ?? plainTextToHtml(text);

  if (
    typeof navigator !== "undefined" &&
    navigator.clipboard?.write &&
    typeof ClipboardItem !== "undefined"
  ) {
    const item = new ClipboardItem({
      "text/plain": new Blob([text], { type: "text/plain" }),
      "text/html": new Blob([htmlPayload], { type: "text/html" }),
    });
    await navigator.clipboard.write([item]);
    return;
  }

  try {
    await navigator.clipboard.writeText(text);
  } catch (err) {
    console.error("Clipboard write failed:", err);
    throw err;
  }
}
