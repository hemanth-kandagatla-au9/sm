import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";
import { AUTH_SESSION_COOKIE, hasAccessCookie } from "@/lib/auth/feature-flags";

const PROTECTED_MATCHER = ["/dashboard"];

function isProtectedPath(pathname: string) {
  return PROTECTED_MATCHER.some(
    (protectedPath) =>
      pathname === protectedPath || pathname.startsWith(`${protectedPath}/`),
  );
}

export function proxy(request: NextRequest) {
  const { pathname } = request.nextUrl;

  if (!isProtectedPath(pathname) && pathname !== "/") {
    return NextResponse.next();
  }

  if (pathname === "/") {
    const hasSession = hasAccessCookie(
      request.cookies.get(AUTH_SESSION_COOKIE)?.value,
    );

    if (hasSession) {
      return NextResponse.redirect(new URL("/dashboard", request.url));
    }

    return NextResponse.next();
  }

  const hasSession = hasAccessCookie(
    request.cookies.get(AUTH_SESSION_COOKIE)?.value,
  );

  if (!hasSession) {
    return NextResponse.redirect(new URL("/", request.url));
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/", "/dashboard/:path*"],
};
