# AI SDLC Orchestrator Frontend

## Tech Stack

- Next.js 16
- React 19
- TypeScript 5
- Tailwind CSS 4
- shadcn/ui with `radix-nova` configuration
- Radix UI primitives
- Microsoft Authentication Library
- Recharts
- Lucide React
- ESLint 9

## Routes and Auth Flow

- `/`
  - Login page
- `/auth/callback`
  - MSAL redirect callback page
- `/dashboard`
  - Protected dashboard area
- `/api/auth/session`
  - Endpoint that syncs MSAL auth state to a cookie

Authentication is Microsoft Entra ID SSO only:

- Uses MSAL redirect flow
- Protects dashboard access with a session cookie

## Getting Started

Install dependencies and create your local environment file:

```bash
npm install
cp env.example .env
```

Update `.env` as needed, then start the development server:

```bash
npm run dev
```

The app runs on [http://localhost:3000](http://localhost:3000) by default.

## Environment Variables

Example variables are provided in [`env.example`](/Users/enisuzan/Desktop/projects/JNJ/ai-sdlc-frontend/env.example).

| Variable                  | Description                                                                                                     |
| ------------------------- | --------------------------------------------------------------------------------------------------------------- |
| `NEXT_PUBLIC_CLIENT_ID`   | Microsoft Entra application client ID.                                                                          |
| `NEXT_PUBLIC_AUTHORITY`   | Tenant ID. The app builds the authority URL as `https://login.microsoftonline.com/<TENANT_ID>`.                 |
| `NEXT_PUBLIC_API_SCOPE`   | API scope requested during login.                                                                               |

## Available Commands

```bash
npm run dev
npm run build
npm run start
npm run lint
```

## Project Structure

```text
app/
  api/auth/session/   # Session cookie sync endpoint
  auth/callback/      # MSAL callback route
  dashboard/          # Protected dashboard route
components/
  auth/               # Login, guard, provider, and session components
  dashboard/          # Dashboard sections and dashboard data
  ui/                 # Shared shadcn/ui-based components
lib/
  auth/               # MSAL config, feature flags, and auth helpers
public/               # Static assets and brand visuals
```
