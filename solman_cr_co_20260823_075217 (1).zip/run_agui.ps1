# run_agui.ps1 - bring up the three AG-UI processes on Windows.
#
#   usage:   . .\set_env.ps1
#            .\run_agui.ps1
#
# Starts, in order:
#   1. agui_server.py     :8084   Python AG-UI host (the agent)
#   2. agui_runtime\      :8006   CopilotKit runtime bridge (Node)
#   3. frontend\          :8005   Vite dev server (the cards)
#
# Ctrl+C stops all three. Logs go to .agui-logs\.
#
# If PowerShell refuses to run this ("running scripts is disabled"), unblock it
# for this session only:
#     Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass

[CmdletBinding()]
param(
    [int]    $AguiPort        = $(if ($env:AGUI_PORT)         { [int]$env:AGUI_PORT }         else { 8084 }),
    [int]    $RuntimePort     = $(if ($env:AGUI_RUNTIME_PORT) { [int]$env:AGUI_RUNTIME_PORT } else { 8006 }),
    [int]    $FrontendPort    = $(if ($env:FRONTEND_PORT)     { [int]$env:FRONTEND_PORT }     else { 8005 }),
    [string] $Python          = "python",
    [switch] $SkipBridge,      # use if your CopilotKit version talks to Python directly
    [switch] $NoInstall        # skip the npm install check
)

$ErrorActionPreference = "Stop"
Set-Location -Path $PSScriptRoot

$LogDir = Join-Path $PSScriptRoot ".agui-logs"
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null

$script:Started = @()

function Stop-All {
    Write-Host ""
    Write-Host "-> shutting down..." -ForegroundColor Yellow
    foreach ($p in $script:Started) {
        if ($p -and -not $p.HasExited) {
            # Kill the whole tree - npm spawns node as a child, and killing only
            # the npm shim leaves the dev server holding the port.
            try { & taskkill.exe /PID $p.Id /T /F 2>&1 | Out-Null } catch { }
        }
    }
}

function Test-PortFree {
    param([int]$Port, [string]$Label)
    $inUse = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue
    if ($inUse) {
        $owner = (Get-Process -Id $inUse[0].OwningProcess -ErrorAction SilentlyContinue).ProcessName
        throw "Port $Port ($Label) is already in use by '$owner' (PID $($inUse[0].OwningProcess)). Stop it, or pass a different port."
    }
}

function Start-Logged {
    # NOTE: do not name the second parameter $Args - that is a PowerShell
    # automatic variable and it shadows the parameter, leaving ArgumentList empty.
    param([string]$File, [string]$ArgLine, [string]$WorkDir, [string]$LogName)
    $startArgs = @{
        FilePath               = $File
        ArgumentList           = $ArgLine
        WorkingDirectory       = $WorkDir
        NoNewWindow            = $true
        PassThru               = $true
        RedirectStandardOutput = (Join-Path $LogDir "$LogName.log")
        RedirectStandardError  = (Join-Path $LogDir "$LogName.err.log")
    }
    $p = Start-Process @startArgs
    $script:Started += $p
    return $p
}

# --- Preflight ---------------------------------------------------------------
if (-not $env:RESOLVE_SSM_PARAMS) {
    Write-Host "set_env.ps1 does not look dot-sourced (RESOLVE_SSM_PARAMS unset)." -ForegroundColor Yellow
    Write-Host "  Run:  . .\set_env.ps1     (leading dot matters)" -ForegroundColor Yellow
    Write-Host ""
}

# Vite reads these at dev-server start; set them here too so run_agui.ps1 works
# standalone without set_env.ps1 having been sourced.
$env:AGUI_PORT             = "$AguiPort"
$env:AGUI_RUNTIME_PORT     = "$RuntimePort"
$env:AGUI_BACKEND_URL      = "http://localhost:$AguiPort/copilotkit"
$env:VITE_AGUI_API_BASE    = "http://localhost:$AguiPort"
$env:VITE_AGUI_RUNTIME_URL = if ($SkipBridge) { "http://localhost:$AguiPort/copilotkit" }
                             else            { "http://localhost:$RuntimePort/api/copilotkit" }

Test-PortFree -Port $AguiPort     -Label "AG-UI backend"
if (-not $SkipBridge) { Test-PortFree -Port $RuntimePort -Label "CopilotKit bridge" }
Test-PortFree -Port $FrontendPort -Label "frontend"

try {
    # --- 1. Python AG-UI host ------------------------------------------------
    Write-Host "-> [1/3] agui_server.py on :$AguiPort" -ForegroundColor Cyan
    $backend = Start-Logged -File $Python -ArgLine "agui_server.py" -WorkDir $PSScriptRoot -LogName "agui_server"

    Write-Host -NoNewline "      waiting for backend"
    $ready = $false
    foreach ($i in 1..60) {
        if ($backend.HasExited) {
            Write-Host ""
            Write-Host "Backend exited during startup. Last lines:" -ForegroundColor Red
            Get-Content (Join-Path $LogDir "agui_server.err.log") -Tail 30 -ErrorAction SilentlyContinue
            Get-Content (Join-Path $LogDir "agui_server.log")     -Tail 30 -ErrorAction SilentlyContinue
            throw "agui_server.py failed to start"
        }
        try {
            Invoke-RestMethod -Uri "http://localhost:$AguiPort/api/ui-contract" -TimeoutSec 2 -ErrorAction Stop | Out-Null
            $ready = $true
            Write-Host " OK" -ForegroundColor Green
            break
        } catch {
            Write-Host -NoNewline "."
            Start-Sleep -Seconds 1
        }
    }
    if (-not $ready) {
        Write-Host ""
        Write-Host "Backend did not answer in 60s. Last lines:" -ForegroundColor Red
        Get-Content (Join-Path $LogDir "agui_server.err.log") -Tail 30 -ErrorAction SilentlyContinue
        throw "backend startup timed out"
    }

    # --- 2. CopilotKit runtime bridge ----------------------------------------
    if ($SkipBridge) {
        Write-Host "-> [2/3] bridge SKIPPED (frontend will hit Python directly)" -ForegroundColor DarkGray
    } else {
        Write-Host "-> [2/3] agui_runtime bridge on :$RuntimePort" -ForegroundColor Cyan
        if (-not $NoInstall -and -not (Test-Path "agui_runtime\node_modules")) {
            Write-Host "      installing bridge deps (first run, this takes a minute)..."
            & npm.cmd install --no-audit --no-fund --prefix agui_runtime 2>&1 |
                Out-File (Join-Path $LogDir "agui_runtime.install.log")
            if ($LASTEXITCODE -ne 0) { throw "npm install failed in agui_runtime (see .agui-logs\agui_runtime.install.log)" }
        }
        Start-Logged -File "npm.cmd" -ArgLine "start" -WorkDir (Join-Path $PSScriptRoot "agui_runtime") -LogName "agui_runtime" | Out-Null
    }

    # --- 3. Vite dev server --------------------------------------------------
    Write-Host "-> [3/3] frontend on :$FrontendPort" -ForegroundColor Cyan
    if (-not $NoInstall -and -not (Test-Path "frontend\node_modules")) {
        Write-Host "      installing frontend deps (first run, this takes a few minutes)..."
        & npm.cmd install --no-audit --no-fund --prefix frontend 2>&1 |
            Out-File (Join-Path $LogDir "frontend.install.log")
        if ($LASTEXITCODE -ne 0) { throw "npm install failed in frontend (see .agui-logs\frontend.install.log)" }
    }
    Start-Logged -File "npm.cmd" -ArgLine "run dev -- --port $FrontendPort --host" -WorkDir (Join-Path $PSScriptRoot "frontend") -LogName "frontend" | Out-Null

    Start-Sleep -Seconds 3
    Write-Host ""
    Write-Host "---------------------------------------------------------" -ForegroundColor Green
    Write-Host "  open      http://localhost:$FrontendPort" -ForegroundColor Green
    Write-Host ""
    Write-Host "  contract  http://localhost:$AguiPort/api/ui-contract"
    if (-not $SkipBridge) { Write-Host "  bridge    http://localhost:$RuntimePort/health" }
    Write-Host "  logs      .agui-logs\"
    Write-Host "---------------------------------------------------------" -ForegroundColor Green
    Write-Host "  Ctrl+C to stop all three." -ForegroundColor Green
    Write-Host ""

    # Hold the console open. Surfaces a crashed child instead of sitting silent.
    while ($true) {
        Start-Sleep -Seconds 2
        foreach ($p in $script:Started) {
            if ($p.HasExited) {
                Write-Host "A process exited unexpectedly (PID $($p.Id), exit $($p.ExitCode)). Check .agui-logs\." -ForegroundColor Red
                return
            }
        }
    }
}
finally {
    Stop-All
}
