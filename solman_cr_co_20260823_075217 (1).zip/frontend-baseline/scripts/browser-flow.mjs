#!/usr/bin/env node
/**
 * scripts/browser-flow.mjs
 *
 * Drive the whole CR flow in a real headless Chrome and report, at each step,
 * what the client actually holds.
 *
 * Same zero-dependency CDP approach as browser-check.mjs. This one clicks:
 * mode choice -> intake form -> submit -> whatever the agent sends back.
 */

import { spawn } from "node:child_process";
import { mkdtempSync, existsSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";

const BASE = process.argv[2] ?? "http://localhost:3000";

const chrome = [
  "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
  "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe",
].find((p) => existsSync(p));
if (!chrome) throw new Error("no browser");

const PORT = 9700 + Math.floor(Math.random() * 200);
const proc = spawn(
  chrome,
  [
    "--headless=new",
    `--remote-debugging-port=${PORT}`,
    `--user-data-dir=${mkdtempSync(join(tmpdir(), "cdp-"))}`,
    "--no-first-run",
    "--disable-gpu",
    "--window-size=1500,1100",
    "about:blank",
  ],
  { stdio: "ignore" },
);

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

for (let i = 0; i < 60; i++) {
  try {
    if ((await fetch(`http://127.0.0.1:${PORT}/json/version`)).ok) break;
  } catch {}
  await sleep(250);
}

const page = (await (await fetch(`http://127.0.0.1:${PORT}/json/list`)).json()).find(
  (t) => t.type === "page",
);
const ws = new WebSocket(page.webSocketDebuggerUrl);

let id = 1;
const pending = new Map();
const logs = [];

ws.addEventListener("message", (ev) => {
  const m = JSON.parse(ev.data);
  if (m.id && pending.has(m.id)) {
    const p = pending.get(m.id);
    pending.delete(m.id);
    if (m.error) p.reject(new Error(JSON.stringify(m.error)));
    else p.resolve(m.result);
    return;
  }
  if (m.method === "Runtime.consoleAPICalled") {
    const text = (m.params.args ?? [])
      .map((a) => (a.type === "string" ? a.value : (a.description ?? "")))
      .join(" ");
    if (text.includes("[agent-session]")) logs.push(text);
  }
});

const send = (method, params = {}) => {
  const n = id++;
  ws.send(JSON.stringify({ id: n, method, params }));
  return new Promise((res, rej) => {
    pending.set(n, { resolve: res, reject: rej });
    setTimeout(() => pending.has(n) && (pending.delete(n), rej(new Error(method))), 30000);
  });
};

await new Promise((r) => ws.addEventListener("open", r, { once: true }));
await send("Runtime.enable");
await send("Page.enable");
// Headless does not reliably honour --window-size for captureScreenshot.
// Setting device metrics explicitly is what makes the capture non-blank.
await send("Emulation.setDeviceMetricsOverride", {
  width: 1500, height: 1100, deviceScaleFactor: 1, mobile: false,
});

const evaluate = async (expression) =>
  (await send("Runtime.evaluate", { expression, returnByValue: true, awaitPromise: true }))
    .result?.value;

const snapshot = () =>
  evaluate(`(() => {
    const t = (s) => document.querySelector(s)?.textContent?.trim()?.slice(0,70) ?? null;
    return {
      // CSS Modules hash class names, so query by structure/substring rather
      // than by literal class. Next keeps the source name inside the hash.
      card: t('main h2, section h2'),
      empty: t('[class*="empty"]'),
      fallback: t('[role="alert"] h2'),
      sections: document.querySelectorAll('[class*="section"] > button[aria-expanded]').length,
      fieldRows: document.querySelectorAll('[class*="row"]').length,
      options: document.querySelectorAll('[role="radio"], [class*="option"] button[aria-checked]').length,
      transcript: document.querySelectorAll('article').length,
      enabled: [...document.querySelectorAll('button')].filter(b=>!b.disabled).length,
      buttons: [...document.querySelectorAll('button')].map(b=>(b.textContent||'').trim().slice(0,28)),
    };
  })()`);

const clickText = (needle) =>
  evaluate(`(() => {
    const b = [...document.querySelectorAll('button')]
      .find(x => (x.textContent||'').includes(${JSON.stringify(needle)}) && !x.disabled);
    if (!b) return false;
    b.click(); return true;
  })()`);

const step = async (label, ms = 4000) => {
  await sleep(ms);
  const s = await snapshot();
  console.log(`\n── ${label}`);
  console.log("   " + JSON.stringify(s));
  if (logs.length) console.log("   " + logs[logs.length - 1]);
  return s;
};

const url = `${BASE}/cr/flow-${Date.now()}`;
console.log(`▶ ${url}`);
await send("Page.navigate", { url });
await step("after load", 6000);

console.log("\n▶ click 'Single Change Request'");
console.log("   clicked:", await clickText("Single Change Request"));
await step("after mode choice");

console.log("\n▶ fill the intake form");
await evaluate(`(() => {
  const set = (el, v) => {
    const proto = el instanceof HTMLTextAreaElement
      ? HTMLTextAreaElement.prototype : el instanceof HTMLSelectElement
      ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, v);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  };
  const sel = document.querySelector('select');
  if (sel && sel.options.length > 1) set(sel, sel.options[1].value);
  const inputs = [...document.querySelectorAll('input:not([disabled])')];
  if (inputs[0]) set(inputs[0], 'PJS 0021237113');
  const areas = [...document.querySelectorAll('textarea')];
  if (areas[0]) set(areas[0], 'Treasury cutoff blocks month-end close.');
  if (areas[1]) set(areas[1], 'Update the posting-rule configuration to use the local calendar.');
  return true;
})()`);
await step("after filling", 1500);

console.log("\n▶ submit");
console.log("   clicked:", await clickText("Start change request"));
await step("after submit — DOES A CARD ARRIVE?", 9000);

console.log("\n▶ answer the cycle picker");
console.log("   clicked:", await clickText("Yes, keep"));
await step("after cycle answer — DRAFT REVIEW?", 9000);

const shot = await send("Page.captureScreenshot", { format: "png", captureBeyondViewport: false });
writeFileSync("browser-flow.png", Buffer.from(shot.data, "base64"));
console.log("\n📸 browser-flow.png");

console.log("\n── all [agent-session] lines ──");
for (const l of logs.slice(-8)) console.log("  " + l);

ws.close();
proc.kill();
process.exit(0);
