#!/usr/bin/env node
/**
 * scripts/check-contract.mjs
 *
 * Fails the build when this app's registry and the backend's published contract
 * disagree.
 *
 * The backend publishes the whole thing machine-readably at
 * `GET /api/ui-contract` — component names, a JSON Schema per component, and a
 * valid example payload (agui_server.py:83-85 → ui_contract.contract_document()).
 * That endpoint is the reason the Controlled generative-UI model is maintainable
 * rather than a standing coordination tax: drift is detectable instead of
 * discovered.
 *
 * The runtime half of this check lives in the dev console. **This is the half
 * that should gate CI** — a console warning nobody reads is not a control.
 *
 * Usage:
 *   node scripts/check-contract.mjs                 # uses AGUI_API_BASE or :8084
 *   node scripts/check-contract.mjs --allow-offline # skip if unreachable
 *
 * Exit codes: 0 ok / 1 drift or unreachable / 2 bad response.
 */

import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";

const HERE = dirname(fileURLToPath(import.meta.url));
const REGISTRY_PATH = resolve(HERE, "../src/app/_client/component-registry.ts");
const TYPES_PATH = resolve(HERE, "../src/agent/contract/types.ts");

const API_BASE = process.env.AGUI_API_BASE ?? "http://localhost:8084";
const ALLOW_OFFLINE = process.argv.includes("--allow-offline");

/**
 * Read the registered names out of the source rather than importing it.
 *
 * Importing would mean compiling TSX and pulling React in, for a check that only
 * needs a list of strings. A regex over the file is uglier and an order of
 * magnitude simpler to keep working.
 */
function registeredNames() {
  const source = readFileSync(REGISTRY_PATH, "utf8");
  const body = source.split("export const COMPONENT_REGISTRY")[1] ?? "";
  return [...body.matchAll(/^\s{2}([A-Za-z][A-Za-z0-9]*):\s*\{/gm)].map((m) => m[1]);
}

function declaredNames() {
  const source = readFileSync(TYPES_PATH, "utf8");
  const block = source.split("export const COMPONENT_NAMES = [")[1]?.split("] as const")[0] ?? "";
  return [...block.matchAll(/"([^"]+)"/g)].map((m) => m[1]);
}

function fail(message) {
  console.error(`\n  contract check FAILED\n  ${message}\n`);
  process.exit(1);
}

const registered = registeredNames();
const declared = declaredNames();

// Local consistency first: this needs no backend and catches the most common
// mistake — adding a type without an entry, or vice versa.
const undeclared = registered.filter((n) => !declared.includes(n));
const unregistered = declared.filter((n) => !registered.includes(n));
if (undeclared.length > 0 || unregistered.length > 0) {
  fail(
    [
      undeclared.length > 0 ? `registered but not in COMPONENT_NAMES: ${undeclared.join(", ")}` : "",
      unregistered.length > 0 ? `declared but not registered: ${unregistered.join(", ")}` : "",
    ]
      .filter(Boolean)
      .join("\n  "),
  );
}

let document;
try {
  const response = await fetch(`${API_BASE}/api/ui-contract`, {
    signal: AbortSignal.timeout(10_000),
  });
  if (!response.ok) {
    console.error(`  contract endpoint returned ${response.status}`);
    process.exit(2);
  }
  document = await response.json();
} catch (error) {
  const message = `could not reach ${API_BASE}/api/ui-contract (${error.message})`;
  if (ALLOW_OFFLINE) {
    console.warn(`  contract check SKIPPED — ${message}`);
    console.warn("  local consistency passed. Run again against a live backend before release.");
    process.exit(0);
  }
  fail(message);
}

const backendNames = Object.keys(document.components ?? {});

// Components the agent can emit but we cannot render → fallback cards in
// production. This is the failure that actually reaches users.
const missingHere = backendNames.filter((n) => !registered.includes(n));
// Components we render but the agent never emits → dead code, and usually a sign
// something was renamed on one side only.
const missingThere = registered.filter((n) => !backendNames.includes(n));

if (missingHere.length > 0 || missingThere.length > 0) {
  fail(
    [
      missingHere.length > 0
        ? `the agent can emit components this app cannot render: ${missingHere.join(", ")}`
        : "",
      missingThere.length > 0
        ? `registered components the agent never emits: ${missingThere.join(", ")}`
        : "",
    ]
      .filter(Boolean)
      .join("\n  "),
  );
}

console.log(
  `  contract check OK — registry matches contract v${document.contract_version} ` +
    `(${backendNames.length} components).`,
);
