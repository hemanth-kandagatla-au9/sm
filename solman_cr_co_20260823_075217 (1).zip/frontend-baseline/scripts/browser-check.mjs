#!/usr/bin/env node
/**
 * scripts/browser-check.mjs
 *
 * Drive the app in a real headless Chrome and report what the CLIENT sees.
 *
 * Zero dependencies: Chrome is launched with `--remote-debugging-port` and driven
 * over the DevTools Protocol using Node 22's built-in `WebSocket`. No Playwright,
 * no Puppeteer, nothing to install — which matters on a locked-down machine.
 *
 * It exists because the server side of this app can be verified with `curl`, and
 * has been, repeatedly — while every remaining bug lived in the gap between "the
 * BFF emitted it" and "a React hook received it". Console output is the only
 * place that gap is visible.
 *
 *   node scripts/browser-check.mjs [url]
 *
 * Prints: console lines (especially `[agent-session]`), page errors, failed
 * requests, the visible card, and whether its controls are enabled.
 */

import { spawn } from "node:child_process";
import { mkdtempSync, existsSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";

const URL_ARG = process.argv[2] ?? "http://localhost:3000";

const CHROME_CANDIDATES = [
  "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
  "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe",
  "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe",
  "C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe",
  "/usr/bin/google-chrome",
  "/usr/bin/chromium",
];

const chrome = CHROME_CANDIDATES.find((p) => existsSync(p));
if (!chrome) {
  console.error("No Chrome/Edge found. Checked:\n  " + CHROME_CANDIDATES.join("\n  "));
  process.exit(2);
}

const PORT = 9222 + Math.floor(Math.random() * 500);
const profile = mkdtempSync(join(tmpdir(), "cdp-"));

const proc = spawn(
  chrome,
  [
    "--headless=new",
    `--remote-debugging-port=${PORT}`,
    `--user-data-dir=${profile}`,
    "--no-first-run",
    "--no-default-browser-check",
    "--disable-gpu",
    "--window-size=1440,1000",
    "about:blank",
  ],
  { stdio: "ignore", detached: false },
);

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** Poll the debugging endpoint rather than sleeping a fixed amount. */
async function waitForDevTools() {
  for (let i = 0; i < 60; i++) {
    try {
      const res = await fetch(`http://127.0.0.1:${PORT}/json/version`);
      if (res.ok) return;
    } catch {
      /* not up yet */
    }
    await sleep(250);
  }
  throw new Error("Chrome DevTools endpoint never came up");
}

let nextId = 1;
const pending = new Map();
const consoleLines = [];
const pageErrors = [];
const failedRequests = [];

function send(ws, method, params = {}, sessionId) {
  const id = nextId++;
  const msg = { id, method, params };
  if (sessionId) msg.sessionId = sessionId;
  ws.send(JSON.stringify(msg));
  return new Promise((resolve, reject) => {
    pending.set(id, { resolve, reject });
    setTimeout(() => {
      if (pending.has(id)) {
        pending.delete(id);
        reject(new Error(`CDP timeout: ${method}`));
      }
    }, 30_000);
  });
}

/** CDP RemoteObject -> readable string, without evaluating anything. */
function renderArg(a) {
  if (a === undefined || a === null) return "";
  if (a.type === "string") return a.value;
  if ("value" in a) return JSON.stringify(a.value);
  if (a.preview?.properties) {
    return (
      "{" +
      a.preview.properties.map((p) => `${p.name}: ${p.value}`).join(", ") +
      (a.preview.overflow ? ", …" : "") +
      "}"
    );
  }
  return a.description ?? a.type ?? "?";
}

await waitForDevTools();

const targetsRes = await fetch(`http://127.0.0.1:${PORT}/json/list`);
const targets = await targetsRes.json();
const page = targets.find((t) => t.type === "page");
if (!page) throw new Error("No page target");

const ws = new WebSocket(page.webSocketDebuggerUrl);

ws.addEventListener("message", (ev) => {
  const msg = JSON.parse(ev.data);

  if (msg.id && pending.has(msg.id)) {
    const { resolve, reject } = pending.get(msg.id);
    pending.delete(msg.id);
    if (msg.error) reject(new Error(JSON.stringify(msg.error)));
    else resolve(msg.result);
    return;
  }

  switch (msg.method) {
    case "Runtime.consoleAPICalled":
      consoleLines.push({
        type: msg.params.type,
        text: (msg.params.args ?? []).map(renderArg).join(" "),
      });
      break;
    case "Runtime.exceptionThrown":
      pageErrors.push(
        msg.params.exceptionDetails?.exception?.description ??
          msg.params.exceptionDetails?.text ??
          "unknown",
      );
      break;
    case "Network.loadingFailed":
      failedRequests.push(`${msg.params.type} ${msg.params.errorText}`);
      break;
    case "Network.responseReceived": {
      const { status, url } = msg.params.response;
      if (status >= 400) failedRequests.push(`HTTP ${status} ${url}`);
      break;
    }
  }
});

await new Promise((resolve, reject) => {
  ws.addEventListener("open", resolve, { once: true });
  ws.addEventListener("error", reject, { once: true });
});

await send(ws, "Runtime.enable");
await send(ws, "Network.enable");
await send(ws, "Page.enable");

const evaluate = async (expression) => {
  const r = await send(ws, "Runtime.evaluate", {
    expression,
    returnByValue: true,
    awaitPromise: true,
  });
  return r.result?.value;
};

console.log(`\n▶ navigating to ${URL_ARG}\n`);
await send(ws, "Page.navigate", { url: URL_ARG });
await sleep(6000);

/** What is actually on screen, and can the user act on it? */
const probe = `(() => {
  const t = (s) => document.querySelector(s)?.textContent?.trim() ?? null;
  const buttons = [...document.querySelectorAll('button')].map((b) => ({
    label: (b.textContent || '').trim().slice(0, 40),
    disabled: b.disabled,
  }));
  return {
    url: location.pathname,
    cardTitle: t('.card__title'),
    emptyState: t('.empty-state'),
    fallback: t('.card--fallback .card__title'),
    runIndicator: t('.run-indicator'),
    sections: document.querySelectorAll('.draft-section').length,
    options: document.querySelectorAll('.option').length,
    transcript: document.querySelectorAll('.message').length,
    buttons,
    enabledButtons: buttons.filter((b) => !b.disabled).length,
    // Vendor chrome injected outside our React tree — portals, web components,
    // marketing toasts. Worth surfacing: it is invisible in our source.
    bodyChildren: [...document.body.children].map(
      (e) => e.tagName.toLowerCase() + (e.id ? "#" + e.id : "") +
             (typeof e.className === "string" && e.className ? "." + e.className.split(" ")[0] : ""),
    ),
    customElements: [...new Set([...document.querySelectorAll("*")]
      .map((e) => e.tagName.toLowerCase()).filter((t) => t.includes("-")))],
    // Is anything actually painted? A blank capture with a populated DOM means
    // capture plumbing; a zero-height body means the styles failed.
    paint: (() => {
      const shell = document.querySelector('[class*="shell"]');
      const r = shell?.getBoundingClientRect();
      return {
        bodyH: document.body.scrollHeight,
        shellBox: r ? Math.round(r.width) + "x" + Math.round(r.height) : null,
        bodyBg: getComputedStyle(document.body).backgroundColor,
        stylesheets: document.styleSheets.length,
      };
    })(),
  };
})()`;

const state = await evaluate(probe);

console.log("── PAGE ─────────────────────────────────────────────");
console.log(JSON.stringify(state, null, 2));

console.log("\n── CONSOLE ──────────────────────────────────────────");
const agentLines = consoleLines.filter((l) => l.text.includes("[agent-session]"));
if (agentLines.length) {
  for (const l of agentLines.slice(-4)) console.log("  " + l.text);
} else {
  console.log("  (no [agent-session] lines — the session hook never rendered)");
}

const other = consoleLines.filter(
  (l) => !l.text.includes("[agent-session]") && (l.type === "error" || l.type === "warning"),
);
if (other.length) {
  console.log("\n  errors/warnings:");
  for (const l of other.slice(0, 8)) console.log(`   [${l.type}] ${l.text.slice(0, 220)}`);
}

if (pageErrors.length) {
  console.log("\n── UNCAUGHT ─────────────────────────────────────────");
  for (const e of pageErrors.slice(0, 5)) console.log("  " + e.split("\n")[0]);
}

if (failedRequests.length) {
  console.log("\n── FAILED REQUESTS ──────────────────────────────────");
  for (const f of [...new Set(failedRequests)].slice(0, 8)) console.log("  " + f);
}

const shot = await send(ws, "Page.captureScreenshot", { format: "png" });
writeFileSync("browser-check.png", Buffer.from(shot.data, "base64"));
console.log("\n📸 browser-check.png written");

ws.close();
proc.kill();
process.exit(0);
