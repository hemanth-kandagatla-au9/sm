import nextCoreWebVitals from "eslint-config-next/core-web-vitals";
import nextTypescript from "eslint-config-next/typescript";
import boundaries from "eslint-plugin-boundaries";

/**
 * eslint.config.mjs
 *
 * This file is where ADR 0001 §3 stops being prose.
 *
 * A dependency rule that is not machine-checked is a comment: it holds until the
 * first person in a hurry, and after that nobody knows which parts still hold.
 * Everything below is a rule the build enforces, and each one guards a specific
 * hazard identified in Phase 0 rather than a style preference.
 *
 * `eslint-config-next@16` exports flat-config arrays (verified against the
 * published package), so these spread directly.
 */
const config = [
  ...nextCoreWebVitals,
  ...nextTypescript,

  {
    ignores: ["node_modules/**", ".next/**", "next-env.d.ts"],
  },

  // ───────────────────────────────────────────────────────────────────────────
  // ADR §3 — the dependency rule. Dependencies point inward, never sideways.
  //
  //   app/  →  features/  →  agent/  →  shared/
  //                       ↘          ↗
  //                        server/ (app/api only)
  // ───────────────────────────────────────────────────────────────────────────
  {
    files: ["src/**/*.{ts,tsx}"],
    plugins: { boundaries },
    settings: {
      /**
       * boundaries resolves imports through `eslint-module-utils`, which reads
       * `import/resolver`. It has to be declared here explicitly: without it the
       * plugin cannot follow the `@/*` alias and every rule fails with
       * "invalid interface loaded as resolver" rather than a useful message.
       */
      "import/resolver": {
        typescript: { alwaysTryTypes: true, project: "./tsconfig.json" },
        node: { extensions: [".js", ".jsx", ".mjs", ".ts", ".tsx"] },
      },
      "boundaries/include": ["src/**/*"],
      // Ordered most-specific first: boundaries matches on the first hit, so the
      // vendor-adapter folder must be declared before the generic agent/.
      "boundaries/elements": [
        {
          type: "agent-vendor",
          pattern: "src/agent/transport/copilotkit/**",
          partialMatch: false,
        },
        { type: "server-gateway", pattern: "src/server/agent-gateway/**", partialMatch: false },
        { type: "server", pattern: "src/server/**", partialMatch: false },
        { type: "app", pattern: "src/app/**", partialMatch: false },
        // Each feature folder is its own element. Because "feature" is absent
        // from the allow-list below, a feature cannot import a *different*
        // feature — the single most valuable rule here, since cross-feature
        // imports are how a feature-oriented codebase quietly decays into a ball
        // of mud. Imports *within* one feature are same-element and unaffected.
        { type: "feature", pattern: "src/features/*" },
        { type: "agent", pattern: "src/agent/**", partialMatch: false },
        { type: "shared", pattern: "src/shared/**", partialMatch: false },
      ],
    },
    rules: {
      "boundaries/no-unknown-dependencies": "error",
      "boundaries/no-unknown-files": "error",
      "boundaries/dependencies": [
        "error",
        {
          default: "disallow",
          policies: [
            // shared/ is the floor. It knows nothing about agents or features,
            // which is what makes it safe to reuse and cheap to test.
            {
              from: { element: { type: "shared" } },
              allow: { to: { element: { type: "shared" } } },
            },

            // agent/ is the isolation layer. It may use shared primitives and the
            // app's env contract; it must never reach up into features.
            {
              from: { element: { types: { anyOf: ["agent", "agent-vendor"] } } },
              allow: {
                to: {
                  element: { types: { anyOf: ["shared", "agent", "agent-vendor"] } },
                },
              },
            },

            // server/ is server-only. Same inward direction.
            {
              from: { element: { types: { anyOf: ["server", "server-gateway"] } } },
              allow: {
                to: {
                  element: {
                    types: {
                      anyOf: ["shared", "agent", "server", "server-gateway"],
                    },
                  },
                },
              },
            },

            // A feature may use agent/ and shared/. Note "feature" is NOT here.
            {
              from: { element: { type: "feature" } },
              allow: {
                to: { element: { types: { anyOf: ["shared", "agent"] } } },
              },
            },

            // app/ composes. It may reach anything, and it holds no logic.
            {
              from: { element: { type: "app" } },
              allow: {
                to: {
                  element: {
                    types: {
                      anyOf: [
                        "shared",
                        "agent",
                        "agent-vendor",
                        "feature",
                        "server",
                        "server-gateway",
                        "app",
                      ],
                    },
                  },
                },
              },
            },

          ],
        },
      ],
    },
  },

  // ───────────────────────────────────────────────────────────────────────────
  // ADR §3 rule 6 — vendor lock containment.
  //
  // @copilotkit/* and @ag-ui/* are allowed in exactly two directories. This is
  // what makes the eventual CopilotKit v2 migration (OPEN_QUESTIONS Q10) a
  // bounded PR instead of an archaeology project: if a v2 migration diff touches
  // features/, the isolation has already failed.
  // ───────────────────────────────────────────────────────────────────────────
  {
    files: ["src/**/*.{ts,tsx}"],
    rules: {
      "no-restricted-imports": [
        "error",
        {
          patterns: [
            {
              group: ["@copilotkit/*", "@ag-ui/*"],
              message:
                "Vendor SDKs are confined to src/agent/transport/copilotkit/ and src/server/agent-gateway/. " +
                "Consume them through the AgentTransport interface in src/agent/transport/types.ts (ADR 0001 §4).",
            },
          ],
        },
      ],
    },
  },
  {
    files: ["src/agent/transport/copilotkit/**", "src/server/agent-gateway/**"],
    rules: { "no-restricted-imports": "off" },
  },

  // Underscore-prefixed parameters are intentionally unused. Several exist
  // because a seam is stubbed but its real signature is already in place — e.g.
  // `resolveSession(_request)`, which will read the request the day auth lands
  // (decision Q2). Renaming them when they start being used is the point.
  {
    files: ["src/**/*.{ts,tsx}"],
    rules: {
      "@typescript-eslint/no-unused-vars": [
        "warn",
        {
          argsIgnorePattern: "^_",
          varsIgnorePattern: "^_",
          caughtErrorsIgnorePattern: "^_",
        },
      ],
    },
  },

  // ───────────────────────────────────────────────────────────────────────────
  // ADR §3 rule 7 — the load-bearing one.
  //
  // Because the BFF currently passes state through untouched (decision Q6),
  // `draft_ui.draft_html` and `recommendations_html` DO cross the wire. They are
  // LLM-generated HTML (state/state.py:50-54). This rule is the only thing
  // standing between that payload and the DOM.
  //
  // Do not relax it to unblock a feature. There is no feature that needs it:
  // every one of those values is already rendered as a typed card.
  // ───────────────────────────────────────────────────────────────────────────
  {
    files: ["src/**/*.{ts,tsx}"],
    rules: {
      "no-restricted-syntax": [
        "error",
        {
          selector: "JSXAttribute[name.name='dangerouslySetInnerHTML']",
          message:
            "dangerouslySetInnerHTML is banned. Agent-produced HTML is untrusted (ADR 0001 §3 rule 7). " +
            "Render structured props, or use the sanitised markdown component in src/shared/ui.",
        },
        {
          selector:
            "MemberExpression[property.name=/^(draft_html|recommendations_html)$/]",
          message:
            "draft_html / recommendations_html are LLM-generated HTML and must never be read or rendered " +
            "(BACKEND_CONTRACT §3.1, GENERATIVE_UI_MAP §3.5). The same content is available as typed card props.",
        },
        {
          selector: "Literal[value=/^(draft_html|recommendations_html)$/]",
          message:
            "draft_html / recommendations_html are LLM-generated HTML and must never be read or rendered " +
            "(BACKEND_CONTRACT §3.1, GENERATIVE_UI_MAP §3.5).",
        },
      ],
    },
  },
];

export default config;
