import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  /**
   * `@copilotkit/runtime` is a Node-targeted package: it pulls in GraphQL, pino,
   * and `@langchain/core`. Bundling it into the server output is at best wasted
   * work and at worst a build failure, because those packages do things
   * (dynamic requires, native-ish deps) that bundlers handle badly.
   *
   * `serverExternalPackages` tells Next to `require()` it at runtime from
   * node_modules instead of bundling it. This is the documented escape hatch for
   * exactly this class of dependency, and it is why the BFF route must run on the
   * Node runtime rather than Edge (see src/app/api/agent/route.ts).
   */
  serverExternalPackages: ["@copilotkit/runtime"],

  // CopilotKit's UI is loaded from a Network URL (EC2 private IP) rather than
  // localhost, which Next 16 blocks by default for dev-resource requests (HMR,
  // source maps, fonts). Allow the EC2 host explicitly.
  allowedDevOrigins: ["10.81.217.211"],

  typescript: {
    // Never ship a build that does not typecheck. The default is already false;
    // it is stated explicitly so that "just unblock the build" is a visible
    // decision in a diff rather than a quiet one.
    ignoreBuildErrors: false,
  },
  // NOTE: Next 16 removed the top-level `eslint` config key. Linting is a
  // separate `npm run lint` step and is gated in CI, not by the build.
};

export default nextConfig;
