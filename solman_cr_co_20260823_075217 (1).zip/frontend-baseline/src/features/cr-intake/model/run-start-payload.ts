/**
 * features/cr-intake/model/run-start-payload.ts
 *
 * ══════════════════════════════════════════════════════════════════════════════
 * THIS FORMAT IS A CONTRACT. It has a golden test. Do not "tidy" it.
 * ══════════════════════════════════════════════════════════════════════════════
 *
 * Submitting the intake form is what starts the graph. There is no structured
 * intake endpoint: six validated form fields are serialised into a labelled text
 * block, and `node_1`'s **LLM extraction prompt** parses them back out
 * (nodes_intake.py:53+). Structured → prose → LLM → structured.
 *
 * We keep the prose contract (decision Q5) because the alternative — seeding
 * `AgentState` directly — uses the same unfiltered state channel the BFF is
 * deliberately closing by forcing `state: {}`. Sending structured data through a
 * hole we just plugged would be incoherent.
 *
 * What we do instead:
 *   1. The exact format lives here, in one place, with a golden test.
 *   2. The BFF logs a warning when the first state snapshot does not reflect the
 *      fields we sent, so silent partial extraction becomes a correlated log line
 *      rather than a user mystery.
 *
 * The labels below are read verbatim by the extraction prompt. Changing a label,
 * the order, or the separator changes what the agent understands — a whitespace
 * edit here can silently drop a user's platform and draft a CR against the wrong
 * system. That is why this is a module and not an inline template literal.
 */

export interface IntakeValues {
  platform: string;
  targetSystem: string;
  jiraId: string;
  reasonForChange: string;
  descriptionOfChange: string;
}

/** Same shape node_2 recognises server-side, e.g. "AAZM-11112". */
export const JIRA_KEY_RE = /^[A-Za-z][A-Za-z0-9]+-\d+$/;

/**
 * The agent needs a platform, a target system, and then EITHER a Jira key OR
 * both narrative fields. Mirrors the backend's own required-field logic so the
 * user is not sent round the node_3 → node_4 loop for something we could have
 * caught before starting a run.
 */
export function canSubmitIntake(values: IntakeValues): boolean {
  const hasBasics = values.platform.trim() !== "" && values.targetSystem.trim() !== "";
  const hasJira = values.jiraId.trim() !== "";
  const hasNarrative =
    values.reasonForChange.trim() !== "" && values.descriptionOfChange.trim() !== "";
  return hasBasics && (hasJira || hasNarrative);
}

export function buildRunStartMessage(values: IntakeValues): string {
  const lines: string[] = [
    "Create a CR.",
    `Platform: ${values.platform.trim()}`,
    `Target System: ${values.targetSystem.trim()}`,
  ];

  // Optional lines are omitted entirely rather than sent empty: a bare
  // "Jira: " line invites the extractor to hallucinate a value for it.
  if (values.jiraId.trim() !== "") lines.push(`Jira: ${values.jiraId.trim()}`);
  if (values.reasonForChange.trim() !== "") {
    lines.push(`Reason for change: ${values.reasonForChange.trim()}`);
  }
  if (values.descriptionOfChange.trim() !== "") {
    lines.push(`Description of change: ${values.descriptionOfChange.trim()}`);
  }

  return lines.join("\n");
}

export const EMPTY_INTAKE: IntakeValues = {
  platform: "",
  targetSystem: "",
  jiraId: "",
  reasonForChange: "",
  descriptionOfChange: "",
};
