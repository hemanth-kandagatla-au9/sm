"use client";

import type { CrModeChoiceProps } from "@/agent/contract";
import type { AgentHandlers } from "@/agent/registry";
import { Card } from "@/shared/ui";
import styles from "./cr-mode-choice.module.css";

/**
 * `crModeChoice` — the opening screen: single vs bulk.
 *
 * ── The bulk tile stays clickable, and that is deliberate ───────────────────
 * `enabled: false` styles the tile; it does NOT disable it. The tile posts
 * `{"mode":"bulk"}` and the **backend** answers with the featureComingSoon card
 * (agui_server.py:112-119).
 *
 * Blocking it client-side would feel more polished and would be wrong: the day
 * bulk ships, `BULK_CR_ENABLED` flips at agui_server.py:47 and this frontend
 * needs no change at all (AGUI_INTEGRATION.md:92-99). Every decision about what
 * the user may do belongs on the server.
 */
export function CrModeChoice({
  props,
  handlers,
}: {
  props: CrModeChoiceProps;
  handlers: AgentHandlers;
}) {
  return (
    <Card title={props.title} subtitle={props.subtitle} meta={props.meta} inert={handlers.answered}>
      <ul className={styles.grid}>
        {props.modes.map((mode) => (
          <li key={mode.value}>
            <button
              type="button"
              className={mode.enabled === false ? `${styles.tile} ${styles.soon}` : styles.tile}
              disabled={handlers.answered}
              onClick={() => handlers.respond(mode.value)}
            >
              <span className={styles.label}>{mode.label}</span>
              {mode.description ? (
                <span className={styles.description}>{mode.description}</span>
              ) : null}
              {mode.enabled === false ? <span className={styles.badge}>Coming soon</span> : null}
            </button>
          </li>
        ))}
      </ul>
    </Card>
  );
}
