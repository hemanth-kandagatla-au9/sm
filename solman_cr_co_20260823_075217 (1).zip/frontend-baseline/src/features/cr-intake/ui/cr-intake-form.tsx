"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { CrIntakeFormProps } from "@/agent/contract";
import type { AgentHandlers } from "@/agent/registry";
import { Button, Card, Field, Select, TextArea, TextInput } from "@/shared/ui";
import {
  buildRunStartMessage,
  canSubmitIntake,
  EMPTY_INTAKE,
  JIRA_KEY_RE,
  type IntakeValues,
} from "../model/run-start-payload";
import styles from "./cr-intake-form.module.css";

/**
 * `crIntakeForm` — Screen 1. Submitting it starts the graph.
 *
 * The most stateful card in the app, and the only one where local state is the
 * point: every keystroke is the user's, not the agent's, right up until submit.
 */

const DIRECTORY = "/api/agent-directory";
const JIRA_DEBOUNCE_MS = 600;

interface JiraLookupResponse {
  found: boolean;
  reason_for_change?: string;
  description_of_change?: string;
  /** false ⇒ the text is raw Jira, not LLM-derived. The UI must say which. */
  generated?: boolean;
  note?: string | null;
  error?: string;
}

export function CrIntakeForm({
  props,
  handlers,
}: {
  props: CrIntakeFormProps;
  handlers: AgentHandlers;
}) {
  const [values, setValues] = useState<IntakeValues>(() => ({
    ...EMPTY_INTAKE,
    platform: props.values?.platform ?? "",
    targetSystem: props.values?.target_system ?? "",
    jiraId: props.values?.jira_id ?? "",
    reasonForChange: props.values?.reason_for_change ?? "",
    descriptionOfChange: props.values?.description_of_change ?? "",
  }));

  const [fetchedTargets, setFetchedTargets] = useState<string[]>(props.target_systems ?? []);
  const [jiraLookup, setJiraLookup] = useState<{
    status: "loading" | "found" | "missing";
    note: string | null;
  } | null>(null);
  /**
   * State, not a ref. It is read during render to label provenance, and a ref
   * read in render is the bug `react-hooks/refs` exists to catch.
   */
  const [autofilled, setAutofilled] = useState<{ reason: string; description: string } | null>(
    null,
  );

  const set = useCallback(<K extends keyof IntakeValues>(key: K, value: IntakeValues[K]) => {
    setValues((current) => ({ ...current, [key]: value }));
  }, []);

  // ── Target systems, per platform ──────────────────────────────────────────
  // Derived, not stored: with no platform the list is empty by definition. That
  // removes a synchronous setState from the effect below, which React 19 flags
  // because it forces a second render for something already computable.
  const targetSystems = values.platform.trim() === "" ? [] : fetchedTargets;

  useEffect(() => {
    const platform = values.platform.trim();
    if (platform === "") return;
    let cancelled = false;
    fetch(`${DIRECTORY}/api/target-systems?platform=${encodeURIComponent(platform)}`)
      .then((response) => (response.ok ? response.json() : Promise.reject(new Error("lookup"))))
      .then((data: { target_systems?: string[] }) => {
        if (!cancelled) setFetchedTargets(data.target_systems ?? []);
      })
      .catch(() => {
        // A failed lookup must never block the user: the field stays free text.
        // The agent validates the target system server-side regardless.
        if (!cancelled) setFetchedTargets([]);
      });
    return () => {
      cancelled = true;
    };
  }, [values.platform]);

  // ── Jira pre-fill ─────────────────────────────────────────────────────────
  /**
   * Behaviour is specified by the backend team (AGUI_INTEGRATION.md:101-108) and
   * every clause of it matters:
   *
   *   1. Typing fires nothing.
   *   2. 600 ms after the last keystroke, or immediately on blur, the value is
   *      tested against JIRA_KEY_RE.
   *   3. Only a matching key calls the API. A half-typed key produces no request
   *      and no error — it is not a mistake yet.
   *   4. Reason and Description are filled ONLY where the user has not typed
   *      their own text. Hand edits are never overwritten by a later lookup.
   *
   * Requests are sequence-numbered so a slow response for an old key cannot
   * overwrite a newer one. The server re-validates the same regex rather than
   * trusting us (agui_server.py:197-201).
   */
  const sequenceRef = useRef(0);

  const runJiraLookup = useCallback(
    (rawKey: string) => {
      const key = rawKey.trim();
      if (!JIRA_KEY_RE.test(key)) return;

      const sequence = ++sequenceRef.current;
      setJiraLookup({ status: "loading", note: null });

      fetch(`${DIRECTORY}/api/jira-lookup?jira_id=${encodeURIComponent(key)}`)
        .then((response) => response.json() as Promise<JiraLookupResponse>)
        .then((data) => {
          if (sequence !== sequenceRef.current) return; // a newer key won
          if (!data.found) {
            setJiraLookup({
              status: "missing",
              note: data.error ?? "No summary or description found for this ticket.",
            });
            return;
          }

          setJiraLookup({
            status: "found",
            // `generated:false` means the text is RAW Jira, not LLM-derived. The
            // backend signals that deliberately so the UI can label provenance
            // rather than implying a summary it did not produce.
            note:
              data.generated === false
                ? "Filled from the raw Jira text — the summariser was unavailable."
                : (data.note ?? null),
          });

          setValues((current) => {
            const reason =
              current.reasonForChange.trim() === ""
                ? (data.reason_for_change ?? "")
                : current.reasonForChange;
            const description =
              current.descriptionOfChange.trim() === ""
                ? (data.description_of_change ?? "")
                : current.descriptionOfChange;
            setAutofilled({ reason, description });
            return { ...current, reasonForChange: reason, descriptionOfChange: description };
          });
        })
        .catch(() => {
          if (sequence !== sequenceRef.current) return;
          setJiraLookup({
            status: "missing",
            note: "Could not reach Jira. You can still fill the fields yourself.",
          });
        });
    },
    [],
  );

  useEffect(() => {
    const key = values.jiraId.trim();
    // No setState here: "idle" is derived below from whether this is even a key
    // yet. A half-typed key is not a mistake, so it produces no request and no
    // error (AGUI_INTEGRATION.md:103-105).
    if (!JIRA_KEY_RE.test(key)) return;
    const timer = setTimeout(() => runJiraLookup(key), JIRA_DEBOUNCE_MS);
    return () => clearTimeout(timer);
  }, [values.jiraId, runJiraLookup]);

  const jiraKeyValid = JIRA_KEY_RE.test(values.jiraId.trim());
  const jiraStatus = jiraKeyValid ? (jiraLookup?.status ?? "idle") : "idle";
  const jiraNote = jiraKeyValid ? (jiraLookup?.note ?? null) : null;
  const jiraMalformed = values.jiraId.trim() !== "" && !jiraKeyValid;
  const submittable = useMemo(() => canSubmitIntake(values), [values]);
  const errors = props.errors ?? {};

  const submit = () => {
    if (!submittable || handlers.answered) return;
    handlers.respond(buildRunStartMessage(values));
  };

  /**
   * True while a field still holds exactly what Jira filled in. Once the user
   * edits it the label disappears, because the text is theirs from then on - and
   * a later lookup must never overwrite it.
   */
  const isAutofilled = (field: "reason" | "description") => {
    if (autofilled === null) return false;
    const current = field === "reason" ? values.reasonForChange : values.descriptionOfChange;
    const filled = field === "reason" ? autofilled.reason : autofilled.description;
    return current !== "" && current === filled;
  };

  return (
    <Card
      title={props.title}
      subtitle={props.subtitle}
      meta={props.meta}
      inert={handlers.answered}
      footer={
        <div className={styles.actions}>
          <Button
            variant="primary"
            disabled={!submittable || handlers.answered}
            onClick={submit}
          >
            Start change request
          </Button>
        </div>
      }
    >
      {props.hint ? <p className={styles.hint}>{props.hint}</p> : null}

      <div className={styles.grid}>
        <Field label="Platform" required error={errors["platform"] ?? null}>
          {(id, describedBy) => (
            <Select
              id={id}
              value={values.platform}
              options={props.platforms}
              disabled={handlers.answered || props.platforms.length === 0}
              describedBy={describedBy}
              onChange={(value) => set("platform", value)}
              placeholder={
                props.platforms.length === 0 ? "Platform directory unavailable" : "Select…"
              }
            />
          )}
        </Field>

        <Field label="Target system" required error={errors["target_system"] ?? null}>
          {(id, describedBy) => (
            <>
              <TextInput
                id={id}
                value={values.targetSystem}
                disabled={handlers.answered}
                describedBy={describedBy}
                list={`${id}-targets`}
                placeholder={values.platform === "" ? "Choose a platform first" : "Type or pick…"}
                onChange={(value) => set("targetSystem", value)}
              />
              <datalist id={`${id}-targets`}>
                {targetSystems.map((system) => (
                  <option key={system} value={system} />
                ))}
              </datalist>
            </>
          )}
        </Field>

        <Field
          label="Jira ID"
          error={jiraMalformed ? "Expected a key like AAZM-11112." : (errors["jira_id"] ?? null)}
          hint={jiraStatusHint(jiraStatus, jiraNote)}
        >
          {(id, describedBy) => (
            <TextInput
              id={id}
              value={values.jiraId}
              disabled={handlers.answered}
              describedBy={describedBy}
              placeholder="AAZM-11112"
              onChange={(value) => set("jiraId", value)}
              // Leaving the field means the user is done typing, so look up now
              // rather than waiting out the remaining debounce.
              onBlur={() => runJiraLookup(values.jiraId)}
            />
          )}
        </Field>

        <Field
          label="IRIS ID"
          hint={props.iris_enabled === true ? null : "IRIS lookup is not available yet."}
        >
          {(id, describedBy) => (
            <TextInput
              id={id}
              value=""
              // Rendered per the design but inert until `iris_enabled` flips
              // server-side. No frontend change needed when it does.
              disabled
              describedBy={describedBy}
              onChange={() => undefined}
            />
          )}
        </Field>
      </div>

      <Field
        label="Reason for change"
        error={errors["reason_for_change"] ?? null}
        hint={isAutofilled("reason") ? "Auto-filled from Jira — edit freely." : null}
      >
        {(id, describedBy) => (
          <TextArea
            id={id}
            value={values.reasonForChange}
            disabled={handlers.answered}
            describedBy={describedBy}
            onChange={(value) => set("reasonForChange", value)}
          />
        )}
      </Field>

      <Field
        label="Description of change"
        error={errors["description_of_change"] ?? null}
        hint={isAutofilled("description") ? "Auto-filled from Jira — edit freely." : null}
      >
        {(id, describedBy) => (
          <TextArea
            id={id}
            value={values.descriptionOfChange}
            disabled={handlers.answered}
            describedBy={describedBy}
            rows={4}
            onChange={(value) => set("descriptionOfChange", value)}
          />
        )}
      </Field>

      {!submittable ? (
        <p className={styles.note}>
          Provide a platform and target system, then either a Jira ID or both the reason and
          description.
        </p>
      ) : null}
    </Card>
  );
}

function jiraStatusHint(
  status: "idle" | "loading" | "found" | "missing",
  note: string | null,
): string | null {
  switch (status) {
    case "loading":
      return "Looking up Jira…";
    case "found":
      return note ?? "Found — reason and description filled where they were empty.";
    case "missing":
      return note;
    case "idle":
      return null;
  }
}
