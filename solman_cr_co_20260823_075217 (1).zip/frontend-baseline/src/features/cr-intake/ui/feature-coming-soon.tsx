"use client";

import type { FeatureComingSoonProps } from "@/agent/contract";
import type { AgentHandlers } from "@/agent/registry";
import { Button, Card } from "@/shared/ui";
import styles from "./cr-mode-choice.module.css";

/**
 * `featureComingSoon` — the answer to "bulk", chosen by the backend.
 *
 * The back action returns `"single"`, which resumes the pending `interrupt()`
 * in `node_0_wait` (agents/nodes/nodes_gateway.py) — so even "go back" is a
 * server decision about what renders next, not a client-side history pop.
 * That keeps the whole entry flow on one rule: the backend names the
 * component in every case.
 */
export function FeatureComingSoon({
  props,
  handlers,
}: {
  props: FeatureComingSoonProps;
  handlers: AgentHandlers;
}) {
  return (
    <Card title={props.title} meta={props.meta}>
      <p className={styles.description}>{props.message}</p>
      <div className={styles.actions}>
        <Button variant="secondary" disabled={handlers.answered} onClick={() => handlers.respond("single")}>
          {props.back_label ?? "Back"}
        </Button>
      </div>
    </Card>
  );
}
