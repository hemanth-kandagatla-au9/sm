"use client";

import { useState } from "react";
import type { CycleIdPickerProps } from "@/agent/contract";
import type { AgentHandlers } from "@/agent/registry";
import { Button, Card, Field, OptionList, TextInput } from "@/shared/ui";
import styles from "./cycle-id-picker.module.css";

/**
 * `cycleIdPicker` — Screen 3, emitted by `node_20`.
 *
 * The draft's deployment cycle disagrees with the most common cycle for this
 * project, so the agent asks.
 *
 * ── `keep_current_label` is absent on purpose sometimes ─────────────────────
 * The backend only offers "Yes, keep <cycle>" when the draft's own cycle is still
 * active; when it is in `INACTIVE_CYCLE_IDS` there is nothing valid to keep and
 * the field stays null (nodes_outcome.py:701-712).
 *
 * So we must NOT synthesise one. Rendering a keep-current button the backend
 * deliberately withheld would offer the user an option that resolves to an
 * inactive cycle — the exact outcome the omission prevents.
 *
 * The literal token for keeping the current cycle is `"yes"`
 * (nodes_outcome.py:709-712); everything else is a cycle ID.
 */
export function CycleIdPicker({
  props,
  handlers,
}: {
  props: CycleIdPickerProps;
  handlers: AgentHandlers;
}) {
  const [manual, setManual] = useState("");

  // The backend hands us only the intro sentence — its own builder strips the
  // markdown table, because the option grid below is this card's job
  // (nodes_outcome.py:722-726).
  return (
    <Card title="Deployment cycle" meta={props.meta} inert={handlers.answered}>
      <p className={styles.message}>{props.message}</p>

      {props.draft_cycle_id ? (
        <p className={styles.current}>
          Current draft cycle: <code>{props.draft_cycle_id}</code>
        </p>
      ) : null}

      {props.options.length > 0 ? (
        <OptionList
          options={props.options}
          disabled={handlers.answered}
          onSelect={(value) => handlers.respond(value)}
        />
      ) : (
        <p className={styles.empty}>
          No alternative cycles were suggested. Enter the cycle ID you want to use.
        </p>
      )}

      {props.keep_current_label ? (
        <div className={styles.actions}>
          <Button
            variant="secondary"
            disabled={handlers.answered}
            onClick={() => handlers.respond("yes")}
          >
            {props.keep_current_label}
          </Button>
        </div>
      ) : null}

      <Field label="…or type a cycle ID">
        {(id, describedBy) => (
          <div className={styles.inline}>
            <TextInput
              id={id}
              value={manual}
              disabled={handlers.answered}
              describedBy={describedBy}
              placeholder="Leading zeros optional"
              onChange={setManual}
            />
            <Button
              variant="secondary"
              disabled={handlers.answered || manual.trim() === ""}
              onClick={() => handlers.respond(manual.trim())}
            >
              Use
            </Button>
          </div>
        )}
      </Field>
    </Card>
  );
}
