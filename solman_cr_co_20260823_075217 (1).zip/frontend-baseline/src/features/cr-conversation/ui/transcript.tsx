"use client";

import { useEffect, useRef } from "react";
import type { RunProgress, TranscriptEntry } from "@/agent/transport";
import { Markdown } from "@/shared/ui";
import styles from "./transcript.module.css";

/**
 * The conversation transcript and the run indicator.
 *
 * Cards are the primary surface; the transcript is the record. Duplicate prose —
 * the intro that `node_17` and `node_20` write alongside their cards — is already
 * suppressed in the BFF, keyed on the emitting node name rather than on the text
 * itself (decision Q9). Nothing in this file matches on message content, and
 * nothing should: that was the old app's approach and it breaks on any copy edit.
 */

export function Transcript({ entries }: { entries: TranscriptEntry[] }) {
  const endRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [entries.length]);

  if (entries.length === 0) {
    return <p className={styles.empty}>The conversation will appear here.</p>;
  }

  return (
    <div className={styles.transcript} aria-live="polite" aria-relevant="additions">
      {entries.map((entry) => (
        <article key={entry.id} className={entry.role === "user" ? `${styles.message} ${styles.user}` : styles.message}>
          <span className={styles.role}>{entry.role === "user" ? "You" : "Agent"}</span>
          <Markdown className={styles.content}>{entry.content}</Markdown>
        </article>
      ))}
      <div ref={endRef} />
    </div>
  );
}

/**
 * Node names are implementation identifiers, never user-facing language.
 *
 * `STEP_STARTED.stepName` carries values like `node_20b` and `cond_edge_c`
 * (graph/builder.py:61-87). Showing those to a user would be leaking our
 * internals into a regulated workflow, so they go through this table and anything
 * unmapped falls back to something generic. A missing entry must degrade, never
 * expose.
 */
const NODE_LABELS: Record<string, string> = {
  node_1: "Reading your request",
  node_2: "Validating platform and scope",
  node_3: "Preparing a question",
  node_4: "Waiting for your reply",
  node_5: "Wrapping up",
  node_6: "Building the draft",
  node_7: "Finding similar change requests",
  node_8: "Preparing the draft for review",
  node_9: "Waiting for your review",
  node_10: "Understanding your change",
  node_10c: "Noting your feedback",
  node_11: "Looking that up",
  node_12: "Submitting to Solution Manager",
  node_13: "Applying your change",
  node_15: "Submission failed",
  node_16: "Submission complete",
  node_17: "Preparing recommendations",
  node_18: "Waiting for your selection",
  node_19: "No recommendations found",
  node_20: "Checking the deployment cycle",
  node_20b: "Waiting for your cycle choice",
  node_s: "Answering your question",
};

export function RunIndicator({ progress }: { progress: RunProgress }) {
  if (!progress.running) return null;

  const label =
    (progress.nodeName ? NODE_LABELS[progress.nodeName] : undefined) ?? "Working…";

  return (
    <p className={styles.indicator} role="status">
      <span className={styles.dot} aria-hidden="true" />
      {label}
    </p>
  );
}
