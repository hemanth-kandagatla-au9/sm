"use client";

import { useState } from "react";
import type { FieldPromptProps } from "@/agent/contract";
import type { AgentHandlers } from "@/agent/registry";
import { Button, Card, Field, OptionList, TextInput } from "@/shared/ui";
import styles from "./field-prompt.module.css";

/**
 * `fieldPrompt` — the generic ask, emitted by `node_3` before the `node_4` pause.
 *
 * Used when a required field is missing or invalid: platform, target system, and
 * so on.
 *
 * ── Option values are prose, and must be sent verbatim ──────────────────────
 * `node_3` builds options like `{label: "HMD", value: "Platform is HMD"}`
 * (nodes_intake.py:879). The value is a sentence because the reply flows back
 * into `node_1`'s extractor, which reads it as natural language. Sending the
 * label instead — or "helpfully" trimming the value to just "HMD" — changes what
 * the agent understands. Send `option.value` untouched.
 *
 * That phrasing also happens to sidestep BUG-3: a sentence cannot be JSON-parsed
 * into a bare integer the way a lone "2" can.
 *
 * ── The dead-end guard ──────────────────────────────────────────────────────
 * If there are no options AND free text is disabled, the user has no way to
 * answer and the graph waits forever. We force free text on and log it, because
 * a stuck run is worse than an unexpected input box.
 */
export function FieldPrompt({
  props,
  handlers,
}: {
  props: FieldPromptProps;
  handlers: AgentHandlers;
}) {
  const [text, setText] = useState("");

  const options = props.options ?? [];
  const allowFreeText = props.allow_free_text !== false;

  const deadEnd = options.length === 0 && !allowFreeText;
  if (deadEnd) {
    console.error(
      "[agent-ui] fieldPrompt had no options and allow_free_text=false — forcing free text to avoid a stuck run.",
    );
  }
  const showFreeText = allowFreeText || deadEnd;

  return (
    <Card title={props.title} meta={props.meta} inert={handlers.answered}>
      <p className={styles.message}>{props.message}</p>

      {options.length > 0 ? (
        <OptionList
          options={options}
          disabled={handlers.answered}
          singleSelect={false}
          onSelect={(value) => handlers.respond(value)}
        />
      ) : null}

      {showFreeText ? (
        <Field label="Your reply">
          {(id, describedBy) => (
            <div className={styles.inline}>
              <TextInput
                id={id}
                value={text}
                disabled={handlers.answered}
                describedBy={describedBy}
                placeholder={props.placeholder ?? "Type your reply…"}
                onChange={setText}
              />
              <Button
                variant="primary"
                disabled={handlers.answered || text.trim() === ""}
                onClick={() => handlers.respond(text.trim())}
              >
                Send
              </Button>
            </div>
          )}
        </Field>
      ) : null}
    </Card>
  );
}
