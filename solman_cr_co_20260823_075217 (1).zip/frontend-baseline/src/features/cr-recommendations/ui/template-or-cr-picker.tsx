"use client";

import { useState } from "react";
import type { TemplateOrCrPickerProps } from "@/agent/contract";
import type { AgentHandlers } from "@/agent/registry";
import { Button, Card, Field, OptionList, Select, TextInput } from "@/shared/ui";
import styles from "./template-or-cr-picker.module.css";

/**
 * `templateOrCrPicker` — Screen 2, emitted by `node_17`.
 *
 * The user picks a baseline: a Template ID, or one of up to five recommended
 * reference change requests.
 *
 * ── Everything in the expansion panel comes from the agent ──────────────────
 * Similarity score, platform, target system, change cycle, description — all of
 * it is supplied in `option.details`. *"the expansion data is supplied by the
 * agent — the frontend never fetches or derives it"* (AGUI_INTEGRATION.md:46).
 * There is no lookup in this file and there should never be one.
 *
 * ── The empty case is a real case ───────────────────────────────────────────
 * `reference_options_from_baseline` skips any slot carrying an `error`, because
 * `node_7` writes fabricated object ids (`CR_0`…`CR_4`) on embedding failure and
 * those must never be offered to a user as real change requests
 * (ui_contract.py:643, AGUI_INTEGRATION.md:190). So an empty list is normal and
 * means "no comparable CRs" — we say that, rather than rendering an empty picker
 * that looks broken.
 */
export function TemplateOrCrPicker({
  props,
  handlers,
}: {
  props: TemplateOrCrPickerProps;
  handlers: AgentHandlers;
}) {
  const [template, setTemplate] = useState(props.selected_template ?? "");
  const [manualId, setManualId] = useState("");

  const references = props.reference_options ?? [];
  const templates = props.template_options ?? [];

  return (
    <Card
      title={props.title}
      subtitle={props.subtitle}
      meta={props.meta}
      inert={handlers.answered}
    >
      <Field label={props.template_label ?? "Template ID"}>
        {(id, describedBy) =>
          templates.length > 0 ? (
            <Select
              id={id}
              value={template}
              options={templates}
              disabled={handlers.answered}
              describedBy={describedBy}
              onChange={setTemplate}
            />
          ) : (
            <TextInput
              id={id}
              value={template}
              disabled={handlers.answered}
              describedBy={describedBy}
              placeholder="e.g. Temp45678"
              onChange={setTemplate}
            />
          )
        }
      </Field>

      {template.trim() !== "" ? (
        <div className={styles.actions}>
          <Button
            variant="primary"
            disabled={handlers.answered}
            onClick={() => handlers.respond(template.trim())}
          >
            Use this template
          </Button>
        </div>
      ) : null}

      <h3 className={styles.heading}>{props.reference_label ?? "Reference Change Request"}</h3>

      {references.length > 0 ? (
        <OptionList
          options={references}
          selectedValue={props.selected_reference ?? null}
          disabled={handlers.answered}
          onSelect={(value) => handlers.respond(value)}
        />
      ) : (
        <p className={styles.empty}>
          No comparable change requests were found. Enter a Template ID or a CR ID to continue.
        </p>
      )}

      <Field label="…or type a CR ID directly">
        {(id, describedBy) => (
          <div className={styles.inline}>
            <TextInput
              id={id}
              value={manualId}
              disabled={handlers.answered}
              describedBy={describedBy}
              placeholder="e.g. 50412146"
              onChange={setManualId}
            />
            <Button
              variant="secondary"
              disabled={handlers.answered || manualId.trim() === ""}
              onClick={() => handlers.respond(manualId.trim())}
            >
              Use
            </Button>
          </div>
        )}
      </Field>
    </Card>
  );
}
