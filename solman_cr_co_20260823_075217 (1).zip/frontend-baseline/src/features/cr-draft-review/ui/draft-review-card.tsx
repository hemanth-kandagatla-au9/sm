"use client";

import { useMemo, useState } from "react";
import type { DraftReviewProps, FieldRow } from "@/agent/contract";
import type { AgentHandlers } from "@/agent/registry";
import { Button, Card, Markdown } from "@/shared/ui";
import styles from "./draft-review-card.module.css";

/**
 * `draftReview` — Screen 4, the approval checkpoint. Emitted by `node_8`.
 *
 * The last thing a human sees before `solman_write` creates a real change request
 * in SAP. That write cannot be undone from this application and cannot be
 * cancelled once started, so every decision in this file is biased towards "make
 * the user certain" over "make the flow smooth".
 *
 * Roughly 118 field rows across 11 sections, each carrying its own edit rules —
 * derived from the same config `node_10` validates edits against, so what the
 * user reads when they expand a field is the ruleset that will actually accept or
 * reject their change (AGUI_INTEGRATION.md:67).
 */

/**
 * ══════════════════════════════════════════════════════════════════════════════
 * ACTION ALLOW-LIST — a deliberate, narrow exception to "render the contract"
 * ══════════════════════════════════════════════════════════════════════════════
 *
 * The backend publishes three actions (ui_contract.py:452-456): `reject`,
 * `approve`, and `submit_for_approval`. Only the first two are exact-match
 * shortcuts in `node_9` (nodes_review.py:197). `submit_for_approval` falls
 * through to the relevance LLM and then to `cond_edge_b`, whose approval guard is
 * a *substring* test — `"submit"` is a substring of `"submit_for_approval"` — so
 * it MAY route to `node_12` (a real SAP write), or the classifier may treat it as
 * a question. The classifier prompt never mentions the token, and nothing else in
 * the backend references it.
 *
 * We do not ship a button on an irreversible path whose outcome is
 * non-deterministic (decision Q4, BUG-2). Unknown actions are dropped and
 * COUNTED, so the day the backend defines one we see it in telemetry rather than
 * finding out in QA.
 *
 * This does NOT generalise. Contrast the five compliance fields that arrive
 * `editable: true` with no lock reason (BUG-1): those we render exactly as sent,
 * because a frontend lock list would drift from the backend the moment the real
 * list lands.
 *
 * The rule: **filter an action whose behaviour is undefined; never override data.**
 */
const HANDLED_ACTIONS = new Set(["approve", "reject"]);

const ACTION_VARIANT: Record<string, "primary" | "danger" | "secondary"> = {
  approve: "primary",
  reject: "danger",
};

export function DraftReviewCard({
  props,
  handlers,
}: {
  props: DraftReviewProps;
  handlers: AgentHandlers;
}) {
  const [openSections, setOpenSections] = useState<Set<string>>(new Set());
  const [openField, setOpenField] = useState<string | null>(null);
  const [pendingEdit, setPendingEdit] = useState<{ key: string; label: string; value: string } | null>(
    null,
  );

  const actions = useMemo(() => {
    const supplied = props.actions ?? [];
    const kept = supplied.filter((action) => HANDLED_ACTIONS.has(action.value));
    const dropped = supplied.filter((action) => !HANDLED_ACTIONS.has(action.value));
    if (dropped.length > 0) {
      // Telemetry, not decoration: a new backend action announces itself here.
      console.warn(
        "[agent-ui] draftReview actions dropped (undefined backend semantics):",
        dropped.map((action) => action.value),
      );
    }
    return kept;
  }, [props.actions]);

  const totals = useMemo(() => {
    let filled = 0;
    let total = 0;
    for (const section of props.sections) {
      for (const field of section.fields) {
        total += 1;
        if (!isEmpty(field)) filled += 1;
      }
    }
    return { filled, total };
  }, [props.sections]);

  const allOpen = openSections.size === props.sections.length && props.sections.length > 0;

  const toggleAll = () => {
    setOpenSections(allOpen ? new Set() : new Set(props.sections.map((section) => section.name)));
  };

  /**
   * A field edit is a MESSAGE, not a mutation.
   *
   * The agent owns every value on this card. Typing a new one does not change
   * state — it resumes the interrupt with text that `node_10` parses into an
   * update intent, which may be applied, rejected, or bounced back for
   * disambiguation. The authoritative value returns on the next snapshot.
   *
   * So the edit shows as *pending*, never as accepted. There is nothing to roll
   * back on failure because nothing was ever committed — which is the whole point
   * on a system that writes irreversibly to SAP.
   *
   * The phrasing also sidesteps BUG-3: "Change Risk to 2" contains letters, so it
   * cannot be JSON-parsed into a bare integer the way "2" alone would be.
   */
  const submitEdit = () => {
    if (!pendingEdit || pendingEdit.value.trim() === "") return;
    handlers.respond(`Change ${pendingEdit.label} to ${pendingEdit.value.trim()}`);
    setPendingEdit(null);
  };

  return (
    <Card
      title={props.title}
      subtitle={props.subtitle}
      meta={props.meta}
      inert={handlers.answered}
      footer={
        <div className={styles.footer}>
          {props.confirm_text ? <p className={styles.confirm}>{props.confirm_text}</p> : null}
          {props.question_text ? <p className={styles.question}>{props.question_text}</p> : null}
          <div className={styles.actions}>
            {actions.map((action) => (
              <Button
                key={action.value}
                variant={ACTION_VARIANT[action.value] ?? "secondary"}
                disabled={handlers.answered}
                onClick={() => handlers.respond(action.value)}
              >
                {action.label}
              </Button>
            ))}
          </div>
        </div>
      }
    >
      {props.notices && props.notices.length > 0 ? (
        <div className={styles.notices} role="status">
          {props.notices.map((notice, index) => (
            <Markdown key={index}>{notice}</Markdown>
          ))}
        </div>
      ) : null}

      <div className={styles.toolbar}>
        <span className={styles.progress}>
          {totals.filled} of {totals.total} fields have a value
        </span>
        <Button variant="ghost" onClick={toggleAll}>
          {allOpen ? "Collapse all" : "Expand all"}
        </Button>
      </div>

      <div className={styles.sections}>
        {props.sections.map((section) => {
          const open = openSections.has(section.name);
          const filled = section.fields.filter((field) => !isEmpty(field)).length;

          return (
            <section key={section.name} className={styles.section}>
              <button
                type="button"
                className={styles.sectionHeader}
                aria-expanded={open}
                onClick={() =>
                  setOpenSections((current) => {
                    const next = new Set(current);
                    if (next.has(section.name)) next.delete(section.name);
                    else next.add(section.name);
                    return next;
                  })
                }
              >
                <span aria-hidden="true">{open ? "▾" : "▸"}</span>
                <span className={styles.sectionName}>{section.name}</span>
                {/* Rendered even at 0/0. Hiding an empty section would read as
                    "no such requirement", which on a regulated form is a
                    different and much worse statement than "nothing entered". */}
                <span className={styles.sectionCount}>
                  {filled}/{section.fields.length}
                </span>
              </button>

              {open ? (
                <ul className={styles.sections}>
                  {section.fields.map((field) => (
                    <FieldRowView
                      key={field.key}
                      field={field}
                      expanded={openField === field.key}
                      onToggle={() =>
                        setOpenField((current) => (current === field.key ? null : field.key))
                      }
                      editing={pendingEdit?.key === field.key}
                      pendingValue={pendingEdit?.key === field.key ? pendingEdit.value : null}
                      disabled={handlers.answered}
                      onStartEdit={() =>
                        setPendingEdit({ key: field.key, label: field.label, value: field.value })
                      }
                      onChangePending={(value) =>
                        setPendingEdit((current) => (current ? { ...current, value } : current))
                      }
                      onCancelEdit={() => setPendingEdit(null)}
                      onSubmitEdit={submitEdit}
                    />
                  ))}
                </ul>
              ) : null}
            </section>
          );
        })}
      </div>
    </Card>
  );
}

function FieldRowView({
  field,
  expanded,
  onToggle,
  editing,
  pendingValue,
  disabled,
  onStartEdit,
  onChangePending,
  onCancelEdit,
  onSubmitEdit,
}: {
  field: FieldRow;
  expanded: boolean;
  onToggle: () => void;
  editing: boolean;
  pendingValue: string | null;
  disabled: boolean;
  onStartEdit: () => void;
  onChangePending: (value: string) => void;
  onCancelEdit: () => void;
  onSubmitEdit: () => void;
}) {
  const locked = field.editable === false || Boolean(field.lock_type);
  const dropdownOptions = field.allowed_values ?? [];

  /**
   * A `dropdown` with no allowed values is read-only, NOT free text.
   *
   * Falling back to a text input would let a user submit an unvalidated value
   * into SAP for a field the backend believes is constrained. Read-only is the
   * safe failure.
   */
  const unusableDropdown = field.field_type === "dropdown" && dropdownOptions.length === 0;
  const editable = !locked && !disabled && !unusableDropdown;

  /**
   * `field_type` is an open string, not a closed enum — the backend emits `date`
   * for the implementation-date fields even though its own published schema does
   * not list it (config.py:910 vs ui_contract.py:132).
   *
   * So this maps *known* types to controls and lets anything else fall through
   * to a plain text input. An unrecognised type must degrade, never block: the
   * user still sees the value and can still edit it.
   */
  const inputType = field.field_type === "date" ? "date" : "text";

  const hasDetail =
    Boolean(field.lock_reason) ||
    Boolean(field.field_type) ||
    dropdownOptions.length > 0 ||
    Boolean(field.section);

  return (
    <li className={locked ? `${styles.row} ${styles.locked}` : styles.row}>
      <div className={styles.rowMain}>
        <span className={styles.rowLabel}>{field.label}</span>
        <span className={isEmpty(field) ? `${styles.rowValue} ${styles.rowEmpty}` : styles.rowValue}>
          {isEmpty(field) ? "Not set" : field.value}
        </span>

        {locked ? <span className={styles.lockBadge}>Locked</span> : null}

        {/* Expanding and editing are separate controls. Reading why a field holds
            its value must never be a step towards changing it. */}
        {hasDetail ? (
          <button
            type="button"
            className={styles.rowAction}
            aria-expanded={expanded}
            onClick={onToggle}
          >
            <span className="visually-hidden">
              {expanded ? "Hide rules for" : "Show rules for"} {field.label}
            </span>
            <span aria-hidden="true">{expanded ? "▾" : "▸"}</span>
          </button>
        ) : null}

        {editable && !editing ? (
          <button type="button" className={styles.rowAction} onClick={onStartEdit}>
            Edit
          </button>
        ) : null}
      </div>

      {editing ? (
        <div className={styles.editor}>
          {dropdownOptions.length > 0 ? (
            <select
              className={styles.control}
              value={pendingValue ?? ""}
              onChange={(event) => onChangePending(event.target.value)}
            >
              {dropdownOptions.map((option) => (
                <option key={option} value={option}>
                  {option}
                </option>
              ))}
            </select>
          ) : (
            <input
              className={styles.control}
              type={inputType}
              value={pendingValue ?? ""}
              onChange={(event) => onChangePending(event.target.value)}
            />
          )}
          <Button variant="primary" onClick={onSubmitEdit}>
            Request change
          </Button>
          <Button variant="ghost" onClick={onCancelEdit}>
            Cancel
          </Button>
          <p className={styles.editorHint}>
            The agent will confirm this change — the value above updates only once it does.
          </p>
        </div>
      ) : null}

      {expanded ? (
        <dl className={styles.panel}>
          {field.section ? (
            <div className={styles.detailRow}>
              <dt>Section</dt>
              <dd>{field.section}</dd>
            </div>
          ) : null}
          {field.field_type ? (
            <div className={styles.detailRow}>
              <dt>Type</dt>
              <dd>{field.field_type}</dd>
            </div>
          ) : null}
          {dropdownOptions.length > 0 ? (
            <div className={styles.detailWide}>
              <dt>Accepted values</dt>
              <dd>{dropdownOptions.join(", ")}</dd>
            </div>
          ) : null}
          {/* A field that silently refuses to change reads as a bug; a stated
              reason makes it a visible control (AGUI_INTEGRATION.md:79-84). When
              lock_type is set but lock_reason is missing we still say something
              rather than showing an inert control with no explanation. */}
          {locked ? (
            <div className={styles.detailWide}>
              <dt>Why locked</dt>
              <dd>{field.lock_reason ?? "This field cannot be changed through this agent."}</dd>
            </div>
          ) : null}
          {unusableDropdown ? (
            <div className={styles.detailWide}>
              <dt>Read-only</dt>
              <dd>
                This field expects a value from a list, but no accepted values were supplied.
              </dd>
            </div>
          ) : null}
        </dl>
      ) : null}
    </li>
  );
}

function isEmpty(field: FieldRow): boolean {
  if (field.empty === true) return true;
  return field.value.trim() === "";
}
