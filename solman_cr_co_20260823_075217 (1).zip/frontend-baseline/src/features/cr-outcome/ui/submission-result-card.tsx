"use client";

import type { SubmissionResultProps } from "@/agent/contract";
import type { AgentHandlers } from "@/agent/registry";
import { Card, Markdown } from "@/shared/ui";
import styles from "./submission-result-card.module.css";

/**
 * `submissionResult` — the terminal card, emitted by `node_15` (failed) and
 * `node_16` (success).
 *
 * ══════════════════════════════════════════════════════════════════════════════
 * SUCCESS WITH NO CR ID IS AN ERROR
 * ══════════════════════════════════════════════════════════════════════════════
 *
 * `solman_write` can return `success: true` with `cr_id: null` — SAP accepted the
 * POST but returned no `EvObjectID` (tools.py:2696-2705). `node_16` passes that
 * straight through as `status: "success", cr_id: null`
 * (nodes_outcome.py:117, 160-164).
 *
 * Rendering that as a success would tell a user their change request was created
 * while giving them no identifier to reconcile against — so they could not check,
 * could not follow up, and would not raise it again. Telling them to verify is
 * strictly better than a green tick they cannot act on. The backend team agrees
 * (AGUI_INTEGRATION.md:194); this card is where that agreement is implemented.
 *
 * ── The message is markdown ─────────────────────────────────────────────────
 * `node_15` builds prose containing `**Root Cause:**` and `**Reason:** …
 * (Transaction ID: …)` (nodes_outcome.py:78-95). Rendered through our HTML-free
 * markdown component — the string is LLM-adjacent and must never reach `innerHTML`.
 */
export function SubmissionResultCard({
  props,
}: {
  props: SubmissionResultProps;
  handlers: AgentHandlers;
}) {
  const crId = props.cr_id?.trim() ?? "";
  const indeterminate = props.status === "success" && crId === "";
  const tone = props.status === "success" && !indeterminate ? "success" : "failure";

  return (
    <Card
      title={
        indeterminate
          ? "Submitted, but not confirmed"
          : props.status === "success"
            ? "Change request created"
            : "Submission failed"
      }
      meta={props.meta}
    >
      <div className={`${styles.outcome} ${tone === "success" ? styles.success : styles.failure}`} role="status">
        {indeterminate ? (
          <>
            <p className={styles.lede}>
              Solution Manager accepted the submission but did not return a change request
              number.
            </p>
            <p className={styles.action}>
              <strong>Check Solution Manager before resubmitting.</strong> A change request may
              already exist. Submitting again could create a duplicate.
            </p>
          </>
        ) : null}

        {props.status === "success" && !indeterminate ? (
          <p className={styles.id}>
            <span className={styles.idLabel}>Change request</span>
            <code className={styles.idValue}>{crId}</code>
          </p>
        ) : null}

        <Markdown className={styles.message}>{props.message}</Markdown>
      </div>
    </Card>
  );
}
