export { SubmissionResultCard } from "./ui/submission-result-card";
