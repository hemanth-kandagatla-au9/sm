import { z } from "zod";
import { COMPONENT_NAMES } from "./types";

/**
 * agent/contract/schemas.ts
 *
 * Runtime validators for every component's props, mirroring PROP_SCHEMAS in
 * ui_contract.py:148-303.
 *
 * ── Two decisions that are easy to get backwards ────────────────────────────
 *
 * 1. **Unknown keys are STRIPPED, not rejected.** zod's default. The backend's
 *    versioning rule is that additive props do NOT bump CONTRACT_VERSION —
 *    "a frontend that ignores them still renders correctly" (AGUI_INTEGRATION.md:88).
 *    Using `.strict()` here would turn every additive backend change into a
 *    fallback card on a regulated approval screen. That is the opposite of what
 *    the contract intends.
 *
 * 2. **Display-hint enums are NOT closed.** An enum that only chooses how to
 *    render must never reject a payload — that turns an additive backend change
 *    into a blocked approval screen.
 *
 *    This is not hypothetical. `config.py:910` emits `field_type: "date"` for
 *    the two implementation-date fields, while `ui_contract.py:132` publishes an
 *    enum of only `text | boolean | dropdown`. The backend violates its own
 *    published schema, and a strict enum here turned that into "We could not
 *    display this step correctly" on the 118-field approval card — for two
 *    fields whose only difference is which input control they deserve.
 *
 *    Rule of thumb: **an enum that drives a rendering choice is permissive; an
 *    enum that drives a safety decision is checked in the component, where the
 *    unsafe branch can be the default.** `submissionResult.status` is the second
 *    kind — but it is still parsed permissively here, because refusing to render
 *    a terminal card is precisely the harm the fallback exists to avoid: the user
 *    is left not knowing whether their change request was created.
 *
 * 3. **Nullable AND optional almost everywhere.** The backend encodes with
 *    `exclude_none=True` (BACKEND_CONTRACT §1.1), so a null field is *omitted*
 *    from the JSON rather than sent as null. But the REST helpers and some
 *    builders do emit explicit nulls. `.nullish()` accepts both, which is the
 *    only shape that survives contact with both paths.
 */

const detailRow = z.object({
  label: z.string(),
  value: z.string(),
  // Styling only. An unknown tone renders untinted rather than failing the card.
  tone: z.string().nullish(),
  wide: z.boolean().optional(),
});

const agentOption = z.object({
  label: z.string(),
  value: z.string(),
  badge: z.string().nullish(),
  disabled: z.boolean().optional(),
  details: z.array(detailRow).nullish(),
});

const cardMeta = z.object({
  timestamp: z.string().nullish(),
  processing_time: z.string().nullish(),
  tokens: z.union([z.number(), z.string()]).nullish(),
  cost: z.string().nullish(),
});

const fieldRow = z.object({
  key: z.string(),
  label: z.string(),
  value: z.string(),
  editable: z.boolean().optional(),
  lock_type: z.string().nullish(),
  /**
   * Known: text | boolean | dropdown | date. Deliberately a plain string —
   * `date` is already outside the backend's own published enum, so a closed set
   * here is a liability rather than a guarantee. Unknown types render read-only
   * (see draft-review-card.tsx).
   */
  field_type: z.string().nullish(),
  allowed_values: z.array(z.string()).nullish(),
  section: z.string().nullish(),
  lock_reason: z.string().nullish(),
  empty: z.boolean().optional(),
});

const crModeChoice = z.object({
  title: z.string(),
  subtitle: z.string().nullish(),
  modes: z
    .array(
      z.object({
        // Permissive: a new mode must not blank the very first screen.
        value: z.string(),
        label: z.string(),
        description: z.string().nullish(),
        enabled: z.boolean().optional(),
      }),
    )
    .min(1),
  meta: cardMeta.nullish(),
});

const featureComingSoon = z.object({
  title: z.string(),
  message: z.string(),
  back_label: z.string().nullish(),
  meta: cardMeta.nullish(),
});

const crIntakeForm = z.object({
  title: z.string(),
  subtitle: z.string().nullish(),
  hint: z.string().nullish(),
  platforms: z.array(z.string()),
  target_systems: z.array(z.string()).nullish(),
  values: z
    .object({
      platform: z.string().nullish(),
      target_system: z.string().nullish(),
      jira_id: z.string().nullish(),
      iris_id: z.string().nullish(),
      reason_for_change: z.string().nullish(),
      description_of_change: z.string().nullish(),
    })
    .nullish(),
  errors: z.record(z.string(), z.string()).nullish(),
  iris_enabled: z.boolean().optional(),
  meta: cardMeta.nullish(),
});

const templateOrCrPicker = z.object({
  title: z.string(),
  subtitle: z.string().nullish(),
  template_label: z.string().nullish(),
  template_optional: z.boolean().optional(),
  template_options: z.array(z.string()).optional(),
  reference_label: z.string().nullish(),
  reference_options: z.array(agentOption).optional(),
  selected_template: z.string().nullish(),
  selected_reference: z.string().nullish(),
  meta: cardMeta.nullish(),
});

const cycleIdPicker = z.object({
  message: z.string(),
  options: z.array(agentOption),
  draft_cycle_id: z.string().nullish(),
  keep_current_label: z.string().nullish(),
  meta: cardMeta.nullish(),
});

const draftReview = z.object({
  title: z.string(),
  subtitle: z.string().nullish(),
  sections: z.array(z.object({ name: z.string(), fields: z.array(fieldRow) })),
  confirm_text: z.string().nullish(),
  question_text: z.string().nullish(),
  notices: z.array(z.string()).nullish(),
  actions: z.array(agentOption).optional(),
  meta: cardMeta.nullish(),
});

const fieldPrompt = z.object({
  title: z.string().nullish(),
  message: z.string(),
  options: z.array(agentOption).optional(),
  allow_free_text: z.boolean().optional(),
  placeholder: z.string().nullish(),
  meta: cardMeta.nullish(),
});

const submissionResult = z.object({
  /**
   * Parsed permissively, judged strictly. The card treats anything that is not
   * exactly "success" *with* a cr_id as not-confirmed, so an unknown status
   * fails safe. Rejecting here would hide the terminal card entirely, leaving a
   * user unable to tell whether their change request exists.
   */
  status: z.string(),
  message: z.string(),
  cr_id: z.string().nullish(),
  meta: cardMeta.nullish(),
});

/** One validator per registered component name. */
export const PROP_SCHEMAS = {
  crModeChoice,
  featureComingSoon,
  crIntakeForm,
  templateOrCrPicker,
  cycleIdPicker,
  draftReview,
  fieldPrompt,
  submissionResult,
} satisfies Record<(typeof COMPONENT_NAMES)[number], z.ZodTypeAny>;

/** Envelope shape only — props are validated per component, after name lookup. */
export const ENVELOPE_SCHEMA = z.object({
  version: z.number(),
  name: z.string(),
  props: z.unknown(),
});
