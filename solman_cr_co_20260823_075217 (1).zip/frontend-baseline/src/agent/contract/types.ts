/**
 * agent/contract/types.ts
 *
 * TypeScript mirror of `agui/ui_contract.py`. These types ARE the contract as far
 * as this app is concerned.
 *
 * Hand-written for now, from PROP_SCHEMAS (ui_contract.py:148-303). The intent is
 * that `npm run contract:gen` regenerates this file from `GET /api/ui-contract`
 * once a backend is reachable — see scripts/generate-contract.mjs. Until then this
 * file is the single place to edit when the backend contract moves, and
 * `schemas.ts` must move with it.
 *
 * Naming note: props use snake_case because the backend does. Renaming them here
 * would mean a translation layer whose only job is to be wrong occasionally.
 */

/** ui_contract.py:44 — bumped only on a BREAKING prop change. */
export const CONTRACT_VERSION = 1;

export const COMPONENT_NAMES = [
  "crModeChoice",
  "featureComingSoon",
  "crIntakeForm",
  "templateOrCrPicker",
  "cycleIdPicker",
  "draftReview",
  "fieldPrompt",
  "submissionResult",
] as const;

export type AgentComponentName = (typeof COMPONENT_NAMES)[number];

// ─────────────────────────────────────────────────────────────────────────────
// Shared sub-shapes (ui_contract.py:76-142)
// ─────────────────────────────────────────────────────────────────────────────

/**
 * One label/value line inside an expanded panel.
 *
 * `tone` is set by the agent, never inferred client-side: `positive` on Platform
 * means *the agent matched it against the user's platform*. If you find yourself
 * computing a tone here, the fix belongs in ui_contract.py.
 */
export interface DetailRow {
  label: string;
  value: string;
  /** Known: neutral | positive | negative. Open by design — see schemas.ts. */
  tone?: string | null;
  /** Render full-width — a hint about text length, not a column span. */
  wide?: boolean;
}

export interface AgentOption {
  label: string;
  value: string;
  /** Right-aligned pill, e.g. the platform name. */
  badge?: string | null;
  disabled?: boolean;
  /**
   * Populated → the row is expandable. Absent/empty → the row renders NO
   * disclosure control at all (AGUI_INTEGRATION.md:61). An empty array must not
   * produce a chevron that expands to nothing.
   */
  details?: DetailRow[] | null;
}

/** Footer strip. Supplied by the agent so the frontend never computes it. */
export interface CardMeta {
  timestamp?: string | null;
  processing_time?: string | null;
  tokens?: number | string | null;
  cost?: string | null;
}

/**
 * One row of the draft. `additionalProperties: True` upstream, so unknown keys
 * are tolerated rather than rejected.
 */
export interface FieldRow {
  /** EDL key, e.g. `zzfld00000v_cus`. Stable identity — use it for React keys. */
  key: string;
  label: string;
  /** Display value, exactly as it will be submitted. */
  value: string;
  editable?: boolean;
  /** `system_readonly` | `compliance_locked` | `session_locked` */
  lock_type?: string | null;
  /**
   * Known: text | boolean | dropdown | date.
   *
   * `date` is emitted by config.py:910 but absent from the backend's published
   * enum (ui_contract.py:132) — so this stays an open string. Unknown values
   * render read-only.
   */
  field_type?: string | null;
  /** For dropdown/boolean fields — the values SolMan will accept. */
  allowed_values?: string[] | null;
  section?: string | null;
  lock_reason?: string | null;
  /** True when no value will be submitted. */
  empty?: boolean;
}

export interface DraftSection {
  name: string;
  fields: FieldRow[];
}

// ─────────────────────────────────────────────────────────────────────────────
// Per-component props
// ─────────────────────────────────────────────────────────────────────────────

export interface CrModeChoiceProps {
  title: string;
  subtitle?: string | null;
  modes: Array<{
    value: string;
    label: string;
    description?: string | null;
    /**
     * Bulk is NOT blocked client-side. The tile stays clickable and posts
     * `{"mode":"bulk"}`; the backend answers with the featureComingSoon card
     * (AGUI_INTEGRATION.md:92-99). `enabled:false` styles it, it does not
     * disable it.
     */
    enabled?: boolean;
  }>;
  meta?: CardMeta | null;
}

export interface FeatureComingSoonProps {
  title: string;
  message: string;
  back_label?: string | null;
  meta?: CardMeta | null;
}

export interface CrIntakeFormProps {
  title: string;
  subtitle?: string | null;
  hint?: string | null;
  platforms: string[];
  target_systems?: string[] | null;
  values?: {
    platform?: string | null;
    target_system?: string | null;
    jira_id?: string | null;
    iris_id?: string | null;
    reason_for_change?: string | null;
    description_of_change?: string | null;
  } | null;
  /** Field-level server-side validation errors, keyed by field name. */
  errors?: Record<string, string> | null;
  /** IRIS has no backing API yet — rendered but inert until this flips. */
  iris_enabled?: boolean;
  meta?: CardMeta | null;
}

export interface TemplateOrCrPickerProps {
  title: string;
  subtitle?: string | null;
  template_label?: string | null;
  template_optional?: boolean;
  template_options?: string[];
  reference_label?: string | null;
  reference_options?: AgentOption[];
  selected_template?: string | null;
  selected_reference?: string | null;
  meta?: CardMeta | null;
}

export interface CycleIdPickerProps {
  message: string;
  options: AgentOption[];
  draft_cycle_id?: string | null;
  /**
   * Absent when the draft's own cycle is inactive — there is nothing valid to
   * keep. Do NOT synthesise one (nodes_outcome.py:701-712).
   */
  keep_current_label?: string | null;
  meta?: CardMeta | null;
}

export interface DraftReviewProps {
  title: string;
  subtitle?: string | null;
  sections: DraftSection[];
  confirm_text?: string | null;
  question_text?: string | null;
  notices?: string[] | null;
  actions?: AgentOption[];
  meta?: CardMeta | null;
}

export interface FieldPromptProps {
  title?: string | null;
  message: string;
  options?: AgentOption[];
  allow_free_text?: boolean;
  placeholder?: string | null;
  meta?: CardMeta | null;
}

export interface SubmissionResultProps {
  /** Known: success | failed. Anything else is treated as not-confirmed. */
  status: string;
  message: string;
  /**
   * May be null even when status is "success" — solman_write can report success
   * with no EvObjectID (tools.py:2696-2705). The card renders that as an ERROR;
   * telling a user their CR was created with no identifier to reconcile against
   * is worse than telling them to check.
   */
  cr_id?: string | null;
  meta?: CardMeta | null;
}

/** Discriminated union of every component the agent can name. */
export type AgentComponentPropsMap = {
  crModeChoice: CrModeChoiceProps;
  featureComingSoon: FeatureComingSoonProps;
  crIntakeForm: CrIntakeFormProps;
  templateOrCrPicker: TemplateOrCrPickerProps;
  cycleIdPicker: CycleIdPickerProps;
  draftReview: DraftReviewProps;
  fieldPrompt: FieldPromptProps;
  submissionResult: SubmissionResultProps;
};

/** The state channel: AgentState["ui_component"] (state.py:155-159). */
export interface AgentComponentEnvelope<
  N extends AgentComponentName = AgentComponentName,
> {
  version: number;
  name: N;
  props: AgentComponentPropsMap[N];
}

export type AnyAgentComponentEnvelope = {
  [N in AgentComponentName]: AgentComponentEnvelope<N>;
}[AgentComponentName];
