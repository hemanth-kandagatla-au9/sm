import {
  CONTRACT_VERSION,
  COMPONENT_NAMES,
  type AgentComponentName,
  type AnyAgentComponentEnvelope,
} from "./types";
import { ENVELOPE_SCHEMA, PROP_SCHEMAS } from "./schemas";

/**
 * agent/contract/envelope.ts
 *
 * The single gate every agent-named component passes through.
 *
 * Four failure modes are distinguished, because a user on a regulated approval
 * path needs to know *which* thing went wrong — "something broke" does not tell
 * them whether their CR went through (AGUI_INTEGRATION.md:196).
 */

export type EnvelopeResult =
  | { kind: "ok"; envelope: AnyAgentComponentEnvelope }
  /** Nothing to render. Not an error — ui_component is null until the first card. */
  | { kind: "empty" }
  /** The agent is ahead of this app's registry. */
  | { kind: "unknown-component"; name: string }
  /** Breaking prop change not deployed here yet. */
  | { kind: "unsupported-version"; name: string; version: number }
  /** Name and version are fine; the payload does not match the schema. */
  | { kind: "invalid-props"; name: string; issues: string[] };

export function isKnownComponentName(name: string): name is AgentComponentName {
  return (COMPONENT_NAMES as readonly string[]).includes(name);
}

/**
 * Validate one `ui_component` payload.
 *
 * Order matters: name before version before props. A component we cannot render
 * at all is a more useful message than "your props are wrong", and knowing the
 * name is what lets the fallback tell the user which step failed.
 */
export function parseEnvelope(raw: unknown): EnvelopeResult {
  if (raw === null || raw === undefined) return { kind: "empty" };

  const outer = ENVELOPE_SCHEMA.safeParse(raw);
  if (!outer.success) {
    return {
      kind: "invalid-props",
      name: "(malformed envelope)",
      issues: outer.error.issues.map((i) => `${i.path.join(".") || "(root)"}: ${i.message}`),
    };
  }

  const { version, name, props } = outer.data;

  if (!isKnownComponentName(name)) {
    return { kind: "unknown-component", name };
  }

  // Only a HIGHER version is rejected. A lower one is a frontend that is ahead of
  // the backend, which by the additive-props rule renders correctly.
  if (version > CONTRACT_VERSION) {
    return { kind: "unsupported-version", name, version };
  }

  const parsed = PROP_SCHEMAS[name].safeParse(props);
  if (!parsed.success) {
    return {
      kind: "invalid-props",
      name,
      issues: parsed.error.issues.map((i) => `${i.path.join(".") || "(root)"}: ${i.message}`),
    };
  }

  return {
    kind: "ok",
    // Cast is contained here and justified: `name` has been narrowed to a known
    // component and `props` validated by that component's own schema, so the
    // pairing is sound. This is the only place in the app that asserts it.
    envelope: { version, name, props: parsed.data } as AnyAgentComponentEnvelope,
  };
}
