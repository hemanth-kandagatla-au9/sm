"use client";

import styles from "./fallback-card.module.css";

/**
 * agent/registry/fallback-card.tsx
 *
 * Four distinct failures, four distinct messages.
 *
 * The backend team's own note is the right instinct and it is kept verbatim as
 * the design rule: *"On a regulated approval path a user must never be left
 * staring at a blank panel wondering whether their CR went through"*
 * (AGUI_INTEGRATION.md:196).
 *
 * So every fallback answers two questions, in this order:
 *   1. Is my change request affected?
 *   2. What do I do now?
 *
 * A generic "something went wrong" answers neither. The technical cause goes
 * behind a disclosure — useful to us, noise to the user, and never the headline.
 */

export type FallbackKind =
  | "unknown-component"
  | "unsupported-version"
  | "invalid-props"
  | "render-error";

interface FallbackCardProps {
  kind: FallbackKind;
  /** Component the agent named, when we know it. */
  name?: string | undefined;
  /** Technical cause. Shown only behind the disclosure. */
  detail?: string | undefined;
  /** Correlation ID, so a user's report is findable in logs. */
  correlationId?: string | undefined;
  /**
   * Whether the run is still live. This is the question the user actually has,
   * so it is stated rather than implied.
   */
  runActive?: boolean;
}

const COPY: Record<FallbackKind, { title: string; body: string }> = {
  "unknown-component": {
    title: "This step needs a newer version of the application",
    body: "The agent asked for a screen this app does not have yet. Your change request has not been affected — nothing was submitted by this step.",
  },
  "unsupported-version": {
    title: "This step needs a newer version of the interface",
    body: "The agent is using a newer version of the screen format than this app understands. Your change request has not been affected.",
  },
  "invalid-props": {
    title: "We could not display this step correctly",
    body: "The agent sent information this app could not read. Nothing has been submitted. Please report this before continuing.",
  },
  "render-error": {
    title: "This step failed to display",
    body: "Something went wrong drawing this screen. The conversation above is intact, and nothing has been submitted by this step.",
  },
};

export function FallbackCard({
  kind,
  name,
  detail,
  correlationId,
  runActive = false,
}: FallbackCardProps) {
  const copy = COPY[kind];

  return (
    <section className={styles.card} role="alert" aria-live="assertive">
      <h2 className={styles.title}>{copy.title}</h2>
      <p className={styles.body}>{copy.body}</p>

      <p className={styles.status}>
        {runActive
          ? "The agent is still running. You can keep waiting, or start a new request."
          : "The agent is not waiting on you. Start a new request when you are ready."}
      </p>

      {(name ?? detail ?? correlationId) !== undefined && (
        <details className={styles.details}>
          <summary>Technical detail</summary>
          <dl className={styles.rows}>
            {name !== undefined && (
              <>
                <dt>Component</dt>
                <dd>
                  <code>{name}</code>
                </dd>
              </>
            )}
            {correlationId !== undefined && (
              <>
                <dt>Reference</dt>
                <dd>
                  <code>{correlationId}</code>
                </dd>
              </>
            )}
            {detail !== undefined && (
              <>
                <dt>Cause</dt>
                <dd>
                  <code>{detail}</code>
                </dd>
              </>
            )}
          </dl>
        </details>
      )}
    </section>
  );
}
