"use client";

import { Component, type ErrorInfo, type ReactNode, useCallback, useMemo, useState } from "react";
import type { AnyAgentComponentEnvelope } from "../contract";
import { FallbackCard } from "./fallback-card";
import type { AgentHandlers, ComponentRegistry } from "./types";

/**
 * agent/registry/component-host.tsx
 *
 * Resolves a name to a component, hands over props and a `respond` channel, and
 * does nothing else.
 *
 * The host is deliberately thin. It contains no knowledge of any particular
 * screen — no "if this is a draftReview then…". If a heuristic ever appears in
 * this file, the fix belongs in `agui/ui_contract.py` instead. That rule is what
 * killed the previous iteration's stage-sniffing, where the frontend inferred
 * which screen to show by inspecting state
 * (`labels.includes("Similarity score:")`), and it should not come back.
 */

interface AgentComponentHostProps {
  registry: ComponentRegistry;
  envelope: AnyAgentComponentEnvelope | null;
  /** Set when validation failed upstream: `"kind:name:detail"`. */
  problem: string | null;
  onRespond: (value: string) => void;
  /**
   * True only while the graph is actually parked at an interrupt. When false the
   * card renders read-only rather than disappearing — the user must still be able
   * to see where they are.
   */
  interactive: boolean;
  /**
   * Changes when a new checkpoint begins. Re-arms the double-submit guard, so two
   * consecutive fieldPrompts do not leave the second one dead.
   */
  turnKey: string;
  correlationId?: string | undefined;
  runActive?: boolean;
}

export function AgentComponentHost({
  registry,
  envelope,
  problem,
  onRespond,
  interactive,
  turnKey,
  correlationId,
  runActive = false,
}: AgentComponentHostProps) {
  const [answeredFor, setAnsweredFor] = useState<string | null>(null);

  const currentKey = useMemo(
    () => `${turnKey}::${envelope?.name ?? ""}`,
    [turnKey, envelope?.name],
  );

  const respond = useCallback(
    (value: string) => {
      if (!interactive) return;
      if (answeredFor === currentKey) return; // guard double-submit
      setAnsweredFor(currentKey);
      onRespond(value);
    },
    [answeredFor, currentKey, interactive, onRespond],
  );

  const handlers: AgentHandlers = useMemo(
    () => ({ respond, answered: !interactive || answeredFor === currentKey }),
    [respond, interactive, answeredFor, currentKey],
  );

  if (problem !== null) {
    const [kind, name, ...rest] = problem.split(":");
    return (
      <FallbackCard
        kind={toFallbackKind(kind)}
        name={name}
        detail={rest.length > 0 ? rest.join(":") : undefined}
        correlationId={correlationId}
        runActive={runActive}
      />
    );
  }

  // Null is not a failure: `ui_component` is null until the first card-emitting
  // node runs. Rendering a spinner forever here would be a lie.
  if (envelope === null) return null;

  const entry = registry[envelope.name];
  if (entry === undefined) {
    return (
      <FallbackCard
        kind="unknown-component"
        name={envelope.name}
        correlationId={correlationId}
        runActive={runActive}
      />
    );
  }

  if (envelope.version < entry.minVersion || envelope.version > entry.maxVersion) {
    return (
      <FallbackCard
        kind="unsupported-version"
        name={envelope.name}
        detail={`payload v${envelope.version}, this app supports v${entry.minVersion}–v${entry.maxVersion}`}
        correlationId={correlationId}
        runActive={runActive}
      />
    );
  }

  // The registry is keyed by name and each entry's Component is typed against
  // that same name, but TypeScript cannot follow the correlation through a
  // runtime lookup. This cast is the one place that gap is bridged; the pairing
  // is guaranteed by ComponentRegistry's mapped type.
  const Rendered = entry.Component as React.ComponentType<{
    props: unknown;
    handlers: AgentHandlers;
  }>;

  return (
    <CardErrorBoundary
      resetKey={currentKey}
      correlationId={correlationId}
      name={envelope.name}
      runActive={runActive}
    >
      <Rendered props={envelope.props} handlers={handlers} />
    </CardErrorBoundary>
  );
}

function toFallbackKind(kind: string | undefined) {
  switch (kind) {
    case "unknown-component":
    case "unsupported-version":
    case "invalid-props":
      return kind;
    default:
      return "invalid-props" as const;
  }
}

/**
 * Card-level error boundary.
 *
 * Scoped to one card on purpose (ADR §9 level 3): a component that throws must
 * not take the transcript with it, because the transcript is the user's evidence
 * of what has happened to their change request.
 *
 * Class component because React still has no hook equivalent.
 */
interface BoundaryProps {
  resetKey: string;
  name: string;
  correlationId?: string | undefined;
  runActive: boolean;
  children: ReactNode;
}

class CardErrorBoundary extends Component<BoundaryProps, { error: Error | null; key: string }> {
  constructor(props: BoundaryProps) {
    super(props);
    this.state = { error: null, key: props.resetKey };
  }

  static getDerivedStateFromError(error: Error) {
    return { error };
  }

  static getDerivedStateFromProps(props: BoundaryProps, state: { error: Error | null; key: string }) {
    // A new checkpoint clears a previous card's error rather than latching it.
    if (props.resetKey !== state.key) return { error: null, key: props.resetKey };
    return null;
  }

  override componentDidCatch(error: Error, info: ErrorInfo) {
    console.error("[agent-ui] card render failed", {
      component: this.props.name,
      correlationId: this.props.correlationId,
      error,
      componentStack: info.componentStack,
    });
  }

  override render() {
    if (this.state.error) {
      return (
        <FallbackCard
          kind="render-error"
          name={this.props.name}
          detail={this.state.error.message}
          correlationId={this.props.correlationId}
          runActive={this.props.runActive}
        />
      );
    }
    return this.props.children;
  }
}
