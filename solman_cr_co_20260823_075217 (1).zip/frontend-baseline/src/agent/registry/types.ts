import type { ComponentType } from "react";
import type { AgentComponentName, AgentComponentPropsMap } from "../contract";

/**
 * agent/registry/types.ts
 *
 * The registry contract.
 *
 * The agent never ships UI. It names one of these components and supplies props.
 * Anything not in the map cannot be rendered — which is the whole point: the host
 * app decides what the agent is allowed to put on screen.
 *
 * ── Why the map is assembled in `app/`, not here ────────────────────────────
 * `agent/` may not import `features/` (the dependency rule points inward). So
 * this module owns the *machinery* — types, host, fallbacks — and the composition
 * root in `app/_client/component-registry.ts` owns the *map*. That inversion is
 * what keeps the registry from becoming a back door through the boundary.
 */

export interface AgentHandlers {
  /**
   * Send the user's answer back to the agent.
   *
   * Always resumes the pending `interrupt()` — every card, from the opening
   * mode choice through the last HITL screen, rides the same channel.
   * Components do not know or care which node emitted them.
   */
  respond: (value: string) => void;
  /**
   * True once this card has been answered, or when the graph is not actually
   * waiting. Cards render read-only rather than hidden in that state: a user must
   * always be able to see where they are, especially after submitting.
   */
  answered: boolean;
}

export interface RegisteredComponentProps<N extends AgentComponentName> {
  props: AgentComponentPropsMap[N];
  handlers: AgentHandlers;
}

/**
 * One entry. `minVersion`/`maxVersion` are per component so a single component
 * can take a breaking change without freezing the other seven — envelope-level
 * versioning alone would stall everything.
 */
export interface RegistryEntry<N extends AgentComponentName = AgentComponentName> {
  minVersion: number;
  maxVersion: number;
  Component: ComponentType<RegisteredComponentProps<N>>;
}

export type ComponentRegistry = {
  [N in AgentComponentName]?: RegistryEntry<N>;
};
