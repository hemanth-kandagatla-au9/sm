/**
 * agent/transport — the public surface.
 *
 * Everything outside `agent/` imports from here. The `./copilotkit/` folder
 * behind it is the only place a vendor SDK is named, which is what keeps a
 * future v2 migration bounded (ADR 0001 §4).
 */
export { AgentProvider } from "./copilotkit/provider";
export { useAgentSession } from "./copilotkit/use-agent-session";
export type {
  AgentSession,
  AgentRunStatus,
  AgentError,
  InterruptHandle,
  RunProgress,
  TranscriptEntry,
} from "./types";
