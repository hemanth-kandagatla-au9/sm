"use client";

import { CopilotKit } from "@copilotkit/react-core";
// `CopilotChatConfigurationProvider` is only re-exported from the /v2 subpath
// (react-core's main entry never re-exports it — see note below).
import { CopilotChatConfigurationProvider } from "@copilotkit/react-core/v2";
import type { ReactNode } from "react";

/**
 * agent/transport/copilotkit/provider.tsx
 *
 * The CopilotKit provider, wrapped so nothing else in the app names it.
 *
 * ── `runtimeUrl` is a relative path, and that is the point ───────────────────
 * `/api/agent` is our own BFF route. The browser therefore never learns the
 * backend's address, there is no `NEXT_PUBLIC_*` variable to leak, and
 * re-pointing the upstream host is a server-side env change with no client
 * rebuild.
 *
 * Contrast the backend team's harness, which shipped `VITE_AGUI_RUNTIME_URL` and
 * `VITE_AGUI_API_BASE` to the browser — correct for a debugging tool, wrong for
 * a product.
 *
 * ── `agent` must match the backend ──────────────────────────────────────────
 * The name is `LangGraphAGUIAgent(name="local_agent")` at agui_server.py:236.
 * A mismatch resolves no agent and every run fails with an error that never
 * mentions the name, so the value is validated server-side in env.ts and passed
 * down rather than duplicated as a literal.
 */

export const AGENT_RUNTIME_URL = "/api/agent";

interface AgentProviderProps {
  agentName: string;
  /**
   * Stable thread identity. Minted by us, never by CopilotKit's default, so that
   * enforcing ownership later is a validation step against an ID space we
   * already control rather than a migration.
   */
  threadId: string;
  children: ReactNode;
}

export function AgentProvider({ agentName, threadId, children }: AgentProviderProps) {
  return (
    <CopilotKit
      runtimeUrl={AGENT_RUNTIME_URL}
      agent={agentName}
      threadId={threadId}
      // Dev console off: it renders CopilotKit's own branding and error surface,
      // which is confusing next to our fallback cards on a regulated screen.
      showDevConsole={false}
    >
      {/*
       * `useCopilotChat()` (in use-agent-session.ts) resolves its agent id from
       * `useCopilotChatConfiguration()` context, NOT from the `agent` prop above
       * — that prop only wires `useCoAgent`. Without this provider it silently
       * falls back to the literal string "default", so `appendMessage()` runs
       * an agent that was never registered: no request error, no run, nothing.
       * This was the cause of every card staying blank end-to-end.
       */}
      <CopilotChatConfigurationProvider agentId={agentName} threadId={threadId}>
        {children}
      </CopilotChatConfigurationProvider>
    </CopilotKit>
  );
}
