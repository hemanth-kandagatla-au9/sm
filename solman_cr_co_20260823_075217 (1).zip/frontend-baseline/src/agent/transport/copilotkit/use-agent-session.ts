"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useCoAgent, useCopilotChat, useLangGraphInterrupt } from "@copilotkit/react-core";
import { Role, TextMessage } from "@copilotkit/runtime-client-gql";
import { parseEnvelope } from "../../contract";
import type {
  AgentError,
  AgentSession,
  InterruptHandle,
  TranscriptEntry,
} from "../types";

/**
 * agent/transport/copilotkit/use-agent-session.ts
 *
 * The CopilotKit-backed implementation of `AgentSession`. The only file in the
 * app that knows how this vendor works.
 *
 * ── Which hooks, and why these ──────────────────────────────────────────────
 *
 * `useCoAgent` — the state channel. This backend has **no LLM tool calling at
 * all** (no `bind_tools`, no `ToolNode`, verified across the whole graph), so it
 * emits no `TOOL_CALL_*` events. Every generative-UI tutorial for CopilotKit
 * teaches `useCopilotAction` with a render function bound to a tool call; that
 * path is dead here. Screens arrive as `state.ui_component` on `STATE_SNAPSHOT`,
 * which is what `useCoAgent` surfaces.
 *
 * `useLangGraphInterrupt` — HITL. The backend signals a pause with a **legacy**
 * `CUSTOM { name: "on_interrupt" }` event, not the newer AG-UI
 * `RUN_FINISHED.outcome` lifecycle (ag-ui-langgraph 0.0.42 never sets `outcome`).
 * This hook handles that path.
 *
 * `useCopilotChat` — messages. Note the deprecated-looking API: `appendMessage`
 * with a `TextMessage` from `@copilotkit/runtime-client-gql`, and
 * `visibleMessages` rather than AG-UI-shaped `messages`.
 *
 * That is deliberate, and the alternative was tried first. `useCopilotChatHeadless_c`
 * takes plain AG-UI objects and looks strictly nicer — but it is a gated Cloud
 * feature:
 *
 *   "You're using useCopilotChatHeadless_c, an Enterprise Intelligence Platform
 *    feature ... you'll need to provide a free public API key"
 *
 * Without `publicApiKey` it raises a banner error and `sendMessage` silently does
 * nothing: no run, no messages, no state. The UI just sat there. Do not switch
 * back without a key, and if you ever do, verify a message actually reaches the
 * agent rather than trusting the call to resolve.
 */

interface CoAgentState {
  ui_component?: unknown;
}

interface UseAgentSessionOptions {
  agentName: string;
  threadId: string;
}

export function useAgentSession({
  agentName,
  threadId,
}: UseAgentSessionOptions): AgentSession {
  const { state, nodeName, running } = useCoAgent<CoAgentState>({
    name: agentName,
    initialState: {},
  });
  const { visibleMessages, appendMessage, isAvailable } = useCopilotChat();

  const [error, setError] = useState<AgentError | null>(null);
  const [hasStarted, setHasStarted] = useState(false);

  const interrupt = usePendingInterrupt(agentName);
  const component = useStickyComponent(state?.ui_component);

  /**
   * `appendMessage` silently no-ops (resolves immediately, sends nothing) if
   * CopilotKit's `agent/connect` handshake hasn't completed yet — it checks
   * `if (!agent) return` internally, with no error, no rejected promise, no
   * signal of any kind. `isAvailable` flips true only once that handshake
   * finishes.
   *
   * `start("")` fires from a mount effect in the same render pass in which
   * this hook first runs, i.e. strictly before that handshake can have
   * completed — every single time. So the send has to be deferred, not fired
   * inline: buffer the requested message here and flush it once `isAvailable`
   * turns true.
   */
  const pendingMessageRef = useRef<string | null>(null);

  const sendMessage = useCallback(
    (message: string) => {
      void appendMessage(
        new TextMessage({ content: message, role: Role.User }),
      ).catch((cause: unknown) => {
        setError({
          code: "upstream_unreachable",
          message:
            cause instanceof Error
              ? cause.message
              : "The agent service could not be reached.",
          retryable: true,
        });
      });
    },
    [appendMessage],
  );

  useEffect(() => {
    if (!isAvailable || pendingMessageRef.current === null) return;
    const message = pendingMessageRef.current;
    pendingMessageRef.current = null;
    sendMessage(message);
  }, [isAvailable, sendMessage]);

  const start = useCallback(
    (message: string) => {
      setError(null);
      setHasStarted(true);
      if (isAvailable) sendMessage(message);
      else pendingMessageRef.current = message;
    },
    [isAvailable, sendMessage],
  );

  /**
   * `visibleMessages` are GraphQL-shaped, so role is an enum and non-text
   * messages (actions, results) appear alongside text. Narrow to the two roles a
   * transcript should show, and drop anything without string content.
   */
  const transcript = useMemo<TranscriptEntry[]>(() => {
    return (visibleMessages ?? [])
      .map((message, index): TranscriptEntry | null => {
        const role = String((message as { role?: unknown }).role ?? "").toLowerCase();
        const content = (message as { content?: unknown }).content;
        if (role !== "user" && role !== "assistant") return null;
        if (typeof content !== "string" || content.trim().length === 0) return null;
        return {
          id: (message as { id?: string }).id ?? `${role}-${index}`,
          role,
          content,
        };
      })
      .filter((entry): entry is TranscriptEntry => entry !== null);
  }, [visibleMessages]);

  /**
   * Has the backend ever confirmed a run for this session? Latches true.
   *
   * State, not a ref: this is read during render to derive `status`, and
   * adjusting state during render is React's supported pattern for exactly that.
   * A ref written during render would be an anti-pattern the linter rightly
   * rejects, and it would not re-render when it mattered.
   */
  const [observedRun, setObservedRun] = useState(false);
  if (running && !observedRun) setObservedRun(true);

  /**
   * ── The gap between "we asked" and "it started" ─────────────────────────────
   *
   * `start()` flips `hasStarted` synchronously; CopilotKit only reports
   * `running` once the POST is in flight. In between, every condition below is
   * false — and an earlier version fell straight through to "finished".
   *
   * That was a real bug with a very confusing symptom: submitting the intake
   * form rendered "This conversation has ended or expired" *immediately*, before
   * the agent had even been contacted. The stream was perfectly healthy; the
   * status derivation was lying.
   *
   * So: once asked, we report "running" until the backend has actually confirmed
   * a run. "Finished" now requires positive evidence that a run happened —
   * never merely the absence of one starting yet.
   */
  const status = useMemo(() => {
    if (error) return "failed" as const;
    if (interrupt) return "awaiting-input" as const;
    if (running) return "running" as const;
    if (!hasStarted) return "idle" as const;
    if (!observedRun) return "running" as const;
    return "finished" as const;
  }, [error, interrupt, running, hasStarted, observedRun]);

  /**
   * Dev-only visibility into what the client actually received.
   *
   * The stream can be perfectly healthy at the BFF and still not reach a hook —
   * agent-name mismatch, a state key that never maps into the coagent, an
   * interrupt the vendor did not surface. Those are indistinguishable from the
   * UI, and reading the network tab does not tell you which hook saw what.
   *
   * One line per state change, so the answer is in the console instead of
   * requiring another round of guessing.
   */
  useEffect(() => {
    if (process.env.NODE_ENV !== "development") return;
    // Serialised to a single string: console object previews are elided by
    // DevTools (and by CDP), which hid the very field that mattered.
    console.debug(
      "[agent-session] " +
        JSON.stringify({
          status,
          running,
          nodeName,
          hasComponent: component.envelope !== null,
          componentName: component.envelope?.name ?? null,
          componentProblem: component.problem,
          hasInterrupt: interrupt !== null,
          stateKeys: state ? Object.keys(state) : [],
          messages: transcript.length,
        }),
    );
  }, [status, running, nodeName, component.envelope, component.problem, interrupt, state, transcript.length]);

  return {
    threadId,
    status,
    component: component.envelope,
    componentProblem: component.problem,
    transcript,
    progress: { nodeName: nodeName ?? null, running },
    interrupt,
    error,
    start,
  };
}

/**
 * Bridges the pending `interrupt()` to a single resume channel.
 *
 * ── The ref-then-effect dance is load-bearing ───────────────────────────────
 * CopilotKit's transport reconnects occasionally — same thread, new runId —
 * while an interrupt is pending, which briefly clears and re-delivers the same
 * interrupt. Committing `render()` output straight to state makes the card
 * flicker and the chat jump-scroll on every reconnect. Capturing into a ref and
 * committing via an effect keeps it stable.
 *
 * This is not a CopilotKit bug: the backend's re-entrant path emits
 * `RUN_STARTED → CUSTOM(on_interrupt) → RUN_FINISHED` with no state snapshot at
 * all (BACKEND_CONTRACT §2.4), so a reconnect genuinely re-delivers the prompt.
 */
function usePendingInterrupt(agentName: string): InterruptHandle | null {
  const latest = useRef<{ prompt: string; resolve: (value: string) => void } | null>(null);
  const [current, setCurrent] = useState<{
    prompt: string;
    resolve: (value: string) => void;
  } | null>(null);

  useLangGraphInterrupt<string>({
    /**
     * ══════════════════════════════════════════════════════════════════════════
     * `agentId` IS REQUIRED HERE. Omitting it silently breaks every HITL pause.
     * ══════════════════════════════════════════════════════════════════════════
     *
     * The hook resolves the agent as:
     *
     *   action.agentId ?? chatConfiguration?.agentId ?? "default"
     *
     * We use no `CopilotChatConfigurationProvider` (a v2 component), so without
     * this line the interrupt is scoped to an agent literally named "default"
     * while ours is `local_agent`. It then never matches, and `render` is never
     * called.
     *
     * The failure is quiet and misleading: the card still arrives via
     * `STATE_SNAPSHOT`, but `interrupt` stays null → the host renders it
     * non-interactive → every control is disabled. It looks like a frozen screen,
     * not a wiring error, and nothing in the network tab hints at it — the stream
     * is perfectly healthy.
     */
    agentId: agentName,
    render: ({ event, resolve }) => {
      const raw: unknown = event.value;
      latest.current = {
        // The BFF already normalises this to a string. The guard stays because
        // `dump_json_safe` returns strings verbatim and JSON-encodes everything
        // else, so both shapes are legal on the wire.
        prompt: typeof raw === "string" ? raw : JSON.stringify(raw ?? ""),
        resolve,
      };
      // Rendering is the component host's job — this hook contributes no DOM.
      // The hook's signature demands `string | ReactElement`, so an empty string
      // is the no-op. (This file is .ts, not .tsx, deliberately: it holds no JSX.)
      return "";
    },
  });

  // eslint-disable-next-line react-hooks/exhaustive-deps -- see the note inside
  useEffect(() => {
    // Deliberate, and the only way this can work. `render` above is invoked
    // during CopilotKit's OWN render, so we cannot setState from there — React
    // forbids updating another component during its render. Capturing into a ref
    // and committing on every commit is the sanctioned bridge.
    //
    // No dependency array is equally deliberate: the ref's identity never
    // changes, so any array would freeze this at the first value. The setState is
    // idempotent once the interrupt stops changing, so it does not loop.
    setCurrent(latest.current);
  });

  const respond = useCallback(
    (value: string) => {
      const trimmed = value.trim();
      if (!current || trimmed.length === 0) return;
      current.resolve(trimmed);
      setCurrent(null);
      latest.current = null;
    },
    [current],
  );

  return current ? { prompt: current.prompt, respond } : null;
}

/**
 * Validate `ui_component`, and hold the last good one.
 *
 * Stickiness is required, not a nicety. No backend node ever writes
 * `ui_component: None`, and the re-entrant resume path sends no snapshot — so a
 * hook that dropped the card whenever a snapshot lacked one would blank the
 * screen mid-approval on every reconnect.
 */
function useStickyComponent(raw: unknown): {
  envelope: AgentSession["component"];
  problem: string | null;
} {
  const [held, setHeld] = useState<AgentSession["component"]>(null);
  const [problem, setProblem] = useState<string | null>(null);

  const result = useMemo(() => parseEnvelope(raw), [raw]);
  const next = describe(result);

  // Adjusting state during render is a supported React pattern for derived
  // values, and the right one here: an effect would commit a render with the
  // stale card first, then immediately re-render with the new one. On an
  // approval screen that flash is the difference between "the card updated" and
  // "the card flickered".
  if (next.envelope !== undefined && next.envelope !== held) setHeld(next.envelope);
  if (next.problem !== problem) setProblem(next.problem);

  return { envelope: held, problem };
}

/**
 * `envelope: undefined` means "leave the held card alone".
 *
 * That is distinct from null and it matters: `ui_component` is absent on the
 * re-entrant resume path, which replays the interrupt with no state snapshot at
 * all. Treating absence as "clear it" blanks the screen mid-approval.
 */
function describe(result: ReturnType<typeof parseEnvelope>): {
  envelope: AgentSession["component"] | undefined;
  problem: string | null;
} {
  switch (result.kind) {
    case "empty":
      return { envelope: undefined, problem: null };
    case "ok":
      return { envelope: result.envelope, problem: null };
    case "unknown-component":
      return { envelope: undefined, problem: `unknown-component:${result.name}` };
    case "unsupported-version":
      return {
        envelope: undefined,
        problem: `unsupported-version:${result.name}:${result.version}`,
      };
    case "invalid-props":
      return {
        envelope: undefined,
        problem: `invalid-props:${result.name}:${result.issues.join("; ")}`,
      };
  }
}
