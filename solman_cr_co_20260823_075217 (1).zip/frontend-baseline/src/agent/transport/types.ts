import type { AnyAgentComponentEnvelope } from "../contract";

/**
 * agent/transport/types.ts
 *
 * The entire vendor surface, restated in our vocabulary.
 *
 * Nothing in `features/` or `app/` imports `@copilotkit/*` — that is a lint error
 * (eslint.config.mjs). They import this instead. The implementation behind it
 * lives in `./copilotkit/`, and it is the only directory that may change when we
 * move to CopilotKit v2.
 *
 * ── Why bother ──────────────────────────────────────────────────────────────
 * This is a dated risk, not vendor paranoia. `@copilotkit/react-core@1.68.1`
 * ships *two* parallel APIs (v1 and a `./v2` surface) and a `2.0.0-next.1`
 * prerelease exists. The interrupt hook is `useLangGraphInterrupt` in v1 and
 * `useInterrupt` in v2. `@ag-ui/client` moved 0.0.42 → 0.0.58 while the backend
 * team's bridge stayed pinned. Welding thirty components to whichever API we
 * picked this quarter is how a codebase becomes unupgradable.
 *
 * The test that this worked: a future v2 migration PR must not touch `features/`.
 */

export type AgentRunStatus =
  /** No run has started yet. */
  | "idle"
  /** A run is in flight; the graph is working. */
  | "running"
  /** The graph is parked at `interrupt()` — the user's turn. */
  | "awaiting-input"
  /** The run ended without an interrupt and without a further card. */
  | "finished"
  | "failed";

export interface TranscriptEntry {
  id: string;
  role: "user" | "assistant";
  content: string;
}

export interface RunProgress {
  /**
   * Raw LangGraph node name (`node_8`, `node_20b`, …).
   *
   * These are implementation identifiers, never user-facing language. Map them
   * through a label table and fall back to something generic — no user should
   * ever read `node_20b`.
   */
  nodeName: string | null;
  running: boolean;
}

/**
 * A pending `interrupt()`.
 *
 * `respond` must be used instead of sending a new message: the graph is blocked
 * on `Command(resume=...)`, and only this interrupt's resolver delivers it.
 * Sending a message instead starts a *new run* against a graph that is still
 * parked — which looks like the UI hanging.
 */
export interface InterruptHandle {
  /** The prompt string the graph passed to `interrupt()`. */
  prompt: string;
  respond: (value: string) => void;
}

export interface AgentError {
  code:
    | "upstream_unreachable"
    | "upstream_idle"
    | "run_timeout"
    | "agent_error"
    | "contract_violation"
    | "thread_expired"
    | "unknown";
  message: string;
  /**
   * Whether a retry is safe.
   *
   * `run_timeout` is deliberately NOT retryable: a CR may already have been
   * created and `solman_write` is not idempotent. The UI must tell the user to
   * check SolMan rather than offer a button that could double-submit.
   */
  retryable: boolean;
  correlationId?: string | undefined;
}

export interface AgentSession {
  threadId: string;
  status: AgentRunStatus;
  /**
   * The card the agent last named.
   *
   * Sticky on purpose. No backend node ever writes `ui_component: None`, and the
   * re-entrant resume path replays the interrupt with **no state snapshot at
   * all** (BACKEND_CONTRACT §2.4). If we cleared this on every run boundary the
   * card would blink out of existence on reconnect — which is exactly the
   * flicker the backend team's own frontend had to work around.
   */
  component: AnyAgentComponentEnvelope | null;
  /** Set when the last envelope failed validation, so the host can explain why. */
  componentProblem: string | null;
  transcript: TranscriptEntry[];
  progress: RunProgress;
  interrupt: InterruptHandle | null;
  error: AgentError | null;
  /** Start a fresh run by sending the opening user message. */
  start: (message: string) => void;
}
