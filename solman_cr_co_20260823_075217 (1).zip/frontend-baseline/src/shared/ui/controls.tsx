"use client";

import type { ChangeEvent, ReactNode } from "react";
import { useId } from "react";
import styles from "./controls.module.css";

/**
 * shared/ui/controls.tsx
 *
 * Form primitives shared across the cards. Nothing agent-aware lives here — this
 * module is at the bottom of the dependency rule and knows nothing about
 * `agent/` or any feature.
 */

type ButtonVariant = "primary" | "secondary" | "danger" | "ghost";

export function Button({
  children,
  variant = "secondary",
  disabled = false,
  onClick,
  type = "button",
}: {
  children: ReactNode;
  variant?: ButtonVariant;
  disabled?: boolean;
  onClick?: () => void;
  type?: "button" | "submit";
}) {
  return (
    <button
      type={type}
      className={`${styles.btn} ${styles[variant]}`}
      disabled={disabled}
      onClick={onClick}
    >
      {children}
    </button>
  );
}

interface FieldShellProps {
  label: string;
  required?: boolean;
  error?: string | null;
  hint?: string | null;
  children: (id: string, describedBy: string | undefined) => ReactNode;
}

/**
 * Wires label, error and hint to the control by id.
 *
 * Done once here rather than per card because the draft review screen alone
 * renders 118 of these, and an unlabelled control on a regulated approval form
 * is an accessibility defect at scale, not a detail.
 */
export function Field({ label, required = false, error, hint, children }: FieldShellProps) {
  const id = useId();
  const errorId = `${id}-error`;
  const hintId = `${id}-hint`;
  const describedBy =
    [error ? errorId : null, hint ? hintId : null].filter(Boolean).join(" ") || undefined;

  return (
    <div className={error ? `${styles.field} ${styles.invalid}` : styles.field}>
      <label className={styles.label} htmlFor={id}>
        {label}
        {required ? (
          <span aria-hidden="true" className={styles.required}>
            *
          </span>
        ) : null}
        {required ? <span className="visually-hidden"> (required)</span> : null}
      </label>
      {children(id, describedBy)}
      {hint ? (
        <p id={hintId} className={styles.hint}>
          {hint}
        </p>
      ) : null}
      {error ? (
        <p id={errorId} className={styles.error} role="alert">
          {error}
        </p>
      ) : null}
    </div>
  );
}

export function TextInput({
  id,
  value,
  onChange,
  placeholder,
  disabled = false,
  describedBy,
  list,
  onBlur,
}: {
  id: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string | undefined;
  disabled?: boolean;
  describedBy?: string | undefined;
  list?: string | undefined;
  onBlur?: () => void;
}) {
  return (
    <input
      id={id}
      className={styles.control}
      type="text"
      value={value}
      placeholder={placeholder}
      disabled={disabled}
      aria-describedby={describedBy}
      list={list}
      onBlur={onBlur}
      onChange={(event: ChangeEvent<HTMLInputElement>) => onChange(event.target.value)}
    />
  );
}

export function TextArea({
  id,
  value,
  onChange,
  placeholder,
  disabled = false,
  describedBy,
  rows = 3,
}: {
  id: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string | undefined;
  disabled?: boolean;
  describedBy?: string | undefined;
  rows?: number;
}) {
  return (
    <textarea
      id={id}
      className={`${styles.control} ${styles.multiline}`}
      value={value}
      rows={rows}
      placeholder={placeholder}
      disabled={disabled}
      aria-describedby={describedBy}
      onChange={(event: ChangeEvent<HTMLTextAreaElement>) => onChange(event.target.value)}
    />
  );
}

export function Select({
  id,
  value,
  options,
  onChange,
  disabled = false,
  describedBy,
  placeholder = "Select…",
}: {
  id: string;
  value: string;
  options: readonly string[];
  onChange: (value: string) => void;
  disabled?: boolean;
  describedBy?: string | undefined;
  placeholder?: string;
}) {
  return (
    <select
      id={id}
      className={`${styles.control} ${styles.select}`}
      value={value}
      disabled={disabled}
      aria-describedby={describedBy}
      onChange={(event: ChangeEvent<HTMLSelectElement>) => onChange(event.target.value)}
    >
      <option value="">{placeholder}</option>
      {options.map((option) => (
        <option key={option} value={option}>
          {option}
        </option>
      ))}
    </select>
  );
}
