"use client";

import { Fragment } from "react";
import styles from "./markdown.module.css";

/**
 * shared/ui/markdown.tsx
 *
 * A deliberately tiny markdown renderer that CANNOT emit HTML.
 *
 * ── Why not react-markdown ──────────────────────────────────────────────────
 * Because the only markdown we need to render comes from an LLM-authored backend
 * string, and the safest renderer is one with no HTML path at all. This handles
 * exactly what `nodes_outcome.py` produces — `**bold**`, blank-line paragraphs,
 * and `- ` bullets (e.g. `"**Root Cause:** …"`, `"**Reason:** … (Transaction ID:
 * …)"` at nodes_outcome.py:78-95) — and renders everything else as literal text.
 *
 * Every output node is a React element built from a string. There is no
 * `dangerouslySetInnerHTML` anywhere, which is also a lint error in this codebase
 * (eslint.config.mjs, ADR §3 rule 7). An `<img onerror=…>` in an agent message is
 * therefore just characters on screen.
 *
 * If richer markdown is ever genuinely needed, add it here — one file, one
 * review — rather than reaching for a general-purpose renderer with an HTML
 * escape hatch.
 */

interface MarkdownProps {
  children: string;
  /**
   * `| undefined` is explicit because CSS Module class lookups are typed
   * `string | undefined`, and `exactOptionalPropertyTypes` distinguishes
   * "absent" from "present and undefined".
   */
  className?: string | undefined;
}

export function Markdown({ children, className }: MarkdownProps) {
  const blocks = children.split(/\n{2,}/).filter((block) => block.trim().length > 0);

  return (
    <div className={className}>
      {blocks.map((block, blockIndex) => {
        const lines = block.split("\n");
        const isList = lines.every((line) => /^\s*[-*]\s+/.test(line));

        if (isList) {
          return (
            <ul key={blockIndex} className={styles.list}>
              {lines.map((line, i) => (
                <li key={i}>{renderInline(line.replace(/^\s*[-*]\s+/, ""))}</li>
              ))}
            </ul>
          );
        }

        return (
          <p key={blockIndex} className={styles.p}>
            {lines.map((line, i) => (
              <Fragment key={i}>
                {i > 0 ? <br /> : null}
                {renderInline(line)}
              </Fragment>
            ))}
          </p>
        );
      })}
    </div>
  );
}

/** `**bold**` and `` `code` ``. Anything else stays literal. */
function renderInline(text: string) {
  const parts = text.split(/(\*\*[^*]+\*\*|`[^`]+`)/g);
  return parts.map((part, i) => {
    if (part.startsWith("**") && part.endsWith("**") && part.length > 4) {
      return <strong key={i}>{part.slice(2, -2)}</strong>;
    }
    if (part.startsWith("`") && part.endsWith("`") && part.length > 2) {
      return <code key={i}>{part.slice(1, -1)}</code>;
    }
    return <Fragment key={i}>{part}</Fragment>;
  });
}
