"use client";

import type { ReactNode } from "react";
import styles from "./card.module.css";

/**
 * shared/ui/card.tsx
 *
 * The card shell every agent screen renders inside: title, body, footer, and
 * the meta strip.
 *
 * ── The footer strip is in the design, and mostly unfillable ────────────────
 * The comp shows `11th Feb, 26 21:13 pm · Processing Time: 30 sec · Token 23 ·
 * Cost $00023`. That maps exactly onto `_CARD_META` (ui_contract.py:105-114).
 *
 * But **no backend node calls `_meta()`** — the builder at :320-334 is dead
 * code. Our BFF fills `timestamp`; the other three stay empty until the backend
 * populates them (REQ-3). So each field renders independently and the strip
 * fills in progressively, with no frontend change needed when it does.
 */

export interface CardMetaLike {
  timestamp?: string | null;
  processing_time?: string | null;
  tokens?: number | string | null;
  cost?: string | null;
}

interface CardProps {
  title?: string | null | undefined;
  subtitle?: string | null | undefined;
  meta?: CardMetaLike | null | undefined;
  /** Dims the card and signals "not your turn" without hiding it. */
  inert?: boolean | undefined;
  children: ReactNode;
  footer?: ReactNode | undefined;
  /** Rendered opposite the title — e.g. the comp's "Reset Form" action. */
  headerAction?: ReactNode | undefined;
}

export function Card({
  title,
  subtitle,
  meta,
  inert = false,
  children,
  footer,
  headerAction,
}: CardProps) {
  return (
    <section
      className={inert ? `${styles.card} ${styles.inert}` : styles.card}
      aria-busy={inert}
    >
      {title || headerAction ? (
        <div className={styles.header}>
          {title ? <h2 className={styles.title}>{title}</h2> : <span />}
          {headerAction}
        </div>
      ) : null}
      {subtitle ? <p className={styles.subtitle}>{subtitle}</p> : null}
      <div className={styles.body}>{children}</div>
      {footer ? <div className={styles.footer}>{footer}</div> : null}
      <CardMetaStrip meta={meta} />
    </section>
  );
}

function CardMetaStrip({ meta }: { meta?: CardMetaLike | null | undefined }) {
  if (!meta) return null;

  const pills: Array<{ label: string; value: string }> = [];
  if (meta.tokens !== null && meta.tokens !== undefined) {
    pills.push({ label: "Token", value: String(meta.tokens) });
  }
  if (meta.cost) pills.push({ label: "Cost", value: meta.cost });

  const hasAnything = Boolean(meta.timestamp || meta.processing_time) || pills.length > 0;
  if (!hasAnything) return null;

  return (
    <div className={styles.meta}>
      {meta.timestamp ? <span>{formatTimestamp(meta.timestamp)}</span> : null}
      <div className={styles.metaPills}>
        {meta.processing_time ? (
          <span className={styles.metaText}>Processing Time: {meta.processing_time}</span>
        ) : null}
        {pills.map((pill) => (
          <span key={pill.label} className={styles.pill}>
            <span className={styles.pillLabel}>{pill.label}</span>
            <span className={styles.pillValue}>{pill.value}</span>
          </span>
        ))}
      </div>
    </div>
  );
}

/**
 * Accepts both shapes deliberately.
 *
 * Our BFF injects ISO 8601; the backend's schema comment describes a *display*
 * string ("11th Feb, 26 21:12 pm"). Both are legal, so parse and format when we
 * can and pass through untouched when we cannot — rather than rendering
 * "Invalid Date" the day the backend starts filling it in.
 */
function formatTimestamp(value: string): string {
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) return value;
  return parsed.toLocaleString(undefined, {
    day: "numeric",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  });
}
