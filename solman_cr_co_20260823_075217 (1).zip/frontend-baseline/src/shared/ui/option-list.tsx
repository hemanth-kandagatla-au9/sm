"use client";

import { useId, useState } from "react";
import type { AgentOption, DetailRow } from "@/agent/contract";
import styles from "./option-list.module.css";

/**
 * shared/ui/option-list.tsx
 *
 * Expandable, selectable option rows — used by templateOrCrPicker, cycleIdPicker
 * and fieldPrompt.
 *
 * It lives in `shared/` rather than in one of those features because a feature
 * may never import another feature (the dependency rule). Lifting genuinely
 * common UI here is the intended escape hatch; side-importing is not.
 *
 * ══════════════════════════════════════════════════════════════════════════════
 * THE INVARIANT THIS COMPONENT EXISTS TO PROTECT
 *
 *   Expanding a row must never select it.
 *
 * From AGUI_INTEGRATION.md:63 — *"Picking a baseline CR determines every field of
 * the resulting draft, so it must not be possible to select one as a side effect
 * of trying to read it."*
 *
 * A mis-click here silently rewrites every field of a change request. So the
 * disclosure control is a **sibling** button, not a nested one: the row body
 * selects, the chevron toggles, and `stopPropagation` is not relied upon —
 * nesting an interactive control inside another is also invalid HTML and breaks
 * keyboard traversal.
 *
 * There is a test for this (decision Q11). Do not "simplify" it into one button.
 * ══════════════════════════════════════════════════════════════════════════════
 */

interface OptionListProps {
  options: AgentOption[];
  selectedValue?: string | null;
  disabled?: boolean;
  onSelect: (value: string) => void;
  /** Radio semantics by default; false renders independent action buttons. */
  singleSelect?: boolean;
}

export function OptionList({
  options,
  selectedValue = null,
  disabled = false,
  onSelect,
  singleSelect = true,
}: OptionListProps) {
  const groupId = useId();

  if (options.length === 0) return null;

  return (
    <ul className={styles.list} role={singleSelect ? "radiogroup" : "list"}>
      {options.map((option) => (
        <OptionRow
          key={option.value}
          option={option}
          groupId={groupId}
          selected={selectedValue === option.value}
          disabled={disabled || option.disabled === true}
          onSelect={onSelect}
          singleSelect={singleSelect}
        />
      ))}
    </ul>
  );
}

function OptionRow({
  option,
  groupId,
  selected,
  disabled,
  onSelect,
  singleSelect,
}: {
  option: AgentOption;
  groupId: string;
  selected: boolean;
  disabled: boolean;
  onSelect: (value: string) => void;
  singleSelect: boolean;
}) {
  const [expanded, setExpanded] = useState(false);
  const panelId = `${groupId}-${option.value}-panel`;

  const details = option.details ?? [];
  // An empty array must NOT produce a chevron that expands to nothing
  // (AGUI_INTEGRATION.md:61): a row with no details renders no disclosure at all.
  const expandable = details.length > 0;

  return (
    <li className={selected ? `${styles.option} ${styles.selected}` : styles.option}>
      <div className={styles.row}>
        <button
          type="button"
          className={styles.select}
          role={singleSelect ? "radio" : undefined}
          aria-checked={singleSelect ? selected : undefined}
          disabled={disabled}
          onClick={() => onSelect(option.value)}
        >
          <span className={styles.label}>{option.label}</span>
          {option.badge ? <span className={styles.badge}>{option.badge}</span> : null}
        </button>

        {expandable ? (
          <button
            type="button"
            className={styles.disclosure}
            aria-expanded={expanded}
            aria-controls={panelId}
            // Deliberately NOT disabled when the card is inert: reading why the
            // agent suggested something stays available after you have answered.
            onClick={() => setExpanded((open) => !open)}
          >
            <span className="visually-hidden">
              {expanded ? "Hide details for" : "Show details for"} {option.label}
            </span>
            <span aria-hidden="true">{expanded ? "▾" : "▸"}</span>
          </button>
        ) : null}
      </div>

      {expandable && expanded ? (
        <div id={panelId} className={styles.panel}>
          <DetailRows rows={details} />
        </div>
      ) : null}
    </li>
  );
}

/**
 * `tone` is set by the agent, never inferred here.
 *
 * `positive` on Platform means *the agent matched it against the user's
 * platform* (AGUI_INTEGRATION.md:61). If you ever find yourself computing a tone
 * from a value in this file, the fix belongs in `ui_contract.py`.
 */
export function DetailRows({ rows }: { rows: DetailRow[] }) {
  if (rows.length === 0) return null;

  return (
    <dl className={styles.details}>
      {rows.map((row, index) => (
        <div
          key={`${row.label}-${index}`}
          className={row.wide === true ? `${styles.detailRow} ${styles.wide}` : styles.detailRow}
        >
          <dt>{row.label}</dt>
          <dd className={toneClass(row.tone)}>{row.value}</dd>
        </div>
      ))}
    </dl>
  );
}

/**
 * `tone` is an open string (see contract/schemas.ts) — the backend may add one.
 * Unknown tones render untinted rather than breaking the row.
 */
function toneClass(tone: string | null | undefined): string | undefined {
  if (tone === "positive") return styles.tonePositive;
  if (tone === "negative") return styles.toneNegative;
  return undefined;
}
