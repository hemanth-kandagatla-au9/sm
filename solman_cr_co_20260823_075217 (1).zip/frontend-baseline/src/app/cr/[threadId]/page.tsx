import { env } from "@/server/env";
import { CrAgentExperience } from "@/app/_client/cr-agent-experience";

/**
 * `/cr/[threadId]` — one conversation.
 *
 * A Server Component. It reads the server-only env, passes the agent name down,
 * and renders the client experience. That is the whole job: the server/client
 * boundary sits exactly at the agent session (ADR 0001 §6), because a live
 * streaming surface is honestly a client tree and pretending otherwise just puts
 * a `"use client"` in a confusing place.
 *
 * `agentName` is not a secret — it must match `LangGraphAGUIAgent(name=…)` at
 * agui_server.py:236 — but it is *validated* server-side in `env.ts`, so passing
 * it down beats duplicating the literal in client code where a typo fails with an
 * error that never mentions the name.
 */

export const dynamic = "force-dynamic";

export default async function ThreadPage({
  params,
}: {
  params: Promise<{ threadId: string }>;
}) {
  const { threadId } = await params;

  return (
    <CrAgentExperience agentName={env.AGUI_AGENT_NAME} threadId={threadId} />
  );
}
