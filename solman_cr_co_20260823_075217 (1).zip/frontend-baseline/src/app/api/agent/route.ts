import { env } from "@/server/env";
import { createAgentEndpoint } from "@/server/agent-gateway/runtime";
import { resolveSession } from "@/server/auth/session";
import { log } from "@/server/observability/logger";
import {
  CORRELATION_HEADER,
  newCorrelationId,
  runWithRequestContext,
} from "@/server/request-context";

/**
 * POST /api/agent — the BFF.
 *
 * ── Why this route exists at all ────────────────────────────────────────────
 * The browser speaks CopilotKit's protocol; `agui_server.py` speaks AG-UI over
 * SSE. Something has to translate. The backend team runs that translator as a
 * separate Node process today (`agui_runtime/`, port 8006) and their README
 * wonders whether the browser could just talk to Python directly.
 *
 * It cannot, in production, and this is verifiable rather than a matter of
 * taste. The CopilotKit config field for a direct browser→agent connection is
 * named `agents__unsafe_dev_only`, documented as *"For development only -
 * production requires CopilotRuntime"* (@copilotkit/core@1.68.1). When a library
 * names a field `__unsafe_dev_only`, that is the answer.
 *
 * So we keep the runtime and host it here instead — same translation, one fewer
 * deployable, one auth boundary instead of two. And because it is our code, it
 * is also where we close the gaps the backend has today: a client-writable state
 * channel, a `RAW` event firehose, and no correlation ID.
 */

/**
 * Node, not Edge. Three hard reasons:
 *   - `@copilotkit/runtime` is Node-targeted (see next.config.ts).
 *   - `AsyncLocalStorage` carries request context into the HttpAgent fetch hook.
 *   - Edge response-duration caps are hostile to a run containing a multi-second
 *     synchronous SAP write.
 */
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
/** Streaming responses must never be cached or collapsed. */
export const fetchCache = "force-no-store";

export async function POST(request: Request): Promise<Response> {
  const correlationId =
    request.headers.get(CORRELATION_HEADER) ?? newCorrelationId();

  // TEMP DEBUG — remove once the "8s call never reaches Python" bug is closed.
  const cloned = request.clone();
  cloned
    .text()
    .then((body) => {
      console.log(
        `[TEMP-DEBUG] /api/agent body (first 500 chars): ${body.slice(0, 500)}`,
      );
    })
    .catch(() => {});

  const session = await resolveSession(request);
  // With auth deferred (decision Q2) this never rejects. The branch is here so
  // that turning auth on is a change in resolveSession() and nowhere else.
  if (session === null) {
    return Response.json(
      { error: "unauthorized", correlationId },
      { status: 401, headers: { [CORRELATION_HEADER]: correlationId } },
    );
  }

  return runWithRequestContext(
    { correlationId, session: null, startedAt: Date.now() },
    async () => {
      log.info("bff.run_start", { agent: env.AGUI_AGENT_NAME });

      // No vendor SDK is named in this file. The runtime lives behind
      // server/agent-gateway/, which is the only place allowed to know which
      // agent framework we are on (ADR 0001 §4).
      const { handleRequest } = createAgentEndpoint(session);

      try {
        const response = await handleRequest(request);
        // The body is a stream. We attach a header and return immediately —
        // reading it here would buffer the run and destroy backpressure.
        const headers = new Headers(response.headers);
        headers.set(CORRELATION_HEADER, correlationId);
        return new Response(response.body, {
          status: response.status,
          statusText: response.statusText,
          headers,
        });
      } catch (error) {
        log.error("bff.run_failed", {
          error: error instanceof Error ? error.message : String(error),
        });
        return Response.json(
          {
            error: "agent_run_failed",
            message: "The agent service could not be reached.",
            correlationId,
          },
          { status: 502, headers: { [CORRELATION_HEADER]: correlationId } },
        );
      }
    },
  );
}
