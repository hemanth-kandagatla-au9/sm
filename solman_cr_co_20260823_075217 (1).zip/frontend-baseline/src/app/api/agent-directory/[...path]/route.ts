import { env } from "@/server/env";
import { downstreamAuthHeaders, resolveSession } from "@/server/auth/session";
import { log } from "@/server/observability/logger";
import {
  CORRELATION_HEADER,
  newCorrelationId,
  runWithRequestContext,
} from "@/server/request-context";

/**
 * /api/agent-directory/[...path] — proxy for the lookup-data REST helpers.
 *
 * `agui_server.py` exposes five small lookup endpoints (platforms,
 * target-systems, templates, jira-lookup, ui-contract) that back dropdowns and
 * dev-time contract checks. The opening mode-choice/intake-form screens used to
 * be REST too (entry, cr-mode) but those are now graph nodes —
 * `node_0_show_entry`/`node_0_wait` in `agents/nodes/nodes_gateway.py` — and ride
 * the same `AgentState.ui_component` + `interrupt()` channel as every other
 * HITL card, so they no longer pass through this proxy.
 *
 * Three reasons the remaining lookups still go through us rather than being
 * called from the browser:
 *
 *   1. **One origin.** The backend's CORS is pinned to port 8005 with a regex
 *      (`agui_server.py:65-76`) — a Next app on 3000 is rejected outright. We
 *      could ask for the pin to be widened; not needing it at all is better.
 *   2. **Caching the backend cannot do.** `/api/platforms` is `@lru_cache`d for
 *      the whole process lifetime (`agui_server.py:134`), so a new platform in
 *      Neo4j needs a backend restart to appear. A short TTL here is strictly
 *      better than that and costs nothing.
 *   3. **One auth boundary.** When a token exists it is injected in exactly one
 *      place, the same place the agent stream uses.
 *
 * Deliberately thin: path passthrough, cache headers, error normalisation.
 */

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** Endpoints whose answers are stable enough to cache, and for how long. */
const CACHE_TTL_SECONDS: Record<string, number> = {
  "api/ui-contract": 300,
  "api/platforms": 60,
  "api/target-systems": 60,
  "api/templates": 60,
};

export async function GET(
  request: Request,
  context: { params: Promise<{ path: string[] }> },
): Promise<Response> {
  return proxy(request, context, "GET");
}

export async function POST(
  request: Request,
  context: { params: Promise<{ path: string[] }> },
): Promise<Response> {
  return proxy(request, context, "POST");
}

async function proxy(
  request: Request,
  context: { params: Promise<{ path: string[] }> },
  method: "GET" | "POST",
): Promise<Response> {
  const correlationId = newCorrelationId();
  const { path } = await context.params;
  const session = await resolveSession(request);

  return runWithRequestContext(
    { correlationId, session: null, startedAt: Date.now() },
    async () => {
      const suffix = path.join("/");

      // Only the documented surface is reachable. Without this the route is an
      // open proxy to anything the backend host serves, which is a much larger
      // thing than "seven dropdown helpers".
      if (!suffix.startsWith("api/")) {
        return Response.json({ error: "not_found" }, { status: 404 });
      }

      const search = new URL(request.url).search;
      const target = `${env.AGUI_API_BASE}/${suffix}${search}`;

      try {
        // `body` is added conditionally rather than set to `undefined`:
        // exactOptionalPropertyTypes treats "absent" and "present and undefined"
        // as different, and RequestInit only permits the former.
        const init: RequestInit = {
          method,
          headers: {
            "content-type": "application/json",
            ...downstreamAuthHeaders(session),
            [CORRELATION_HEADER]: correlationId,
          },
          signal: AbortSignal.timeout(15_000),
          cache: "no-store",
        };
        if (method === "POST") init.body = await request.text();

        const upstream = await fetch(target, init);

        const bodyText = await upstream.text();
        const ttl = CACHE_TTL_SECONDS[suffix];

        if (!upstream.ok) {
          log.warn("directory.upstream_error", { suffix, status: upstream.status });
        }

        return new Response(bodyText, {
          status: upstream.status,
          headers: {
            "content-type": upstream.headers.get("content-type") ?? "application/json",
            "cache-control":
              upstream.ok && ttl !== undefined
                ? `private, max-age=${ttl}, stale-while-revalidate=${ttl * 2}`
                : "no-store",
            [CORRELATION_HEADER]: correlationId,
          },
        });
      } catch (error) {
        const isTimeout = error instanceof Error && error.name === "TimeoutError";
        log.error("directory.unreachable", {
          suffix,
          error: error instanceof Error ? error.message : String(error),
        });
        return Response.json(
          {
            error: isTimeout ? "upstream_timeout" : "upstream_unreachable",
            // The user-facing wording matters: this is the very first screen, and
            // "the agent service is unavailable" is more actionable than a stack.
            detail: "The agent service is unavailable. Please try again shortly.",
            correlationId,
          },
          { status: 503, headers: { [CORRELATION_HEADER]: correlationId } },
        );
      }
    },
  );
}
