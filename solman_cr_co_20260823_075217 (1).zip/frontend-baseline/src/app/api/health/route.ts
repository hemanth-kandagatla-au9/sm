import { env } from "@/server/env";

/**
 * GET /api/health — is the whole chain actually up?
 *
 * Reports on both hops separately, because "the frontend is up" and "the agent
 * is reachable" fail independently and the difference is the first thing anyone
 * asks. Mirrors the backend team's own two-command check
 * (`curl :8084/api/ui-contract` and `curl :8006/health`) with one call.
 *
 * `/copilotkit/health` is a real endpoint — ag_ui_langgraph registers it
 * alongside the POST handler (endpoint.py:34-42) — so this is a genuine
 * round-trip, not a TCP ping.
 */

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

interface ProbeResult {
  ok: boolean;
  status?: number;
  ms: number;
  detail?: string;
}

async function probe(url: string): Promise<ProbeResult> {
  const started = Date.now();
  try {
    const response = await fetch(url, {
      signal: AbortSignal.timeout(5_000),
      cache: "no-store",
    });
    return { ok: response.ok, status: response.status, ms: Date.now() - started };
  } catch (error) {
    return {
      ok: false,
      ms: Date.now() - started,
      detail: error instanceof Error ? error.message : String(error),
    };
  }
}

export async function GET(): Promise<Response> {
  const agentHealthUrl = `${env.AGUI_BACKEND_URL.replace(/\/$/, "")}/health`;
  const contractUrl = `${env.AGUI_API_BASE.replace(/\/$/, "")}/api/ui-contract`;

  const [agent, contract] = await Promise.all([probe(agentHealthUrl), probe(contractUrl)]);

  const ok = agent.ok && contract.ok;

  return Response.json(
    {
      ok,
      frontend: { ok: true },
      agentStream: { url: agentHealthUrl, ...agent },
      directory: { url: contractUrl, ...contract },
      agentName: env.AGUI_AGENT_NAME,
    },
    // 503 rather than 200-with-a-flag: a health endpoint that always returns 200
    // is invisible to every load balancer and uptime check that would use it.
    { status: ok ? 200 : 503, headers: { "cache-control": "no-store" } },
  );
}
