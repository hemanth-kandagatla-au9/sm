"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { AgentComponentHost } from "@/agent/registry";
import { AgentProvider, useAgentSession } from "@/agent/transport";
import { RunIndicator, Transcript } from "@/features/cr-conversation";
import { COMPONENT_REGISTRY, REGISTERED_NAMES } from "./component-registry";
import styles from "./experience.module.css";

/**
 * app/_client/cr-agent-experience.tsx
 *
 * The composition root. One phase, one renderer.
 *
 * The opening cards (mode choice → intake form) are no longer a REST detour —
 * `node_0_show_entry`/`node_0_wait` (agents/nodes/nodes_gateway.py) emit them as
 * ordinary `ui_component` + `interrupt()` turns, identical to every downstream
 * HITL card. The graph is kicked off once on mount with an empty message; from
 * then on everything rides `AgentState.ui_component` on the AG-UI event stream.
 *
 * Nothing in this file inspects props to guess a stage — if you find yourself
 * adding a heuristic here, the fix belongs in `agui/ui_contract.py`.
 *
 * That rule is not stylistic. The previous iteration of this UI inferred which
 * screen to show by sniffing state (`labels.includes("Similarity score:")`,
 * `options.some(o => o.value === "approve")`). All of it is gone, and it should
 * not come back.
 */

const DIRECTORY = "/api/agent-directory";

interface CrAgentExperienceProps {
  agentName: string;
  threadId: string;
}

export function CrAgentExperience({ agentName, threadId }: CrAgentExperienceProps) {
  return (
    <AgentProvider agentName={agentName} threadId={threadId}>
      <CrFlow agentName={agentName} threadId={threadId} />
    </AgentProvider>
  );
}

function CrFlow({ agentName, threadId }: CrAgentExperienceProps) {
  const session = useAgentSession({ agentName, threadId });

  // State, not a ref: `turnKey` is read during render, and a ref read in
  // render is exactly the bug react-hooks/refs exists to catch.
  const [turn, setTurn] = useState(0);

  // Kick the graph off once on mount so node_0_show_entry fires and populates
  // `state.ui_component` with the opening card — there is no pre-graph REST
  // phase to wait on anymore.
  //
  // Dev-mode Strict Mode double-invokes this effect (mount → cleanup → mount)
  // with no unmount in between, so without a guard `start("")` fires twice
  // against the same threadId — two concurrent runs racing each other's
  // interrupt/resume. The ref survives the double-invoke; a `[]` dependency
  // array does not protect against it.
  const startedRef = useRef(false);
  const { start } = session;
  useEffect(() => {
    if (startedRef.current) return;
    startedRef.current = true;
    start("");
    // eslint-disable-next-line react-hooks/exhaustive-deps -- fire once per mount
  }, []);

  useContractDriftCheck();

  /**
   * Every card — mode choice, intake form, or any downstream HITL screen —
   * resumes the pending `interrupt()`.
   *
   * Starting a new message here instead would leave the graph parked on the
   * `Command(resume=...)` it is blocked on — which looks exactly like the UI
   * hanging, and is the single easiest mistake to make in this integration.
   */
  const handleAgentRespond = useCallback(
    (value: string) => {
      setTurn((n) => n + 1);
      session.interrupt?.respond(value);
    },
    [session],
  );

  // ── In-graph ──────────────────────────────────────────────────────────────
  // The card is live only while the graph is actually parked at an interrupt.
  // Otherwise it renders read-only — never hidden, because a user must always be
  // able to see where they are, especially just after submitting.
  const awaitingUser = session.interrupt !== null;

  return (
    // One scrolling column, as the comp shows: the conversation above, the
    // agent's current card beneath. Not a chat panel beside a card panel.
    <div className={styles.stream}>
      <section aria-label="Conversation">
        <Transcript entries={session.transcript} />
        <RunIndicator progress={session.progress} />
        {session.error ? <RunError error={session.error} /> : null}
      </section>

      <main className={styles.cardSlot}>
        <AgentComponentHost
          registry={COMPONENT_REGISTRY}
          envelope={session.component}
          problem={session.componentProblem}
          onRespond={handleAgentRespond}
          interactive={awaitingUser}
          turnKey={`graph-${turn}-${awaitingUser ? "live" : "idle"}`}
          runActive={session.progress.running}
        />

        {/*
          Only shown once a run has demonstrably completed and produced no card.
          The wording is deliberately narrow: this component cannot tell an
          expired thread from a run that simply ended, and claiming the former
          when it might be the latter sent a previous debugging session in
          entirely the wrong direction.
        */}
        {session.status === "finished" && session.component === null ? (
          <p className={styles.empty}>
            The agent finished without anything to show. Start a new request, or check the
            conversation for what happened.
          </p>
        ) : null}

        {session.status === "running" && session.component === null ? (
          <p className={styles.empty}>Working on your request…</p>
        ) : null}
      </main>
    </div>
  );
}

/**
 * Run-level failures sit ABOVE the card, never replacing it: the card is context
 * the user needs in order to interpret the failure.
 *
 * `run_timeout` is deliberately never retryable — a change request may already
 * have been created, and `solman_write` is not idempotent. Offering a retry
 * button there risks a duplicate CR.
 */
function RunError({ error }: { error: NonNullable<ReturnType<typeof useAgentSession>["error"]> }) {
  return (
    <div className={styles.error} role="alert">
      <p className={styles.errorMessage}>{error.message}</p>
      {error.code === "run_timeout" ? (
        <p className={styles.errorAction}>
          <strong>Do not resubmit.</strong> Check Solution Manager first — a change request may
          already have been created.
        </p>
      ) : null}
      {error.correlationId ? (
        <p className={styles.errorRef}>
          Reference: <code>{error.correlationId}</code>
        </p>
      ) : null}
    </div>
  );
}

/**
 * Dev-time drift check against the live contract.
 *
 * Logs any component the agent can emit that this app cannot render, and vice
 * versa. Cheap insurance against the two sides being deployed out of step —
 * drift shows up in the console immediately instead of as a fallback card in QA.
 *
 * This is the runtime half. The build-time half (`npm run contract:check`) is the
 * one that should gate CI; a console warning nobody reads is not a control.
 */
function useContractDriftCheck(): void {
  useEffect(() => {
    if (process.env.NODE_ENV !== "development") return;

    fetch(`${DIRECTORY}/api/ui-contract`)
      .then((response) => (response.ok ? response.json() : Promise.reject(new Error("unavailable"))))
      .then((doc: { components?: Record<string, unknown>; contract_version?: number }) => {
        const backendNames = Object.keys(doc.components ?? {});
        const missingHere = backendNames.filter((name) => !REGISTERED_NAMES.includes(name));
        const missingThere = REGISTERED_NAMES.filter((name) => !backendNames.includes(name));

        if (missingHere.length > 0) {
          console.error(
            "[agent-ui] The agent can emit components this app cannot render:",
            missingHere,
            "— these will render the fallback card.",
          );
        }
        if (missingThere.length > 0) {
          console.warn("[agent-ui] Registered components the agent never emits:", missingThere);
        }
        if (missingHere.length === 0 && missingThere.length === 0) {
          console.info(
            `[agent-ui] Registry matches contract v${doc.contract_version} (${backendNames.length} components).`,
          );
        }
      })
      .catch(() => {
        // Contract endpoint unreachable — not fatal. The fallback card still
        // covers us at runtime, and CI covers us at build time.
      });
  }, []);
}
