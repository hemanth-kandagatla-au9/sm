"use client";

import { CONTRACT_VERSION } from "@/agent/contract";
import type { ComponentRegistry } from "@/agent/registry";
import { CrIntakeForm, CrModeChoice, FeatureComingSoon } from "@/features/cr-intake";
import { TemplateOrCrPicker } from "@/features/cr-recommendations";
import { CycleIdPicker } from "@/features/cr-cycle";
import { DraftReviewCard } from "@/features/cr-draft-review";
import { SubmissionResultCard } from "@/features/cr-outcome";
import { FieldPrompt } from "@/features/cr-conversation";

/**
 * app/_client/component-registry.ts
 *
 * ══════════════════════════════════════════════════════════════════════════════
 * THE REGISTRY. The agent may render exactly these eight things and nothing else.
 * ══════════════════════════════════════════════════════════════════════════════
 *
 * The agent never ships UI. It names one of these components and supplies JSON
 * props. Anything not in this map cannot be rendered — that is the entire
 * security model of the Controlled generative-UI approach, and it is what makes
 * this safe on a regulated approval path.
 *
 * ── Why this file lives in app/ and not in agent/ ───────────────────────────
 * `agent/` may not import `features/` — dependencies point inward, and a registry
 * sitting in `agent/` would be a back door straight through that boundary. So
 * `agent/registry` owns the machinery (host, fallbacks, types) and this
 * composition root owns the map. `app/` is the only layer allowed to know about
 * every feature at once, which is exactly what composing a registry is.
 *
 * It is a client module because a registry is a map of React components, and
 * component references cannot cross the server→client serialisation boundary.
 *
 * ── Versioning, two axes ────────────────────────────────────────────────────
 * `minVersion`/`maxVersion` are per component so one component can take a
 * breaking change without freezing the other seven. Envelope-level versioning
 * alone would stall everything on any single change.
 *
 * Additive props must NOT bump the version: a frontend that ignores an unknown
 * prop still renders correctly, and our schemas strip unknown keys rather than
 * rejecting them (AGUI_INTEGRATION.md:88, agent/contract/schemas.ts).
 *
 * ── Adding a component ──────────────────────────────────────────────────────
 *   1. name + prop schema + builder in `agui/ui_contract.py` (backend)
 *   2. props interface in `agent/contract/types.ts` + validator in `schemas.ts`
 *   3. the component in a feature, then an entry here
 * All three must agree. The compiler catches 2↔3; `npm run contract:check`
 * catches 1↔3 against the live backend.
 */

const RANGE = { minVersion: 1, maxVersion: CONTRACT_VERSION } as const;

export const COMPONENT_REGISTRY: ComponentRegistry = {
  crModeChoice: { ...RANGE, Component: CrModeChoice },
  featureComingSoon: { ...RANGE, Component: FeatureComingSoon },
  crIntakeForm: { ...RANGE, Component: CrIntakeForm },
  templateOrCrPicker: { ...RANGE, Component: TemplateOrCrPicker },
  cycleIdPicker: { ...RANGE, Component: CycleIdPicker },
  draftReview: { ...RANGE, Component: DraftReviewCard },
  fieldPrompt: { ...RANGE, Component: FieldPrompt },
  submissionResult: { ...RANGE, Component: SubmissionResultCard },
};

/** Names this app can render. Used by the contract drift check. */
export const REGISTERED_NAMES = Object.keys(COMPONENT_REGISTRY);
