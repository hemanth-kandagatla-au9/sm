import type { Metadata } from "next";
import Link from "next/link";
import styles from "./shell.module.css";
import "./globals.css";

/**
 * Root layout — the application shell. A Server Component, and it stays one.
 *
 * ADR 0001 §6 puts the server/client boundary at the agent session, not here.
 * Everything above the session is streamable server-rendered chrome; everything
 * inside it is honestly a client tree. There is no `"use client"` in this file.
 *
 * ── What this shell deliberately does NOT show (decision Q19) ───────────────
 * The comp has a user chip ("Kelvin Johnson / Admin User"), an agent list with a
 * live-status dot, a role selector, and a "Recent Conversations" panel. We render
 * the *structure* — because the layout depends on it — but not fabricated
 * content: there is no authentication yet (Q2) and no thread-listing API
 * (Gap G-8), so every one of those values would be invented.
 *
 * The previous harness hardcoded a plausible-looking person and history. We do
 * not: screenshots outlive their context, and a fake identity on a change-control
 * tool is a bad habit to start. The slots are here and wire up the day the
 * platform provides them.
 *
 * All chrome is confined to this file and `shell.module.css`. If "standalone for
 * now" (Q8) becomes "embedded", this layer is deleted — not untangled.
 */

export const metadata: Metadata = {
  title: "Change Request Agent",
  description: "Draft and submit SAP Solution Manager change requests.",
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>
        <div className={styles.shell}>
          <nav className={styles.rail} aria-label="Workspaces">
            <Link href="/" className={styles.brand}>
              J&amp;J
            </Link>
          </nav>

          <aside className={styles.sidebar} aria-label="Agents">
            <Link href="/" className={styles.newChat}>
              New Chat
            </Link>
            <div>
              <p className={styles.sectionLabel}>Available Agents</p>
            </div>
          </aside>

          <div className={styles.main}>
            <header className={styles.header}>
              <div>
                <h1 className={styles.pageTitle}>AI SDLC Orchestration</h1>
                <p className={styles.breadcrumb}>
                  Projects <span className={styles.breadcrumbCurrent}>&gt; Change Request</span>
                </p>
              </div>
            </header>

            <div className={styles.canvas}>{children}</div>

            <p className={styles.disclaimer}>
              AI SDLC can make mistakes. Verify important information.
            </p>
          </div>
        </div>
      </body>
    </html>
  );
}
