import { redirect } from "next/navigation";
import { randomUUID } from "node:crypto";

/**
 * `/` — mint a thread and go.
 *
 * The thread ID is generated **on the server**, not by CopilotKit's default and
 * not by the browser. With auth deferred (decision Q2) this buys nothing today,
 * but it means turning on ownership checks later is a validation step against an
 * ID space we already control rather than a migration.
 *
 * It also makes every conversation addressable: `/cr/<id>` is shareable and
 * resumable, which matters because the backend has no thread-listing API
 * (BACKEND_CONTRACT Gap G-8) and we are not going to fake a history sidebar.
 */
export default function NewRequestPage(): never {
  redirect(`/cr/${randomUUID()}`);
}
