import "server-only";
import { AsyncLocalStorage } from "node:async_hooks";
import { randomUUID } from "node:crypto";

/**
 * server/request-context.ts
 *
 * Carries per-request context down to code that cannot receive it as an
 * argument — specifically the `fetch` hook we install on `HttpAgent`, which
 * CopilotKit calls for us and therefore never hands the incoming Request.
 *
 * `AsyncLocalStorage` is the standard Node answer to exactly this problem, and
 * it is why the BFF route must run on the Node runtime rather than Edge
 * (next.config.ts / route.ts both say so).
 *
 * Why this exists now, before there is any auth (decision Q2): the correlation
 * ID is useful immediately, and when a session does arrive it slots into the
 * same store without touching any call site.
 */

export interface RequestContext {
  /** Joins a browser session to a BFF log line to (eventually) a backend run. */
  correlationId: string;
  /** Null until auth is wired. The shape is here so nothing has to change later. */
  session: { userId: string; wwid: string } | null;
  startedAt: number;
}

const storage = new AsyncLocalStorage<RequestContext>();

export function newCorrelationId(): string {
  return randomUUID();
}

export function runWithRequestContext<T>(ctx: RequestContext, fn: () => T): T {
  return storage.run(ctx, fn);
}

/**
 * Returns null outside a request. Callers must handle that rather than assume —
 * a background task or a module-init path has no request, and pretending
 * otherwise produces a correlation ID that correlates nothing.
 */
export function getRequestContext(): RequestContext | null {
  return storage.getStore() ?? null;
}

export const CORRELATION_HEADER = "x-correlation-id";
