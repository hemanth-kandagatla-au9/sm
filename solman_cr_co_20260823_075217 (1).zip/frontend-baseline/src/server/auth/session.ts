import "server-only";

/**
 * server/auth/session.ts
 *
 * The auth seam — deliberately a no-op today (decision Q2: "no auth for now").
 *
 * This file exists so that *every* call site is already written as though a
 * session exists. Wiring real authentication later means implementing one
 * function, not threading a new concept through the BFF, the thread routing and
 * the directory proxy.
 *
 * ── What is NOT deferred ────────────────────────────────────────────────────
 * Two protections are active right now, because neither of them needs to know
 * who the user is:
 *
 *   1. The BFF forces `state: {}` on every upstream request. Without it a browser
 *      can write `wwid`, `scope_confirmed` or `submission_result` straight into
 *      the graph (BACKEND_CONTRACT §3.4). This is the single most valuable line
 *      in the gateway and it is unrelated to auth.
 *   2. Thread IDs are minted here rather than accepted from the client, so
 *      switching on ownership checks later is a validation step against an
 *      existing ID space, not a migration.
 *
 * ── What no frontend work can fix ───────────────────────────────────────────
 * `agui_server.py:42,44` bake `ACTOR_ID` and `WWID = "12345678"` into module
 * scope, and ag-ui-langgraph 0.0.42 does not plumb the request through to the
 * agent. So every CR this app creates is written to SAP as wwid=12345678 and all
 * sessions share one AgentCore memory actor. Fine for a demo; not shippable.
 * Tracked as BUG-4 in OPEN_QUESTIONS.md.
 */

export interface Session {
  userId: string;
  /** SAP WWID. Ignored by the backend today — see the note above. */
  wwid: string;
  displayName: string;
}

/** Decision Q19: a clearly-labelled placeholder, never a plausible fake person. */
const ANONYMOUS_SESSION: Session = {
  userId: "anonymous",
  wwid: "",
  displayName: "Unauthenticated session",
};

/**
 * Resolve the caller's session.
 *
 * Today: always the anonymous placeholder. Later: validate the platform token on
 * `request` and return the real user, or null to reject.
 */
export async function resolveSession(_request: Request): Promise<Session | null> {
  return ANONYMOUS_SESSION;
}

/**
 * Headers to send downstream on behalf of the caller.
 *
 * Empty today. When a token exists it is injected here and nothing else changes:
 * `HttpAgent` accepts a `headers` record, and the directory proxy uses the same
 * function.
 */
export function downstreamAuthHeaders(_session: Session | null): Record<string, string> {
  return {};
}
