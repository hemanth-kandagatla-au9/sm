import "server-only";
import { z } from "zod";

/**
 * src/env.ts — the environment contract.
 *
 * Two properties matter here, and both are deliberate:
 *
 * 1. `import "server-only"` makes this module a build error if it is ever
 *    imported from a Client Component. The backend URL, and later the service
 *    token, must never reach the browser bundle.
 *
 * 2. Every value is parsed once, at module load, and the process refuses to start
 *    on a bad config. A typo in AGUI_BACKEND_URL should fail at boot with a
 *    readable message — not three screens into a CR draft as an opaque fetch
 *    error.
 *
 * Note what is NOT here: there is no NEXT_PUBLIC_* variable at all. The browser
 * needs zero backend configuration, because it only ever talks to our own BFF at
 * a relative path (`/api/agent`). That is a direct consequence of the topology
 * decision in ADR 0001 §5 — and it is why re-pointing the upstream host later
 * (OPEN_QUESTIONS Q17) is a server-side env change with no client rebuild.
 */

const EnvSchema = z.object({
  /**
   * The AG-UI event stream. This is `POST /copilotkit` on the FastAPI host.
   *
   * Verified in BACKEND_CONTRACT §1.1: SSE, `data: {json}\n\n`, camelCase keys,
   * null fields omitted. Note the path is `/copilotkit`, NOT `/agent` — there is
   * no `/agent` endpoint in the backend.
   */
  AGUI_BACKEND_URL: z
    .string()
    .url("AGUI_BACKEND_URL must be an absolute URL, e.g. http://localhost:8084/copilotkit"),

  /**
   * Origin of the same FastAPI host, used for the seven `/api/*` REST helpers
   * (BACKEND_CONTRACT §1.5) that we proxy in ADR 0001 §5.7. Kept separate from
   * AGUI_BACKEND_URL because one is a full endpoint path and the other is an
   * origin — conflating them is how you end up with `//copilotkit/api/platforms`.
   */
  AGUI_API_BASE: z
    .string()
    .url("AGUI_API_BASE must be an absolute URL, e.g. http://localhost:8084"),

  /**
   * Must match `LangGraphAGUIAgent(name=...)` in agui_server.py:236. If these
   * disagree, CopilotKit resolves no agent and every run fails with a message
   * that does not mention the name mismatch. Defaulted, but validated.
   */
  AGUI_AGENT_NAME: z.string().min(1).default("local_agent"),

  NODE_ENV: z.enum(["development", "test", "production"]).default("development"),
});

export type Env = z.infer<typeof EnvSchema>;

function loadEnv(): Env {
  const parsed = EnvSchema.safeParse(process.env);

  if (!parsed.success) {
    // Fail loudly and readably. `z.prettifyError` is zod 3.25's formatter; the
    // manual join keeps this readable on older minors too.
    const issues = parsed.error.issues
      .map((issue) => `  - ${issue.path.join(".") || "(root)"}: ${issue.message}`)
      .join("\n");
    throw new Error(
      `Invalid environment configuration.\n${issues}\n\n` +
        `Copy .env.example to .env.local and fill it in. See docs/build/IMPLEMENTATION_LOG.md step 1.`,
    );
  }

  return parsed.data;
}

export const env: Env = loadEnv();
