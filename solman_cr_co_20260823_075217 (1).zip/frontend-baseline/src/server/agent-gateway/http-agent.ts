import "server-only";
import { HttpAgent } from "@ag-ui/client";
import { env } from "@/server/env";
import { log } from "../observability/logger";
import { downstreamAuthHeaders, type Session } from "../auth/session";
import { CORRELATION_HEADER, getRequestContext } from "../request-context";
import { SseFrameParser, serialiseFrame } from "./sse";
import { AgentStreamTransformer } from "./transforms";

/**
 * server/agent-gateway/http-agent.ts
 *
 * The single place that talks to Python.
 *
 * `HttpAgent` accepts a custom `fetch`
 * (`HttpAgentFetchFn = (url: string, requestInit: RequestInit) => Promise<Response>`),
 * which gives us both sides of the exchange in one hook:
 *
 *   request  → force `state: {}`, guard the resume payload, add correlation
 *   response → parse SSE, run the transforms, re-serialise, never buffer
 *
 * That is why the transforms live here rather than in the route handler: by the
 * time CopilotRuntime hands us a Response, the AG-UI stream has already been
 * translated into CopilotKit's own protocol and the AG-UI event types are gone.
 * This hook is the last point where the stream is still AG-UI.
 */

/** Fail fast if the host is not there at all. */
const CONNECT_TIMEOUT_MS = 10_000;
/**
 * No frame for this long means the upstream is wedged.
 *
 * Must exceed the slowest node. `solman_write` does a CSRF GET plus a POST to
 * SAP inside a synchronous node, and the backend writes NOTHING to the socket
 * while that runs — there is no heartbeat upstream (BACKEND_CONTRACT §1.2).
 * 120s is a guess pending real measurement in Phase 5; it is deliberately
 * generous, because a false positive here aborts a run that was fine.
 */
const IDLE_TIMEOUT_MS = 120_000;
/**
 * Total ceiling. On expiry the client must NOT offer a retry: a CR may already
 * have been created and `solman_write` is not idempotent.
 */
const TOTAL_TIMEOUT_MS = 15 * 60_000;

export function createAgentHttpAgent(session: Session | null): HttpAgent {
  return new HttpAgent({
    url: env.AGUI_BACKEND_URL,
    headers: {
      "content-type": "application/json",
      ...downstreamAuthHeaders(session),
    },
    fetch: gatewayFetch,
  });
}

const gatewayFetch = async (url: string, init: RequestInit): Promise<Response> => {
  const ctx = getRequestContext();
  const correlationId = ctx?.correlationId ?? "no-context";

  const controller = new AbortController();
  const signal =
    init.signal instanceof AbortSignal
      ? AbortSignal.any([init.signal, controller.signal])
      : controller.signal;

  const connectTimer = setTimeout(() => {
    controller.abort(new DOMException("connect_timeout", "TimeoutError"));
  }, CONNECT_TIMEOUT_MS);

  const totalTimer = setTimeout(() => {
    log.error("gateway.run_timeout", { totalTimeoutMs: TOTAL_TIMEOUT_MS });
    controller.abort(new DOMException("run_timeout", "TimeoutError"));
  }, TOTAL_TIMEOUT_MS);

  const started = Date.now();
  let upstream: Response;
  try {
    const upstreamHeaders = new Headers(init.headers);
    // `HttpAgent` (from @ag-ui/client) and the `headers` option passed to
    // `createAgentHttpAgent` both set a content-type header, and whatever
    // combines them does so additively — the result is a single header whose
    // value is the literal string "application/json, application/json" (or,
    // worse, two distinctly-cased keys — "Content-Type" and "content-type" —
    // surviving side by side in a plain object, since plain-object keys are
    // case-sensitive but HTTP header names are not). FastAPI/Starlette can't
    // match either malformed form against `application/json` and stops
    // treating the body as JSON, so it reaches the endpoint as an unparsed
    // string instead of a dict, and RunAgentInput validation fails with a
    // top-level "not a valid dictionary" 422 — every single time, regardless
    // of the body's content. `Headers.set()` is case-insensitive and replaces
    // rather than appends, so it's the only safe way to fix this up.
    upstreamHeaders.set("content-type", "application/json");
    upstreamHeaders.set(CORRELATION_HEADER, correlationId);

    const upstreamInit: RequestInit = {
      ...init,
      headers: upstreamHeaders,
      signal,
      cache: "no-store",
    };
    // Assigned conditionally: exactOptionalPropertyTypes forbids an explicit
    // `undefined` where RequestInit expects the property to be absent.
    const rewritten = rewriteRequestBody(init.body);
    if (rewritten !== undefined) upstreamInit.body = rewritten;

    upstream = await fetch(url, upstreamInit);
  } catch (error) {
    clearTimeout(connectTimer);
    clearTimeout(totalTimer);
    log.error("gateway.upstream_unreachable", {
      url,
      error: error instanceof Error ? error.message : String(error),
    });
    throw error;
  }
  clearTimeout(connectTimer);

  log.info("gateway.upstream_open", { status: upstream.status, ms: Date.now() - started });

  if (!upstream.ok || upstream.body === null) {
    clearTimeout(totalTimer);
    // A 422 arrives as JSON, not SSE — RunAgentInput failed validation before a
    // single frame was produced. Pass it through unchanged so the real message
    // survives; wrapping it here would hide the only useful detail.
    log.error("gateway.upstream_error", { status: upstream.status });
    return upstream;
  }

  const body = upstream.body.pipeThrough(createTransformStream(controller, totalTimer));

  return new Response(body, {
    status: upstream.status,
    statusText: upstream.statusText,
    headers: {
      "content-type": upstream.headers.get("content-type") ?? "text/event-stream",
      "cache-control": "no-cache, no-transform",
      connection: "keep-alive",
      [CORRELATION_HEADER]: correlationId,
    },
  });
};

/**
 * The streaming transform.
 *
 * Retains exactly one partial line plus the frame being assembled. It never
 * accumulates, so backpressure propagates from the browser all the way to
 * Python through the WHATWG stream chain.
 */
function createTransformStream(
  controller: AbortController,
  totalTimer: ReturnType<typeof setTimeout>,
): TransformStream<Uint8Array, Uint8Array> {
  const decoder = new TextDecoder();
  const encoder = new TextEncoder();
  const parser = new SseFrameParser();
  const transformer = new AgentStreamTransformer();

  let idleTimer: ReturnType<typeof setTimeout> | null = null;
  const resetIdle = () => {
    if (idleTimer) clearTimeout(idleTimer);
    idleTimer = setTimeout(() => {
      log.error("gateway.idle_timeout", { idleTimeoutMs: IDLE_TIMEOUT_MS });
      controller.abort(new DOMException("upstream_idle", "TimeoutError"));
    }, IDLE_TIMEOUT_MS);
    idleTimer.unref?.();
  };
  const clearTimers = () => {
    if (idleTimer) clearTimeout(idleTimer);
    clearTimeout(totalTimer);
  };

  resetIdle();

  return new TransformStream<Uint8Array, Uint8Array>({
    transform(chunk, ctrl) {
      resetIdle();
      for (const frame of parser.push(decoder.decode(chunk, { stream: true }))) {
        for (const out of transformer.transform(frame)) {
          ctrl.enqueue(encoder.encode(serialiseFrame(out)));
        }
      }
    },
    // NOTE: `Transformer` has no `cancel` hook. If the consumer cancels the
    // stream, `flush` does not run — so the timers are `unref()`ed above and
    // cannot hold the process open on their own.
    flush(ctrl) {
      const tail = parser.flush();
      if (tail) {
        // A frame without its terminating blank line means the stream was cut.
        // Emitting it is more useful than dropping it silently.
        log.warn("gateway.truncated_frame");
        for (const out of transformer.transform(tail)) {
          ctrl.enqueue(encoder.encode(serialiseFrame(out)));
        }
      }
      transformer.finish();
      clearTimers();
    },
  });
}

/**
 * Rewrite the outbound `RunAgentInput`.
 *
 * Two guards, both cheap, both independent of authentication:
 *
 * 1. **`state` is forced to `{}`.** On any non-resume run the backend merges the
 *    client's `state` straight into the graph input, and the schema filter that
 *    is supposed to constrain it resolves to a no-op (BACKEND_CONTRACT §3.4). So
 *    a browser could otherwise set `wwid` — the SAP requestor on a regulated
 *    change request — or `scope_confirmed`, skipping the SOP-8794 guard. This
 *    single line closes that.
 *
 * 2. **The resume payload is inspected.** `ag-ui-langgraph` runs `json.loads` on
 *    a string resume value before `Command(resume=...)`, so `"654678"` reaches
 *    the graph as the integer 654678. `node_18` and `node_20b` coerce with
 *    `str()`; `node_9` and `node_4` do not, and raise AttributeError mid-node
 *    (BUG-3). We cannot fix the value without corrupting the user's answer, so we
 *    log it loudly and pass it through — the backend fix is the real one.
 */
function rewriteRequestBody(body: BodyInit | null | undefined): BodyInit | null | undefined {
  if (typeof body !== "string") return body;

  let parsed: unknown;
  try {
    parsed = JSON.parse(body);
  } catch {
    log.warn("gateway.request_body_unparseable");
    return body;
  }
  if (typeof parsed !== "object" || parsed === null) return body;

  const input = parsed as Record<string, unknown>;

  const clientState = input["state"];
  if (clientState && typeof clientState === "object" && Object.keys(clientState).length > 0) {
    log.warn("gateway.client_state_discarded", { keys: Object.keys(clientState) });
  }
  // `state` is a REQUIRED key on RunAgentInput (no default) — omitting it is a
  // 422, so this must be `{}` rather than deleted.
  input["state"] = {};

  const forwarded = input["forwardedProps"];
  if (forwarded && typeof forwarded === "object") {
    const command = (forwarded as Record<string, unknown>)["command"];
    if (command && typeof command === "object") {
      inspectResumeValue((command as Record<string, unknown>)["resume"]);
    }
  }

  return JSON.stringify(input);
}

function inspectResumeValue(resume: unknown): void {
  if (typeof resume !== "string") return;
  try {
    const reparsed: unknown = JSON.parse(resume);
    if (typeof reparsed !== "string") {
      log.warn("gateway.resume_value_json_parseable", {
        preview: resume.slice(0, 40),
        parsedType: reparsed === null ? "null" : typeof reparsed,
        note: "ag-ui-langgraph will pass a non-string to Command(resume=); node_9/node_4 do not coerce (BUG-3)",
      });
    }
  } catch {
    // Not valid JSON — which is the safe case.
  }
}

function toHeaderRecord(headers: HeadersInit | undefined): Record<string, string> {
  if (!headers) return {};
  if (headers instanceof Headers) return Object.fromEntries(headers.entries());
  if (Array.isArray(headers)) return Object.fromEntries(headers);
  return { ...headers };
}
