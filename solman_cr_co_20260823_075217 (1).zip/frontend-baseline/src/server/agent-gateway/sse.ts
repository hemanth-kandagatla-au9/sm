import "server-only";

/**
 * server/agent-gateway/sse.ts
 *
 * A streaming SSE frame codec.
 *
 * The backend's encoder is deliberately minimal (BACKEND_CONTRACT §1.1): every
 * event is `data: {json}\n\n` with **no `event:` name, no `id:`, no `retry:`**.
 * All discrimination happens on the JSON `type` field. So this codec only needs
 * to understand `data:` lines — but it must handle them correctly across chunk
 * boundaries, because a JSON payload carrying a 118-row draftReview tree will
 * absolutely be split across TCP reads.
 *
 * ── The rule this file exists to keep ───────────────────────────────────────
 * We never buffer the whole stream. Not `.text()`, not an accumulating array.
 * The only retained state is one partial line plus the frame currently being
 * assembled. Backpressure is inherited from the WHATWG stream chain, which only
 * works if nothing in the middle eagerly drains it.
 */

export interface SseFrame {
  /** Concatenated `data:` payload. Usually one JSON object. */
  data: string;
  /** Comment lines (`: …`), including heartbeats. Preserved so we can pass them on. */
  comments: string[];
}

/** Serialise a frame back to the wire. Mirrors ag_ui/encoder/encoder.py:28-32. */
export function serialiseFrame(frame: SseFrame): string {
  const parts: string[] = [];
  for (const comment of frame.comments) parts.push(`: ${comment}\n`);
  if (frame.data.length > 0) {
    // Multi-line data must be re-emitted as one `data:` line per line.
    for (const line of frame.data.split("\n")) parts.push(`data: ${line}\n`);
  }
  parts.push("\n");
  return parts.join("");
}

export function serialiseComment(text: string): string {
  return `: ${text}\n\n`;
}

/**
 * Incremental SSE parser.
 *
 * Feed it decoded text chunks; it yields whole frames as they complete and holds
 * onto whatever is left over.
 */
export class SseFrameParser {
  private buffer = "";
  private dataLines: string[] = [];
  private comments: string[] = [];

  push(chunk: string): SseFrame[] {
    this.buffer += chunk;
    const frames: SseFrame[] = [];

    // Normalise CRLF so a proxy that rewrites line endings cannot break framing.
    let newlineIndex: number;
    while ((newlineIndex = this.buffer.indexOf("\n")) !== -1) {
      const rawLine = this.buffer.slice(0, newlineIndex).replace(/\r$/, "");
      this.buffer = this.buffer.slice(newlineIndex + 1);

      if (rawLine === "") {
        // Blank line = end of frame. Skip genuinely empty frames.
        if (this.dataLines.length > 0 || this.comments.length > 0) {
          frames.push({ data: this.dataLines.join("\n"), comments: this.comments });
          this.dataLines = [];
          this.comments = [];
        }
        continue;
      }

      if (rawLine.startsWith(":")) {
        this.comments.push(rawLine.slice(1).trimStart());
        continue;
      }

      if (rawLine.startsWith("data:")) {
        // Per spec a single leading space after the colon is stripped.
        const value = rawLine.slice(5);
        this.dataLines.push(value.startsWith(" ") ? value.slice(1) : value);
        continue;
      }

      // `event:` / `id:` / `retry:` are not emitted by this backend. If one ever
      // appears we drop it rather than guess — and the caller can notice via the
      // absence, since every real payload arrives on `data:`.
    }

    return frames;
  }

  /**
   * Anything still buffered when the upstream closes. A well-behaved stream ends
   * on a blank line and this returns null; a truncated one does not, and the
   * partial frame is worth surfacing rather than silently dropping.
   */
  flush(): SseFrame | null {
    if (this.dataLines.length === 0 && this.comments.length === 0) return null;
    const frame = { data: this.dataLines.join("\n"), comments: this.comments };
    this.dataLines = [];
    this.comments = [];
    return frame;
  }
}
