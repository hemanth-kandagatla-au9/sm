import "server-only";
import { log } from "../observability/logger";
import { SnapshotReducer } from "./reductions";
import type { SseFrame } from "./sse";

/**
 * server/agent-gateway/transforms.ts
 *
 * The BFF's view of the AG-UI event stream.
 *
 * Scope is deliberately narrow (decision Q6): **drop `RAW`, and change nothing
 * about what the state looks like.** Full `STATE_SNAPSHOT` payloads pass through
 * untouched so we can see the real wire format while the contract is still
 * settling, and so the backend's expected `STATE_DELTA` work lands against
 * something honest.
 *
 * The payload-reduction transforms (snapshot diffing, stripping never-rendered
 * keys) live in `reductions.ts` and are wired in below via `SnapshotReducer`.
 * They are a no-op until `AGUI_REDUCE_SNAPSHOTS=true` (decision Q6) — the class
 * always runs, so flipping the flag is what it is documented to be: a flag
 * flip, not a code change discovered later to be missing.
 *
 * ── Why a class and not a pure function ─────────────────────────────────────
 * Three of these transforms are genuinely stateful across a run: node attribution
 * needs the current step, duplicate suppression needs the set of messages already
 * seen, and the run summary needs counters. One instance per stream, discarded
 * when it closes.
 */

/** Event names, from the AG-UI protocol enum (@ag-ui/core EventType). */
const EV = {
  RAW: "RAW",
  RUN_STARTED: "RUN_STARTED",
  RUN_FINISHED: "RUN_FINISHED",
  RUN_ERROR: "RUN_ERROR",
  STEP_STARTED: "STEP_STARTED",
  STEP_FINISHED: "STEP_FINISHED",
  STATE_SNAPSHOT: "STATE_SNAPSHOT",
  MESSAGES_SNAPSHOT: "MESSAGES_SNAPSHOT",
  CUSTOM: "CUSTOM",
  TOOL_CALL_START: "TOOL_CALL_START",
  TOOL_CALL_ARGS: "TOOL_CALL_ARGS",
  TOOL_CALL_END: "TOOL_CALL_END",
  TOOL_CALL_RESULT: "TOOL_CALL_RESULT",
  TEXT_MESSAGE_START: "TEXT_MESSAGE_START",
  TEXT_MESSAGE_CONTENT: "TEXT_MESSAGE_CONTENT",
  TEXT_MESSAGE_END: "TEXT_MESSAGE_END",
} as const;

/**
 * Graph nodes whose chat prose the card already carries.
 *
 * Keyed on the node name from `STEP_STARTED.stepName` — never on the text itself.
 * The old app matched hardcoded English sentences, which breaks on any copy edit
 * and cannot be localised (decision Q9).
 *
 *   node_17 — writes an intro whose options templateOrCrPicker already renders
 *             (nodes_outcome.py:258-274)
 *   node_20 — writes a markdown table of cycles that cycleIdPicker renders as a
 *             grid; the card's own `message` is already the intro half, because
 *             ui_contract splits it (nodes_outcome.py:722-726)
 *
 * Full suppression is correct for both: in each case the card shows the intro
 * AND the options, so nothing is lost. Truncating instead would require prose
 * matching, which is the thing we are avoiding.
 */
const CARD_DUPLICATING_NODES = new Set(["node_17", "node_20"]);

/**
 * Pydantic schemas from utils/schemas.py used with
 * `with_structured_output(..., method="function_calling")`.
 *
 * These are internal classifier calls, not user-facing actions — this graph has
 * no real tools at all (BACKEND_CONTRACT §4.1). If the adapter surfaces them as
 * TOOL_CALL_* events they would show up in the UI as `RelevanceCheck` running on
 * a regulated approval screen.
 *
 * Whether that actually happens is an open question I could not settle without a
 * live backend. So we filter, and we COUNT — a non-zero counter in Phase 3
 * answers the question as a side effect (decision Q16).
 */
const INTERNAL_TOOL_NAMES = new Set([
  "ExtractedField",
  "ExtractedFields",
  "RelevanceCheck",
  "RequestInfoOutput",
  "BuildDraftOutput",
  "PresentDraftOutput",
  "IntentRouterB",
  "FieldUpdateItem",
  "ParseUpdateIntent",
  "GetInformationOutput",
  "ApplyUpdateOutput",
  "SuggestCRsOutput",
  "PresentRecsOutput",
  "IntentRouterC",
  "ValidateSelectedCR",
  "FieldCompletenessCheck",
]);

interface AnyEvent {
  type?: string;
  [key: string]: unknown;
}

export interface TransformStats {
  rawDropped: number;
  internalToolCallsDropped: number;
  messagesSuppressed: number;
}

export class AgentStreamTransformer {
  private currentStep: string | null = null;
  /** Fingerprints of messages we have already attributed to a node. */
  private seenMessages = new Set<string>();
  /** Fingerprints suppressed because the emitting node's card carries them. */
  private suppressed = new Set<string>();
  /** Tool call ids whose START we dropped, so ARGS/END/RESULT go too. */
  private droppedToolCallIds = new Set<string>();
  /** Streamed message ids whose START we dropped, so CONTENT/END go too. */
  private suppressedMessageIds = new Set<string>();
  /** No-op until AGUI_REDUCE_SNAPSHOTS=true — see the class-level note above. */
  private reducer = new SnapshotReducer();

  private sawInterrupt = false;
  private sawComponent = false;
  private sawStateSnapshot = false;

  readonly stats: TransformStats = {
    rawDropped: 0,
    internalToolCallsDropped: 0,
    messagesSuppressed: 0,
  };

  /**
   * Transform one frame into zero or more outbound frames.
   *
   * Non-JSON frames (comments, heartbeats) pass straight through — we do not
   * want to swallow a keep-alive we ourselves may come to depend on.
   */
  transform(frame: SseFrame): SseFrame[] {
    if (frame.data.length === 0) return [frame];

    let event: AnyEvent;
    try {
      event = JSON.parse(frame.data) as AnyEvent;
    } catch {
      // Unparseable payload. Pass it on rather than drop it: the client's error
      // handling is better placed to report it than a silent deletion here.
      log.warn("gateway.frame_unparseable", { preview: frame.data.slice(0, 200) });
      return [frame];
    }

    switch (event.type) {
      case EV.RAW:
        // One per LangGraph internal event, duplicating every typed event and
        // carrying prompts and model chunks. No upstream off switch.
        this.stats.rawDropped += 1;
        return [];

      case EV.STEP_STARTED:
        this.currentStep = asString(event["stepName"]);
        return [frame];

      case EV.STEP_FINISHED:
        // Deliberately do NOT clear currentStep here: messages produced by a node
        // can arrive in the snapshot emitted at its exit, i.e. after this event.
        return [frame];

      case EV.TOOL_CALL_START:
      case EV.TOOL_CALL_ARGS:
      case EV.TOOL_CALL_END:
      case EV.TOOL_CALL_RESULT:
        return this.filterToolCall(event, frame);

      case EV.TEXT_MESSAGE_START:
      case EV.TEXT_MESSAGE_CONTENT:
      case EV.TEXT_MESSAGE_END:
        return this.filterStreamedText(event, frame);

      case EV.STATE_SNAPSHOT:
        return this.handleStateSnapshot(event);

      case EV.MESSAGES_SNAPSHOT:
        return this.handleMessagesSnapshot(event);

      case EV.CUSTOM:
        if (event["name"] === "on_interrupt") {
          this.sawInterrupt = true;
          return [reserialise(this.normaliseInterrupt(event))];
        }
        return [frame];

      /**
       * ══════════════════════════════════════════════════════════════════════
       * NOTHING MAY BE EMITTED AFTER RUN_FINISHED OR RUN_ERROR.
       * ══════════════════════════════════════════════════════════════════════
       *
       * AG-UI treats the run as sealed once either arrives, and the client
       * verifier enforces it:
       *
       *   RUN_ERROR "Cannot send event type 'CUSTOM': The run has already
       *              finished with 'RUN_FINISHED'."  (code INCOMPLETE_STREAM)
       *
       * An earlier version of this file appended a `bff.run_summary` CUSTOM
       * frame here. It poisoned every run: CopilotKit rejected the stream, so
       * the interrupt and the final state snapshot were discarded and the UI
       * showed a finished run with no card — indistinguishable from an expired
       * thread. Cost a whole debugging session.
       *
       * The run statistics go to structured logs in `finish()` instead, where
       * they are actually useful. The client could not consume a custom event
       * here anyway — CopilotKit's hooks do not surface raw AG-UI events.
       */
      case EV.RUN_FINISHED:
        return [frame];

      case EV.RUN_ERROR:
        log.warn("gateway.run_error", { message: event["message"], code: event["code"] });
        return [frame];

      default:
        return [frame];
    }
  }

  /** Called when the upstream closes, so counters land even on a truncated run. */
  finish(): void {
    log.info("gateway.stream_closed", {
      ...this.stats,
      sawInterrupt: this.sawInterrupt,
      sawComponent: this.sawComponent,
    });
    if (this.stats.internalToolCallsDropped > 0) {
      // This resolves OPEN_QUESTIONS Q16 the first time it fires.
      log.warn("gateway.internal_tool_calls_observed", {
        count: this.stats.internalToolCallsDropped,
      });
    }
  }

  // ───────────────────────────────────────────────────────────────────────────

  /**
   * Suppress prose the card already carries — the streamed half.
   *
   * A message reaches the client by TWO independent paths, and both have to be
   * handled or the suppression does nothing:
   *
   *   1. streamed live as TEXT_MESSAGE_START/CONTENT/END  ← this method
   *   2. replayed in STATE_SNAPSHOT.messages and MESSAGES_SNAPSHOT
   *
   * An earlier version only did (2). `MESSAGES_SNAPSHOT` came back empty, which
   * looked like success — while the identical markdown table had already been
   * streamed into the transcript through (1). Suppression that covers one path
   * is worse than none, because it looks like it works.
   *
   * Keyed on the emitting node, never on the text. A copy edit upstream must not
   * silently re-enable the duplicate.
   */
  private filterStreamedText(event: AnyEvent, frame: SseFrame): SseFrame[] {
    const messageId = asString(event["messageId"]);

    if (event.type === EV.TEXT_MESSAGE_START) {
      if (this.currentStep !== null && CARD_DUPLICATING_NODES.has(this.currentStep)) {
        if (messageId) this.suppressedMessageIds.add(messageId);
        this.stats.messagesSuppressed += 1;
        log.debug("gateway.streamed_message_suppressed", { node: this.currentStep });
        return [];
      }
      return [frame];
    }

    // CONTENT and END follow their START.
    if (messageId && this.suppressedMessageIds.has(messageId)) return [];
    return [frame];
  }

  private filterToolCall(event: AnyEvent, frame: SseFrame): SseFrame[] {
    const id = asString(event["toolCallId"]);

    if (event.type === EV.TOOL_CALL_START) {
      const name = asString(event["toolCallName"]);
      if (name && INTERNAL_TOOL_NAMES.has(name)) {
        if (id) this.droppedToolCallIds.add(id);
        this.stats.internalToolCallsDropped += 1;
        return [];
      }
      return [frame];
    }

    // ARGS / END / RESULT follow their START.
    if (id && this.droppedToolCallIds.has(id)) return [];
    return [frame];
  }

  private handleStateSnapshot(event: AnyEvent): SseFrame[] {
    this.sawStateSnapshot = true;
    const snapshot = event["snapshot"];
    if (!isRecord(snapshot)) return [reserialise(event)];

    // (a) Attribute newly-appeared messages to the node currently running. This
    //     is what makes node-keyed suppression possible without prose matching.
    const messages = snapshot["messages"];
    if (Array.isArray(messages)) {
      for (const message of messages) {
        const fp = messageFingerprint(message);
        if (!fp || this.seenMessages.has(fp)) continue;
        this.seenMessages.add(fp);
        if (this.currentStep && CARD_DUPLICATING_NODES.has(this.currentStep)) {
          this.suppressed.add(fp);
          log.debug("gateway.message_suppressed", { node: this.currentStep });
        }
      }
      snapshot["messages"] = messages.filter((m) => {
        const fp = messageFingerprint(m);
        const drop = fp !== null && this.suppressed.has(fp);
        if (drop) this.stats.messagesSuppressed += 1;
        return !drop;
      });
    }

    // (b) Fill meta.timestamp on the card. `_meta()` exists in ui_contract.py but
    //     is never called by any node, so the designed footer would always be
    //     empty (decision Q13). Tokens and cost stay absent — those are the
    //     backend's to supply (REQ-3).
    const component = snapshot["ui_component"];
    if (isRecord(component)) {
      this.sawComponent = true;
      const props = component["props"];
      if (isRecord(props)) {
        const meta = isRecord(props["meta"]) ? props["meta"] : {};
        if (meta["timestamp"] === undefined || meta["timestamp"] === null) {
          props["meta"] = { ...meta, timestamp: new Date().toISOString() };
        }
      }
    }

    return [reserialise(event)];
  }

  private handleMessagesSnapshot(event: AnyEvent): SseFrame[] {
    const messages = event["messages"];
    if (!Array.isArray(messages)) return [reserialise(event)];

    event["messages"] = messages.filter((m) => {
      const fp = messageFingerprint(m);
      return !(fp !== null && this.suppressed.has(fp));
    });
    return [reserialise(event)];
  }

  /**
   * `dump_json_safe` returns a string verbatim and JSON-encodes anything else
   * (BACKEND_CONTRACT §2.3), so `value` is usually the raw prompt string but may
   * be encoded JSON. Normalise to a plain string once, here, so no client has to
   * repeat the `typeof raw === "string" ? raw : JSON.stringify(raw)` dance.
   */
  private normaliseInterrupt(event: AnyEvent): AnyEvent {
    const value = event["value"];
    event["value"] = typeof value === "string" ? value : JSON.stringify(value ?? "");
    return event;
  }
}

// ─────────────────────────────────────────────────────────────────────────────

function reserialise(event: AnyEvent): SseFrame {
  return { data: JSON.stringify(event), comments: [] };
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function asString(value: unknown): string | null {
  return typeof value === "string" && value.length > 0 ? value : null;
}

/**
 * Stable identity for a message across BOTH event shapes.
 *
 * `STATE_SNAPSHOT.messages` holds serialised LangChain messages (`type: "ai"`),
 * while `MESSAGES_SNAPSHOT.messages` holds AG-UI messages (`role: "assistant"`).
 * Their ids are not guaranteed to agree, so identity is role + content prefix.
 *
 * This is a fingerprint, not a prose match: the suppression *decision* is made by
 * node name, and this only re-finds the same message in a different envelope. It
 * survives copy edits and localisation, which string matching would not.
 */
function messageFingerprint(message: unknown): string | null {
  if (!isRecord(message)) return null;

  const rawRole = asString(message["role"]) ?? asString(message["type"]);
  if (!rawRole) return null;
  const role = normaliseRole(rawRole);

  const content = message["content"];
  const text =
    typeof content === "string"
      ? content
      : Array.isArray(content)
        ? content
            .map((part) => (isRecord(part) ? asString(part["text"]) ?? "" : ""))
            .join("")
        : "";

  if (text.length === 0) return null;
  return `${role}:${text.slice(0, 300)}`;
}

function normaliseRole(role: string): string {
  switch (role) {
    case "ai":
    case "AIMessageChunk":
    case "assistant":
      return "assistant";
    case "human":
    case "user":
      return "user";
    case "system":
      return "system";
    case "tool":
      return "tool";
    default:
      return role;
  }
}
