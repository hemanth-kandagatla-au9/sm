import "server-only";

/**
 * server/agent-gateway/reductions.ts
 *
 * Payload reduction — **written, and shipped disabled** (decision Q6).
 *
 * The backend sends the entire `AgentState` on every `STATE_SNAPSHOT`: ~20 times
 * per run, each carrying a 118-row `draftReview` tree, the full SAP OData
 * entities in `cr_id.data` / `template_id.data`, and the whole message list.
 * There is no `STATE_DELTA` path in ag-ui-langgraph 0.0.42.
 *
 * We decided to carry that for now, because seeing the real wire format while the
 * contract is still settling is worth more than an early optimisation, and the
 * backend is expected to add deltas (REQ-1).
 *
 * So this exists as a flag flip rather than a retrofit. "The backend will
 * implement it soon" is a reason to keep the seam warm, not a reason to have no
 * seam — retrofitting a stream transform after thirty components have been
 * written against raw events is a much worse day.
 *
 * ── Turning it on ───────────────────────────────────────────────────────────
 * Set `AGUI_REDUCE_SNAPSHOTS=true`. Do that when Phase 5 measurement shows the
 * payload actually hurts AND the backend has not shipped deltas — not before.
 */

export const REDUCTIONS_ENABLED = process.env["AGUI_REDUCE_SNAPSHOTS"] === "true";

/**
 * State keys the UI never reads.
 *
 * `draft_ui.draft_html` and `recommendations_html` are **LLM-generated HTML**
 * (state/state.py:50-54). Because reductions are off by default they currently
 * DO cross the wire — which is exactly why the lint rule banning any reference to
 * them (eslint.config.mjs, ADR §3 rule 7) is load-bearing rather than hygienic.
 * Passing them through is safe only because nothing renders them.
 *
 * The rest is telemetry the backend keeps for its own spans.
 */
const NEVER_RENDERED_KEYS = [
  "metrics",
  "first_draft_snapshot",
  "first_draft_accuracy",
  "task_input_tokens",
  "task_output_tokens",
  "task_cost_usd",
  "task_start_ts",
] as const;

// This is the ONE file allowed to name these keys: it is the code that strips
// them. The ban exists so no renderer can reach them, and a stripper that cannot
// name what it strips would be useless.
// eslint-disable-next-line no-restricted-syntax
const NEVER_RENDERED_DRAFT_UI_KEYS = ["draft_html", "recommendations_html"] as const;

export class SnapshotReducer {
  private previous: Record<string, unknown> | null = null;

  /**
   * Returns the snapshot to forward: the full object on the first call, then only
   * top-level keys whose serialised value changed.
   *
   * Top-level granularity is deliberate. Deep-diffing a 118-row tree costs more
   * than it saves, and the client replaces state wholesale by key anyway (the
   * agent owns every value — ADR §8), so a partial key would be meaningless.
   */
  reduce(snapshot: Record<string, unknown>): Record<string, unknown> {
    const stripped = stripNeverRendered(snapshot);

    if (!REDUCTIONS_ENABLED) return stripped;

    if (this.previous === null) {
      this.previous = stripped;
      return stripped;
    }

    const changed: Record<string, unknown> = {};
    for (const [key, value] of Object.entries(stripped)) {
      const before = this.previous[key];
      if (!stableEqual(before, value)) changed[key] = value;
    }
    this.previous = stripped;
    return changed;
  }
}

function stripNeverRendered(snapshot: Record<string, unknown>): Record<string, unknown> {
  if (!REDUCTIONS_ENABLED) return snapshot;

  const out: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(snapshot)) {
    if ((NEVER_RENDERED_KEYS as readonly string[]).includes(key)) continue;
    if (key === "draft_ui" && typeof value === "object" && value !== null) {
      const draftUi: Record<string, unknown> = {};
      for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
        if ((NEVER_RENDERED_DRAFT_UI_KEYS as readonly string[]).includes(k)) continue;
        draftUi[k] = v;
      }
      out[key] = draftUi;
      continue;
    }
    out[key] = value;
  }
  return out;
}

/**
 * Structural equality by serialisation.
 *
 * Slower than a deep walk in theory; in practice these are already-serialised
 * JSON values and `JSON.stringify` is native. Key order is stable because the
 * objects come from `JSON.parse` of the same producer.
 */
function stableEqual(a: unknown, b: unknown): boolean {
  if (a === b) return true;
  try {
    return JSON.stringify(a) === JSON.stringify(b);
  } catch {
    return false;
  }
}
