import "server-only";
import {
  CopilotRuntime,
  ExperimentalEmptyAdapter,
  copilotRuntimeNextJSAppRouterEndpoint,
} from "@copilotkit/runtime";
import { env } from "@/server/env";
import type { Session } from "../auth/session";
import { createAgentHttpAgent } from "./http-agent";

/**
 * server/agent-gateway/runtime.ts
 *
 * Constructs the CopilotKit runtime and its Next.js endpoint.
 *
 * ── Why this file exists ────────────────────────────────────────────────────
 * It was originally inline in `app/api/agent/route.ts`, and the vendor-containment
 * lint rule rejected it — correctly. `@copilotkit/*` is confined to
 * `agent/transport/copilotkit/` and `server/agent-gateway/`, and a route handler
 * is neither.
 *
 * That was the rule catching a real design smell rather than being pedantic: the
 * route now contains only composition (correlation, session, request context)
 * and holds no knowledge of which agent framework is underneath. When CopilotKit
 * v2 lands, this file changes and the route does not — which is exactly the
 * property the isolation boundary is supposed to buy.
 */

/**
 * The adapter is stateless and does no LLM work of its own — the agent runs its
 * own models inside LangGraph, so the runtime here is purely transport. Hoisted
 * because constructing it per request would be waste.
 */
const serviceAdapter = new ExperimentalEmptyAdapter();

export interface AgentEndpoint {
  handleRequest: (request: Request) => Response | Promise<Response>;
}

/**
 * Built per request so the downstream HttpAgent — and therefore its headers —
 * can depend on the caller. Those headers are empty today (auth is deferred,
 * decision Q2); the day a token exists, only `downstreamAuthHeaders` changes.
 */
export function createAgentEndpoint(session: Session | null): AgentEndpoint {
  /**
   * A plain record — deliberately NOT the factory form.
   *
   * `AgentsConfig` accepts a factory, and it typechecks, but v1's
   * `handleServiceAdapter` does this:
   *
   *   Promise.resolve(agents ?? {}).then((agents) => {
   *     const isAgentsListEmpty = !Object.keys(agents).length;
   *     if (isAgentsListEmpty && …) throw new CopilotKitMisuseError(
   *       "No default agent provided. Please provide a default agent…");
   *
   * `Promise.resolve(fn)` resolves to the *function*, whose `Object.keys` is
   * empty — so a factory throws there on every construction. Requests still
   * work (a different code path resolves the factory), which makes it worse:
   * the only symptom is a stream of `unhandledRejection` entries in the server
   * log for an app that appears healthy.
   *
   * Per-request construction already gives us what the factory was for: this
   * function runs per request, so `session` is in scope and the day a token
   * exists only `downstreamAuthHeaders` changes.
   */
  const runtime = new CopilotRuntime({
    agents: { [env.AGUI_AGENT_NAME]: createAgentHttpAgent(session) },
  });

  return copilotRuntimeNextJSAppRouterEndpoint({
    runtime,
    serviceAdapter,
    endpoint: "/api/agent",
  });
}
