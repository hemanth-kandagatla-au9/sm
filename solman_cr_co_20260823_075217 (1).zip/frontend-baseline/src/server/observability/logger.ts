import "server-only";
import { getRequestContext } from "../request-context";

/**
 * server/observability/logger.ts
 *
 * Structured, correlated, dependency-free logging.
 *
 * One line of JSON per event, with the correlation ID attached automatically. No
 * pino, no winston: this runs inside a Next route handler whose stdout is already
 * collected by the platform, and a logging library here would be a dependency
 * that buys nothing.
 *
 * Every log line the BFF emits carries `correlationId`, which is the same value
 * stamped on the response header. That is the whole point — the backend exposes
 * no correlation ID of its own (BACKEND_CONTRACT Gap G-5), so ours is the only
 * thread joining a user's report to a run.
 */

type Level = "debug" | "info" | "warn" | "error";

interface LogFields {
  [key: string]: unknown;
}

function emit(level: Level, event: string, fields?: LogFields): void {
  const ctx = getRequestContext();
  const line = {
    ts: new Date().toISOString(),
    level,
    event,
    ...(ctx ? { correlationId: ctx.correlationId } : {}),
    ...fields,
  };

  const serialised = safeStringify(line);
  if (level === "error") console.error(serialised);
  else if (level === "warn") console.warn(serialised);
  else console.log(serialised);
}

/**
 * Never let a logging call throw. A circular reference in an error payload
 * should not take down a run that was otherwise fine.
 */
function safeStringify(value: unknown): string {
  try {
    return JSON.stringify(value);
  } catch {
    return JSON.stringify({ ts: new Date().toISOString(), level: "error", event: "log.serialise_failed" });
  }
}

export const log = {
  debug: (event: string, fields?: LogFields) => emit("debug", event, fields),
  info: (event: string, fields?: LogFields) => emit("info", event, fields),
  warn: (event: string, fields?: LogFields) => emit("warn", event, fields),
  error: (event: string, fields?: LogFields) => emit("error", event, fields),
};
