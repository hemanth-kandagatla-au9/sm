"""
config/ssm_bootstrap.py
-----------------------
Resolve AWS SSM Parameter Store references into process environment variables.

WHY THIS EXISTS
===============
AWS Bedrock AgentCore Runtime does NOT auto-resolve SSM Parameter Store (or
Secrets Manager) references in environment variables. Whatever string is typed
into the AgentCore console env var is injected into the container *literally*.

In production the console env vars hold SSM *parameter names* (paths), e.g.:


…while the real secret value lives in SSM under that parameter name:


Without this module, every `os.environ.get(...)` in config.py / settings.py /
builder.py receives the SSM *path* string instead of the secret value — which is
exactly why AgentCore rejected the memory id ("Invalid AgentCore memory id").

WHAT THIS DOES
==============
When RESOLVE_SSM_PARAMS=true, for each managed variable below it:
  1. reads the current env value (the SSM parameter name),
  2. fetches the real value from SSM (WithDecryption=True for SecureString),
  3. overwrites os.environ[var] with the resolved value.

This MUST run before config.config / config.settings / graph.builder are
imported, because those modules read env vars at import time.

LOCAL / DEV
===========
Leave RESOLVE_SSM_PARAMS unset (or != "true") to keep using literal values from
the AgentCore console or a local .env file — no SSM calls are made.
"""
from __future__ import annotations

import os
from typing import Dict, List

from observability import get_logger

logger = get_logger("cr_agent.ssm")

# Application-managed variables whose console value is an SSM parameter NAME.
# NOTE: AgentCore platform vars consumed by the runtime *before* Python starts
# (e.g. AGENTCORE_PROTOCOL, AGENTCORE_INBOUND_PROTOCOL) and control flags
# (USE_AGENTCORE_MEMORY, RESOLVE_SSM_PARAMS, AWS_REGION) must stay LITERAL in the
# console and are intentionally NOT listed here.
_SSM_MANAGED_VARS: List[str] = [
    # Secrets/credentials stored in SSM Parameter Store
    "AZURE_OPENAI_API_KEY",
    "AZURE_OPENAI_EMBEDDING_API_KEY",
    "JIRA_API_TOKEN",
    "JIRA_PASSWORD",
    "JIRA_USERNAME",
    "NEO4J_PASSWORD",
    "NEO4J_USER",
    "OAUTH_CLIENT_ID",
    "OAUTH_SCOPE",
    "OAUTH_TOKEN_URL",
    "SOLMAN_API_KEY",
    "SOLMAN_BASE_URL",
    "SOLMAN_READ_PASSWORD",
    "SOLMAN_READ_USERNAME",
]

# Names of secret-bearing vars — values are masked in logs.
_SECRET_VARS = {
    "AZURE_OPENAI_API_KEY",
    "AZURE_OPENAI_EMBEDDING_API_KEY",
    "JIRA_API_TOKEN",
    "JIRA_PASSWORD",
    "NEO4J_PASSWORD",
    "OAUTH_CLIENT_ID",
    "SOLMAN_API_KEY",
    "SOLMAN_READ_PASSWORD",
}

_SSM_MAX_NAMES_PER_CALL = 10  # AWS get_parameters hard limit


def _looks_like_ssm_parameter_name(value: str) -> bool:
    """Best-effort check for values intended to be resolved from SSM."""
    candidate = (value or "").strip()
    if not candidate:
        return False

    return (
        candidate.startswith("/")
        or candidate.startswith("arn:aws:ssm:")
        or candidate.startswith("JJYY-")
    )


def _mask(var: str, value: str) -> str:
    """Mask secret values for safe logging."""
    if var in _SECRET_VARS:
        return "***"
    return value


def is_enabled() -> bool:
    """True when SSM resolution should run."""
    return os.environ.get("RESOLVE_SSM_PARAMS", "").strip().lower() == "true"


def resolve_ssm_parameters() -> None:
    """
    Resolve managed env vars from SSM in place.

    No-op unless RESOLVE_SSM_PARAMS=true. Safe to call exactly once at startup,
    before any config module is imported.
    """
    if not is_enabled():
        logger.info("[ssm] RESOLVE_SSM_PARAMS!=true — using literal env values (no SSM lookup).")
        return

    # env_var -> ssm parameter name (the current env value)
    pending: Dict[str, str] = {}
    for var in _SSM_MANAGED_VARS:
        raw = os.environ.get(var, "").strip()
        if raw and _looks_like_ssm_parameter_name(raw):
            pending[var] = raw

    if not pending:
        logger.warning("[ssm] RESOLVE_SSM_PARAMS=true but no SSM-style managed vars are set — nothing to resolve.")
        return

    region = (os.environ.get("AWS_REGION") or os.environ.get("AWS_DEFAULT_REGION") or "us-east-1").strip()
    logger.info("[ssm] Resolving %d parameters from SSM in region %s", len(pending), region)

    try:
        import boto3  # imported lazily so local runs without boto3 still work
        from botocore.exceptions import ClientError
    except ImportError as exc:  # pragma: no cover
        raise RuntimeError("[ssm] boto3 is required to resolve SSM parameters but is not installed.") from exc

    ssm = boto3.client("ssm", region_name=region)

    # ssm parameter name -> list of env vars pointing at it (usually 1)
    name_to_vars: Dict[str, List[str]] = {}
    for var, ssm_name in pending.items():
        name_to_vars.setdefault(ssm_name, []).append(var)

    unique_names = list(name_to_vars.keys())
    resolved: Dict[str, str] = {}
    invalid: List[str] = []

    for i in range(0, len(unique_names), _SSM_MAX_NAMES_PER_CALL):
        batch = unique_names[i : i + _SSM_MAX_NAMES_PER_CALL]
        try:
            resp = ssm.get_parameters(Names=batch, WithDecryption=True)
        except ClientError as exc:
            code = exc.response.get("Error", {}).get("Code", "Unknown")
            msg = exc.response.get("Error", {}).get("Message", str(exc))
            role_arn = (
                os.environ.get("AWS_ROLE_ARN")
                or os.environ.get("BEDROCK_AGENTCORE_RUNTIME_ROLE_ARN")
                or "<runtime execution role>"
            )
            if code in ("AccessDeniedException", "AccessDenied", "UnauthorizedOperation"):
                logger.error(
                    "[ssm] PERMISSION DENIED (%s) calling ssm:GetParameters for batch %s. "
                    "DevOps action: attach ssm:GetParameters (and ssm:GetParameter) to the "
                    "AgentCore runtime execution role %s for these parameter ARNs. "
                    "If any parameter is a SecureString, also grant kms:Decrypt on its KMS key. "
                    "AWS message: %s",
                    code, batch, role_arn, msg,
                )
                raise RuntimeError(
                    f"[ssm] PERMISSION DENIED ({code}) on ssm:GetParameters. "
                    f"DevOps must grant ssm:GetParameters (+ kms:Decrypt for SecureString) "
                    f"to the AgentCore runtime execution role for parameters: {batch}. "
                    f"AWS message: {msg}"
                ) from exc
            if code in ("KMSAccessDeniedException", "AccessDeniedException"):
                logger.error(
                    "[ssm] KMS DECRYPT DENIED (%s) for SecureString parameters %s. "
                    "DevOps action: grant kms:Decrypt on the KMS key to role %s. AWS message: %s",
                    code, batch, role_arn, msg,
                )
                raise RuntimeError(
                    f"[ssm] KMS DECRYPT DENIED ({code}). DevOps must grant kms:Decrypt on the "
                    f"KMS key used by SecureString parameters {batch} to the AgentCore runtime "
                    f"execution role. AWS message: {msg}"
                ) from exc
            logger.error(
                "[ssm] AWS error (%s) calling ssm:GetParameters for batch %s. AWS message: %s",
                code, batch, msg,
            )
            raise RuntimeError(
                f"[ssm] AWS error ({code}) on ssm:GetParameters for {batch}. AWS message: {msg}"
            ) from exc
        for p in resp.get("Parameters", []):
            resolved[p["Name"]] = p["Value"]
        invalid.extend(resp.get("InvalidParameters", []))

    # Apply resolved values to os.environ
    applied = 0
    for ssm_name, value in resolved.items():
        for var in name_to_vars[ssm_name]:
            os.environ[var] = value
            applied += 1
            logger.info("[ssm] %s <- SSM:%s = %s", var, ssm_name, _mask(var, value))

    if invalid:
        # Leave the original literal values in place for invalid names and fail
        # loudly — a missing/mistyped SSM parameter must not silently fall back.
        bad = sorted(
            f"{var} (SSM name: {ssm_name})"
            for ssm_name in invalid
            for var in name_to_vars.get(ssm_name, ["?"])
        )
        raise RuntimeError(
            "[ssm] Failed to resolve the following SSM parameters (not found or "
            "no permission). Check the parameter names and the runtime IAM role's "
            "ssm:GetParameters / kms:Decrypt permissions:\n  - " + "\n  - ".join(bad)
        )

    logger.info("[ssm] Resolved %d/%d managed env vars from SSM.", applied, len(pending))
