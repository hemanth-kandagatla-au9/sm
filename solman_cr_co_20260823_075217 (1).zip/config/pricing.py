"""
Static Azure OpenAI pricing table used to estimate per-call LLM cost.
"""
from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

PRICING_LAST_VERIFIED: str = "2026-07-22"

# ── model/deployment name -> {"input": $/1M tokens, "output": $/1M tokens} ───
MODEL_PRICING: dict[str, dict[str, float]] = {
    "gpt-5.4-mini-global": {"input": 0.75,  "output": 4.50},
    "gpt-5.4-mini-2026-03-17": {"input": 0.75,  "output": 4.50}
}

# Fallback rate used when the active deployment name isn't in MODEL_PRICING
DEFAULT_PRICING: dict[str, float] = {"input": 2.50, "output": 10.00}

# Track which unknown model names we've already warned about, so we don't
# spam the logs once per LLM call.
_warned_unknown_models: set[str] = set()


def _rates_for_model(model: str) -> dict[str, float]:
    rates = MODEL_PRICING.get(model)
    if rates is not None:
        return rates
    if model not in _warned_unknown_models:
        _warned_unknown_models.add(model)
        logger.warning(
            "pricing: no rate configured for model/deployment %r — "
            "using DEFAULT_PRICING fallback (input=$%.2f/1M, output=$%.2f/1M). "
            "Update config/pricing.py.MODEL_PRICING.",
            model, DEFAULT_PRICING["input"], DEFAULT_PRICING["output"],
        )
    return DEFAULT_PRICING


def estimate_cost(model: str, input_tokens: int, output_tokens: int) -> float:
    """Estimate USD cost for one LLM call given token counts and model/deployment name."""
    rates = _rates_for_model(model or "")
    input_cost = (input_tokens / 1_000_000) * rates["input"]
    output_cost = (output_tokens / 1_000_000) * rates["output"]
    return round(input_cost + output_cost, 6)
