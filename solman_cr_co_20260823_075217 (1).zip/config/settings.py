"""
database/settings.py
--------------------
Application configuration and environment variable loading.

This module centralises ALL settings for:
  - Impala / ODBC connection
  - Neo4j connection
  - Azure OpenAI (chat + embeddings)
  - Embedding / search tuning
  - Impala schema / table names
  - Ingestion date window
  - Legacy file paths

All secrets must be supplied via environment variables loaded from the
.env file at the project root.
"""
from __future__ import annotations

import os
import re
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv
from observability import get_logger
logger = get_logger("config.settings")

# ── Load .env from project root (two levels up from this file) ───────────────
_PROJECT_ROOT = Path(__file__).resolve().parents[1]
_ENV_PATH = _PROJECT_ROOT / ".env"
if _ENV_PATH.exists():
    load_dotenv(_ENV_PATH, override=True)
    logger.info(f"[settings] Loaded .env from {_ENV_PATH}")
else:
    logger.warning(f"[settings] No .env found at {_ENV_PATH}; relying on process env vars")


# ── Internal helpers ─────────────────────────────────────────────────────────

def _get(name: str, default: Optional[str] = None) -> Optional[str]:
    """Read an env var, strip whitespace and surrounding quotes."""
    val = os.environ.get(name, default)
    if val is None:
        return default
    return val.strip().strip('"').strip("'") or default


def _require(name: str) -> str:
    """Read a required env var — raises ValueError if missing or empty."""
    val = _get(name)
    if not val:
        raise ValueError(f"Missing required environment variable: {name}")
    return val


_IDENTIFIER_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def _require_identifier(name: str) -> str:
    """Read a required env var that must be a safe SQL identifier."""
    val = _require(name)
    if not _IDENTIFIER_RE.match(val):
        raise ValueError(
            f"Invalid SQL identifier for {name}: {val!r} "
            "(must match [A-Za-z_][A-Za-z0-9_]*)"
        )
    return val


# ── Settings dataclass ───────────────────────────────────────────────────────

@dataclass(frozen=True)
class Settings:
    """
    Typed, immutable application settings container.
    Build via get_settings() — never instantiate directly.
    """

    # ── Impala / ODBC (DATA PIPELINE — commented out, not needed for agent) ──
    # src_edl_host: str
    # src_edl_user: str
    # src_edl_password: str
    # src_edl_port: int
    # idl_source_db: str
    # impala_transport_mode: str   # "SOCKET" or "HTTP"
    # impala_http_path: str        # used only when transport_mode == "HTTP"

    # ── Neo4j ──────────────────────────────────────────────────────────────
    neo4j_uri: str
    neo4j_user: str
    neo4j_password: str
    neo4j_database: str

    # ── Azure OpenAI (chat) ────────────────────────────────────────────────
    azure_openai_api_key: str
    azure_openai_endpoint: str
    azure_openai_api_version: str
    azure_openai_deployment: str

    # ── Azure OpenAI (embeddings) ──────────────────────────────────────────
    azure_embedding_api_key: str
    azure_embedding_endpoint: str
    azure_embedding_api_version: str
    azure_embedding_deployment: str

    # ── Embedding / search tuning (DATA PIPELINE — commented out) ───────────
    # embed_batch_size: int
    # embed_dim: int
    # k_neighbors: int
    # top_n: int
    # min_score: float

    # ── Impala schema + table names (DATA PIPELINE — commented out) ──────────
    # impala_schema: str
    # impala_table_crhd: str
    # impala_table_cr: str
    # impala_table_text: str

    # ── Ingestion date window (DATA PIPELINE — commented out) ────────────────
    # cr_start_date: Optional[str]   # YYYY-MM-DD or None → rolling window
    # cr_end_date: Optional[str]     # YYYY-MM-DD or None → today
    # cr_window_days: int

    # ── Legacy file paths (DATA PIPELINE — commented out) ────────────────────
    # data_dir: Path
    # solmcrhd_path: Path
    # solmtext_path: Path
    # field_map_xlsx: Path

    # ── Convenience: fully-qualified Impala table names (DATA PIPELINE) ──────
    # @property
    # def fq_crhd(self) -> str:
    #     return f"{self.impala_schema}.{self.impala_table_crhd}"
    #
    # @property
    # def fq_cr(self) -> str:
    #     return f"{self.impala_schema}.{self.impala_table_cr}"
    #
    # @property
    # def fq_text(self) -> str:
    #     return f"{self.impala_schema}.{self.impala_table_text}"


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """
    Build and cache a Settings instance from environment variables.
    Call this once at startup; subsequent calls return the cached instance.
    """
    # ── DATA PIPELINE locals — commented out ─────────────────────────────────
    # data_dir = Path(_get("DATA_DIR", str(_PROJECT_ROOT / "data")) or str(_PROJECT_ROOT / "data"))
    #
    # src_edl_port_raw = _get("SRC_EDL_PORT", "21050") or "21050"
    # try:
    #     src_edl_port = int(src_edl_port_raw)
    # except ValueError:
    #     raise ValueError(
    #         f"Invalid SRC_EDL_PORT value: {src_edl_port_raw!r} (must be an integer like 21050)"
    #     )
    #
    # cr_window_days_raw = _get("CR_WINDOW_DAYS", "30") or "30"
    # try:
    #     cr_window_days = int(cr_window_days_raw)
    # except ValueError:
    #     cr_window_days = 30

    return Settings(
        # ── Impala (DATA PIPELINE — commented out) ──────────────────────────
        # src_edl_host=_require("SRC_EDL_HOST"),
        # src_edl_user=_require("SRC_EDL_USER"),
        # src_edl_password=_require("SRC_EDL_PASSWORD"),
        # src_edl_port=src_edl_port,
        # idl_source_db=_require("IDL_SOURCE_DB"),
        # impala_transport_mode=(_get("IMPALA_TRANSPORT_MODE", "SOCKET") or "SOCKET").upper(),
        # impala_http_path=_get("IMPALA_HTTP_PATH", "cliservice") or "cliservice",

        # ── Neo4j ────────────────────────────────────────────────────────
        neo4j_uri=_require("NEO4J_URI"),
        neo4j_user=_require("NEO4J_USER"),
        neo4j_password=_require("NEO4J_PASSWORD"),
        neo4j_database=_get("NEO4J_DATABASE", "neo4j") or "neo4j",

        # ── Azure OpenAI chat ─────────────────────────────────────────────
        azure_openai_api_key=_require("AZURE_OPENAI_API_KEY"),
        azure_openai_endpoint=_require("AZURE_OPENAI_ENDPOINT"),
        azure_openai_api_version=_require("AZURE_OPENAI_API_VERSION"),
        azure_openai_deployment=_require("AZURE_OPENAI_DEPLOYMENT"),

        # ── Azure OpenAI embeddings ───────────────────────────────────────
        azure_embedding_api_key=_require("AZURE_OPENAI_EMBEDDING_API_KEY"),
        azure_embedding_endpoint=_require("AZURE_OPENAI_EMBEDDING_ENDPOINT"),
        azure_embedding_api_version=_require("AZURE_OPENAI_EMBEDDING_API_VERSION"),
        azure_embedding_deployment=_require("AZURE_OPENAI_EMBEDDING_DEPLOYMENT"),

        # ── Embedding / search (DATA PIPELINE — commented out) ───────────────
        # embed_batch_size=int(_get("EMBED_BATCH_SIZE", "100") or "100"),
        # embed_dim=int(_get("EMBED_DIM", "3072") or "3072"),
        # k_neighbors=int(_get("K_NEIGHBORS", "200") or "200"),
        # top_n=int(_get("TOP_N", "5") or "5"),
        # min_score=float(_get("MIN_SCORE", "0.6") or "0.6"),

        # ── Impala schema / tables (DATA PIPELINE — commented out) ───────────
        # impala_schema=_require_identifier("IMPALA_SCHEMA"),
        # impala_table_crhd=_require_identifier("IMPALA_TABLE_CRHD"),
        # impala_table_cr=_require_identifier("IMPALA_TABLE_CR"),
        # impala_table_text=_require_identifier("IMPALA_TABLE_TEXT"),

        # ── Date window (DATA PIPELINE — commented out) ───────────────────────
        # cr_start_date=_get("CR_START_DATE", None),
        # cr_end_date=_get("CR_END_DATE", None),
        # cr_window_days=cr_window_days,

        # ── Legacy paths (DATA PIPELINE — commented out) ──────────────────────
        # data_dir=data_dir,
        # solmcrhd_path=Path(
        #     _get("SOLMCRHD_PATH", str(data_dir / "solmcrhd.csv")) or str(data_dir / "solmcrhd.csv")
        # ),
        # solmtext_path=Path(
        #     _get("SOLMTEXT_PATH", str(data_dir / "solmtext.csv")) or str(data_dir / "solmtext.csv")
        # ),
        # field_map_xlsx=Path(
        #     _get(
        #         "FIELD_MAP_XLSX",
        #         str(data_dir / "SolMan_EDL_AI_Master_Field_Map_v1.0.xlsx"),
        #     ) or str(data_dir / "SolMan_EDL_AI_Master_Field_Map_v1.0.xlsx")
        # ),
    )