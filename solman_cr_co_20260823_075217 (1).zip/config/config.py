"""
config/config.py
----------------
CR Agent configuration constants.

Simple env-var constants used by agents, tools, and graph nodes.
For full database/embedding settings use get_settings() which returns
the Settings dataclass from database/settings.py.
"""
import os
from functools import lru_cache

# ── Azure OpenAI (chat model used by all LLM nodes) ──────────────────────────
AZURE_OPENAI_API_KEY: str = os.environ.get("AZURE_OPENAI_API_KEY", "")
AZURE_OPENAI_ENDPOINT: str = os.environ.get("AZURE_OPENAI_ENDPOINT", "")
AZURE_OPENAI_API_VERSION: str = os.environ.get("AZURE_OPENAI_API_VERSION", "")
MODEL_NAME: str = os.environ.get("CR_MODEL", os.environ.get("AZURE_OPENAI_DEPLOYMENT", ""))

# ── HITL limits ────────────────────────────────────────────────────────────────
MAX_ATTEMPTS: int = 3
MAX_RECOMMENDATIONS: int = 15

# ── Inactive Cycle IDs — must not be recommended to users ─────────────────────
INACTIVE_CYCLE_IDS: list[str] = [
    "654404","654405","654529","654409","655103","655104","652911","652912",
    "652913","652914","652915","652920","652925","652926","652927","652928",
    "652929","652930","652931","652932","652933","652934","652935","652936",
    "652937","652939","652940","652941","652942","652944","652945","652946",
    "652947","652948","652949","652952","652954","652957","652958","652959",
    "652960","652961","652962","652963","652964","652968","652969","652970",
    "652971","652972","652973","652974","652975","652976","652977","652979",
    "652980","652983","653551","653560","653692","653883","654092","654094",
    "653018","653031","653032","653037","653442","653444","653694","654351",
    "653063","653543","653643","653783","653945","654015","653168","653502",
    "653645","653781","653902","653908","653909","653944","654241","652902",
    "653072","653144","653601","653602","653972","653978","654025","654072",
    "654204","652905","653142","654202","654429","654467","654470","654475",
    "655018","655114","654904","654944","654945","655305","654825","655049",
    "655182","654578","654734","655128","655329","655801","656749","656811",
    "656877","657032","658231","655449","655794","655940","655973","656454",
    "656459","656537","656577","656579","656580","656789","656810","656821",
    "656920","657000","657023","657229","657275","657279","657861","658044",
    "658336","655828","655841","656473","656479","656693","656692","656858",
]

# ── Locked fields ─────────────────────────────────────────────────────────────
LOCKED_FIELDS: list[str] = ["template_id", "cr_id", "jira_id", "platform", "target_system"]

# ── Compliance fields — hard-blocked from chat edits ─────────────────────────
# These fields are auto-filled by the cycle autofill flow (node_20/node_20b).
# Users cannot edit them via chat — any attempt is rejected with ⛔.
COMPLIANCE_LOCKED_FIELDS: list[str] = [
    "standard_change_adtnl",   # Standard Change — set by cycle autofill
    "operate_change_adtnl",    # Operate Change  — set by cycle autofill
    "aprv_proc_adtnl",         # Approval Process — set by cycle autofill
    "release_type_ctx",        # Cycle Type       — set by cycle autofill
    "transaction_type_scope",  # Transaction Type — set by cycle autofill
]

# ── Boolean fields — stored as 0/1 in Neo4j, displayed as Yes/No ──────────────
BOOL_FIELDS: set[str] = {
    "zzfld000023_cus",  # Prod Confirm
    "zzfld00000r_cus",  # Technical Unit Test (Dev)
    "zzfld00000s_cus",  # Functional Unit Test (Dev)
    "zzfld00000t_cus",  # Screen Shot (QAS)
    "zzfld00000u_cus",  # System Test (QAS)
    "zzfld00000v_cus",  # Regression Test (QAS)
    "zzfld00000w_cus",  # UAT (QAS)
    "zzfld00000n_cus",  # Technical Design
    "zzfld00000o_cus",  # Functional Design
    "zzfld000001_cus",  # BC Set
    "zzfld000002_cus",  # Config Doc Update
    "zzfld000003_cus",  # Code Review
    "zzfld000004_cus",  # SOD RuleSet
    "zzfld000005_cus",  # Training Materials
    "zzfld000006_cus",  # Updates to SOP/WI
    "zzfld000007_cus",  # BPML Update
    "zzfld00000b_cus",  # Security Change
    "zzfld00000c_cus",  # GxP Relevant
    "zzfld00000e_cus",  # SOX Impact
    "zzfld00000l_cus",  # Train Users
    "zzfld00004p",      # User Requirements
    "zzfld00004r",      # Functional Requirements
    "zzfld000054",      # Bus Proc Analysis
    "zzfld000056",      # Bus Proc Hierarchy
}

# ── Shared platform literals (used in multiple maps) ─────────────────────────
PLATFORM_CENTRAL_FINANCE = "Central Finance"
PLATFORM_AS_SOLMAN = "AS SolMan"

# ── Platform aliases — maps user input (lowercase) to official SOP-8794 names ─
PLATFORM_ALIASES: dict[str, str] = {
    # ── Back to basics ───────────────────────────────────────────────────────
    # SOP exact text: "Back to Basics SAP"
    # SOP alias names: Back to Basic SAP, Data Stewardship Platform(DSP),
    #   Enterprise Supplier Portal, Animas JDE, BWI JDE, DePuy US JDE,
    #   Life Scan JDE, Data Retention Platform JDE, Ethicon JDE,
    #   Ethicon Endo Synergy JDE, Mentor JDE, Synthes JDE, MBP Japan ERP
    "back to basics sap":              "Back to basics",
    "back to basic sap":               "Back to basics",
    "data stewardship platform(dsp)":  "Back to basics",
    "enterprise supplier portal":      "Back to basics",
    "animas jde":                      "Back to basics",
    "bwi jde":                         "Back to basics",
    "depuy us jde":                    "Back to basics",
    "life scan jde":                   "Back to basics",
    "data retention platform jde":     "Back to basics",
    "ethicone jde":                    "Back to basics",
    "ethicon endo synergy jde":        "Back to basics",
    "mentor jde":                      "Back to basics",
    "synthes jde":                     "Back to basics",
    "mbp japan erp":                   "Back to basics",

    # ── Central Finance ──────────────────────────────────────────────────────
    # SOP exact text: "Central Finance SAP (CFIN)"  |  SOP alias: CFIN
    "central finance sap (cfin)":     PLATFORM_CENTRAL_FINANCE,
    "cfin":                           PLATFORM_CENTRAL_FINANCE,

    # ── HMD ──────────────────────────────────────────────────────────────────
    # SOP exact text: "Hospital Medical Devices ERP (HMD)"
    # SOP alias names: Hospital Medical Devices ERP (HMD), Data Stewardship Platform
    # NOTE: Data Stewardship Platform appears in both BTB and HMD —
    "hospital medical devices erp (hmd)": "HMD",
    "data stewardship platform":          "HMD",
    "mt 1.0":                             "HMD",
    "medtech 1.0":                        "HMD",
    "transcend mt1.0":                    "HMD",
    

    # ── TIME ─────────────────────────────────────────────────────────────────
    # SOP exact text: "Innovative Medicine (TIME ERP Instances)"
    "innovative medicine (time erp instances)":  "TIME",
    "transcend im":                              "TIME",
    "transend innovetive medicine":               "TIME",

    # ── GMED ─────────────────────────────────────────────────────────────────
    # SOP exact text: "eWM GMED"  (DB name: GMED — pending Edson/Mahesh confirmation)
    # SOP alias names: eWM GMED, Lucas voice picking, pi, GOSAP(P01,BI,GRC),
    #                  One time network, MEIO Pharma OMP
    "ewm gmed":          "GMED",
    "lucas voice picking": "GMED",
    "gosap(p01)":         "GMED",
    "one time network":  "GMED",
    "meio pharma omp":   "GMED",

    # ── E2 ───────────────────────────────────────────────────────────────────
    # SOP exact text: "Europe2"
    "europe2":           "E2",

    # ── USROTC ───────────────────────────────────────────────────────────────
    # SOP exact text: "United States Regional Order to Cash SAP (USROTC)"
    # SOP alias names: MITEK sap, ANSPACH SAP
    "united states regional order to cash sap (usrotc)": "USROTC",
    "mitek sap":         "USROTC",
    "anspach sap":       "USROTC",

    # ── Medtech ──────────────────────────────────────────────────────────────
    # SOP exact text: "MedTech (MedTech ERP Instances)"
    # SOP alias: MedTech ERP Instances
    "medtech (medtech erp instances)": "Medtech",
    "medtech erp instances":           "Medtech",
    "mt2.0":                           "Medtech",
    "medtech2.0":                      "Medtech",
    "transcend mt2.0":                 "Medtech",

    # ── Galaxy ───────────────────────────────────────────────────────────────
    "galaxy":            "Galaxy",

    # ── Symphony ─────────────────────────────────────────────────────────────
    # SOP exact text & alias: Symphony Treasury, Trax & SWIFT
    "symphony treasury": "Symphony",
    "trax":              "Symphony",
    "swift":             "Symphony",

    # ── LA Vista ─────────────────────────────────────────────────────────────
    # SOP exact text: "Vista LATAM"
    "vista latam":       "LA Vista",

    # ── Sustain ──────────────────────────────────────────────────────────────
    "sustain":           "Sustain",

    # ── ABIOMED ──────────────────────────────────────────────────────────────
    "abiomed":           "ABIOMED",

    # ── Concourse ────────────────────────────────────────────────────────────
    # SOP exact text: "Concourse ATTP SAP"
    "concourse attp sap": "Concourse",

    # ── Taishan ──────────────────────────────────────────────────────────────
    # SOP exact text: "Taishan SAP"
    "taishan sap":       "Taishan",

    # ── WMS EWM ──────────────────────────────────────────────────────────────
    # SOP exact text: "EWM"  |  SOP alias names: EWM, JAX EWM, MLC EWM
    "ewm":               "WMS EWM",
    "jax ewm":           "WMS EWM",
    "mlc ewm":           "WMS EWM",

    # ── SNC ──────────────────────────────────────────────────────────────────
    # SOP exact text: "SNC GOLD"
    "snc gold":          "SNC",

    # ── Fusion ───────────────────────────────────────────────────────────────
    # SOP exact text: "Fusion SAP"
    "fusion sap":        "Fusion",

    # ── Atlas ────────────────────────────────────────────────────────────────
    # SOP exact text: "Atlas SAP"
    "atlas sap":         "Atlas",

    # ── PandA ────────────────────────────────────────────────────────────────
    # SOP exact text: "PandA SAP"
    "panda sap":         "PandA",

    # ── AS GRC ───────────────────────────────────────────────────────────────
    # SOP exact text: "GRC"
    "grc":               "AS GRC",

    # ── Lynx ─────────────────────────────────────────────────────────────────
    # SOP exact text: "LYNX"
    "lynx":              "Lynx",

    # ── AS SolMan ────────────────────────────────────────────────────────────
    # SOP exact text: "Solman, Solution Manager."
    "solman":            PLATFORM_AS_SOLMAN,
    "solution manager": PLATFORM_AS_SOLMAN,
}

# ── Related-system → parent platform map (SOP-8794 Section 2) ───────────────────
# Keys are lowercase SOP alias names; values are DB Platform names.
# Used to suggest the correct platform when a user types a sub-system as a target.
TARGET_SYSTEM_PLATFORM_MAP: dict[str, str] = {
    # Back to basics sub-systems
    "enterprise supplier portal":      "Back to basics",
    "animas jde":                      "Back to basics",
    "bwi jde":                         "Back to basics",
    "depuy us jde":                    "Back to basics",
    "life scan jde":                   "Back to basics",
    "data retention platform jde":     "Back to basics",
    "ethicone jde":                    "Back to basics",
    "ethicon endo synergy jde":        "Back to basics",
    "mentor jde":                      "Back to basics",
    "synthes jde":                     "Back to basics",
    "mbp japan erp":                   "Back to basics",

    # HMD sub-systems (Data Stewardship Platform pending Edson/Mahesh confirmation)
    "data stewardship platform":       "HMD",

    # GMED sub-systems
    "lucas voice picking":             "GMED",
    "pi":                              "GMED",
    "gosap(p01,bi,grc)":              "GMED",
    "one time network":                "GMED",
    "meio pharma omp":                 "GMED",

    # USROTC sub-systems
    "mitek sap":                       "USROTC",
    "anspach sap":                     "USROTC",

    # Symphony sub-systems
    "symphony treasury":               "Symphony",
    "trax":                            "Symphony",
    "swift":                           "Symphony",
}
INFRASTRUCTURE_KEYWORDS: list[str] = [
    "operating system",
    "os patch",
    "database patch",
    "db patch",
    "network",
    "storage area network",
    "san",
    "sap kernel",
    "kernel",
    "executables",
    "infrastructure",
    "infra",
    "basis change",
    "server",
    "hardware",
    "firewall",
    "dns",
    "load balancer",
]

# ── Solman WRITE API (CR submission) — kept for backward compat, no longer used ──
SOLMAN_BASE_URL: str = os.environ.get("SOLMAN_BASE_URL", "")
SOLMAN_API_KEY: str  = os.environ.get("SOLMAN_API_KEY", "")

# ── Solman READ API (OData — for get_template) ────────────────────────────────
SOLMAN_READ_BASE_URL: str = os.environ.get("SOLMAN_READ_BASE_URL", "")
SOLMAN_READ_USERNAME: str    = os.environ.get("SOLMAN_READ_USERNAME", "")
SOLMAN_READ_PASSWORD: str    = os.environ.get("SOLMAN_READ_PASSWORD", "")
SOLMAN_READ_VERIFY_SSL: bool = (
    os.environ.get("SOLMAN_READ_VERIFY_SSL", "").strip().lower() == "true"
)

# ── Jira REST endpoint ─────────────────────────────────────────────────────────
JIRA_BASE_URL: str    = os.environ.get("JIRA_BASE_URL", "")
JIRA_RESOURCE_PATH: str = os.environ.get("JIRA_RESOURCE_PATH", "")
JIRA_API_TOKEN: str   = os.environ.get("JIRA_API_TOKEN", "")
JIRA_USERNAME: str    = os.environ.get("JIRA_USERNAME", "")
JIRA_PASSWORD: str    = os.environ.get("JIRA_PASSWORD", "")

# ── SOP instructions path ─────────────────────────────────────────────────────
SOP_PATH: str = os.environ.get("SOP_PATH", "")

# ── Solman OData ChangeRequestSet path ───────────────────────────────────────
SOLMAN_ODATA_PATH: str = os.environ.get(
    "SOLMAN_ODATA_PATH", "")


def _print_runtime_config_trace() -> None:
    """Print effective runtime values and source (env vs default literal)."""
    tracked = {
        "SOLMAN_READ_BASE_URL": SOLMAN_READ_BASE_URL,
        "JIRA_BASE_URL": JIRA_BASE_URL,
        "JIRA_RESOURCE_PATH": JIRA_RESOURCE_PATH,
        "SOP_PATH": SOP_PATH,
        "SOLMAN_ODATA_PATH": SOLMAN_ODATA_PATH,
    }

    print("[RUNTIME CONFIG CHECK START]")
    for key, value in tracked.items():
        source = "os.environ" if key in os.environ else "config default literal"
        print(f"[RUNTIME CONFIG] {key}={value!r} [source={source}]")
    print("[RUNTIME CONFIG CHECK END]")


_print_runtime_config_trace()

# ── ZCHM_RFC_SRV API field mapping ───────────────────────────────────────────
# Maps (OData group name, PascalCase field) → internal zzfld* key.
# New API uses Iv* groups with updated field names for both GET and POST.
# Used by _parse_odata_response (GET flatten) and solman_write (POST build).
ODATA_FIELD_MAP: dict[tuple[str, str], str] = {
    # IvDetails (previously IsDetails)
    ("IvDetails", "TransactionNo"):              "object_id",
    ("IvDetails", "Description"):                "description",
    ("IvDetails", "Requestor"):                  "requestor_adtnl",
    ("IvDetails", "Status"):                     "status_adtnl",
    ("IvDetails", "Priority"):                   "priority_adtnl",
    ("IvDetails", "Risk"):                       "risk_adtnl",
    ("IvDetails", "PlannedImplementationDate"):  "planned_impl_dt_adtnl",
    ("IvDetails", "ActualImplementationDate"):   "actual_impl_dt_adtnl",
    ("IvDetails", "Team"):                       "zzfld000026",
    ("IvDetails", "SupportGroup"):               "zzfld000029",
    ("IvDetails", "RelatedIRISNumber"):          "zzfld000024_cus",
    ("IvDetails", "CreatedOn"):                  "posting_date",
    ("IvDetails", "ChangedOn"):                  "changed_at",
    ("IvDetails", "StandardChange"):             "standard_change_adtnl",
    ("IvDetails", "OperateChange"):              "operate_change_adtnl",
    ("IvDetails", "AprvProc"):                   "aprv_proc_adtnl",
    # IvScope
    ("IvScope", "TransactionType"):              "transaction_type_scope",
    ("IvScope", "ConfigurationItem"):            "configuration_item_scope",
    # IvValidation (previously IsValidationRequirements)
    ("IvValidation", "UserRequirement"):         "zzfld00004p",
    ("IvValidation", "DocIDwVer7"):              "zzfld00004q",
    ("IvValidation", "FunctionalReq"):           "zzfld00004r",
    ("IvValidation", "DocIDwVer8"):              "zzfld00004s",
    ("IvValidation", "DocIDwVer9"):              "zzfld00004t",
    ("IvValidation", "DocIDwVer10"):             "zzfld00004u",
    ("IvValidation", "Others1ValReq"):           "zzfld00004v",
    ("IvValidation", "Others2ValReq"):           "zzfld00004w",
    ("IvValidation", "TechincalDesign"):         "zzfld00000n_cus",
    ("IvValidation", "FunctionalDesign"):        "zzfld00000o_cus",
    # IvTestReq (previously IsTestingRequirement)
    ("IvTestReq", "TestReference3"):             "zzfld00004x",
    ("IvTestReq", "TestReference2"):             "zzfld00004y",
    ("IvTestReq", "TestReference1"):             "zzfld00004z",
    ("IvTestReq", "ProdConfirm"):                "zzfld000023_cus",
    ("IvTestReq", "TechnicalUnitTestDev"):       "zzfld00000r_cus",
    ("IvTestReq", "FunctionUnitTestDev"):        "zzfld00000s_cus",
    ("IvTestReq", "ScreenShotQAS"):              "zzfld00000t_cus",
    ("IvTestReq", "SystemTestQAS"):              "zzfld00000u_cus",
    ("IvTestReq", "RegressionTestQAS"):          "zzfld00000v_cus",
    ("IvTestReq", "UATQAS"):                     "zzfld00000w_cus",
    ("IvTestReq", "TestScript"):                 "zzfld00000x_cus",
    ("IvTestReq", "Others1"):                    "zzfld00000y_cus",
    ("IvTestReq", "Others2"):                    "zzfld00000z_cus",
    ("IvTestReq", "Others3"):                    "zzfld000010_cus",
    # IvDocumentation (previously IsDocumentationRequirement)
    ("IvDocumentation", "DocIDwVer4"):           "zzfld000050",
    ("IvDocumentation", "DocIDwVer3"):           "zzfld000051",
    ("IvDocumentation", "DocIDwVer2"):           "zzfld000052",
    ("IvDocumentation", "DocIDwVer1"):           "zzfld000053",
    ("IvDocumentation", "BusProcAnalysis"):      "zzfld000054",
    ("IvDocumentation", "DocIDwVer5"):           "zzfld000055",
    ("IvDocumentation", "BusProcHierarchy"):     "zzfld000056",
    ("IvDocumentation", "DocIDwVer6"):           "zzfld000057",
    ("IvDocumentation", "BCSet"):                "zzfld000001_cus",
    ("IvDocumentation", "ConfigDocUpdate"):      "zzfld000002_cus",
    ("IvDocumentation", "ProcessDecomposition"): "zzfld000000_cus",
    ("IvDocumentation", "CodeReview"):           "zzfld000003_cus",
    ("IvDocumentation", "SodRuleset"):           "zzfld000004_cus",
    ("IvDocumentation", "TrainingMaterials"):    "zzfld000005_cus",
    ("IvDocumentation", "UpdateToSopWI"):        "zzfld000006_cus",
    ("IvDocumentation", "BPMLUpdate"):           "zzfld000007_cus",
    ("IvDocumentation", "Others2"):              "zzfld000008_cus",
    ("IvDocumentation", "Others1"):              "zzfld000009_cus",
    ("IvDocumentation", "Others3"):              "zzfld00000a_cus",
    # IvOthers (previously IsOthers)
    ("IvOthers", "SecurityChange"):              "zzfld00000b_cus",
    ("IvOthers", "GxPRelevant"):                 "zzfld00000c_cus",
    ("IvOthers", "RICEF"):                       "zzfld00000d_cus",
    ("IvOthers", "SOXImpact"):                   "zzfld00000e_cus",
    ("IvOthers", "DefectReference"):             "zzfld00000f_cus",
    ("IvOthers", "EndUserTcode"):                "zzfld00000g_cus",
    ("IvOthers", "Others2"):                     "zzfld00000h_cus",
    ("IvOthers", "Others1"):                     "zzfld00000i_cus",
    ("IvOthers", "Others3"):                     "zzfld00000j_cus",
    ("IvOthers", "RequirementNo"):               "zzfld00000k_cus",
    ("IvOthers", "TrainUsers"):                  "zzfld00000l_cus",
    ("IvOthers", "DeferredTo"):                  "zzfld00000m_cus",
    ("IvOthers", "AdditionalDescr"):             "zzfld00002a_cus",
    # IvLocation (previously IsLocation)
    ("IvLocation", "Platform"):                  "zzfld000013_cus",
    ("IvLocation", "Site"):                      "zzfld000028_cus",
    # IvFunctionalArea (previously IsFunctionalArea)
    ("IvFunctionalArea", "PrimaryFunctionalArea"): "zzfld000016_cus",
    ("IvFunctionalArea", "SfaLogistics"):        "zzfld00002c_cus",
    ("IvFunctionalArea", "SfaOFM"):              "zzfld00001b_cus",
    ("IvFunctionalArea", "SfaSource"):           "zzfld00001c_cus",
    ("IvFunctionalArea", "SfaDeliver"):          "zzfld00001d_cus",
    ("IvFunctionalArea", "SfaMake"):             "zzfld00001e_cus",
    ("IvFunctionalArea", "SfaPlan"):             "zzfld00001f_cus",
    ("IvFunctionalArea", "SfaQM"):               "zzfld00001g_cus",
    ("IvFunctionalArea", "SfaSecurity"):         "zzfld00001h_cus",
    ("IvFunctionalArea", "SfaBasis"):            "zzfld00001i_cus",
    ("IvFunctionalArea", "SfaIMWM"):             "zzfld00001j_cus",
    ("IvFunctionalArea", "SfaMDM"):              "zzfld00001k_cus",
    ("IvFunctionalArea", "SfaDWMS"):             "zzfld00001l_cus",
    ("IvFunctionalArea", "SfaBI"):               "zzfld00001m_cus",
    ("IvFunctionalArea", "SfaIntegration"):      "zzfld00001r_cus",
    ("IvFunctionalArea", "SfaHR"):               "zzfld00001s_cus",
    ("IvFunctionalArea", "SfaPayroll"):          "zzfld00001t_cus",
    ("IvFunctionalArea", "SfaGlobalTrade"):      "zzfld00002h_cus",
    ("IvFunctionalArea", "SfaCRM"):              "zzfld00001u_cus",
    ("IvFunctionalArea", "SfaPortal"):           "zzfld00001w_cus",
    ("IvFunctionalArea", "SfaDevelopment"):      "zzfld00001v_cus",
    ("IvFunctionalArea", "SfaBasis"):            "zzfld00001i_cus",
}

# Reverse map: internal zzfld* key → (OData group, PascalCase field)
# Used by solman_write to build the nested POST payload.
ODATA_FIELD_MAP_REVERSE: dict[str, tuple[str, str]] = {
    v: k for k, v in ODATA_FIELD_MAP.items()
}


# ── EDL Mapping — SAP field name → Solman UI display label ───────────────────
# Source: EDL mapping table in data lake (confirmed via Solman UI labels)
# Used in app.py to replace raw field names (zzfld000029) with readable labels
# ── Field mapping organized by SolMan UI section ─────────────────────────────
FIELD_GROUPS: dict = {
    "Details": {
        "object_id":                "Transaction No.",
        "posting_date":             "Created On",
        "description":              "Description",
        "changed_at":               "Changed On",
        "zzfld000026":              "Team",
        "zzfld000029":              "Support Group",
        "zzfld000024_cus":          "Related IRIS Number",
        "ibase_ctx":                "Installed Base",
        "ibase_instance_ctx":       "Component",
        "product_id_ctx":           "Product ID",
        "solution_id_ctx":          "Cycle ID",
        "project_title_ctx":        "Change Cycle",
        "current_phase_desc_ctx":   "Current Phase",
        "slan_name_ctx":            "Landscape",
        "sbra_name_ctx":            "Branch",
        "release_type_ctx":         "Cycle Type",
        "status_adtnl":             "Status",
        "requestor_adtnl":          "Requestor",
        "priority_adtnl":           "Priority",
        "risk_adtnl":               "Risk",
        "planned_impl_dt_adtnl":    "Planned Implementation Date",
        "actual_impl_dt_adtnl":     "Actual Implementation Date",
        "support_group_adtnl":      "Support Group",
        "platform":                 "Platform",
        "approve_status_ctx":       "Approval Status",
        "process_type_ctx":         "Process Type",
        "standard_change_adtnl":    "Standard Change",
        "operate_change_adtnl":     "Operate Change",
        "aprv_proc_adtnl":          "Approval Process",
    },
    "Request for Change Scope": {
        "transaction_type_scope":   "Transaction Type",
        "configuration_item_scope": "Configuration Item",
    },
    "Approval": {
        "it_lead_adtnl":    "IT Lead",
        "blead_adtnl":      "Business Lead",
    },
    "Functional Areas": {
        "zzfld000016_cus":  "Primary Functional Area",
        "zzfld000017_cus":  "Secondary Functional Area",
        "zzfld00001b_cus":  "OFM",
        "zzfld00001c_cus":  "Source",
        "zzfld00001d_cus":  "Deliver",
        "zzfld00001e_cus":  "Make",
        "zzfld00001f_cus":  "Plan",
        "zzfld00001g_cus":  "QM",
        "zzfld00001h_cus":  "Security",
        "zzfld00002c_cus":  "Logistics",
        "zzfld00001j_cus":  "IM/WM",
        "zzfld00001k_cus":  "MDM",
        "zzfld00001l_cus":  "DWMS",
        "zzfld00001m_cus":  "BI",
        "zzfld00001r_cus":  "Integration",
        "zzfld00001s_cus":  "HR",
        "zzfld00001t_cus":  "Payroll",
        "zzfld00002h_cus":  "Global Trade",
        "zzfld00001u_cus":  "CRM",
        "zzfld00001w_cus":  "Portal",
        "zzfld00001v_cus":  "Development",
        "zzfld00001i_cus":  "Basis",
    },
    "Location": {
        "zzfld000013_cus":  "Platform ID",
        "zzfld000028_cus":  "Site",
    },
    "Documentation Requirements": {
        "zzfld000001_cus":  "BC Set",
        "zzfld000002_cus":  "Config Doc Update",
        "zzfld000053":      "1. Doc ID with Ver.#",
        "zzfld000003_cus":  "Code Review",
        "zzfld000004_cus":  "SOD RuleSet",
        "zzfld000052":      "2. Doc ID with Ver.#",
        "zzfld000005_cus":  "Training Materials",
        "zzfld000006_cus":  "Updates to SOP/WI",
        "zzfld000051":      "3. Doc ID with Ver.#",
        "zzfld000007_cus":  "BPML Update",
        "zzfld000000_cus":  "Process Decomposition",
        "zzfld000050":      "4. Doc ID with Ver.#",
        "zzfld000054":      "Bus Proc Analysis",
        "zzfld000055":      "5. Doc ID with Ver.#",
        "zzfld000056":      "Bus Proc Hierarchy",
        "zzfld000057":      "6. Doc ID with Ver.#",
        "zzfld000009_cus":  "Others1",
        "zzfld000008_cus":  "Others2",
        "zzfld00000a_cus":  "Others3",
    },
    "Validation Requirements": {
        "zzfld00004p":      "User Requirements",
        "zzfld00004q":      "7. Doc ID with Ver.#",
        "zzfld00004r":      "Functional Requirements",
        "zzfld00004s":      "8. Doc ID with Ver.#",
        "zzfld00000o_cus":  "Functional Design",
        "zzfld00004t":      "9. Doc ID with Ver.#",
        "zzfld00000n_cus":  "Technical Design",
        "zzfld00004u":      "10. Doc ID with Ver.#",
        "zzfld00004v":      "Others1 (Val Req)",
        "zzfld00004w":      "Others2 (Val Req)",
    },
    "Testing Requirements": {
        "zzfld00000s_cus":  "Functional Unit Test (Dev)",
        "zzfld00000r_cus":  "Technical Unit Test (Dev)",
        "zzfld00000t_cus":  "Screen Shot (QAS)",
        "zzfld00000u_cus":  "System Test (QAS)",
        "zzfld00004z":      "1. Test Reference",
        "zzfld00000v_cus":  "Regression Test (QAS)",
        "zzfld00004y":      "2. Test Reference",
        "zzfld00000w_cus":  "UAT (QAS)",
        "zzfld00004x":      "3. Test Reference",
        "zzfld00000x_cus":  "Test Script",
        "zzfld00000y_cus":  "Others1",
        "zzfld00000z_cus":  "Others2",
        "zzfld000010_cus":  "Others3",
        "zzfld000023_cus":  "Prod Confirm",
    },
    "Others": {
        "zzfld00000c_cus":  "GxP Relevant",
        "zzfld00000b_cus":  "Security Change",
        "zzfld00000e_cus":  "SOX Impact",
        "zzfld00000l_cus":  "Train Users",
        "zzfld00000g_cus":  "End User Tran Code",
        "zzfld00000f_cus":  "Defect Reference",
        "zzfld00000d_cus":  "RICEF",
        "zzfld00000i_cus":  "Others1",
        "zzfld00000h_cus":  "Others2",
        "zzfld00000j_cus":  "Others3",
        "zzfld00000m_cus":  "Deferred To",
        "zzfld00000k_cus":  "Requirement Number",
        "zzfld00002a_cus":  "Add.Description",
    },
    "Parties Involved": {
        "developer_adtnl":   "Developer",
        "implementer_adtnl": "Implementer",
    },
}

# ── Backward-compatible flat dict (auto-built — do not edit manually) ─────────
FIELD_DISPLAY_NAMES: dict = {
    k: v
    for section in FIELD_GROUPS.values()
    for k, v in section.items()
}

# ── Helper functions ──────────────────────────────────────────────────────────
def get_display_name(field_key: str) -> str:
    for section_fields in FIELD_GROUPS.values():
        if field_key in section_fields:
            return section_fields[field_key]
    return field_key

def get_field_section(field_key: str) -> str | None:
    for section, section_fields in FIELD_GROUPS.items():
        if field_key in section_fields:
            return section
    return None


# ── Shared approval / cycle / transaction type literals ─────────────────────
JNJ_APPROVAL = "J&J Approval"
JNJ_EMERGENCY_APPROVAL = "J&J Emergency Approval"

CONTINUAL_CYCLE = "Continual Cycle"
PHASE_CYCLE = "Phase Cycle"
RELEASE_CYCLE = "Release Cycle"

JNJ_URGENT_CHANGE = "JnJ-Urgent Change"
JNJ_ADMIN_CHANGE = "JnJ-Admin Change"
JNJ_NORMAL_CHANGE = "JnJ-Normal Change"
JNJ_NORMAL_CHANGE_TOC = "JnJ-Normal Chg (ToC)"
JNJ_EMERGENCY_CHANGE = "JnJ-Emergency Change"
JNJ_EMERGENCY_ADMIN = "JnJ-Emergency Admin"
JNJ_STANDARD_CHANGE = "JnJ-Standard Change"
JNJ_OPERATE_CHANGE = "JnJ-Operate Change"
JNJ_OPERATE_ADMIN = "JNJ-Admin CO"
OPERATE_EMERGENCY_CHANGE = "Operate Emergency Change"
OPERATE_EMERGENCY_ADMIN_CHANGE = "Operate Emergency Admin Change"
JNJ_PROJECT_CHANGE = "JnJ-Project Change"


# ── Dropdown fields — restricted to specific allowed values ─────────────────────
# Maps edl_key → {display_label: sap_code_or_canonical_value}
# Values are accepted as either display label OR SAP code (case-insensitive).
DROPDOWN_FIELDS: dict[str, dict[str, str]] = {
    "risk_adtnl": {
        "Very High": "001",
        "High":      "002",
        "Medium":    "003",
        "Low":       "004",
    },
    "priority_adtnl": {
        "Very High": "1",
        "High":      "2",
        "Medium":    "3",
        "Low":       "4",
    },
    "aprv_proc_adtnl": {
        JNJ_APPROVAL:           "ZMCR0001",
        JNJ_EMERGENCY_APPROVAL: "ZMCR0003",
    },
    "transaction_type_scope": {
        JNJ_URGENT_CHANGE:    "YMHF",
        JNJ_ADMIN_CHANGE:     "ZMAD",
        JNJ_NORMAL_CHANGE:    "ZMMJ",
        JNJ_NORMAL_CHANGE_TOC: "ZTMJ",
        JNJ_EMERGENCY_CHANGE: "YYHF",
        JNJ_EMERGENCY_ADMIN:  "YMAD",
        JNJ_STANDARD_CHANGE:  "YMSG",
        JNJ_OPERATE_CHANGE:   "ZHHF",
        JNJ_OPERATE_ADMIN:    "ZHAD",
        JNJ_PROJECT_CHANGE:    "ZPMJ",
    },
    "zzfld000013_cus": {  # IvLocation.Platform
        "Mercury":         "01",
        "CrossRoads":      "02",
        "Lynx":            "03",
        "LA Vista":        "04",
        "BSC":             "05",
        "StF":             "06",
        "PandA":           "07",
        "SNC":             "08",
        "Atlas":           "09",
        "Sustain":         "10",
        "Consumer ASPAC":  "11",
        "HR":              "12",
        "E2":              "13",
        "Galaxy":          "14",
        "ASPAC MDD":       "15",
        "Beacon":          "16",
        "USROTC":          "17",
        "AS GRC":          "18",
        PLATFORM_AS_SOLMAN: "19",
        "Solar":           "20",
        "Taishan":         "21",
        "Back to Basics":  "22",
        "Concourse":       "23",
        "GMED":            "24",
        "Surgical Vision": "25",
        PLATFORM_CENTRAL_FINANCE: "26",
        "Fusion":          "27",
        "Symphony":        "28",
        "HMD":             "29",
        "TIME":            "30",
        "ABIOMED":         "31",
        "Medtech":         "32",
        "WMS EWM":         "33",
    },
    "zzfld000016_cus": {  # IvFunctionalArea.PrimaryFunctionalArea
        "OFM":          "01",
        "Source":       "02",
        "Deliver":      "03",
        "Make":         "04",
        "Plan":         "05",
        "QM":           "06",
        "Security":     "07",
        "Basis":        "08",
        "IM/WM":        "09",
        "MDM":          "10",
        "DWMS":         "11",
        "BI":           "12",
        "Integration":  "13",
        "HR":           "14",
        "Payroll":      "15",
        "CRM":          "16",
        "Development":  "17",
        "Portal":       "18",
        "Logistics":    "19",
        "Global Trade": "20",
    },
}

# ── Change Type Rule Matrix ──────────────────────────────────────────────────
# Maps SAP transaction type code → autofill values for SC/OC/AprvProc/CycleType.
# ZMAD and ZHAD are cycle-type-dependent (value is None → caller must resolve
# from cycle_type_hint at runtime). All other codes are unconditional.
# Key:   SAP transaction type code (from transaction_type_scope)
# Value: dict with standard_change, operate_change, approval_process,
#        cycle_type (None = resolve from hint), transaction_type (display label)
TRANSACTION_TYPE_RULES: dict[str, dict] = {
    "YMHF": {
        "standard_change": "",
        "operate_change": "",
        "approval_process": JNJ_APPROVAL,
        "cycle_type": CONTINUAL_CYCLE,
        "transaction_type": JNJ_URGENT_CHANGE,
    },
    "ZMMJ": {
        "standard_change": "",
        "operate_change": "",
        "approval_process": JNJ_APPROVAL,
        "cycle_type": PHASE_CYCLE,
        "transaction_type": JNJ_NORMAL_CHANGE,
    },
    "ZTMJ": {
        "standard_change": "",
        "operate_change": "",
        "approval_process": JNJ_APPROVAL,
        "cycle_type": RELEASE_CYCLE,
        "transaction_type": JNJ_NORMAL_CHANGE_TOC,
    },
    "YYHF": {
        "standard_change": "",
        "operate_change": "",
        "approval_process": JNJ_EMERGENCY_APPROVAL,
        "cycle_type": CONTINUAL_CYCLE,
        "transaction_type": JNJ_EMERGENCY_CHANGE,
    },
    "YMAD": {
        "standard_change": "",
        "operate_change": "",
        "approval_process": JNJ_EMERGENCY_APPROVAL,
        "cycle_type": CONTINUAL_CYCLE,
        "transaction_type": JNJ_EMERGENCY_ADMIN,
    },
    "YMSG": {
        "standard_change": "X",
        "operate_change": "",
        "approval_process": "",
        "cycle_type": CONTINUAL_CYCLE,
        "transaction_type": JNJ_STANDARD_CHANGE,
    },
    "ZHHF": {
        "standard_change": "",
        "operate_change": "X",
        "approval_process": "",
        "cycle_type": CONTINUAL_CYCLE,
        "transaction_type": JNJ_OPERATE_CHANGE,
    },
    OPERATE_EMERGENCY_CHANGE: {
        "standard_change": "",
        "operate_change": "X",
        "approval_process": "",
        "cycle_type": CONTINUAL_CYCLE,
        "transaction_type": OPERATE_EMERGENCY_CHANGE,
    },
    OPERATE_EMERGENCY_ADMIN_CHANGE: {
        "standard_change": "",
        "operate_change": "X",
        "approval_process": "",
        "cycle_type": CONTINUAL_CYCLE,
        "transaction_type": OPERATE_EMERGENCY_ADMIN_CHANGE,
    },
    "ZPMJ": {
        "standard_change": "",
        "operate_change": "X",
        "approval_process": "",
        "cycle_type": RELEASE_CYCLE,
        "transaction_type": JNJ_PROJECT_CHANGE,
    },
    "ZMAD": {
        "standard_change": "",
        "operate_change": "",
        "approval_process": JNJ_APPROVAL,
        "cycle_type": CONTINUAL_CYCLE,  
        "transaction_type": JNJ_ADMIN_CHANGE,
    },
    "ZHAD": {
        "standard_change": "",
        "operate_change": "X",
        "approval_process": "",
        "cycle_type": CONTINUAL_CYCLE,
        "transaction_type": JNJ_OPERATE_ADMIN,
    },
}

# ── Transaction Type Option Matrix (for SC/OC/AprvProc/CycleType validation) ─
# Centralized option mapping used by get_transaction_type_options().
TRANSACTION_TYPE_OPTIONS_MATRIX: dict[str, dict] = {
    # SC='X' always forces Standard Change transaction type.
    "sc_x": {
        "options": [JNJ_STANDARD_CHANGE],
    },
    # OC='X' options depend on cycle family.
    # Evaluation order matters: Continual before Release to preserve current behavior
    # when cycle text contains both words.
    "oc_x_by_cycle": {
        "Continual": [
            JNJ_OPERATE_CHANGE,
            OPERATE_EMERGENCY_CHANGE,
            JNJ_OPERATE_ADMIN,
            OPERATE_EMERGENCY_ADMIN_CHANGE,
        ],
        "Release": [JNJ_PROJECT_CHANGE, JNJ_OPERATE_ADMIN],
    },
    # SC='' and OC='' options keyed by approval process and cycle family.
    "blank_sc_oc_by_approval_and_cycle": {
        JNJ_APPROVAL: {
            "Continual": [JNJ_URGENT_CHANGE, JNJ_ADMIN_CHANGE],
            "Phase": [JNJ_NORMAL_CHANGE, JNJ_ADMIN_CHANGE],
            "Release": [JNJ_NORMAL_CHANGE_TOC, JNJ_ADMIN_CHANGE],
        },
        JNJ_EMERGENCY_APPROVAL: {
            "Continual": [JNJ_EMERGENCY_CHANGE, JNJ_EMERGENCY_ADMIN],
        },
    },
}

# ── System-readonly EDL keys — set by SolMan server, not writable via API ─────
_SYSTEM_READONLY_EDL: frozenset[str] = frozenset({
    "object_id",              # Transaction No. — assigned by SolMan
    "posting_date",           # Created On — set by server
    "changed_at",             # Changed On — set by server
    "status_adtnl",           # Status — controlled by workflow
    "requestor_adtnl",        # Requestor — set from user session
    "approve_status_ctx",     # Approval Status — workflow-controlled
    "process_type_ctx",       # Process Type — fixed by CR type
    "current_phase_desc_ctx", # Current Phase — workflow-controlled
    "solution_id_ctx",        # Cycle ID — managed by cycle HITL
    "project_title_ctx",      # Change Cycle — managed by cycle HITL
    "slan_name_ctx",          # Landscape — managed by cycle HITL
    "sbra_name_ctx",          # Branch — managed by cycle HITL
    "release_type_ctx",       # Cycle Type — managed by cycle HITL
    "support_group_adtnl",    # Support Group (duplicate of zzfld000029)
    "platform",               # Platform — session-locked
})


def get_field_metadata(field_key: str) -> dict | None:
    """
    Get comprehensive metadata for a draft field.
    
    """
    # Find the field in FIELD_GROUPS
    section = get_field_section(field_key)
    if not section:
        return None
    
    display_name = get_display_name(field_key)
    
    # Determine lock type
    lock_type = None
    is_editable = True
    
    if field_key in _SYSTEM_READONLY_EDL:
        lock_type = 'system_readonly'
        is_editable = False
    elif field_key in COMPLIANCE_LOCKED_FIELDS:
        lock_type = 'compliance_locked'
        is_editable = False
    elif field_key in LOCKED_FIELDS:
        lock_type = 'session_locked'
        is_editable = False
    
    # Determine field type
    field_type = 'text'  # default
    if field_key in BOOL_FIELDS:
        field_type = 'boolean'
    elif field_key in DROPDOWN_FIELDS:
        field_type = 'dropdown'
    elif field_key in ODATA_FIELD_MAP_REVERSE:
        group, odata_field = ODATA_FIELD_MAP_REVERSE[field_key]
        if 'Date' in odata_field:
            field_type = 'date'
    
    return {
        'edl_key': field_key,
        'display_name': display_name,
        'section': section,
        'is_editable': is_editable,
        'lock_type': lock_type,
        'field_type': field_type,
    }


@lru_cache(maxsize=1)
def get_settings():
    from config.settings import get_settings as _db_get_settings
    return _db_get_settings()
