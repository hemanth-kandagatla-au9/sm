from setuptools import setup, find_packages

setup(
    name="cr-agent",
    version="1.0.0",
    packages=find_packages(),
    python_requires=">=3.10",
    install_requires=[
        "langgraph>=0.2.0",
        "langchain>=0.2.0",
        "langchain-openai>=0.1.0",
        "langchain-core>=0.2.0",
        "openai>=1.30.0",
        "neo4j>=5.0.0",
        "requests>=2.31.0",
        "pydantic>=1.10.0,<3.0.0",
    ],
)