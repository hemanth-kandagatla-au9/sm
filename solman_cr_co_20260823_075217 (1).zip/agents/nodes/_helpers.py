"""
agents/nodes/_helpers.py

Private helper functions, constants, and local overrides shared across all node modules.
"""
from __future__ import annotations

import re
from functools import lru_cache
from typing import Any

from observability import get_logger
from config.config import (
    FIELD_DISPLAY_NAMES,
    FIELD_GROUPS,
    PLATFORM_ALIASES,
    SOP_PATH,
    get_field_metadata,
)
from state.state import AgentState, FieldState
from tools.tools import execute_cypher

logger = get_logger(__name__)

# ── Platform name sets — used in node_1 extraction prompt ─────────────────────
# Canonical DB names (e.g. "HMD", "TIME", "Back to basics")
_KNOWN_PLATFORMS: str = ", ".join(sorted(set(PLATFORM_ALIASES.values())))
# All alias keys the user might type (e.g. "hospital medical devices erp (hmd)", "cfin")
_PLATFORM_ALIASES_LIST: str = ", ".join(sorted(PLATFORM_ALIASES.keys()))

# ── IS-to-EDL field mapping — shared by node_6 (first-draft snapshot) and
# node_12 (accuracy check). Both blocks use the identical structure; keeping
# it here prevents drift between the two copies.
_IS_TO_EDL: dict = {
    "IvDetails": {
        "CycleId":          "solution_id_ctx",
        "CycleType":        "release_type_ctx",
        "Landscape":        "slan_name_ctx",
        "ChangeCyclePhase": "project_title_ctx",
        "Branch":           "sbra_name_ctx",
        "Risk":             "risk_adtnl",
        "Priority":         "priority_adtnl",
    },
    # IvContext is the primary source; runs after IvDetails so it wins on cycle fields
    "IvContext": {
        "CycleID":          "solution_id_ctx",
        "CycleType":        "release_type_ctx",
        "Landscape":        "slan_name_ctx",
        "ChangeCyclePhase": "current_phase_desc_ctx",
        "Branch":           "sbra_name_ctx",
    },
}


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _load_sop() -> str:
    try:
        with open(SOP_PATH) as fh:
            return fh.read()
    except FileNotFoundError:
        return "(SOP instructions not found)"


def _state_summary(state: AgentState) -> str:
    """Compact summary of current field values for prompts."""
    fields = [
        "reason_for_change", "description_of_change", "additional_information",
        "target_system", "platform", "template_id", "cr_id", "jira_id",
    ]
    lines = []
    for f in fields:
        fs: FieldState = state[f]  # type: ignore[literal-required]
        lines.append(
            f"  {f}: given={fs['given']}, valid={fs['valid']}, "
            f"value={fs['value']!r}, error={fs['error']!r}"
        )
    return "\n".join(lines)


def _deep_merge_dict(base: dict[str, Any], overlay: dict[str, Any]) -> dict[str, Any]:
    """Recursively merge overlay into base, preserving nested siblings."""
    merged: dict[str, Any] = dict(base)
    for key, value in overlay.items():
        existing = merged.get(key)
        if isinstance(existing, dict) and isinstance(value, dict):
            merged[key] = _deep_merge_dict(existing, value)
        else:
            merged[key] = value
    return merged


def get_display_name(field_key: str) -> str:
    """Get user-friendly display name for a field EDL key or field label."""
    if not field_key:
        return ""
    # Try FIELD_DISPLAY_NAMES first (handles all EDL keys)
    if field_key in FIELD_DISPLAY_NAMES:
        return FIELD_DISPLAY_NAMES[field_key]
    # If it's already a display name (text), return as-is
    return field_key


def get_field_section(field_key: str) -> str:
    """Get section name for a field EDL key."""
    if not field_key:
        return ""
    for section, fields in FIELD_GROUPS.items():
        if field_key in fields:
            return section
    return ""


def _normalize_for_match(text: str) -> str:
    """Normalize free text for deterministic field/group matching."""
    s = (text or "").lower()
    s = re.sub(r"[^a-z0-9]+", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def _resolve_field_with_group_hint(
    field_label: str,
    group_hint: str,
    field_context: dict[str, list[dict]],
) -> tuple[bool, str | None, dict | None]:
    """
    Validate that field_label + group_hint is a valid pair using ground truth.
    Returns resolved metadata if valid, or error message if invalid.
    
    Args:
        field_label: Field name or EDL key from user input
        group_hint: Group/section name mentioned by user (or empty string if none)
        field_context: Dict from _build_draft_field_context()
    
    Returns:
        (success: bool, error_message: str | None, metadata: dict | None)
        - success=True: (error_message=None, metadata with resolved field info)
        - success=False: (error_message="reason", metadata=None)
    """
    if not field_label:
        return False, "Field name is required", None
    
    normalized_label = _normalize_for_match(field_label)
    
    # Find all candidates for this field name from ground truth
    matching_metadata = field_context.get(normalized_label, [])
    
    if not matching_metadata:
        # Try direct EDL key lookup from config
        metadata = get_field_metadata(field_label)
        if metadata:
            matching_metadata = [metadata]
        else:
            return False, f"Field '{field_label}' not found in any group", None
    
    # If only one match exists in ground truth, use it regardless of group_hint
    if len(matching_metadata) == 1:
        metadata = matching_metadata[0]
        if not metadata.get('is_editable', False):
            lock_type = metadata.get('lock_type', 'locked')
            return False, f"Field '{field_label}' is {lock_type} in group '{metadata.get('section', '')}'" , None
        return True, None, metadata
    
    # Multiple matches exist — group_hint is required for disambiguation
    if not group_hint:
        # Return all candidates so disambiguation can ask user
        return False, f"Field '{field_label}' exists in multiple groups, user must specify which one", None
    
    # Normalize group hint for matching against ground truth section names
    normalized_hint = _normalize_for_match(group_hint)
    
    # Find matching group in ground truth
    for metadata in matching_metadata:
        section = metadata.get('section', '')
        normalized_section = _normalize_for_match(section)
        
        # Check if group_hint matches this section (substring or exact)
        if (normalized_hint in normalized_section or 
            normalized_section in normalized_hint or
            normalized_hint == normalized_section):
            
            # Found a match in ground truth!
            if not metadata.get('is_editable', False):
                lock_type = metadata.get('lock_type', 'locked')
                return False, f"Field '{field_label}' is {lock_type} in group '{section}'", None
            
            return True, None, metadata
    
    # No matching group found in ground truth
    valid_sections = sorted({m.get('section', '') for m in matching_metadata})
    return False, (
        f"Field '{field_label}' does not exist in group '{group_hint}'. "
        f"Valid groups for this field: {', '.join(valid_sections)}"
    ), None


def _looks_like_field_update_message(text: str) -> bool:
    """Return True when a draft-review reply is clearly field-shaped."""
    raw = (text or "").strip()
    if not raw or ":" not in raw:
        return False

    lower_raw = raw.lower()
    if lower_raw in {"yes", "y", "yeah", "yep", "ok", "okay", "approve", "approved", "confirm", "confirmed", "submit", "reject"}:
        return False

    field_name, field_value = raw.split(":", 1)
    return len(field_name.strip()) > 1 and bool(field_value.strip())


# NOTE: Regex-based field extraction helpers removed.
# Draft field extraction is now handled entirely by LLM in node_10_parse_update_intent.
# _normalize_for_match is kept as it is still used by _classify_field_updates.


@lru_cache(maxsize=1)
def _build_draft_field_context() -> dict[str, list[dict]]:
    """
    Build cached field context mapping display names to all metadata occurrences.
    
    Returns a dict: {display_name → [metadata, metadata, ...]}
    where each metadata dict has: {
        'edl_key': str,
        'display_name': str,
        'section': str,
        'is_editable': bool,
        'lock_type': str | None,
        'field_type': str,
    }
    
    Handles field duplicates (e.g., "Others1" appears in multiple sections).
    This context is passed to LLM for intelligent field extraction.
    """
    context: dict[str, list[dict]] = {}
    
    for section, fields in FIELD_GROUPS.items():
        for field_key, display_name in fields.items():
            metadata = get_field_metadata(field_key)
            if metadata:
                normalized_display = _normalize_for_match(display_name)
                if normalized_display not in context:
                    context[normalized_display] = []
                context[normalized_display].append(metadata)
    
    return context


def _classify_field_updates(
    extracted_updates: list[dict],
    field_context: dict[str, list[dict]],
) -> dict[str, list[dict]]:
    """
    Classify extracted field updates into 6 categories.
    """
    classification = {
        'ready_to_apply': [],
        'needs_group': [],
        'locked_denied': [],
        'unknown_fields': [],
        'invalid_value': [],
        'missing_value': [],
    }
    
    for update in extracted_updates:
        if not isinstance(update, dict):
            continue
        
        field_label = (update.get('field_label') or '').strip()
        new_value = (update.get('new_value') or '').strip()
        group_hint = (update.get('group_hint') or '').strip()
        field_type = (update.get('field_type') or 'unknown').strip()
        
        if not field_label:
            classification['missing_value'].append(update)
            continue
        
        if not new_value:
            update['resolved_field'] = field_label
            classification['missing_value'].append(update)
            continue

        # Text fields (reason_for_change / description_of_change / additional_information)
        # are NOT EDL/zzfld fields tracked in FIELD_GROUPS -- they live directly on
        # AgentState. The node_10 prompt explicitly instructs the LLM to return these
        # exact keys as field_name for text-field updates, but the metadata lookup
        # below only knows about FIELD_GROUPS entries, so these were falling through
        # to "unknown field" even though they are perfectly valid, editable fields.
        _TEXT_FIELD_KEYS_CLASSIFY = {"reason_for_change", "description_of_change", "additional_information"}
        if field_label in _TEXT_FIELD_KEYS_CLASSIFY:
            update['resolved_field'] = field_label
            classification['ready_to_apply'].append(update)
            logger.info("NODE 10: -> [READY] text field=%r value=%r", field_label, new_value)
            continue

        # NEW: If group_hint was provided by LLM, validate field + group pair using ground truth
        if group_hint:
            is_valid, error_msg, matched_metadata = _resolve_field_with_group_hint(
                field_label, group_hint, field_context
            )
            
            if is_valid and matched_metadata:
                # Perfect match in ground truth — use resolved EDL key
                edl_key = matched_metadata['edl_key']
                is_editable = matched_metadata['is_editable']
                actual_field_type = matched_metadata.get('field_type', 'unknown')
                
                # Validate value based on field type from ground truth
                if actual_field_type == 'boolean':
                    valid_bool_values = {'1', '0', 'yes', 'no', 'y', 'n', 'true', 'false', 't', 'f', 'x'}
                    if new_value.lower() not in valid_bool_values:
                        update['resolved_field'] = edl_key
                        update['reason'] = f"Invalid boolean value: '{new_value}'. Accepted: yes, no, 1, 0, true, false, y, n, t, f, x"
                        classification['invalid_value'].append(update)
                        logger.info("NODE 10: → [INVALID] boolean value (group hint %r validated)", group_hint)
                        continue
                
                # Field is ready to apply
                update['resolved_field'] = edl_key
                update['resolved_section'] = matched_metadata.get('section')
                classification['ready_to_apply'].append(update)
                logger.info("NODE 10: → [READY] field=%r section=%r (group hint %r validated from ground truth)", 
                           field_label, matched_metadata.get('section'), group_hint)
                continue
            
            elif not is_valid:
                # Field + group mismatch against ground truth
                update['resolved_field'] = field_label
                update['reason'] = error_msg or "Field and group do not match"
                classification['invalid_value'].append(update)
                logger.warning("NODE 10: → [MISMATCH] %s", error_msg)
                continue
        
        # DEFENSIVE CHECK: If LLM returned an EDL key without group hint, verify it's not ambiguous
        # This catches cases where LLM incorrectly resolved an ambiguous field
        if field_label.startswith('zzfld') and not group_hint:
            metadata = get_field_metadata(field_label)
            if metadata:
                display_name = metadata.get('display_name', '')
                normalized_display = _normalize_for_match(display_name)
                candidates_for_display = field_context.get(normalized_display, [])
                # If this display name has multiple matches (ambiguous), reject LLM's resolution
                if len(candidates_for_display) > 1:
                    logger.warning(
                        "NODE 10: LLM resolved ambiguous field '%s' to '%s' without group hint — reverting to literal text",
                        display_name, field_label
                    )
                    field_label = display_name  # Use literal display name instead
                    update['field_label'] = field_label
                    # Will be treated as ambiguous below
        
        # Find field matches in context
        normalized_label = _normalize_for_match(field_label)
        matching_metadata = field_context.get(normalized_label, [])
        
        if not matching_metadata:
            # Try fallback: direct EDL key match
            metadata = get_field_metadata(field_label)
            if metadata:
                matching_metadata = [metadata]
                logger.info(
                    "NODE 10: found metadata via EDL key lookup — edl=%s display=%s field_type=%s",
                    field_label, metadata.get('display_name', 'Unknown'), metadata.get('field_type', 'unknown')
                )
            else:
                logger.info("NODE 10: no metadata found — treating as unknown field: %s", field_label)
                classification['unknown_fields'].append(update)
                continue
        
        # DEFENSIVE: Correct field_type if LLM got it wrong
        # (e.g., LLM marked boolean field as 'text')
        llm_field_type = (update.get('field_type') or '').strip().lower()
        if matching_metadata:
            actual_field_type = matching_metadata[0].get('field_type', '')
            if actual_field_type == 'boolean' and llm_field_type != 'boolean':
                logger.warning(
                    "NODE 10: LLM provided wrong field_type '%s' for field '%s' (actually boolean) — correcting",
                    llm_field_type, field_label
                )
                update['field_type'] = 'boolean'
        
        # Check for locked fields
        locked_matches = [m for m in matching_metadata if m.get('lock_type')]
        if len(matching_metadata) == 1 and locked_matches:
            update['resolved_field'] = matching_metadata[0]['edl_key']
            update['reason'] = f"Field '{matching_metadata[0]['display_name']}' is {matching_metadata[0]['lock_type']}"
            classification['locked_denied'].append(update)
            continue
        
        # Single match — validate value type and apply
        if len(matching_metadata) == 1:
            metadata = matching_metadata[0]
            edl_key = metadata['edl_key']
            field_type = metadata['field_type']
            display_name = metadata.get('display_name', field_label)
            
            logger.info(
                "NODE 10: single-match validation — field='%s' (edl=%s) field_type=%s value=%r",
                display_name, edl_key, field_type, new_value
            )
            
            # Validate value based on field type
            if field_type == 'boolean':
                valid_bool_values = {'1', '0', 'yes', 'no', 'y', 'n', 'true', 'false', 't', 'f', 'x'}
                if new_value.lower() not in valid_bool_values:
                    update['resolved_field'] = edl_key
                    update['reason'] = f"Invalid boolean value: '{new_value}'. Expected: yes, no, 1, 0, true, false, y, n, t, f, x"
                    classification['invalid_value'].append(update)
                    logger.info("NODE 10: → [INVALID] boolean (value not in valid set)")
                    continue
                logger.info("NODE 10: → [READY] boolean (valid value)")

            elif field_type == 'dropdown':
                from config.config import DROPDOWN_FIELDS
                allowed = DROPDOWN_FIELDS.get(edl_key, {})
                # Accept display label (case-insensitive) or SAP code
                lower_val = new_value.lower()
                matched = any(
                    lower_val == label.lower() or lower_val == code.lower()
                    for label, code in allowed.items()
                )
                if not matched:
                    allowed_labels = list(allowed.keys())
                    update['resolved_field'] = edl_key
                    update['reason'] = (
                        f"Invalid value '{new_value}' for {display_name}. "
                        f"Allowed values: {', '.join(allowed_labels)}"
                    )
                    classification['invalid_value'].append(update)
                    logger.info(
                        "NODE 10: → [INVALID] dropdown field=%r value=%r not in allowed set",
                        display_name, new_value
                    )
                    continue
                logger.info("NODE 10: → [READY] dropdown (valid value)")
            
            update['resolved_field'] = edl_key
            update['resolved_section'] = metadata['section']
            classification['ready_to_apply'].append(update)
            continue
        
        # Multiple matches — MUST have group_hint to disambiguate
        if not group_hint:
            # NO group hint provided for ambiguous field → MUST ask user
            logger.info(
                "NODE 10: → [AMBIG] field=%r found in %d sections, NO group_hint — requesting disambiguation",
                field_label, len(matching_metadata)
            )
            update['candidates'] = [
                {
                    'field_key': m['edl_key'],
                    'display_name': m['display_name'],
                    'section': m['section'],
                }
                for m in matching_metadata
            ]
            classification['needs_group'].append(update)
            continue
    
    return classification


def _classify_with_disambiguation_context(
    extracted_updates: list[dict],
    pending_update: dict,
    field_context: dict[str, list[dict]],
) -> dict:
    """
    Enhanced classification for disambiguation follow-ups.
    
    During disambiguation, user may respond with:
    1. Group selection (section name) → resolves pending field with stored value
    2. Additional field updates (new fields) → classified normally
    
    Args:
        extracted_updates: List of extracted field updates from LLM
        pending_update: {value, field_label, candidates} for the pending field
        field_context: Dict from _build_draft_field_context()
    
    Returns:
        dict with:
        - 'pending_resolved': Update for the pending field (with group selection applied)
        - 'additional_updates': Classification of other extracted fields
        - 'group_selection': The matched section name (if any)
        - 'error': String if group selection failed validation
    """
    result = {
        'pending_resolved': None,
        'additional_updates': {
            'ready_to_apply': [],
            'needs_group': [],
            'locked_denied': [],
            'unknown_fields': [],
            'invalid_value': [],
            'missing_value': [],
        },
        'group_selection': None,
        'error': None,
    }
    
    pending_candidates = pending_update.get('candidates') or []
    pending_field_label = pending_update.get('field_label', '')
    pending_value = pending_update.get('value', '')
    
    # Build TWO lookups: by section name AND by EDL key
    # Candidates can be dicts {field_key, display_name, section} OR strings (EDL keys)
    candidate_sections = {}  # {normalized_section → {section, field_key, display_name}}
    candidate_edl_keys = {}  # {edl_key → {section, field_key, display_name}}
    
    for candidate in pending_candidates:
        # Handle both dict and string candidates
        if isinstance(candidate, dict):
            section = candidate.get('section', '')
            field_key = candidate.get('field_key', '')
            display_name = candidate.get('display_name', '')
        else:
            # Candidate is a string EDL key — look up its metadata
            field_key = str(candidate).strip()
            metadata = get_field_metadata(field_key)
            if not metadata:
                continue
            section = metadata.get('section', '')
            display_name = metadata.get('display_name', '')
        
        # Index by normalized section name
        normalized_section = _normalize_for_match(section)
        candidate_sections[normalized_section] = {
            'section': section,
            'field_key': field_key,
            'display_name': display_name,
        }
        
        # Index by EDL key (for when LLM resolves the section to its EDL key)
        candidate_edl_keys[field_key] = {
            'section': section,
            'field_key': field_key,
            'display_name': display_name,
        }
    
    pending_resolved = False
    remaining_updates = []
    
    # Process each extracted update
    for update in extracted_updates:
        field_label = (update.get('field_label') or '').strip()
        new_value = (update.get('new_value') or '').strip()
        
        if pending_resolved:
            # Already resolved — treat remaining updates as additional fields
            remaining_updates.append(update)
            continue
        
        # Check if this update is a group selection — try BOTH:
        # 1. Section name match (user typed "Testing Requirements")
        normalized_label = _normalize_for_match(field_label)
        if normalized_label in candidate_sections:
            # This resolves the pending disambiguation!
            matched_section_info = candidate_sections[normalized_label]
            result['pending_resolved'] = {
                'resolved_field': matched_section_info['field_key'],
                'resolved_section': matched_section_info['section'],
                'field_label': pending_field_label,
                'new_value': pending_value,  # Use the stored pending value
                'display_name': matched_section_info['display_name'],
            }
            result['group_selection'] = matched_section_info['section']
            pending_resolved = True
            logger.info(
                "NODE 10: disambiguation resolved (section name match) — '%s' selected for '%s' with value %r",
                matched_section_info['section'], pending_field_label, pending_value
            )
            continue
        
        # 2. EDL key match (LLM resolved "Testing Requirements" to "zzfld00000y_cus")
        if field_label in candidate_edl_keys:
            # This resolves the pending disambiguation via EDL key!
            matched_section_info = candidate_edl_keys[field_label]
            result['pending_resolved'] = {
                'resolved_field': matched_section_info['field_key'],
                'resolved_section': matched_section_info['section'],
                'field_label': pending_field_label,
                'new_value': pending_value,  # Use the stored pending value
                'display_name': matched_section_info['display_name'],
            }
            result['group_selection'] = matched_section_info['section']
            pending_resolved = True
            logger.info(
                "NODE 10: disambiguation resolved (EDL key match) — '%s' (section: %s) selected for '%s' with value %r",
                field_label, matched_section_info['section'], pending_field_label, pending_value
            )
            continue
        
        # Not a group selection — treat as additional field update
        remaining_updates.append(update)
    
    # If user didn't select a group, that's an error
    if not pending_resolved:
        section_list = list({s['section'] for s in candidate_sections.values()})
        result['error'] = f"No valid group selection found for '{pending_field_label}'. Please select from: {', '.join(sorted(section_list))}"
        logger.warning("NODE 10: disambiguation failed — %s", result['error'])
        return result
    
    # Classify remaining updates as new field extractions
    if remaining_updates:
        result['additional_updates'] = _classify_field_updates(remaining_updates, field_context)
        logger.info(
            "NODE 10: disambiguation follow-up has %d additional update(s) to classify",
            len(remaining_updates)
        )
    
    return result


# ─────────────────────────────────────────────────────────────────────────────
# Helper for NODE 1 — fetch known target-system values for a platform (DB read
# only, no LLM call) so they can be injected into node_1's single extraction
# prompt below. This lets the LLM normalize fuzzy/punctuated user input against
# the real DB values in the SAME call that already runs every turn, instead of
# needing a second LLM call later in tools.py.
# ─────────────────────────────────────────────────────────────────────────────
def _fetch_target_system_candidates(resolved_platform: str, limit: int = 200) -> list[str]:
    if not resolved_platform:
        return []
    rows = execute_cypher(
        "MATCH (p:Platform)-[:HAS_SYSTEM]->(ts:TargetSystem) "
        "WHERE p.name = $platform OR toLower(p.name) CONTAINS toLower($platform) "
        "RETURN DISTINCT ts.name AS name "
        "UNION "
        "MATCH (c:ChangeRequest) "
        "WHERE (c.platform = $platform OR toLower(c.platform) CONTAINS toLower($platform)) "
        "AND c.configuration_descr IS NOT NULL AND c.configuration_descr <> '' "
        "RETURN DISTINCT c.configuration_descr AS name "
        f"LIMIT {int(limit)}",
        {"platform": resolved_platform},
    )
    return [r["name"] for r in rows if r.get("name") and not r.get("error")]


def _safe_json_default(obj: Any) -> str:
    """JSON serializer for objects not serializable by default — handles DateTime etc."""
    if hasattr(obj, "isoformat"):
        return obj.isoformat()
    return str(obj)


# ─────────────────────────────────────────────────────────────────────────────
# Structured view of the current draft — used by node_8 to populate the AG-UI
# draftReview card.
#
# Source of truth is the merged API payload (template_id.data overlaid with
# cr_id.data), because that is exactly what solman_write overlays onto the
# baseline at submit time. Deriving the review card from anything else would let
# the user approve one set of values while a different set is submitted.
#
# No DB round-trip here: this runs on every draft render, and Neo4j is a drafting
# fallback, not the record of what will be sent.
# ─────────────────────────────────────────────────────────────────────────────
def _build_current_field_values(state: AgentState) -> dict[str, str]:
    """Flat {edl_key: value} for every field in FIELD_GROUPS."""
    from config.config import ODATA_FIELD_MAP

    merged: dict = {}
    for _src in (state["template_id"].get("data"), state["cr_id"].get("data")):
        if isinstance(_src, dict):
            merged = _deep_merge_dict(merged, _src)

    flat: dict[str, str] = {}
    for _sec_fields in FIELD_GROUPS.values():
        for _edl_key in _sec_fields:
            flat[_edl_key] = ""

    # IS-group → EDL (the same mapping node_6 and node_12 use)
    for _grp_key, _fld_map in _IS_TO_EDL.items():
        _grp = merged.get(_grp_key) if isinstance(merged, dict) else None
        if isinstance(_grp, dict):
            for _api_fld, _edl_fld in _fld_map.items():
                _val = _grp.get(_api_fld)
                if _val is not None:
                    flat[_edl_fld] = str(_val).strip()

    # Everything else the OData map knows about, so node_13's zzfld patches show up
    for (_grp_name, _api_fld), _edl_key in ODATA_FIELD_MAP.items():
        _grp_data = merged.get(_grp_name) if isinstance(merged, dict) else None
        if isinstance(_grp_data, dict):
            _val = _grp_data.get(_api_fld)
            if _val is not None:
                flat[_edl_key] = str(_val).strip()

    return flat


def _build_draft_field_groups(state: AgentState) -> dict[str, list[dict]]:
    """{section: [{"key", "label", "value"}, ...]} — the draft as the user reviews it."""
    flat = _build_current_field_values(state)
    groups: dict[str, list[dict]] = {
        section: [
            {"key": edl_key, "label": display, "value": flat.get(edl_key, "")}
            for edl_key, display in fields.items()
        ]
        for section, fields in FIELD_GROUPS.items()
    }
    # The three narrative fields live on AgentState, not in FIELD_GROUPS. They are
    # what the user actually wrote or approved, so they lead the review.
    groups["Change Details"] = [
        {
            "key": _key,
            "label": _label,
            "value": str(state[_key].get("value") or ""),  # type: ignore[literal-required]
        }
        for _key, _label in (
            ("reason_for_change", "Reason for Change"),
            ("description_of_change", "Description of Change"),
            ("additional_information", "Additional Information"),
        )
    ] + groups.get("Change Details", [])
    return groups
