"""
agents/nodes/nodes_gateway.py

Pre-intake gateway — replaces the old /api/entry + /api/cr-mode REST handlers.
Renders the single/bulk mode choice and (for single) the CR intake form as
graph-native ui_component turns, using interrupt() the same way node_3/node_4
do for every other HITL screen. /api/ui-contract stays REST (pure contract
discovery, never part of the live user flow) — only the mode-choice and
intake-form screens move here.

  node_0_show_entry — sets the opening ui_component (crModeChoice), no interrupt.
  node_0_wait       — Command node; interrupt()s on whatever ui_component is
                       currently showing, then re-renders in place ("bulk" →
                       featureComingSoon, "single" → crIntakeForm) or hands off
                       to node_1 once the intake form is submitted.
"""
from __future__ import annotations

from observability import get_logger
from langchain_core.messages import HumanMessage
from langgraph.types import Command, interrupt

from state.state import AgentState
from agui import ui_contract
from tools.tools import execute_cypher

logger = get_logger(__name__)

# Bulk CR is not implemented. Flipping this to True is the ONLY change needed
# once it is — node_0_show_entry and node_0_wait both read it.
BULK_CR_ENABLED = False


def _fetch_platform_names() -> list[str]:
    rows = execute_cypher("MATCH (p:Platform) RETURN p.name AS name ORDER BY p.name")
    if rows and isinstance(rows[0], dict) and rows[0].get("error"):
        logger.error("node_0: platform lookup failed: %s", rows[0]["error"])
        return []
    return [r["name"] for r in rows if r.get("name") and not r.get("error")]


# ─────────────────────────────────────────────────────────────────────────────
# NODE 0a — Show Entry
# First node in the graph. Sets the opening card; no interrupt here so the
# ui_component patch reaches the frontend as its own STATE_SNAPSHOT before the
# graph pauses in node_0_wait.
# ─────────────────────────────────────────────────────────────────────────────
def node_0_show_entry(state: AgentState) -> dict:
    logger.info("NODE 0a: show_entry")
    return {"ui_component": ui_contract.cr_mode_choice(bulk_enabled=BULK_CR_ENABLED)}


# ─────────────────────────────────────────────────────────────────────────────
# NODE 0b — Wait
# Command node: interrupt()s on the currently-shown ui_component, then decides
# what to do with the response based on which component was showing.
# ─────────────────────────────────────────────────────────────────────────────
def node_0_wait(state: AgentState) -> Command:
    logger.info("NODE 0b: wait")

    ui = state.get("ui_component") or {}
    name = ui.get("name")

    user_response: str = interrupt(ui)
    raw = (user_response or "").strip()

    if name == "crModeChoice":
        mode = raw.lower()
        if mode == "bulk":
            logger.info("node_0_wait: bulk requested but not enabled — showing coming-soon card")
            return Command(
                update={"ui_component": ui_contract.feature_coming_soon(
                    title="Bulk Change Request",
                    message="Feature available soon.",
                    back_label="Back to Single Change Request",
                )},
                goto="node_0_wait",
            )
        return Command(
            update={"ui_component": ui_contract.cr_intake_form(
                platforms=_fetch_platform_names(),
                iris_enabled=False,
            )},
            goto="node_0_wait",
        )

    if name == "featureComingSoon":
        # Only exit is "back" — any response returns to the mode choice.
        return Command(
            update={"ui_component": ui_contract.cr_mode_choice(bulk_enabled=BULK_CR_ENABLED)},
            goto="node_0_wait",
        )

    if name == "crIntakeForm":
        # The form's submitted text (e.g. "Create a CR.\nPlatform: ...") starts
        # the real flow — node_1 parses it exactly as it does today.
        logger.info("node_0_wait: intake form submitted — handing off to node_1")
        return Command(
            update={"messages": [HumanMessage(content=user_response)]},
            goto="node_1",
        )

    # Defensive fallback — should not happen once ui_component is always set
    # by node_0_show_entry before this node ever runs.
    logger.warning("node_0_wait: unexpected ui_component name %r — routing to node_1", name)
    return Command(
        update={"messages": [HumanMessage(content=user_response)]},
        goto="node_1",
    )
