"""
agents/nodes/nodes_review.py

Draft review, update, and submission phase nodes:
  node_8_present_draft
  node_9_hitl_wait
  cond_edge_b
  node_10c_handle_rejection
  node_10_parse_update_intent
  node_11_get_information
  node_s_output_answer
  node_12_submit
  node_13_apply_update
"""
from __future__ import annotations

import json

from observability import get_logger
from langchain_core.messages import AIMessage, HumanMessage
from langgraph.types import Command, interrupt

from config.config import (
    BOOL_FIELDS,
    DROPDOWN_FIELDS,
    FIELD_DISPLAY_NAMES,
    FIELD_GROUPS,
    LOCKED_FIELDS,
    MAX_ATTEMPTS,
    ODATA_FIELD_MAP,
    ODATA_FIELD_MAP_REVERSE,
)
from state.state import AgentState

# AG-UI registered-component contract. Every ui_component payload in this module
# is built through these helpers — never as an inline dict — so the frontend
# registry and the agent stay in lockstep. See agui/ui_contract.py.
from agui import ui_contract
from tools.tools import (
    approval_process_to_code,
    approval_process_to_display,
    dropdown_to_code,
    dropdown_to_display,
    execute_cypher,
    get_transaction_type_options,
    solman_write,
    transaction_type_to_code,
    transaction_type_to_display,
    valid_approval_process_values,
    valid_transaction_type_values,
)
from utils.schemas import (
    ApplyUpdateOutput,
    GetInformationOutput,
    IntentRouterB,
    ParseUpdateIntent,
    RelevanceCheck,
)
from utils.llm import llm_with_output, llm_fast_with_output
from ._helpers import (
    _state_summary,
    _looks_like_field_update_message,
    _build_draft_field_context,
    _classify_field_updates,
    _classify_with_disambiguation_context,
    _deep_merge_dict,
    _normalize_for_match,
    _IS_TO_EDL,
    _build_draft_field_groups,
    get_display_name,
    get_field_section,
)

logger = get_logger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# NODE 8 — Present Draft
# Formats draft_ui, produces output text asking user to review / modify / approve.
# ─────────────────────────────────────────────────────────────────────────────
def node_8_present_draft(state: AgentState) -> dict:
    logger.info("NODE 8: present_draft")

    intro_text = (
        "You've created the CR draft for review. Please verify the details on the right panel, "
        'if you are satisfied with all the content please click on the "Submit CR draft to SolMan" button. '
        "If you would still need to work on the details, tell me which fields to modify to which value."
    )
    # The draft review card (ui_component below) already renders every field —
    # don't duplicate it as a text block in the chat.
    output_text = intro_text

    # ── Collect feedback from current turn only ────────────────────────────────
    # Scan backwards: collect AIMessages until we hit a HumanMessage boundary.
    # This ensures old feedback from previous turns is NOT repeated.
    current_turn_feedback: list[AIMessage] = []
    for msg in reversed(state.get("messages", [])):
        if isinstance(msg, HumanMessage):
            # Hit the boundary — stop collecting
            break
        if isinstance(msg, AIMessage) and msg.content:
            # Skip internal handoff messages
            if not str(msg.content).startswith("Parsed update intents:"):
                current_turn_feedback.insert(0, msg)  # Preserve order

    # ── Assemble final messages: current-turn feedback FIRST, then draft ──────
    final_messages: list[AIMessage] = []
    if current_turn_feedback:
        final_messages.extend(current_turn_feedback)
    final_messages.append(AIMessage(content=output_text))

    patch: dict = {
        "messages": final_messages,
        "draft_ui": {
            **state["draft_ui"],
            "output_text": output_text,
        },
        "exhausted_attempts": 0,
        "clickable_options": [
            {"label": "Submit CR draft to SolMan", "value": "approve"},
        ],
        # AG-UI: the draft review card. Sections are built from the merged API
        # payload — the same source solman_write overlays at submit time — then
        # enriched with each field's edit rules, so what the user approves here is
        # what actually gets sent.
        "ui_component": ui_contract.draft_review(
            sections=ui_contract.sections_from_field_groups(
                _build_draft_field_groups(state)
            ),
            confirm_text=(
                "These inputs will raise a change request for CR ID "
                f"{str(state['cr_id'].get('value') or state['template_id'].get('value') or '').strip()}."
                if (state["cr_id"].get("value") or state["template_id"].get("value"))
                else None
            ),
            notices=[str(m.content) for m in current_turn_feedback] or None,
        ),
    }

    return patch


# ─────────────────────────────────────────────────────────────────────────────
# NODE 9 — HITL Wait (draft review)
# Command node: interrupt(), check relevance ×MAX_ATTEMPTS.
# Relevant → Cond Edge B (goto node_9_router which calls cond_edge_b)
# Exhausted → Node 5
# ─────────────────────────────────────────────────────────────────────────────
def node_9_hitl_wait(state: AgentState) -> Command:
    logger.info("NODE 9: hitl_wait (draft review)")

    attempts: int = state.get("exhausted_attempts", 0)

    if attempts >= MAX_ATTEMPTS:
        return Command(
            update={
                "messages": [
                    AIMessage(
                        content=(
                            "We seem to be stuck. Please start a new session when ready."
                        )
                    )
                ]
            },
            goto="node_5",
        )

    if attempts == 0:
        # Prepend node_8's draft presentation message (last AIMessage in state).
        # resume_agent returns only the interrupt value as chat_text when paused,
        # so node_8's streamed message would otherwise be lost.
        _base_prompt_9 = "Please review the draft above. You can approve it, ask questions, or request changes."
        _last_ai_9 = next(
            (m.content.strip() for m in reversed(state["messages"]) if isinstance(m, AIMessage) and m.content),
            "",
        )
        _prompt_9 = f"{_last_ai_9}\n\n{_base_prompt_9}" if _last_ai_9 and _last_ai_9 != _base_prompt_9 else _base_prompt_9
        user_response: str = interrupt(_prompt_9)
    else:
        user_response = interrupt(
            "That doesn't seem related to the Change Request draft. "
            "You can approve, ask questions, or suggest modifications."
        )

    # Field-shaped replies should flow into update parsing, not approval routing.
    if _looks_like_field_update_message(user_response):
        logger.info("NODE 9: field-shaped reply detected — routing to update parsing")
        return Command(
            update={
                "messages": [HumanMessage(content=user_response)],
                "exhausted_attempts": 0,
            },
            goto="cond_edge_b",
        )

    # Short-circuit: bypass relevance check for known action keywords (approve, reject, etc.)
    _SHORTCUT_KEYWORDS = {"approve", "approved",  "confirm", "confirmed", "submit", "reject"}
    if user_response.strip().lower() in _SHORTCUT_KEYWORDS:
        return Command(
            update={
                "messages": [HumanMessage(content=user_response)],
                "exhausted_attempts": 0,
            },
            goto="cond_edge_b",
        )

    # CRITICAL: If pending_update exists (user is responding to disambiguation prompt),
    # ALWAYS accept their response without relevance check. They're already in the flow.
    _pending_update = state.get("pending_update") or {}
    if _pending_update:
        logger.info("NODE 9: pending_update exists — skipping relevance check (disambiguation flow)")
        return Command(
            update={
                "messages": [HumanMessage(content=user_response)],
                "exhausted_attempts": 0,
            },
            goto="cond_edge_b",
        )

    relevance: RelevanceCheck = llm_fast_with_output(RelevanceCheck).invoke(  # fast model — simple classification
        f"""You are evaluating whether a user message is relevant to reviewing a Change Request (CR) draft.

Relevant messages are ONLY those that:
- Approve, confirm, or submit the draft (e.g. "approved", "approve", "submit")
- Ask about a specific field IN the draft (e.g. "what does this description mean?", "can you explain the reason for change?")
- Request a modification to a field in the draft (e.g. "change the target system", "update the description")

NOT relevant (out of context) examples:
- Questions about scoring algorithms, recommendation logic, or system internals (e.g. "how is the score calculated?")
- General questions unrelated to the current CR draft content
- Questions about other CRs, systems, or workflows not part of this draft

User said: {user_response}

Is this message relevant to reviewing or acting on the current CR draft?"""
    )

    if relevance.is_relevant:
        return Command(
            update={
                "messages": [HumanMessage(content=user_response)],
                "exhausted_attempts": 0,
            },
            goto="cond_edge_b",
        )

    return Command(
        update={
            "messages": [
                HumanMessage(content=user_response),
                AIMessage(
                    content=(
                        "That doesn't seem related to the Change Request draft. "
                        f"Attempt {attempts + 1}/{MAX_ATTEMPTS}. "
                        "Please approve, ask a question, or request a modification."
                    )
                ),
            ],
            "exhausted_attempts": attempts + 1,
        },
        goto="node_9",
    )


# ─────────────────────────────────────────────────────────────────────────────
# CONDITIONAL EDGE B — LLM intent router (after Node 9 HITL)
# Routes to node_12 (approval), node_11 (question), node_10 (update), or node_10c (reject).
# ─────────────────────────────────────────────────────────────────────────────
def cond_edge_b(state: AgentState) -> str:
    logger.info("COND B: routing draft intent")

    last_human = next(
        (m.content for m in reversed(state["messages"]) if isinstance(m, HumanMessage)),
        "",
    )

    # ── Pre-LLM check: if pending_update exists, check if user text matches candidate sections ──
    pending_update: dict = state.get("pending_update")
    if pending_update:
        candidates = pending_update.get("candidates", [])
        candidate_sections = {
            _normalize_for_match(c.get("section", "")) for c in candidates
        }
        candidate_display_names = {
            _normalize_for_match(c.get("display_name", "")) for c in candidates
        }
        
        normalized_input = _normalize_for_match(last_human)
        
        # Check if user just said one of the section names (e.g. "Documentation Requirements")
        for section in candidate_sections:
            if section and section in normalized_input:
                logger.info("COND B: detected section name in pending_update flow — forcing intent to 'update'")
                return "node_10"  # Skip LLM, go directly to update processing
        
        # Also check display names (e.g. "Others")
        for display in candidate_display_names:
            if display and display in normalized_input:
                logger.info("COND B: detected display name in pending_update flow — forcing intent to 'update'")
                return "node_10"

    if _looks_like_field_update_message(last_human):
        logger.info("COND B: field-shaped reply detected — forcing intent to 'update'")
        return "node_10"

    result: IntentRouterB = llm_with_output(IntentRouterB).invoke(
        f"""Determine the user's intent regarding the CR draft.

User message: {last_human}

Classify as one of:
- approval: user is happy and wants to submit (e.g. "approved", "approve", "submit")
- question: user wants more information about a field or the draft
- update: user wants to change a specific named field in the draft (e.g. "change the description", "update target system to X")
- reject: user is dissatisfied with the overall draft but has NOT named a specific field to change (e.g. "I don't approve this", "this is not acceptable", "redo this", "I don't like it")

IMPORTANT: Use "reject" when the user expresses general dissatisfaction WITHOUT specifying what to change.
Only use "update" when the user names a specific field or value to change.
"""
    )
    logger.info("COND B intent: %s", result.intent)
        
    # ── Post-LLM guard: override approval if user didn't use approved keywords ──────
    # Apply keyword validation in ALL approval scenarios (both CR creation and recommendation flows).
    _APPROVAL_KEYWORDS = {"approve", "approved", "submit", "confirm", "confirmed"}
    
    # Validate approval keyword in both CR creation AND recommendation workflows
    if result.intent == "approval":
        _msg_lower = last_human.strip().lower()
        if not any(kw in _msg_lower for kw in _APPROVAL_KEYWORDS):
            logger.info(
                "COND B: LLM classified 'approval' but no approval keyword found. "
                "Downgrading to 'question' to suggest correct keywords. User said: %r",
                last_human[:50]
            )
            result.intent = "question"
    
    mapping = {
        "approval": "node_12",
        "question": "node_11",
        "update": "node_10",
        "reject": "node_10c",
    }
    
    return mapping[result.intent]


# ─────────────────────────────────────────────────────────────────────────────
# NODE 10c — Handle Draft Rejection
# User is dissatisfied with the overall draft without naming a specific change.
# Responds with a helpful message and loops back to node_9.
# ─────────────────────────────────────────────────────────────────────────────
def node_10c_handle_rejection(state: AgentState) -> dict:
    logger.info("NODE 10c: handle_rejection")
    return {
        "messages": [
            AIMessage(
                content=(
                    "I understand the draft doesn't look right. "
                    "Could you tell me what you'd like to change?"
                )
            )
        ],
        "exhausted_attempts": 0,
    }


# ─────────────────────────────────────────────────────────────────────────────
# NODE 10 — Parse Update Intent
# Command node: LLM parses which field to update and whether it is locked.
# Locked → locked_denied (blocked), not locked → node_13 (Apply)
# ─────────────────────────────────────────────────────────────────────────────
def node_10_parse_update_intent(state: AgentState) -> Command:
    logger.info("NODE 10: parse_update_intent")

    last_human = next(
        (m.content for m in reversed(state["messages"]) if isinstance(m, HumanMessage)),
        "",
    )

    _pending_update = state.get("pending_update") or {}

    # ── Build field context (cached) ──────────────────────────────────────────
    _field_context = _build_draft_field_context()
    _field_context_lines = []
    for _norm, _meta_list in sorted(_field_context.items()):
        for _meta in _meta_list:
            _lock = "LOCKED" if not _meta['is_editable'] else "editable"
            # Format: display_name [section: SectionName] → edl_key [lock_status, field_type]
            # Use colons to make it clear section is metadata, not extraction target
            _field_context_lines.append(
                f"  • {_meta['display_name']} [section: {_meta['section']}] → {_meta['edl_key']} [{_lock}, {_meta['field_type']}]"
            )
    _field_context_str = "\n".join(sorted(_field_context_lines))

    # ── If disambiguation is in progress, include pending context for LLM ─────
    _pending_context = ""
    if _pending_update:
        _p_candidates = _pending_update.get("candidates") or []
        _p_value = _pending_update.get("value") or ""
        _p_field_label = _pending_update.get("field_label", "Unknown field")
        if _p_candidates:
            _cand_lines = "\n".join(
                f"  • {c.get('display_name')} ({c.get('section')}) → {c.get('field_key')}"
                for c in _p_candidates if isinstance(c, dict)
            )
            _pending_context = (
                f"\nDISAMBIGUATION IN PROGRESS:\n"
                f"The user was asked: 'Which group for {_p_field_label}?' to disambiguate:\n"
                f"{_cand_lines}\n"
                f"EXTRACTION RULES:\n"
                f"1. First, check if user's message contains ONE of the section names above (e.g. 'Testing Requirements', 'Documentation Requirements', 'Others').\n"
                f"   If found, that RESOLVES the pending disambiguation for '{_p_field_label}' → use value '{_p_value}'.\n"
                f"2. After resolving #1, check if the message contains ANY OTHER field updates (e.g., 'Global Trade: 1').\n"
                f"   Extract those as additional field updates in the same request.\n"
                f"3. PARSE BOTH: extract the section name selection AND any additional field updates separately.\n"
                f"   The section name resolves the pending field; other field updates should be extracted as new updates.\n"
                f"Example: 'Testing Requirements, Global Trade:1' means:\n"
                f"  → {_p_field_label} (Testing Requirements section) = '{_p_value}' (resolved disambiguation)\n"
                f"  → Global Trade = '1' (new field update)\n"
            )

    # ── LLM call — single source of truth for field extraction ───────────────
    logger.info("NODE 10: raw user input → %r", last_human)
    if _pending_update:
        logger.info(
            "NODE 10: disambiguation context active — pending_value=%r, field_label=%r, candidates=%s",
            _pending_update.get('value'), _pending_update.get('field_label'),
            [c.get('field_key') for c in (_pending_update.get('candidates') or [])],
        )

    result: ParseUpdateIntent = llm_with_output(ParseUpdateIntent).invoke(
        f"""You are processing a user request to update one or more fields in a CR draft.

User message: {last_human}
{_pending_context}
AVAILABLE FIELDS (with section and EDL key):
{_field_context_str}

=== GROUP AND SECTION MAPPING (GROUND TRUTH) ===
Fields are organized into these sections (groups):
1. Validation Requirements - for validation-related fields
2. Testing Requirements - for testing-related fields
3. Documentation Requirements - for documentation-related fields
4. Others - for other miscellaneous fields
5. Details - for basic CR details
6. Functional Areas - for functional area fields
7. Location - for location fields
8. Approval - for approval fields
9. Parties Involved - for party involvement fields

User may refer to these groups by:
- Full name: "Validation Requirements", "Testing Requirements", etc.
- Short name: "Val Req", "Test Req", "Doc Req", "Validation", "Testing", "Documentation"
- Abbreviation: "Val", "Test", "Doc"
- Generic: "Others"

TEXT FIELDS — return their exact key as field_name:
  - reason_for_change      (user may say: "reason", "reason of change", "business reason")
  - description_of_change  (user may say: "description", "description of change")
  - additional_information (user may say: "additional info", "additional information")

INSTRUCTIONS (PROCESS IN THIS ORDER):

1. EXTRACT GROUP HINT FROM USER MESSAGE (if provided):
   Look for mentions of group/section names in the user input. Examples:
   ✓ "Others1 from group Others to Sachin" → field="Others1", group_hint="Others"
   ✓ "Update Others2: Sachin, group name is Testing Requirements" → field="Others2", group_hint="Testing Requirements"
   ✓ "can you update others3 to testing from Documentation requirements group" → field="Others3", group_hint="Documentation Requirements"
   ✓ "Others1 (Val Req): India" → field="Others1", group_hint="Val Req"
   ✓ "Others2 (Testing): value" → field="Others2", group_hint="Testing"
   
   ⚠️ CRITICAL: Do NOT infer group_hint from the field context display (the section name shown in parentheses).
   ONLY extract group_hint if the USER explicitly mentioned a group name in their message.
   
   Set group_hint to the section name mentioned by the user (full name, abbreviation, or short form).
   If NO group is mentioned → set group_hint to empty string "".

2. PARSE FIELD NAMES FIRST — Check for group hints IN USER MESSAGE ONLY:
   For each field in the user message, extract the field name and check if USER mentioned a group.
   ⚠️ CRITICAL: Do NOT use the field context display [section: X] as a group hint source.
   ONLY extract group hints from patterns WITHIN THE USER MESSAGE:
   
   Pattern: "FieldName (GroupName):" or "FieldName from group GroupName" or "FieldName group name is GroupName"
   ✓ "Others1 (Val Req):" → extract group_hint="Val Req" from USER MESSAGE
   ✓ "Others2 from group Testing:" → extract group_hint="Testing" from USER MESSAGE
   ✓ "Others2, group is Documentation" → extract group_hint="Documentation" from USER MESSAGE
   ✗ "Others2:" → NO group mention in USER MESSAGE → group_hint="" (empty), even if field context shows [section: X]
   ✗ "Others1:" → EVEN IF field context shows [section: Others], do NOT extract → group_hint=""

3. THEN EXTRACT VALUES using VALUE BOUNDARY RULE (after you've extracted group_hint):
   A value ends where you see the START of the next field (detected by the pattern "<FieldName>:" or "update <FieldName>:")
   Do NOT include the next field name in the current field's value.
   Example: "Others2: testing, sachin: Ramesh" 
     → Others2 value is "testing" (STOPS at comma before "sachin:")
     → sachin value is "Ramesh" (STOPS at comma or end)

- Extract EVERY field+value pair with group_hint if provided. Support ANY user format:
    "update <Field>: <value>"         e.g. "update GxP Relevant: No"
    "<Field> (<Group>): <value>"      e.g. "Others1 (Val Req): India" → group_hint="Val Req"
    "update <Field> to <value>"       e.g. "update description to xyz"
    "<Field>: <value>"                e.g. "GxP Relevant: No" → group_hint=""
    "<Field> should be <value>"       e.g. "description should be xyz"
    "<Field> from group <GroupName>" → extract group_hint from this pattern
    "<Field> ... group name is <GroupName>" → extract group_hint from this pattern
4. VALUE BOUNDARY RULE — CRITICAL for multi-field updates. A field's value ends where the NEXT field name begins:
  
  MULTI-FIELD COMMA-SEPARATED FORMAT:
  "GxP Relevant: No, Security Change: No, Others2: testing, sachin: Ramesh, platform: 23"
  Parse as 5 SEPARATE field updates (comma-separated):
    → GxP Relevant = "No"     (ends at comma before "Security")
    → Security Change = "No"  (ends at comma before "Others2")
    → Others2 = "testing"     (ends at comma before "sachin" — do NOT include "sachin: Ramesh, ...")
    → sachin = "Ramesh"       (ends at comma before "platform")
    → platform = "23"         (ends at end or next field)
  
  SPECIAL CASE — Field names containing group name substring (OTHERS GROUP):
  When field names like "Others1", "Others2" contain the group name "Others" as substring:
  "from Others update Others1: Developer, Others2: Tester"
  Parse as 2 SEPARATE field updates:
    → Others1 = "Developer"   (STOPS at comma before "Others2:")
    → Others2 = "Tester"      (ends at end of message)
  
  ⚠️ CRITICAL BOUNDARY DETECTION RULE — SPACES ARE OPTIONAL:
  Look for the pattern: comma + optional whitespace + FieldName + colon
  Both of these are EQUALLY VALID field boundaries:
    - "value, Others2:" (comma + space + fieldname + colon)
    - "value,Others2:" (comma + NO SPACE + fieldname + colon) ← EQUALLY VALID!
  
  The key is: When you see a comma followed (immediately or after spaces) by a known
  FIELDNAME TOKEN and a colon, that comma marks the boundary between fields.
  Whitespace after the comma is OPTIONAL and does NOT change boundary detection.
  
  Even though "Others" appears in "Others2", the pattern "Others2:" (preceded by comma)
  is a FIELD START marker, not a value continuation. The comma is the boundary signal.
  
  ⚠️ CRITICAL: Do NOT treat "Others" substring in "Others2" as group context.
  The comma+optional-space+fieldname pattern signals the end of the previous value.
  
  SINGLE FIELD FORMAT (group-qualified):
  "Others2 (Val Req): New Zealand, Bangladesh: No, update Others2: Sanity"
    → Others2 (Val Req) = "New Zealand"   (ends at comma+field "Bangladesh:")
    → Bangladesh = "No"                   (ends at "update Others2:")
    → Others2 = "Sanity"                  (ends at end of message)
  
  EXTRACTION RULE:
  Each comma marks a potential field boundary. Look for: comma + optional spaces + FieldName + colon.
  Once you see that pattern after a comma, the PREVIOUS field's value is COMPLETE.
  Do NOT include text from the next segment in the current field's value.
  Examples of field name starts: "GxP Relevant:", "Security Change:", "Global Trade:", "Others2:", "Others1:", "sachin:"
  NEVER let a value span across a comma+fieldname boundary.
  
  CRITICAL EXAMPLES FOR "OTHERS" FIELDS (with AND without spaces):
  ✓ "In Documentation Requirements update Others1: Hyderabad,Others2: Vijayawda"
    → Others1 = "Hyderabad" (STOPS at comma before "Others2:" — NO SPACE IS OKAY!)
    → Others2 = "Vijayawda" (ends at message end)
  ✓ "In Documentation Requirements update Others1: Hyderabad, Others2: Vijayawda"
    → Others1 = "Hyderabad" (STOPS at comma + space before "Others2:")
    → Others2 = "Vijayawda" (ends at message end)
  ✓ "from Others update Others1: India,Others2: USA" 
    → Others1 = "India" (STOPS at comma before "Others2:" — NO SPACE)
    → Others2 = "USA"
  ✓ "from Others update Others1: India, Others2: USA" 
    → Others1 = "India" (STOPS at comma + space before "Others2:")
    → Others2 = "USA"
  ✓ "IN Others Others1: Developer, Others2: Tester, Others3: Manager"
    → Others1 = "Developer"
    → Others2 = "Tester"
    → Others3 = "Manager"
  ✗ "In Documentation Requirements update Others1: Hyderabad,Others2: Vijayawda"
    WRONG extraction: Others1 = "Hyderabad,Others2: Vijayawda" (did not detect comma+fieldname boundary)
    RIGHT extraction: Others1 = "Hyderabad", Others2 = "Vijayawda" (detected comma before fieldname)

  AMBIGUITY DETECTION IN MULTI-FIELD FORMAT:
  When parsing comma-separated fields, check EACH field for the group hint (parentheses):
    ✓ "Others2 (Val Req): testing" → has (Val Req) → resolve to EDL key zzfld00004w
    ✓ "Others2 (Testing): testing" → has (Testing) → resolve to EDL key
    ✗ "Others2: testing" → NO parentheses → ambiguous → return field_name='Others2' (literal text)
    ✗ "Others1: free text, Others2: value" → NEITHER has parentheses → both are ambiguous → return literals
  
  RULE: Check each field for group_hint independently. Return group_hint value if extracted.

5. GROUP HINT VALIDATION (performed by system, NOT by LLM):
   Your job: Extract group_hint from user message if provided.
   System job: Validate field_name + group_hint against ground truth and provide specific error if mismatch.
   Examples:
   ✓ "Others1 (Val Req): India" → field_name='Others1', group_hint='Val Req' → system validates against ground truth
   ✓ "Update Others2: value, group name is Testing Requirements" → field_name='Others2', group_hint='Testing Requirements'
   ✓ "Others1: value" → field_name='Others1', group_hint='' (no group mentioned)
   
   For ambiguous fields (exist in multiple groups) WITHOUT group_hint → system asks user to clarify.
   For fields WITH group_hint → system immediately validates and returns specific error if mismatch.
- FIELD NAME EXTRACTION RULES:
  1️⃣ If user EXPLICITLY mentioned a group (e.g., "Others1 (Val Req):" or "from group Testing") 
     → Return EDL key (e.g., "zzfld000009_cus") and include group_hint
  
  2️⃣ If NO group mentioned by user (e.g., "update Others1 to value" with no group context)
     → Return DISPLAY NAME (e.g., "Others1") and set group_hint="" (empty)
     NEVER try to guess or resolve to EDL key when user didn't specify a group
  
  3️⃣ If field does NOT match any known field
     → Return the user's exact text as field_name and set field_type="unknown"

EXAMPLES:
  ✓ "Others1 (Val Req): India" → field_name="zzfld000009_cus", group_hint="Val Req", field_type="text"
  ✓ "can you update Others2 to Dhoni" → field_name="Others2", group_hint="", field_type="text" (display name, NOT EDL key!)
  ✓ "GxP Relevant: No" → field_name="gxp_relevant", group_hint="", field_type="text"
  ✗ "can you update Others2 to Dhoni" → WRONG: field_name="zzfld00000h_cus", group_hint="Others"
- For boolean fields, accepted values: Yes, No, y, n, 1, 0, true, false, X.
- Set is_locked=True only for fields marked LOCKED in the field list above.
- field_type: "zzfld_writable" for editable fields, "text" for text fields,
  "locked" for locked fields, "unknown" for unrecognized field names.
"""
    )

    logger.info("NODE 10: LLM extracted %d update(s):", len(result.updates))
    for _i, _item in enumerate(result.updates):
        logger.info(
            "  [%d] field_name=%-30r  value=%-30r  group_hint=%-20r  field_type=%r",
            _i + 1, _item.field_name, _item.new_value, _item.group_hint, _item.field_type,
        )

    extra_messages: list = []
    writable_updates: list = []

    # ── Classify all extracted updates ────────────────────────────────────────
    _extracted = [
        {
            'field_label': item.field_name, 
            'new_value': item.new_value, 
            'group_hint': item.group_hint,  # NOW CAPTURED FROM LLM EXTRACTION
            'field_type': item.field_type
        }
        for item in result.updates
    ]
    
    # CRITICAL: Validate that group_hint was actually mentioned in user message
    # This catches cases where LLM infers group_hint from field context
    _last_human_lower = last_human.lower()
    logger.info("NODE 10: validating group_hints against user message: %r", last_human[:80])
    for _item in _extracted:
        _gh = (_item.get('group_hint') or '').strip()
        if _gh:  # Only check if group_hint is not empty
            _gh_lower = _gh.lower()
            logger.info("NODE 10: checking group_hint=%r against message", _gh)
            
            # Check for EXPLICIT group mention patterns (keywords that indicate group context)
            _patterns = [
                f'group {_gh_lower}',
                f'({_gh_lower})',
                f'from {_gh_lower}',
                f'in {_gh_lower}',  # Support "IN Others" prefix
                f'section {_gh_lower}',
                f', {_gh_lower}',
                f'{_gh_lower} requirements',
                f'requirements {_gh_lower}',
            ]
            
            _found = any(p in _last_human_lower for p in _patterns)
            logger.info("NODE 10: patterns checked: found=%s patterns=%s", _found, _patterns[:3])
            
            if not _found:
                # Try full section names that contain "requirements"
                _full_section_patterns = [
                    'testing requirements',
                    'validation requirements', 
                    'documentation requirements',
                ]
                if _gh_lower in _full_section_patterns:
                    _found = _gh_lower in _last_human_lower
                    logger.info("NODE 10: checked full section pattern for %r: found=%s", _gh_lower, _found)
                
            if not _found:
                # Group hint NOT found with explicit keywords — LLM inferred it, discard it
                logger.warning(
                    "NODE 10: LLM extracted group_hint=%r but NOT explicitly mentioned in user message — discarding",
                    _gh
                )
                _item['group_hint'] = ''  # Force to empty
            else:
                logger.info("NODE 10: group_hint=%r CONFIRMED in user message", _gh)
    
    # Use specialized classification when disambiguating
    if _pending_update:
        logger.info("NODE 10: using disambiguation-aware classification")
        _disambig_result = _classify_with_disambiguation_context(_extracted, _pending_update, _field_context)
        
        # If disambiguation resolution failed, re-prompt
        if _disambig_result['error']:
            _candidates = _pending_update.get('candidates', [])
            _section_opts = sorted({c['section'] for c in _candidates})
            _display_label = get_display_name(_pending_update.get('field_label', '')) or _pending_update.get('field_label', 'Field')
            logger.warning("NODE 10: disambiguation resolution failed — %s", _disambig_result['error'])
            return Command(
                update={
                    "pending_update": {
                        "value": _pending_update.get('value', ''),
                        "field_label": _pending_update.get('field_label', 'Unknown'),
                        "candidates": _candidates,
                    },
                    "messages": [
                        AIMessage(content=(
                            f"I didn't recognize that response. Please select `{_display_label}` from:\n"
                            + "\n".join(f"  • {c['display_name']} ({c['section']})" for c in _candidates)
                            + f"\n\nJust reply with the group name: {', '.join(_section_opts)}"
                        ))
                    ],
                },
                goto="node_8",
            )
        
        # Disambiguation resolved! Add the pending field to ready_to_apply
        if _disambig_result['pending_resolved']:
            _ready_update = _disambig_result['pending_resolved']
            _classification = _disambig_result['additional_updates']
            _classification['ready_to_apply'].insert(0, _ready_update)
            logger.info(
                "NODE 10: disambiguation resolved — '%s' selected, value=%r",
                _disambig_result['group_selection'], _ready_update.get('new_value')
            )
        else:
            _classification = _disambig_result['additional_updates']
    else:
        _classification = _classify_field_updates(_extracted, _field_context)

    logger.info("NODE 10: classification results:")
    for _u in _classification['ready_to_apply']:
        logger.info(
            "  [READY]   edl=%-25s  display=%-30r  section=%-30r  value=%r",
            _u.get('resolved_field'), get_display_name(_u.get('resolved_field', '')),
            get_field_section(_u.get('resolved_field', '')), _u.get('new_value'),
        )
    for _u in _classification['needs_group']:
        _cands = [(c['display_name'], c['section']) for c in _u.get('candidates', [])]
        logger.info(
            "  [AMBIG]   label=%-30r  value=%-20r  candidates=%s",
            _u.get('field_label'), _u.get('new_value'), _cands,
        )
    for _u in _classification['locked_denied']:
        logger.info(
            "  [LOCKED]  edl=%-25s  display=%r",
            _u.get('resolved_field'), get_display_name(_u.get('resolved_field', '')),
        )
    for _u in _classification['unknown_fields']:
        logger.info("  [UNKNOWN] label=%r  (not found in any field group)", _u.get('field_label'))
    for _u in _classification['invalid_value']:
        logger.info(
            "  [INVALID] edl=%-25s  value=%r  reason=%r",
            _u.get('resolved_field'), _u.get('new_value'), _u.get('reason'),
        )
    for _u in _classification['missing_value']:
        logger.info("  [NOVALUE] label=%r", _u.get('field_label'))

    # ready_to_apply → queue for node_13
    for update in _classification['ready_to_apply']:
        writable_updates.append(
            type('Update', (), {
                'field_name': update['resolved_field'],
                'new_value': update['new_value'],
                'field_type': 'zzfld_writable',
                'is_locked': False,
            })()
        )

    # locked_denied → inform user
    for update in _classification['locked_denied']:
        _display = get_display_name(update.get('resolved_field', '')) or update.get('field_label', 'Field')
        extra_messages.append(AIMessage(content=f"⛔ `{_display}` is locked and cannot be changed."))

    # invalid_value → inform user
    for update in _classification['invalid_value']:
        _fk = update.get('resolved_field')
        _display = get_display_name(_fk) if _fk else update.get('field_label', 'Field')
        extra_messages.append(AIMessage(content=f"❌ `{_display}`: {update.get('reason', 'Invalid value')}"))

    # unknown_fields → inform user
    for update in _classification['unknown_fields']:
        extra_messages.append(AIMessage(
            content=f"❓ Field not found: `{update.get('field_label', 'Unknown')}`. Please use a valid field name from the draft."
        ))

    # missing_value → inform user
    for update in _classification['missing_value']:
        _label = update.get('field_label', 'Unknown field')
        _display_name = get_display_name(_label) or _label
        extra_messages.append(AIMessage(
            content=f"⚠️ No value provided for: `{_display_name}`"
        ))

    # ── Ambiguous fields — apply ready ones first, then ask for group ─────────
    if _classification['needs_group']:
        first_ambiguous = _classification['needs_group'][0]
        candidates = first_ambiguous.get('candidates', [])
        _sections = sorted({c['section'] for c in candidates})
        _field_label = first_ambiguous.get('field_label', 'Unknown')
        _display_label = get_display_name(_field_label) or _field_label
        logger.info(
            "NODE 10: needs_group → asking disambiguation for '%s' (%s): candidates=%s",
            _field_label, _display_label,
            [(c['display_name'], c['section']) for c in candidates],
        )
        _ready_payload = [
            {"field": u.field_name, "value": u.new_value, "type": u.field_type}
            for u in writable_updates
        ]
        _msgs = extra_messages.copy()
        if _ready_payload:
            _msgs.append(AIMessage(content=f"Parsed update intents: {json.dumps(_ready_payload)}"))
        _msgs.append(AIMessage(
            content=(
                f"I found multiple fields matching `{_display_label}`. "
                f"Which group did you mean?\n"
                + "\n".join(f"  • {c['display_name']} ({c['section']})" for c in candidates)
                + f"\n\nReply with the group name or section: {', '.join(_sections)}"
            )
        ))
        return Command(
            update={
                "pending_update": {
                    "value": first_ambiguous.get('new_value', ''),
                    "field_label": _field_label,
                    "candidates": candidates,
                },
                "messages": _msgs,
            },
            goto="node_13" if _ready_payload else "node_8",
        )

    # ── No valid updates found ────────────────────────────────────────────────
    if not writable_updates:
        logger.info("NODE 10: no valid updates to apply")
        return Command(
            update={
                "pending_update": None,
                "messages": extra_messages or [
                    AIMessage(content=(
                        "I couldn't identify any fields to update. "
                        "Please specify the field name and value — for example: "
                        "'update GxP Relevant to No' or 'Others1 (Val Req): Sachin'."
                    ))
                ],
            },
            goto="node_8",
        )

    # ── Route to node_13 with all resolved updates ────────────────────────────
    _resolved_updates = [
        {"field": u.field_name, "value": u.new_value, "type": u.field_type}
        for u in writable_updates
    ]
    _updates_payload = json.dumps(_resolved_updates)
    logger.info("NODE 10: routing to node_13 with %d update(s):", len(_resolved_updates))
    for _upd in _resolved_updates:
        _fk = _upd['field']
        logger.info(
            "  → edl=%-25s  display=%-30r  section=%-25r  value=%r",
            _fk, get_display_name(_fk), get_field_section(_fk), _upd['value'],
        )

    return Command(
        update={
            "pending_update": None,
            "messages": extra_messages + [AIMessage(content=f"Parsed update intents: {_updates_payload}")],
        },
        goto="node_13",
    )


# ─────────────────────────────────────────────────────────────────────────────
# NODE 11 — Get Information
# LLM + cypher: answers user question, then output routes back to Node 9 via Node S.
# ─────────────────────────────────────────────────────────────────────────────
def node_11_get_information(state: AgentState) -> dict:
    logger.info("NODE 11: get_information")

    # ── Check if this is a downgraded wrong approval keyword (CR creation mode only) ──
    # Detect when user said a simple non-approval keyword in CR creation flow
    last_human = next(
        (m.content for m in reversed(state["messages"]) if isinstance(m, HumanMessage)),
        "",
    ).strip()
    
    _APPROVAL_KEYWORDS = {"approve", "approved", "submit", "confirm", "confirmed"}
    _SIMPLE_NONKEYWORDS = {"yes", "y", "yeah", "yep", "ok", "okay", "yup", "sure"}
    
    # Trigger keyword suggestion in ALL approval scenarios with simple non-approval keywords
    if (last_human.lower() in _SIMPLE_NONKEYWORDS 
        and not any(kw in last_human.lower() for kw in _APPROVAL_KEYWORDS)):
        logger.info("NODE 11: CR creation mode — wrong approval keyword detected (%r) — showing suggestion", last_human)
        return {
            "messages": [
                AIMessage(
                    content=(
                        "To approve and submit this CR draft, please use one of these exact keywords:\n\n"
                        "• **approve**\n"
                        "• **submit**\n"
                        "• **confirm**\n"
                        "• **confirmed**\n\n"
                        "Which would you like to do?"
                    )
                )
            ]
        }

    # ── Generic question handler (existing logic continues) ──
    prompt = f"""The user has a question about the CR or related data.

User question: {last_human}

State summary:
{_state_summary(state)}

Graph schema (use entity nodes for accurate results):
  Nodes: ChangeRequest, TextLog, Platform, TargetSystem, ChangeType, Priority, Status, Project
  Relationships:
    (TextLog)-[:PART_OF]->(ChangeRequest)
    (ChangeRequest)-[:BELONGS_TO]->(Platform)
    (ChangeRequest)-[:TARGETS]->(TargetSystem)
    (Platform)-[:HAS_SYSTEM]->(TargetSystem)
    (ChangeRequest)-[:OF_TYPE]->(ChangeType)
    (ChangeRequest)-[:HAS_PRIORITY]->(Priority)
    (ChangeRequest)-[:HAS_STATUS]->(Status)
    (ChangeRequest)-[:PART_OF_PROJECT]->(Project)
  Entity properties: Platform.name, TargetSystem.name, ChangeType.name,
    Priority.label, Status.name, Project.title
  ChangeRequest flat properties: object_id, platform, configuration_descr,
    process_type_ctx, priority_adtnl, approve_status_ctx, project_title_ctx,
    description, posting_date

1. Formulate a Cypher query (if needed) to fetch relevant data from GraphDB.
   Prefer entity node traversal over flat property scans, e.g.:
     MATCH (p:Platform {{name: $name}})<-[:BELONGS_TO]-(c:ChangeRequest)
     MATCH (p:Platform)-[:HAS_SYSTEM]->(ts:TargetSystem)
2. Provide a helpful output_text answer for the user.

If no GraphDB query is needed, set cypher_query to empty string.
"""
    result: GetInformationOutput = llm_with_output(GetInformationOutput).invoke(prompt)

    db_results: list[dict] = []
    if result.cypher_query.strip():
        db_results = execute_cypher(result.cypher_query)

    answer = result.output_text
    if db_results and not db_results[0].get("error"):
        answer += f"\n\n(Data from knowledge graph: {json.dumps(db_results[:3], indent=2)})"

    return {"messages": [AIMessage(content=answer)]}


# ─────────────────────────────────────────────────────────────────────────────
# NODE S — Output Answer Text  (intermediate after Node 11)
# Formats the answer and loops back to Node 9.
# ─────────────────────────────────────────────────────────────────────────────
def node_s_output_answer(state: AgentState) -> dict:
    logger.info("NODE S: output_answer → back to node_9")
    # The answer is already appended by node_11; reset attempts so node_9
    # treats this as a fresh interaction.
    return {"exhausted_attempts": 0}


# ─────────────────────────────────────────────────────────────────────────────
# NODE 12 — Submit (Command node)
# Calls WRITE API to push draft to Solman, then routes to node_15 or node_16.
# ─────────────────────────────────────────────────────────────────────────────
def node_12_submit(state: AgentState) -> Command:
    logger.info("NODE 12: submit → Solman WRITE API")

    # Compute first draft accuracy — diff current Solman fields vs first draft snapshot
    _snapshot = state.get("first_draft_snapshot") or {}
    _accuracy = None
    if _snapshot:
        # Build current flat dict to compare against snapshot.
        # Re-fetch Neo4j for base EDL values, then overlay session changes.
        _curr_flat: dict = {}
        _tmpl_id_12 = str(
            state["cr_id"].get("value") or state["template_id"].get("value") or ""
        ).strip()
        _neo4j_props_12: dict = {}
        if _tmpl_id_12:
            _neo4j_rows_12 = execute_cypher(
                "MATCH (c:ChangeRequest {object_id: $oid}) RETURN properties(c) AS props LIMIT 1",
                {"oid": _tmpl_id_12},
            )
            if _neo4j_rows_12 and not _neo4j_rows_12[0].get("error") and _neo4j_rows_12[0].get("props"):
                _neo4j_props_12 = dict(_neo4j_rows_12[0]["props"])
        for _sec_fields in FIELD_GROUPS.values():
            for _edl_key in _sec_fields:
                _raw = _neo4j_props_12.get(_edl_key)
                _curr_flat[_edl_key] = str(_raw).strip() if _raw is not None else ""
        # Overlay API fields from both template_id and cr_id payloads (same as node_6 snapshot)
        # so Template ID and CR ID paths use the same comparison source.
        _IS_TO_EDL_12 = _IS_TO_EDL
        _tmpl_api_data_12 = {}
        _template_api_12 = state["template_id"].get("data") or {}
        _cr_api_12 = state["cr_id"].get("data") or {}
        if isinstance(_template_api_12, dict):
            _tmpl_api_data_12 = _deep_merge_dict(_tmpl_api_data_12, _template_api_12)
        if isinstance(_cr_api_12, dict):
            _tmpl_api_data_12 = _deep_merge_dict(_tmpl_api_data_12, _cr_api_12)
        for _grp_key_12, _fld_map_12 in _IS_TO_EDL_12.items():
            _grp_12 = _tmpl_api_data_12.get(_grp_key_12, {}) if isinstance(_tmpl_api_data_12, dict) else {}
            if isinstance(_grp_12, dict):
                for _api_fld, _edl_fld in _fld_map_12.items():
                    _val = _grp_12.get(_api_fld)
                    if _val is not None:
                        _curr_flat[_edl_fld] = str(_val).strip()
        # Overlay ALL merged API fields via ODATA_FIELD_MAP so zzfld* patches
        # made by node_13 (e.g. Regression Test changed to "X") are reflected,
        # while template-only values remain visible in template_id flow.
        # Only overlay FIELD_GROUPS keys — excludes text fields (description_of_change
        # etc.) which are tracked separately as text.* keys to avoid inflating total.
        for (_grp_all, _api_all), _edl_all in ODATA_FIELD_MAP.items():
            if _edl_all in FIELD_DISPLAY_NAMES and _edl_all not in FIELD_GROUPS.get("Details", {}):
                _grp_data_all = (_tmpl_api_data_12.get(_grp_all) or {}) if isinstance(_tmpl_api_data_12, dict) else {}
                if isinstance(_grp_data_all, dict):
                    _v_all = _grp_data_all.get(_api_all)
                    if _v_all is not None:
                        _curr_flat[_edl_all] = str(_v_all).strip()
        # 3 AI-written text fields
        for _tf in ("reason_for_change", "description_of_change", "additional_information"):
            _curr_flat[f"text.{_tf}"] = str((state[_tf].get("value") or "")).strip()  # type: ignore[literal-required]
        _total = len(_snapshot)
        _changed = [f for f, v in _snapshot.items() if str(_curr_flat.get(f, "")).strip() != v]
        _accuracy = {
            "total":          _total,
            "unchanged":      _total - len(_changed),
            "changed":        len(_changed),
            "changed_fields": _changed,
            "pct":            round((_total - len(_changed)) / _total * 100, 1) if _total else 100.0,
        }
        logger.info(
            "NODE 12: first_draft_accuracy=%d/%d (%.1f%%) changed=%s",
            _accuracy["unchanged"], _total, _accuracy["pct"], _changed,
        )

    # DEBUG: Log what's in state["cr_id"] before calling solman_write
    _cr_id_state = state.get("cr_id", {})
    _cr_id_data = _cr_id_state.get("data", {}) if isinstance(_cr_id_state, dict) else {}
    logger.warning("NODE 12: DEBUG — state['cr_id'] structure: type=%s, has_data=%s, data_keys=%s",
                   type(_cr_id_state).__name__,
                   isinstance(_cr_id_data, dict),
                   list(_cr_id_data.keys()) if isinstance(_cr_id_data, dict) else "N/A")
    if isinstance(_cr_id_data, dict) and "IvFunctionalArea" in _cr_id_data:
        _sfa_del = _cr_id_data["IvFunctionalArea"].get("SfaDeliver")
        logger.warning("NODE 12: DEBUG — SfaDeliver in state['cr_id']['data']=%r", _sfa_del)

    result = solman_write(
        draft=state.get("draft", ""),
        state_snapshot={
            k: state[k]  # type: ignore[literal-required]
            for k in [
                "template_id", "cr_id", "jira_id", "platform", "target_system",
                "reason_for_change", "description_of_change", "additional_information",
                "planned_impl_dt_adtnl", "zzfld00000v_cus", "zzfld00004y",
                "zzfld00000w_cus", "zzfld00004x", "wwid",
                "aprv_proc", "transaction_type",
            ]
        },
    )

    if result["success"]:
        return Command(
            update={
                "submission_result": result,
                "first_draft_accuracy": _accuracy,
            },
            goto="node_16",
        )

    return Command(
        update={
            "submission_result": result,
            "first_draft_accuracy": _accuracy,
        },
        goto="node_15",
    )


# ─────────────────────────────────────────────────────────────────────────────
# NODE 13 — Apply Update
# LLM applies the requested field update to the draft, then → Node 8 (re-present).
# ─────────────────────────────────────────────────────────────────────────────
def node_13_apply_update(state: AgentState) -> dict:
    logger.info("NODE 13: apply_update → node_8")

    last_ai = next(
        (m.content for m in reversed(state["messages"]) 
        if isinstance(m, AIMessage) and "Parsed update intents:" in m.content),
        "",
    )

    _TEXT_FIELD_KEYS = frozenset({"reason_for_change", "description_of_change", "additional_information"})

    # ── Parse updates list: JSON format (multi-update) ────────────────────────
    updates_to_apply: list[dict] = []
    if "Parsed update intents:" in last_ai:
        try:
            _json_str = last_ai.split("Parsed update intents:", 1)[1].strip()
            # Take only the first line (JSON), skip any clarification message on subsequent lines
            _json_line = _json_str.split('\n')[0].strip()
            updates_to_apply = json.loads(_json_line)
        except (json.JSONDecodeError, IndexError, ValueError):
            pass

    if not updates_to_apply:
        return {"messages": [AIMessage(content="Could not parse update intent.")]}

    # ── Split into zzfld vs text updates ─────────────────────────────────────
    _zzfld_updates = [
        u for u in updates_to_apply
        if u["field"] in ODATA_FIELD_MAP_REVERSE and u["field"] not in _TEXT_FIELD_KEYS
    ]
    _text_updates = [
        u for u in updates_to_apply
        if u["field"] not in ODATA_FIELD_MAP_REVERSE or u["field"] in _TEXT_FIELD_KEYS
    ]

    patch: dict = {}
    summary_parts: list[str] = []
    validation_errors: list[str] = []

    # ── Apply all zzfld* updates in one accumulated patch ─────────────────────
    if _zzfld_updates:
        _CHECKBOX_FIELDS = {
            "zzfld00001b_cus", "zzfld00001c_cus", "zzfld00001d_cus", "zzfld00001e_cus",
            "zzfld00001f_cus", "zzfld00001g_cus", "zzfld00001h_cus", "zzfld00001i_cus",
            "zzfld00001j_cus", "zzfld00001k_cus", "zzfld00001l_cus", "zzfld00001m_cus",
            "zzfld00001r_cus", "zzfld00001s_cus", "zzfld00001t_cus", "zzfld00001u_cus",
            "zzfld00001v_cus", "zzfld00001w_cus", "zzfld00002c_cus", "zzfld00002h_cus",
        }
        _FIELDSTATE_SLOTS = frozenset({
            "zzfld00000v_cus", "zzfld00004y", "zzfld00000w_cus", "zzfld00004x",
            "planned_impl_dt_adtnl",
        })
        _original_crid = dict(state.get("cr_id") or {})
        _original_data = dict(_original_crid.get("data") or {})
        _updated_data = dict(_original_data)  # accumulate all group patches here

        for upd in _zzfld_updates:
            _field_name = upd["field"]
            _new_value = upd["value"]
            _group, _api_field = ODATA_FIELD_MAP_REVERSE[_field_name]
            _group_data = dict(_updated_data.get(_group) or {})
            _display = FIELD_DISPLAY_NAMES.get(_field_name, _field_name)

            # Dropdown value normalization/validation (label -> code) for payload fields.
            if _field_name == "aprv_proc_adtnl":
                _aprv_code = approval_process_to_code(str(_new_value))
                if str(_new_value).strip() and not _aprv_code:
                    _allowed = ", ".join(valid_approval_process_values())
                    validation_errors.append(
                        f"❌ Invalid value `{_new_value}` for field **{_display}**. "
                        f"Allowed values: {_allowed}"
                    )
                    logger.error("NODE 13: approval process validation failed — %s", _new_value)
                    continue
                _new_value = _aprv_code

            if _field_name == "transaction_type_scope":
                _raw_tt = str(_new_value or "").strip()
                _normalized_tt = transaction_type_to_display(_raw_tt)

                _iv_details_for_rules = dict(_updated_data.get("IvDetails") or {})
                _iv_context_for_rules = dict(_updated_data.get("IvContext") or {})
                _sc = str(_iv_details_for_rules.get("StandardChange") or "").strip().upper()
                _oc = str(_iv_details_for_rules.get("OperateChange") or "").strip().upper()
                _cycle_type = str(_iv_context_for_rules.get("CycleType") or "").strip()
                _aprv_raw = str(_iv_details_for_rules.get("AprvProc") or "").strip()
                _aprv_for_rules = approval_process_to_display(_aprv_raw)

                _allowed_opts = get_transaction_type_options(_sc, _oc, _aprv_for_rules, _cycle_type)
                if not _allowed_opts:
                    _allowed_opts = valid_transaction_type_values()

                _allowed_lc = {o.lower(): o for o in _allowed_opts}
                _selected_display = _allowed_lc.get(_normalized_tt.lower())
                if _normalized_tt and not _selected_display:
                    _allowed = ", ".join(_allowed_opts)
                    validation_errors.append(
                        f"❌ Invalid value `{_new_value}` for field **{_display}**. "
                        f"Allowed values: {_allowed}"
                    )
                    logger.error("NODE 13: transaction type validation failed — %s", _new_value)
                    continue

                _new_value = transaction_type_to_code(_selected_display or "") or (_selected_display or _raw_tt)

            # Generic dropdown normalization for risk, priority, platform ID, primary FA
            if _field_name in ("risk_adtnl", "priority_adtnl", "zzfld000013_cus", "zzfld000016_cus"):
                _dd_code = dropdown_to_code(_field_name, str(_new_value))
                if str(_new_value).strip() and not _dd_code:
                    _allowed = ", ".join(DROPDOWN_FIELDS.get(_field_name, {}).keys())
                    validation_errors.append(
                        f"❌ Invalid value `{_new_value}` for field **{_display}**. "
                        f"Allowed values: {_allowed}"
                    )
                    logger.error(
                        "NODE 13: dropdown validation failed — field=%s value=%s",
                        _field_name, _new_value,
                    )
                    continue
                if _dd_code:
                    _new_value = _dd_code

            # Validation — collect errors and skip invalid fields; do not abort the whole batch
            if _field_name in BOOL_FIELDS:
                _VALID_BOOL = {"1", "0", "YES", "NO", "Y", "N", "TRUE", "FALSE", "T", "F", "X"}
                if str(_new_value).strip().upper() not in _VALID_BOOL:
                    validation_errors.append(
                        f"❌ Invalid value `{_new_value}` for boolean field **{_display}**. "
                        f"Please choose: Yes/No (or 1/0, True/False)"
                    )
                    logger.error("NODE 13: boolean field validation failed — %s", _display)
                    continue
            elif _field_name in _CHECKBOX_FIELDS:
                _VALID_CHECKBOX = {"1", "0", "YES", "NO", "Y", "N", "TRUE", "FALSE", "T", "F", "X", ""}
                if str(_new_value).strip().upper() not in _VALID_CHECKBOX:
                    validation_errors.append(
                        f"❌ Invalid value `{_new_value}` for checkbox field **{_display}**. "
                        f"Please choose: Yes/No (or 1/0, True/False, X for checked)"
                    )
                    logger.error("NODE 13: checkbox field validation failed — %s", _display)
                    continue

            _group_data[_api_field] = _new_value
            _updated_data[_group] = _group_data
            
            # Convert code back to display label for user-facing summary message
            _display_value_for_summary = _new_value
            if _field_name == "aprv_proc_adtnl" and str(_new_value).strip():
                _display_value_for_summary = approval_process_to_display(str(_new_value))
            elif _field_name == "transaction_type_scope" and str(_new_value).strip():
                _display_value_for_summary = transaction_type_to_display(str(_new_value))
            elif _field_name in ("risk_adtnl", "priority_adtnl", "zzfld000013_cus", "zzfld000016_cus") and str(_new_value).strip():
                _display_value_for_summary = dropdown_to_display(_field_name, str(_new_value))
            
            logger.info(
                "NODE 13: zzfld patch — %s.%s (%s) → %r", _group, _api_field, _display, _new_value
            )
            summary_parts.append(f"**{_display}** → `{_display_value_for_summary}`")

            # Sync AgentState FieldState for fields that have their own state slot
            if _field_name in _FIELDSTATE_SLOTS:
                _existing_fs = dict(state.get(_field_name) or {})
                patch[_field_name] = {**_existing_fs, "value": _new_value, "given": True, "valid": True, "error": None}
                logger.info("NODE 13: synced AgentState FieldState for %s → %r", _field_name, _new_value)

            if _field_name == "aprv_proc_adtnl":
                _existing_ap = dict(state.get("aprv_proc") or {})
                patch["aprv_proc"] = {
                    **_existing_ap,
                    "value": approval_process_to_display(str(_new_value)),
                    "given": True,
                    "valid": True,
                    "error": None,
                }
                logger.info("NODE 13: synced aprv_proc state from draft update")

            if _field_name == "transaction_type_scope":
                _existing_tt = dict(state.get("transaction_type") or {})
                patch["transaction_type"] = {
                    **_existing_tt,
                    "value": transaction_type_to_display(str(_new_value)),
                    "given": True,
                    "valid": True,
                    "error": None,
                }
                logger.info("NODE 13: synced transaction_type state from draft update")

        patch["cr_id"] = {**_original_crid, "data": _updated_data}

    # ── Apply all text field updates via a single LLM call ────────────────────
    if _text_updates:
        _text_instructions = "\n".join(
            f"- Set {u['field'].replace('_', ' ')} to: {u['value']}"
            for u in _text_updates
        )
        prompt = f"""Apply the following updates to the CR draft.

Current draft:
{state["draft"]}

Updates to apply:
{_text_instructions}

Apply every update listed. Return the full updated draft and its HTML rendering.
"""
        result: ApplyUpdateOutput = llm_with_output(ApplyUpdateOutput).invoke(prompt)
        patch["draft"] = result.updated_draft
        patch["draft_ui"] = {
            **state["draft_ui"],
            "draft_html": result.updated_draft_html,
        }
        summary_parts.append(result.update_summary)

        # Sync AgentState text field slots
        _KEYWORD_TO_FIELD = {
            "reason": "reason_for_change",
            "description": "description_of_change",
            "additional": "additional_information",
        }
        for upd in _text_updates:
            _fn_lower = upd["field"].lower()
            _agentstate_key: str | None = None
            if _fn_lower in {"reason_for_change", "description_of_change", "additional_information"}:
                _agentstate_key = _fn_lower
            else:
                _agentstate_key = next(
                    (v for k, v in _KEYWORD_TO_FIELD.items() if k in _fn_lower), None
                )
            if _agentstate_key and upd["value"]:
                patch[_agentstate_key] = {**state[_agentstate_key], "value": upd["value"]}
                logger.info("NODE 13: synced AgentState field '%s' → '%s'", _agentstate_key, upd["value"])

    # ── Assemble final messages: errors first, then success summary ────────────
    # NOTE: If we have a clarification message from node_10 (disambiguation flow),
    # it's already in the message history with group/section info included.
    # Only add NEW messages for: (1) validation errors or (2) text field updates.
    # Skip adding messages for zzfld-only updates (clarification already provided by node_10).
    _final_messages: list[AIMessage] = []
    if validation_errors:
        _final_messages.extend(AIMessage(content=e) for e in validation_errors)

    # Confirmation for all successfully applied updates (zzfld and text)
    # summary_parts only contains entries for fields that passed validation
    if summary_parts:
        if len(summary_parts) == 1:
            _final_messages.append(AIMessage(content=f"✅ Updated: {summary_parts[0]}"))
        else:
            _final_messages.append(AIMessage(
                content="✅ Updated:\n" + "\n".join(f"  • {p}" for p in summary_parts)
            ))
    elif not validation_errors:
        _final_messages.append(AIMessage(content="Could not parse update intent."))

    if _final_messages:
        patch["messages"] = _final_messages
    return patch
