"""
agents/nodes/nodes_outcome.py

Outcome, recommendation, and cycle ID phase nodes:
  node_15_failed
  node_16_success
  node_17_present_top_5
  node_18_hitl_wait
  cond_edge_c
  node_19_no_recommendations
  node_20_cycle_id_check
  cond_edge_20
  node_20b_cycle_id_hitl
"""
from __future__ import annotations

import re

from observability import get_logger
from langchain_core.messages import AIMessage, HumanMessage
from langgraph.types import Command, interrupt

from config.config import INACTIVE_CYCLE_IDS, MAX_ATTEMPTS, MAX_RECOMMENDATIONS
from state.state import AgentState, empty_field

# AG-UI registered-component contract. Every ui_component payload in this module
# is built through these helpers — never as an inline dict — so the frontend
# registry and the agent stay in lockstep. See agui/ui_contract.py.
from agui import ui_contract
from tools.tools import (
    approval_process_to_code,
    execute_cypher,
    get_template,
    get_transaction_type_for_cycle,
    resolve_change_type_rule,
    transaction_type_to_code,
)
from utils.schemas import IntentRouterC, PresentRecsOutput, RelevanceCheck, ValidateSelectedCR
from utils.llm import llm_with_output, llm_fast_with_output
from ._helpers import get_display_name

logger = get_logger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# NODE 15 — Failed
# Output text: submission failed. → Node 5 → END.
# ─────────────────────────────────────────────────────────────────────────────
def node_15_failed(state: AgentState) -> dict:
    logger.info("NODE 15: failed")
    result = state.get("submission_result") or {}
    _failed_error = str(result.get("error") or "")
    _sap_transaction_id = str(result.get("sap_transaction_id") or "")
    _is_sap_error = bool(result.get("is_sap_error"))
    if "Requestor User ID" in _failed_error and "does not exist" in _failed_error:
        _failed_message = (
            "Submission failed because your user is not configured as a valid requestor in Solution Manager. "
            "Please contact the SolMan support team to map your WWID to a Business Partner, then try again."
        )
    elif "Unable to derive valid Requestor Business Partner" in _failed_error or "derive valid Requestor" in _failed_error:
        _failed_message = (
            "Submission failed."
            "Please contact the SolMan support team to get support, then try again."
        )
    elif _is_sap_error:
        # A genuine SAP API failure (HTTP error, or an EvHasError=X inline
        # business validation error) that doesn't match the two specific
        # patterns above. The real root cause is appended below via the
        # dynamic "Reason" block — avoid repeating it here so it isn't shown twice.
        _failed_message = "Submission failed while creating the Change Request in Solution Manager."
    else:
        # Agent-side failure (missing config, CSRF/template fetch failure,
        # field validation, transaction-type mismatch, generic exceptions,
        # connectivity/URL issues, etc.) — surface the real root cause instead
        # of a generic permission message so the user/SAP support team can
        # actually diagnose it.
        _failed_message = (
            "Submission failed while creating the Change Request in Solution Manager.\n\n"
            f"**Root Cause:** {_failed_error or 'Unknown error — please check application logs.'}\n\n"
            "Please share this detail with the SolMan support team for further investigation."
        )

    # ── Append SAP error detail + transaction ID ONLY when the failure came
    # from the actual SAP API (HTTP error response, or an EvHasError=X inline
    # business validation error), not from agent-side issues (config, CSRF
    # fetch, field validation, etc.). This is additive only — none of the
    # existing messaging above is changed.
    if _is_sap_error and _failed_error and _failed_error != "Solution Manager submission failed":
        if _sap_transaction_id:
            _failed_message += (
                f"\n\n**Reason:** {_failed_error} (Transaction ID: {_sap_transaction_id}). "
                "Please share this Transaction ID with the SAP SolMan support team for further investigation."
            )
        else:
            _failed_message += f"\n\n**Reason:** {_failed_error}"

    return {
        "messages": [
            AIMessage(content=_failed_message)
        ],
        "ui_component": ui_contract.submission_result(
            status="failed", message=_failed_message
        ),
    }


# ─────────────────────────────────────────────────────────────────────────────
# NODE 16 — Success
# Output text: new CR ID. → Node 5 → END.
# ─────────────────────────────────────────────────────────────────────────────
def node_16_success(state: AgentState) -> dict:
    logger.info("NODE 16: success")
    result = state.get("submission_result") or {}
    cr_id = result.get("cr_id", "UNKNOWN")

    # Use the SAP response data (contains all fields of the newly created CR)
    # if available; fall back to the submission template data (has cycle ID etc.).
    existing_crid_state = dict(state.get("cr_id") or {})
    response_data = result.get("response_data") or {}
    # Merge: start from template data (has cycle/landscape), then overlay
    # the real SAP response fields so populated values replace blanks.
    merged_data = dict(existing_crid_state.get("data") or {})
    if response_data:
        for _grp, _val in response_data.items():
            if isinstance(_val, dict) and (_grp.startswith("Is") or _grp.startswith("Iv")):
                existing_grp = dict(merged_data.get(_grp) or {})
                existing_grp.update({k: v for k, v in _val.items() if k != "__metadata" and v not in (None, "", "00000000")})
                merged_data[_grp] = existing_grp
    updated_crid_state = {
        **existing_crid_state,
        "value": cr_id,
        "given": True,
        "valid": True,
        "error": None,
        "data": merged_data,
    }
    logger.info("NODE 16: updated cr_id value to %s, merged SAP response into sidebar data", cr_id)

    # ── Include first draft accuracy if available ────────────────────────────
    _accuracy = state.get("first_draft_accuracy") or {}
    _acc_msg = ""
    if _accuracy and _accuracy.get("total", 0) > 0:
        _pct  = _accuracy["pct"]
        _unch = _accuracy["unchanged"]
        _tot  = _accuracy["total"]
        _chg  = _accuracy.get("changed_fields", [])
        _acc_msg = f"\n\n🎯 **First Draft Accuracy: {_unch}/{_tot} ({_pct}%)**\n"
        if _chg:
            _chg_labels = [get_display_name(f) or f for f in _chg]
            _acc_msg += f"Fields modified from first draft: {', '.join(_chg_labels)}"
        else:
            _acc_msg += "No fields were changed from the first draft."

    _success_message = f"✅ Successfully submitted! New CR ID: {cr_id}{_acc_msg}"
    return {
        "messages": [
            AIMessage(content=_success_message)
        ],
        "cr_id": updated_crid_state,
        # cr_id may be None here — solman_write can report success without an
        # EvObjectID. The card renders that case as an error rather than a success,
        # since a CR with no identifier cannot be reconciled.
        "ui_component": ui_contract.submission_result(
            status="success", message=_success_message, cr_id=cr_id
        ),
    }


# ─────────────────────────────────────────────────────────────────────────────
# NODE 17 — Present Top 5 Recommendations
# LLM formats output text + draft_ui showcasing ALL 5 recommendations.
# ─────────────────────────────────────────────────────────────────────────────
def node_17_present_top_5(state: AgentState) -> dict:
    logger.info("NODE 17: present_top_5")

    bc = state["baseline_crs"]
    recs = []
    for slot in ["cr_1", "cr_2", "cr_3", "cr_4", "cr_5"]:
        cr = bc.get(slot)
        if cr:
            recs.append(cr)

    recs_text = "\n".join(
        (
            f"{i+1}. Object ID: {r['object_id']}"
            + (f" | Platform: {r['platform']}" if r.get('platform') else "")
            + (f" | Target System: {r['target_system']}" if r.get('target_system') else "")
            + (f" | Change Cycle: {r['title'][:80]}" if r.get('title') else "")
            + (f" | Description: {r['description'][:100]}" if r.get('description') else "")
            + f" Similarity score: {r['ranking_score']:.3f}"
            + (" [Platform match]" if r.get('platform_match') else "")
            + (" [Target match]" if r.get('target_system_match') else "")
        )
        for i, r in enumerate(recs)
    )

    # ── Build the reasoning intro sentence deterministically (no LLM paraphrasing) ──
    # description_of_change / reason_for_change already hold the EXACT text —
    # either the user's own explicit input, or (if the user didn't provide it)
    # the text auto-generated from the JIRA ticket in node_2. Either way, use it verbatim.
    _desc_ctx = state["description_of_change"].get("value", "").strip()
    _reason_ctx = state["reason_for_change"].get("value", "").strip()

    def _trunc_ctx(t: str, n: int = 200) -> str:
        return (t[:n] + "…") if len(t) > n else t

    if _desc_ctx and _reason_ctx:
        _reasoning_intro = (
            f'Based on your description of change and reason for change '
            f'here are the top matching Change Requests:'
        )
    
    else:
        _reasoning_intro = "Here are the top matching Change Requests:"

    prompt = f"""Produce HTML for display of these top 5 similar Change Requests (recommendations_html only).
Do not generate output_text — it is built separately in code.

Recommendations:
{recs_text}
"""
    result: PresentRecsOutput = llm_fast_with_output(PresentRecsOutput).invoke(prompt)  # fast model — simple formatting

    # ── Build output_text in code: exact reasoning intro + numbered list (never paraphrased) ──
    _numbered_list = "\n".join(
        f"{i+1}. Object ID: {r['object_id']}"
        + (f" | Platform: {r['platform']}" if r.get('platform') else "")
        + (f" | Target System: {r['target_system']}" if r.get('target_system') else "")
        + (f" | Change Cycle: {r['title'][:80]}" if r.get('title') else "")
        + (f" | Description: {r['description'][:100]}" if r.get('description') else "")
        + f" | Similarity score: {r['ranking_score']:.3f}"
        + (" [Platform match]" if r.get('platform_match') else "")
        + (" [Target match]" if r.get('target_system_match') else "")
        for i, r in enumerate(recs)
    )
    _instruction_line = "You can choose from the options below or type a CR ID directly."
    output_text = _reasoning_intro + (
        f"\n\n{_instruction_line}\n{_numbered_list}" if _numbered_list else ""
    )

    _n = len([r for r in recs if r.get("object_id")])

    _obj_ids = [
        {
            "label": (
                f"{r['object_id']}"
                + (f" | Platform: {r['platform']}" if r.get('platform') else "")
                + (f" | Target System: {r['target_system']}" if r.get('target_system') else "")
                + (f" | Change Cycle: {r['title'][:80]}" if r.get('title') else "")
                + (f" | Description: {r['description'][:100]}" if r.get('description') else "")
                + f" | Similarity score: {r['ranking_score']:.3f}"
                + (" [Platform match]" if r.get('platform_match') else "")
                + (" [Target match]" if r.get('target_system_match') else "")
            ),
            "value": str(r["object_id"]),
        }
        for r in recs if r.get("object_id")
    ]
    return {
        "messages": [AIMessage(content=output_text)],
        "draft_ui": {
            **state["draft_ui"],
            "recommendations_html": result.recommendations_html,
            "output_text": output_text,
        },
        "exhausted_attempts": 0,
        "clickable_options": _obj_ids or None,
        # AG-UI: Template ID / Reference CR picker. Each reference row carries the
        # CR's own data as an expandable detail panel. reference_options_from_baseline
        # skips any slot carrying an `error`, so placeholder rows are never offered.
        "ui_component": ui_contract.template_or_cr_picker(
            template_options=[],
            reference_options=ui_contract.reference_options_from_baseline(
                state.get("baseline_crs")
            ),
        ),
    }


# ─────────────────────────────────────────────────────────────────────────────
# NODE 18 — HITL Wait (CR selection from recommendations)
# Command node: interrupt(), check relevance ×MAX_ATTEMPTS.
# Also checks if user intent is to approve a CR — validates against mentioned_object_ids.
# Exhausted → Node 5 (CORRECTED from previous version)
# Relevant → Cond Edge C
# ─────────────────────────────────────────────────────────────────────────────
def node_18_hitl_wait(state: AgentState) -> Command:
    logger.info("NODE 18: hitl_wait (CR selection)")

    attempts: int = state.get("exhausted_attempts", 0)

    if attempts >= MAX_ATTEMPTS:
        return Command(
            update={
                "messages": [
                    AIMessage(
                        content=(
                            "We're having trouble finding a suitable CR. "
                            "Please start a new session when you're ready."
                        )
                    )
                ]
            },
            goto="node_5",   # ★ CORRECTED: exhausted → Node 5
        )

    if attempts == 0:
        user_response: str = interrupt(
            "Please type the full Object ID (e.g. Object ID: 50412146), "
            "or provide your own Template ID or CR ID."
        )
    else:
        user_response = interrupt(
            "Please type a full CR Object ID (e.g. Object ID: 50412496), "
            "or your own Template ID / CR ID."
        )

    # Short-circuit: bare number 1–5 → map to the corresponding recommended object ID
    _cr_source: str | None = None  # tracks how the user selected their baseline CR
    user_response = str(user_response)
    _bare_num_match = re.fullmatch(r'\s*([1-5])\s*', user_response)
    if _bare_num_match:
        _slot = f"cr_{_bare_num_match.group(1)}"
        _picked_cr = state["baseline_crs"].get(_slot)
        if _picked_cr and _picked_cr.get("object_id"):
            user_response = _picked_cr["object_id"]
            _cr_source = f"rank_{_bare_num_match.group(1)}"
            logger.info(
                "NODE 18: user selected number %s → mapped to object_id=%s",
                _bare_num_match.group(1), user_response,
            )

    # Deterministic pre-check: template_id — user said "template [id] NNNNN" (5-7 digit number)
    _template_id_match = re.search(r'\btemplate\b[^\d\n]{0,20}?(\d{5,7})\b', user_response, re.IGNORECASE)
    if not _template_id_match:
        # Fallback: bare 5-7 digit number with no other context → treat as template ID.
        # Excludes 1-5 (already handled as recommendation slot above) and 8-digit (CR Object IDs).
        _bare_tmpl_match = re.fullmatch(r'\s*(\d{5,7})\s*', user_response)
        if _bare_tmpl_match:
            _template_id_match = _bare_tmpl_match  # reuse same variable for unified handling below
    if _template_id_match:
        _tmpl_id = _template_id_match.group(1)
        logger.info("NODE 18: detected template_id=%s — fetching data and routing to node_6", _tmpl_id)
        tmpl_data = get_template(_tmpl_id)
        if "error" in tmpl_data:
            # Template ID not found — tell the user and re-interrupt instead of silently failing
            logger.info("NODE 18: template_id=%s not found (error=%s) — re-prompting", _tmpl_id, tmpl_data.get("error"))
            return Command(
                update={
                    "messages": [
                        HumanMessage(content=user_response),
                        AIMessage(content=(
                            f"I couldn't find a template with ID **{_tmpl_id}**. "
                            "Please check the ID and try again, or select one of the recommendations above."
                        )),
                    ],
                    "exhausted_attempts": attempts + 1,
                },
                goto="node_18",
            )
        return Command(
            update={
                "messages": [HumanMessage(content=user_response)],
                "exhausted_attempts": 0,
                "template_id": {
                    "given": True,
                    "valid": True,
                    "value": _tmpl_id,
                    "data": tmpl_data,
                    "error": None,
                },
                "cr_recommendation_source": "user_template_id",
            },
            goto="node_6",
        )

    # Deterministic pre-check: if message contains an 8-digit number it IS a CR ID selection
    _cr_id_in_msg = re.search(r'\b\d{8}\b', user_response)
    if _cr_id_in_msg:
        logger.info(
            "NODE 18: detected 8-digit CR ID in message (%s) — treating as relevant",
            _cr_id_in_msg.group(),
        )
        _is_relevant = True
    else:
        relevance: RelevanceCheck = llm_fast_with_output(RelevanceCheck).invoke(  # fast model — simple classification
            f"""Is the user directly trying to SELECT, APPROVE, or IDENTIFY a specific Change Request?

Valid relevant responses include: choosing a number (1-5), providing a CR/Object ID, naming a CR, expressing intent to use a specific recommendation.

NOT relevant: questions about how the system works, scoring methodology, explanations, general questions, or anything unrelated to picking a CR.

User said: {user_response}"""
        )
        _is_relevant = relevance.is_relevant

    if not _is_relevant:
        return Command(
            update={
                "messages": [
                    HumanMessage(content=user_response),
                    AIMessage(
                        content=(
                            "That doesn't seem related to the CR recommendations. "
                            f"Attempt {attempts + 1}/{MAX_ATTEMPTS}."
                        )
                    ),
                ],
                "exhausted_attempts": attempts + 1,
            },
            goto="node_18",
        )

    # Check if user is approving a specific CR — validate it hasn't been mentioned
    mentioned = state["baseline_crs"].get("mentioned_object_ids", [])
    validation: ValidateSelectedCR = llm_with_output(ValidateSelectedCR).invoke(
        f"""The user responded to CR recommendations.
User message: {user_response}
Already mentioned CR IDs: {mentioned}

Is the user approving a specific CR ID? If so, which one?
Is that CR ID already in the mentioned list? If yes, is_valid_selection=False.
"""
    )

    new_mentioned = list(mentioned)
    cr_id_patch = dict(state["cr_id"])   # carry forward existing value by default
    if validation.selected_cr_id and validation.selected_cr_id not in new_mentioned:
        new_mentioned.append(validation.selected_cr_id)
        logger.info("NODE 18: fetching Solman data for selected cr_id=%s", validation.selected_cr_id)
        cr_data = get_template(validation.selected_cr_id)
        cr_id_patch = {
            "given": True,
            "valid": "error" not in cr_data,
            "value": validation.selected_cr_id,
            "data":  cr_data if "error" not in cr_data else None,
            "error": cr_data.get("error") if "error" in cr_data else None,
        }
        logger.info("NODE 18: cr_id populated — value=%s valid=%s fields=%d",
            validation.selected_cr_id, cr_id_patch["valid"], len(cr_id_patch.get("data") or {}))
        
     # If user typed a full CR ID (not picked by slot number), check if it matches a recommendation
    if validation.selected_cr_id and not _cr_source:
        for _rank, _slot in enumerate(["cr_1", "cr_2", "cr_3", "cr_4", "cr_5"], 1):
            _slot_cr = state["baseline_crs"].get(_slot)
            if _slot_cr and _slot_cr.get("object_id") == validation.selected_cr_id:
                _cr_source = f"rank_{_rank}"
                logger.info(
                    "NODE 18: typed CR ID %s matches recommendation slot_%d",
                    validation.selected_cr_id, _rank,
                )
                break

    return Command(
        update={
            "messages": [HumanMessage(content=user_response)],
            "exhausted_attempts": 0,
            "cr_id": cr_id_patch,
            "baseline_crs": {
                **state["baseline_crs"],
                "mentioned_object_ids": new_mentioned,
            },
            "cr_recommendation_source": _cr_source or "user_cr_id",
        },
        goto="cond_edge_c",
    )


# ─────────────────────────────────────────────────────────────────────────────
# CONDITIONAL EDGE C — LLM intent router (after Node 18 HITL)
# approve_cr → node_6 (Build Draft using selected CR as basis)
# recommend_more → node_7 (Suggest Similar CRs again)
# max_hit (len(mentioned_object_ids) >= MAX_RECOMMENDATIONS) → node_19
# ─────────────────────────────────────────────────────────────────────────────
def cond_edge_c(state: AgentState) -> str:
    logger.info("COND C: routing recommendation intent")

    mentioned = state["baseline_crs"].get("mentioned_object_ids", [])

    if len(mentioned) >= MAX_RECOMMENDATIONS:
        logger.info("COND C → node_19 (max recommendations hit)")
        return "node_19"

    last_human = next(
        (m.content for m in reversed(state["messages"]) if isinstance(m, HumanMessage)),
        "",
    )
    result: IntentRouterC = llm_with_output(IntentRouterC).invoke(
        f"""Determine the user's intent regarding CR recommendations.

User message: {last_human}
Already mentioned CRs: {mentioned}
Max recommendations limit: {MAX_RECOMMENDATIONS}

Classify as:
- approve_cr: user selected and approved a specific CR OR provided a Template ID to use as the basis for their draft (e.g. "template id 656280", "use template 12345", any 5-8 digit ID the user is offering as their own)
- recommend_more: user wants to see more recommendations or has not selected any specific CR or template
- max_hit: recommendation limit reached (use only if len(mentioned) >= {MAX_RECOMMENDATIONS})
"""
    )
    logger.info("COND C intent: %s", result.intent)

    mapping = {
        "approve_cr": "node_6",
        "recommend_more": "node_7",
        "max_hit": "node_19",
    }
    return mapping.get(result.intent, "node_7")


# ─────────────────────────────────────────────────────────────────────────────
# NODE 19 — Format Output: No Recommendations Good Enough
# Max recommendations hit or none were suitable. → Node 5 → END.
# ─────────────────────────────────────────────────────────────────────────────
def node_19_no_recommendations(state: AgentState) -> dict:
    logger.info("NODE 19: no_recommendations")

    mentioned = state["baseline_crs"].get("mentioned_object_ids", [])
    return {
        "messages": [
            AIMessage(
                content=(
                    f"We've reviewed {len(mentioned)} Change Requests and none were a suitable match. "
                    "Unfortunately, the agent cannot help further with CR recommendations. "
                    "Please contact your CR coordinator directly."
                )
            )
        ],
        "cr_recommendation_source": "none_selected",
    }


# ─────────────────────────────────────────────────────────────────────────────
# NODE 20 — Cycle ID Check (regular node — emits AIMessage question if mismatch)
# Only active when cr_id is the baseline (user selected an 8-digit CR ID).
# After Node 6 builds the draft, checks whether the Cycle ID in that draft
# is the most common one for the user's platform + target_system in Neo4j.
#
# If skip / match  → sets cycle_id_pending=None, cond_edge_20 routes to node_8
# If mismatch      → sets cycle_id_pending={...}, emits AIMessage question,
#                    cond_edge_20 routes to node_20b (HITL interrupt)
# ─────────────────────────────────────────────────────────────────────────────
def node_20_cycle_id_check(state: AgentState) -> dict:
    logger.info("NODE 20: cycle_id_check — checking if draft cycle matches target system")

    # Skip if user already made a cycle decision (selected or declined)
    if state.get("cycle_confirmed"):
        logger.info("NODE 20: skipping — cycle already confirmed by user")
        return {"cycle_id_pending": None}

    crid_state = state.get("cr_id") or {}
    cr_id_value = str(crid_state.get("value", "")).strip()
    if not cr_id_value:
        logger.info("NODE 20: skipping — cr_id value is empty")
        return {"cycle_id_pending": None, "cycle_id_selection": "N/A"}

    # Resolve target_system value
    tgt_state = state.get("target_system") or {}
    tgt_value = tgt_state.get("value", "").strip()

    if not tgt_value:
        logger.info("NODE 20: skipping — target_system not available")
        return {"cycle_id_pending": None, "cycle_id_selection": "N/A"}

    # Fetch Cycle ID of the baseline CR from Neo4j
    rows = execute_cypher(
        "MATCH (c:ChangeRequest {object_id: $oid}) "
        "RETURN c.solution_id_ctx AS cycle_id, "
        "c.project_title_ctx AS cycle, c.slan_name_ctx AS landscape LIMIT 1",
        {"oid": cr_id_value},
    )
    if not rows or rows[0].get("error") or not rows[0].get("cycle_id"):
        # Neo4j miss — template IDs (5-7 digits) are not stored as ChangeRequest nodes.
        # Fall back to cycle data already fetched from the Solman API into state.
        _cr_data_20  = crid_state.get("data") or {}
        _iv_ctx_20   = _cr_data_20.get("IvContext") or {}
        _iv_det_20   = _cr_data_20.get("IvDetails") or {}
        _fb_cycle_id = (
            str(_iv_ctx_20.get("CycleID") or "").strip()
            or str(_iv_det_20.get("CycleId") or "").strip()
        )
        if not _fb_cycle_id:
            logger.info(
                "NODE 20: Neo4j/API cycle_id unavailable for cr_id=%s — proceeding with target-system recommendations",
                cr_id_value,
            )
        else:
            logger.info(
                "NODE 20: Neo4j miss for %s — using API IvContext/IvDetails CycleId=%r",
                cr_id_value, _fb_cycle_id,
            )
        draft_cycle_id   = _fb_cycle_id
        draft_cycle_name = str(_iv_ctx_20.get("ChangeCyclePhase") or _iv_det_20.get("ChangeCyclePhase") or "").strip()
        draft_landscape  = str(_iv_ctx_20.get("Landscape") or _iv_det_20.get("Landscape") or "").strip()
    else:
        draft_cycle_id   = str(rows[0]["cycle_id"]).strip()
        draft_cycle_name = str(rows[0].get("cycle")     or "").strip()
        draft_landscape  = str(rows[0].get("landscape") or "").strip()

    # Find common Cycle IDs for target_system (broader list, capped for usability)
    common_rows = execute_cypher(
        """
        MATCH (c:ChangeRequest)
        WHERE c.configuration_descr = $target_system
          AND c.solution_id_ctx IS NOT NULL
          AND c.solution_id_ctx <> ''
          AND NOT toString(toInteger(toString(c.solution_id_ctx))) IN $inactiveCycleIds
        WITH c.solution_id_ctx AS cycle_id, count(*) AS cnt,
             collect(c.project_title_ctx)[0] AS cycle,
             collect(c.slan_name_ctx)[0] AS landscape
        RETURN cycle_id, cnt, cycle, landscape
        ORDER BY cnt DESC
           LIMIT 30
        """,
        {"target_system": tgt_value, "inactiveCycleIds": INACTIVE_CYCLE_IDS},
    )
    if not common_rows or common_rows[0].get("error"):
        logger.info("NODE 20: skipping — could not determine cycle options")
        return {"cycle_id_pending": None, "cycle_id_selection": "N/A"}

    options = [
        {
            "cycle_id":  str(r["cycle_id"]).strip(),
            "cnt":       int(r.get("cnt", 0)),
            "cycle":     str(r.get("cycle")     or "").strip(),
            "landscape": str(r.get("landscape") or "").strip(),
        }
        for r in common_rows
        if r.get("cycle_id") and not r.get("error")
           and str(r["cycle_id"]).strip() != draft_cycle_id
    ]

    if not options:
        logger.info("NODE 20: skipping — no cycle options found for target system")
        return {"cycle_id_pending": None, "cycle_id_selection": "N/A"}

    # Add dominant transaction type display (e.g., "JnJ-Admin Change") per cycle option.
    for opt in options:
        tx_desc = get_transaction_type_for_cycle(opt["cycle_id"])
        opt["transaction_type"] = tx_desc or "—"

    top_cycle_id = options[0]["cycle_id"]

    # Always show cycle confirmation — even when draft already matches the top option
    logger.info("NODE 20: always prompting cycle confirmation for draft cycle %r", draft_cycle_id)

    # Build message with cycle options table
    def _disp_cycle(raw: str) -> str:
        """Strip leading zeros for display."""
        return raw.lstrip("0") or "0"

    # Format as numbered list with aligned starts (not messy table)
    # Each option takes multiple lines for readability
    option_lines = []
    for i, opt in enumerate(options, start=1):
        option_lines.append(
            f"{i}. **Cycle ID:** {_disp_cycle(opt['cycle_id'])}\n"
            f"   **Change Cycle:** {opt.get('cycle', '—')}\n"
            f"   **Landscape:** {opt.get('landscape', '—')}\n"
            f"   **Transaction Type:** {opt.get('transaction_type', '—')}\n"
            f"   **Occurrences:** {opt['cnt']}"
        )
    options_table = "\n\n".join(option_lines)

    if draft_cycle_id:
        _draft_meta = f"**Change Cycle:** {draft_cycle_name}" if draft_cycle_name else ""
        if draft_landscape:
            _draft_meta += (f" | **Landscape:** {draft_landscape}")
        # Check if the draft's current cycle is inactive — warn user to pick another
        _draft_cycle_id_norm = str(int(str(draft_cycle_id).strip())) if str(draft_cycle_id).strip() else ""
        _inactive_norm = {str(int(str(cid).strip())) for cid in INACTIVE_CYCLE_IDS if str(cid).strip()}
        _inactive_warning = (
            f"\n\n⚠️ **Cycle ID {_disp_cycle(draft_cycle_id)} is inactive.** Please select one of the active options below."
            if _draft_cycle_id_norm in _inactive_norm else ""
        )
        question_text = (
            f" **Cycle ID Confirmation**\n\n"
            f"This draft uses Cycle ID **{_disp_cycle(draft_cycle_id)}** ({_draft_meta}), "
            f"but for target system **{tgt_value}**, there are more common Cycle IDs available."
            f"{_inactive_warning}\n\n"
            f"Select one of the options below to update the draft.\n\n"
            f"{options_table}"
        )
    else:
        question_text = (
            f" **Cycle ID Recommendation**\n\n"
            f"We could not read a draft Cycle ID for this template, but for target system **{tgt_value}** "
            f"these are the most common Cycle IDs.\n\n"
            f"Select one of the options below to set the cycle, or reply **yes** to keep the draft unchanged.\n\n"
            f"{options_table}"
        )

    logger.info("NODE 20: cycle mismatch detected — routing to node_20b for user selection")
    _cycle_btn_opts = [
        {
            "label": f"{_disp_cycle(o['cycle_id'])} — {o.get('cycle', '')}" if o.get("cycle") else _disp_cycle(o["cycle_id"]),
            "value": _disp_cycle(o["cycle_id"]),
        }
        for o in options
    ]
    # Only hide "Yes, keep" when draft_cycle_id is explicitly listed as inactive.
    _inactive_cycle_ids_norm = {str(int(str(cid).strip())) for cid in INACTIVE_CYCLE_IDS if str(cid).strip()}
    _draft_cycle_id_norm = str(int(str(draft_cycle_id).strip())) if str(draft_cycle_id).strip() else ""
    # Only offered when the draft's own cycle is still active — otherwise there is
    # nothing valid to keep. Stays None in that case so the card does not render a
    # keep-current row.
    _keep_label: str | None = None
    if draft_cycle_id and _draft_cycle_id_norm not in _inactive_cycle_ids_norm:
        _keep_label = f"Yes, keep {_disp_cycle(draft_cycle_id)}"
        _cycle_btn_opts.append({
            "label": _keep_label,
            "value": "yes",
        })
    return {
        "messages": [AIMessage(content=question_text)],
        "cycle_id_pending": {
            "draft_cycle_id": draft_cycle_id,
            "options": options,
        },
        "clickable_options": _cycle_btn_opts or None,
        # AG-UI: cycle picker. Only the intro sentence is passed through — the option
        # grid is the card's job, so question_text's markdown table is stripped to
        # avoid showing the same list twice in two formats.
        "ui_component": ui_contract.cycle_id_picker(
            message=question_text.split("Select one of the options below")[0].strip(),
            options=ui_contract.options_from_clickable(_cycle_btn_opts),
            draft_cycle_id=_disp_cycle(draft_cycle_id) if draft_cycle_id else None,
            keep_current_label=_keep_label,
        ),
    }


def cond_edge_20(state: AgentState) -> str:
    """Route cycle flow through HITL when needed, otherwise proceed directly to draft."""
    if state.get("cycle_id_pending"):
        return "node_20b"
    return "node_8"


# ─────────────────────────────────────────────────────────────────────────────
# NODE 20b — Cycle ID HITL (interrupt + apply user decision)
# Reads cycle_id_pending set by node_20, interrupts for user confirmation,
# then either updates the draft or leaves it unchanged.
# ─────────────────────────────────────────────────────────────────────────────
def node_20b_cycle_id_hitl(state: AgentState) -> Command:
    logger.info("NODE 20b: cycle_id_hitl (awaiting user selection)")

    pending        = state.get("cycle_id_pending") or {}
    draft_cycle_id = pending.get("draft_cycle_id", "")
    options        = pending.get("options", [])  # list of {"cycle_id": str, "cnt": int}
    n              = len(options)
    cycle_attempts: int = state.get("cycle_hitl_attempts", 0)

    if cycle_attempts >= MAX_ATTEMPTS:
        # Too many irrelevant inputs — keep current cycle and move on
        logger.info("NODE 20b: max out-of-context attempts reached — keeping draft cycle_id as-is")
        return Command(
            update={
                "messages": [
                    AIMessage(
                        content=(
                            "We're having trouble with the cycle selection. "
                            "Keeping the current cycle and proceeding."
                        )
                    )
                ],
                "cycle_id_pending": None,
                "cycle_confirmed": True,
                "cycle_hitl_attempts": 0,
                "cycle_id_selection": "default",
                "cycle_change_autofilled": None,
            },
            goto="node_8",
        )

    if cycle_attempts == 0:
        _base_prompt_20b = (
            f"Please reply with the Cycle ID (leading zeros optional) to update, "
            f"or type 'yes' to keep the current one."
        ) if n else "Please type the Cycle ID to use, or 'yes' to keep the current one."
        # Prepend node_20's rich cycle context message (last AIMessage in state)
        _last_ai_20b = next(
            (m.content.strip() for m in reversed(state["messages"]) if isinstance(m, AIMessage) and m.content),
            "",
        )
        prompt = f"{_last_ai_20b}\n\n{_base_prompt_20b}" if _last_ai_20b and _last_ai_20b != _base_prompt_20b else _base_prompt_20b
    else:
        prompt = (
            f"That doesn't seem related to the cycle selection. "
            f"Please reply with a Cycle ID, or 'yes' to keep the current one."
        ) if n else (
            f"That doesn't seem related to the cycle selection. "
            f"Please type the Cycle ID to use, or 'yes' to keep the current one."
        )

    user_response: str = interrupt(prompt)
    user_response = str(user_response)

    # ── Resolve which cycle ID the user chose ────────────────────────────────
    raw          = user_response.strip()
    lower_resp   = raw.lower()
    chosen_cycle_id: str | None = None

    _YES_KEEP_WORDS = {"yes", "y", "yeah", "yep", "keep", "ok", "okay", "confirm"}

    if not any(w == lower_resp for w in _YES_KEEP_WORDS):
        option_ids = [o["cycle_id"] for o in options]

        # Helper: normalize cycle IDs by stripping leading zeros
        def normalize_cycle(cid: str) -> str:
            return str(cid).lstrip("0") or "0"

        # 1) A Cycle ID appears anywhere in the user's message (with leading zero handling)
        for oid in option_ids:
            oid_norm = normalize_cycle(oid)
            # Try direct match or normalized match
            if oid in raw or oid_norm in raw:
                chosen_cycle_id = oid
                logger.info("NODE 20b: matched cycle ID %r (normalized: %r)", oid, oid_norm)
                break

        # 2) User typed a bare number like "1" or "2" (for option selection)
        if chosen_cycle_id is None and raw.isdigit():
            idx = int(raw) - 1
            if 0 <= idx < n:
                chosen_cycle_id = options[idx]["cycle_id"]
                logger.info("NODE 20b: matched option number %s → cycle ID %r", raw, chosen_cycle_id)

        # 3) A standalone cycle ID in text (multi-digit number like "652917")
        if chosen_cycle_id is None:
            m = re.search(r'\b(\d{2,})\b', raw)  # Match 2+ digit numbers (cycle IDs typically 6 digits)
            if m:
                user_number = m.group(1)
                user_norm = normalize_cycle(user_number)
                # Find matching option by normalized value
                for oid in option_ids:
                    oid_norm = normalize_cycle(oid)
                    if user_norm == oid_norm:
                        chosen_cycle_id = oid
                        logger.info("NODE 20b: matched cycle ID from text %r (normalized: %r)", user_number, user_norm)
                        break

        # 4) Fallback: if only one option and user said yes/ok/sure treat as pick #1
        if chosen_cycle_id is None and n == 1:
            _YES_WORDS = {"yes", "y", "yeah", "sure", "ok", "okay", "proceed", "go ahead", "change", "update"}
            if any(w in lower_resp for w in _YES_WORDS):
                chosen_cycle_id = options[0]["cycle_id"]
                logger.info("NODE 20b: single option with affirmative response → cycle ID %r", chosen_cycle_id)

    if chosen_cycle_id and draft_cycle_id:
        # Look up the landscape for the chosen cycle from the options list
        chosen_landscape = ""
        for opt in options:
            if opt.get("cycle_id") == chosen_cycle_id:
                chosen_landscape = str(opt.get("landscape") or "").strip()
                break
        logger.info(
            "NODE 20b: user chose cycle_id %r (was %r) landscape=%r — finding template CR for new cycle",
            chosen_cycle_id, draft_cycle_id, chosen_landscape,
        )
        
        # Find ANY CR that uses the new cycle_id (not requiring target system match)
        # This gives us a valid template with all fields correct for the new cycle
        template_cr_rows = execute_cypher(
            """
            MATCH (c:ChangeRequest)
            WHERE c.solution_id_ctx = $cycle_id
            RETURN c.object_id AS object_id
            LIMIT 1
            """,
            {"cycle_id": chosen_cycle_id},
        )
        
        new_template_cr_id = None
        if template_cr_rows and not template_cr_rows[0].get("error"):
            new_template_cr_id = str(template_cr_rows[0].get("object_id", "")).strip()
            logger.info("NODE 20b: found CR %s for new cycle %s — will fetch and rebuild draft", new_template_cr_id, chosen_cycle_id)
        else:
            logger.warning("NODE 20b: no CR found for cycle %s — will use current template only", chosen_cycle_id)
        
        # Build updated data for the new cycle.
        # ONLY update cycle-specific fields in IsDetails — keep all other groups
        # (IsOthers, IsTestingRequirements, IsDocumentationRequirements, etc.)
        # exactly as they were from the original CR.
        # This ensures picking a cycle only changes CycleId, Landscape, CycleType,
        # ApprovalProcedure — not 50 unrelated fields from a different template CR.
        original_crid_state = dict(state.get("cr_id") or {})
        original_data = dict(original_crid_state.get("data") or {})

        # Fetch cycle-specific fields from the new template CR.
        _cycle_fields: dict = {}
        if new_template_cr_id:
            new_template_data = get_template(new_template_cr_id)
            if "error" not in new_template_data or not new_template_data.get("error"):
                _new_details = new_template_data.get("IvDetails") or {}
                _new_context = new_template_data.get("IvContext") or {}
                # Read from both IvDetails and IvContext so the selected cycle's
                # latest CycleType/phase data wins regardless of where SAP returned it.
                _DETAIL_FIELDS = {
                    "CycleId": "CycleId",
                    "CycleType": "CycleType",
                    "Landscape": "Landscape",
                    "ApprovalProcedure": "ApprovalProcedure",
                    "ChangeCyclePhase": "ChangeCyclePhase",
                    "Branch": "Branch",
                    "ChangeCycle": "ChangeCycle",
                }
                _CONTEXT_TO_DETAIL = {
                    "CycleID": "CycleId",
                    "CycleType": "CycleType",
                    "Landscape": "Landscape",
                    "ChangeCyclePhase": "ChangeCyclePhase",
                    "Branch": "Branch",
                    "ChangeCycle": "ChangeCycle",
                }
                if isinstance(_new_details, dict):
                    for _src_f, _dest_f in _DETAIL_FIELDS.items():
                        _val = _new_details.get(_src_f)
                        if _val not in (None, "", "00000000"):
                            _cycle_fields[_dest_f] = _val
                if isinstance(_new_context, dict):
                    for _src_f, _dest_f in _CONTEXT_TO_DETAIL.items():
                        _val = _new_context.get(_src_f)
                        if _val not in (None, "", "00000000"):
                            _cycle_fields[_dest_f] = _val

        # Always force CycleId and Landscape from the user's selection
        # Normalise to 10-digit zero-padded format (strip excess leading zeros, then pad to 10)
        _cycle_fields["CycleId"] = (chosen_cycle_id.lstrip("0") or "0").zfill(10)
        if chosen_landscape:
            _cycle_fields["Landscape"] = chosen_landscape

        # Apply only cycle fields on top of original IvDetails — everything else untouched
        orig_iv_details = dict(original_data.get("IvDetails") or {})
        updated_iv_details = {**orig_iv_details, **_cycle_fields}

        # Also sync cycle fields into IvContext (primary source for document display/submission)
        _DET_TO_CTX = {
            "CycleId":          "CycleID",
            "CycleType":        "CycleType",
            "Landscape":        "Landscape",
            "ChangeCyclePhase": "ChangeCyclePhase",
            "Branch":           "Branch",
            "ChangeCycle":      "ChangeCycle",
        }
        orig_iv_context = dict(original_data.get("IvContext") or {})
        for _det_f, _ctx_f in _DET_TO_CTX.items():
            if _det_f in _cycle_fields:
                orig_iv_context[_ctx_f] = _cycle_fields[_det_f]

        merged_data = {**original_data, "IvDetails": updated_iv_details, "IvContext": orig_iv_context}
        merged_data["IvTemplateID"] = new_template_cr_id

        transaction_type = get_transaction_type_for_cycle(chosen_cycle_id)
        resolved_change_type = resolve_change_type_rule(
            transaction_type,
            str(orig_iv_context.get("CycleType") or updated_iv_details.get("CycleType") or "").strip(),
        ) if transaction_type else {}

        _aprv_state_patch = None
        _tt_state_patch = None
        _cycle_autofilled = False
        if resolved_change_type:
            updated_iv_details["StandardChange"] = resolved_change_type["standard_change"]
            updated_iv_details["OperateChange"] = resolved_change_type["operate_change"]
            updated_iv_details["AprvProc"] = approval_process_to_code(resolved_change_type["approval_process"])
            orig_iv_context["CycleType"] = resolved_change_type["cycle_type"]
            _iv_scope_updated = dict(merged_data.get("IvScope") or {})
            _iv_scope_updated["TransactionType"] = transaction_type_to_code(resolved_change_type["transaction_type"])
            # CRITICAL: Preserve IvTemplateID through reassignment — MUST use new template CR ID
            merged_data = {
                **merged_data,
                "IvDetails": updated_iv_details,
                "IvContext": orig_iv_context,
                "IvScope": _iv_scope_updated,
                "IvTemplateID": new_template_cr_id,
            }
            _aprv_state_patch = {
                **dict(state.get("aprv_proc") or empty_field()),
                "given": True,
                "valid": True,
                "value": resolved_change_type["approval_process"],
                "error": None,
            }
            _tt_state_patch = {
                **dict(state.get("transaction_type") or empty_field()),
                "given": True,
                "valid": True,
                "value": resolved_change_type["transaction_type"],
                "error": None,
            }
            _cycle_autofilled = True
            logger.info(
                "NODE 20b: cycle %s resolved transaction type %r → SC=%r OC=%r AprvProc=%r CycleType=%r TT=%r",
                chosen_cycle_id,
                transaction_type,
                resolved_change_type["standard_change"],
                resolved_change_type["operate_change"],
                resolved_change_type["approval_process"],
                resolved_change_type["cycle_type"],
                resolved_change_type["transaction_type"],
            )
        else:
            logger.warning(
                "NODE 20b: no transaction-type mapping resolved for cycle %s; re-prompting cycle selection (no legacy fallback path)",
                chosen_cycle_id,
            )
            return Command(
                update={
                    "messages": [
                        HumanMessage(content=user_response),
                        AIMessage(
                            content=(
                                "I couldn't resolve change-type mapping for that cycle. "
                                "Please select another cycle ID, or type 'yes' to keep the current cycle."
                            )
                        ),
                    ],
                    "cycle_hitl_attempts": cycle_attempts + 1,
                    "cycle_change_autofilled": None,
                },
                goto="node_20b",
            )

        # Log exactly what changed for visibility in terminal
        _changed_fields = {
            f: {"before": orig_iv_details.get(f, ""), "after": v}
            for f, v in _cycle_fields.items()
            if str(orig_iv_details.get(f, "")).strip() != str(v).strip()
        }
        logger.info(
            "NODE 20b: cycle update — IvDetails + IvContext cycle fields updated (%d changes): %s",
            len(_changed_fields),
            {f: f"{v['before']!r} → {v['after']!r}" for f, v in _changed_fields.items()},
        )

        updated_crid_state = {
            **original_crid_state,
            "data": merged_data,
        }
        
        logger.info("NODE 20b: routing to node_6 to rebuild draft with new cycle fields")
        _cycle_rank = next(
            i + 1 for i, o in enumerate(options) if o["cycle_id"] == chosen_cycle_id
        )
        return Command(
            update={
                "messages": [HumanMessage(content=user_response)],
                "cr_id": updated_crid_state,
                "aprv_proc": _aprv_state_patch,
                "transaction_type": _tt_state_patch,
                "cycle_id_pending": None,
                "cycle_confirmed": True,
                "cycle_change_autofilled": _cycle_autofilled,
                "cycle_hitl_attempts": 0,
                "cycle_id_selection": f"rank_{_cycle_rank}",
            },
            goto="node_6",  # Route to rebuild draft with new template
        )

    # Check if it's an explicit "keep current" confirmation
    if any(w == lower_resp for w in _YES_KEEP_WORDS):
        logger.info("NODE 20b: user confirmed keep — keeping draft cycle_id as-is, skipping approval process and transaction type")
        return Command(
            update={
                "messages": [HumanMessage(content=user_response)],
                "cycle_id_pending": None,
                "cycle_confirmed": True,
                "cycle_change_autofilled": None,
                "cycle_hitl_attempts": 0,
                "cycle_id_selection": "default",
            },
            goto="node_8",
        )

    # Input was neither a valid selection nor an explicit decline — treat as out-of-context
    logger.info(
        "NODE 20b: unrecognised/irrelevant input — attempt %d/%d",
        cycle_attempts + 1, MAX_ATTEMPTS,
    )
    return Command(
        update={
            "messages": [
                HumanMessage(content=user_response),
                AIMessage(
                    content=(
                        f"That's not related to the cycle selection — "
                        f"attempt {cycle_attempts + 1}/{MAX_ATTEMPTS}. "
                        f"Please reply with a number (1\u2013{n}), a Cycle ID, or 'yes' to keep the current one."
                    )
                ),
            ],
            "cycle_hitl_attempts": cycle_attempts + 1,
        },
        goto="node_20b",
    )
