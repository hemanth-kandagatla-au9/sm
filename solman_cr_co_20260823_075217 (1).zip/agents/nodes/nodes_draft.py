"""
agents/nodes/nodes_draft.py

Draft production phase nodes:
  node_5_gather_metrics
  node_6_build_draft
  node_7_suggest_similar_crs
"""
from __future__ import annotations

import json
import re
import time

import markdown as _markdown
from opentelemetry import trace

from observability import get_logger, derive_task_status, get_env_dimension
from langchain_core.messages import AIMessage, HumanMessage

from config.config import (
    FIELD_DISPLAY_NAMES,
    FIELD_GROUPS,
    ODATA_FIELD_MAP,
)
from state.state import AgentState, empty_ui
from tools.tools import execute_cypher
from utils.llm import get_llm
from ._helpers import _load_sop, _safe_json_default, _deep_merge_dict, _IS_TO_EDL
from ._metrics import (
    _task_first_draft_accuracy_histogram,
    _task_duration_histogram,
    _task_token_usage_histogram,
    _task_cost_usd_histogram,
    _task_completed_counter,
    _task_cycle_id_selection_counter,
    _task_cr_recommendation_source_counter,
    _task_target_suggestion_selection_counter,
    _task_end_without_draft_counter,
    _task_submission_counter,
    _CYCLE_ID_SELECTION_VALUES,
    _CR_RECOMMENDATION_SOURCE_VALUES,
    _TARGET_SUGGESTION_SELECTION_VALUES,
    _SUBMISSION_STATUS_VALUES,
    _END_WITHOUT_DRAFT_VALUES,
    _emit_one_hot_counter,
)

logger = get_logger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# NODE 5 — Gather Metrics
# Programmatic node: compute and store metrics via Agentcore memory.
# Always routes to END.
# ─────────────────────────────────────────────────────────────────────────────
def node_5_gather_metrics(state: AgentState) -> dict:
    logger.info("NODE 5: gather_metrics")

    messages = state.get("messages", [])
    human_count = sum(1 for m in messages if isinstance(m, HumanMessage))
    ai_count = sum(1 for m in messages if isinstance(m, AIMessage))

    metrics = {
        "X": human_count,
        "Y": ai_count,
        "Z": state.get("iteration", 0),
    }

    # In production: persist via Agentcore memory / observability sink
    logger.info("Metrics gathered: %s", metrics)

    # ── Task-level quality metrics for CloudWatch Logs Insights ──────────────
    _submission_status = derive_task_status(state.get("submission_result"))

    session_metrics = {
        "end_without_draft": str(state.get("first_draft_snapshot") is None).lower(),
        "first_draft_accuracy": state.get("first_draft_accuracy") or "N/A",
        "cycle_id_selection": state.get("cycle_id_selection") or "N/A",
        "cr_recommendation_source": state.get("cr_recommendation_source") or "N/A",
        "target_suggestion_selection": state.get("target_suggestion_selection") or "N/A",
        "submission_status": _submission_status,
    }

    logger.info(
        "NODE 5: SESSION_METRICS: %s",
        json.dumps(session_metrics, separators=(',', ':'), default=_safe_json_default)
    )

    task_id = state.get("task_id", "")
    task_start_ts = state.get("task_start_ts")
    task_duration_ms = (time.time() - task_start_ts) * 1000 if task_start_ts else None

    # ── Emit task_metrics as span attributes + OTel metrics ───────────
    span = trace.get_current_span()
    if span is not None and span.is_recording():
        span.set_attribute("app.task.id", task_id)
        span.set_attribute("app.task.end_without_draft", session_metrics["end_without_draft"])
        span.set_attribute("app.task.first_draft_accuracy", str(session_metrics["first_draft_accuracy"]))
        span.set_attribute("app.task.cycle_id_selection", str(session_metrics["cycle_id_selection"]))
        span.set_attribute("app.task.cr_recommendation_source", str(session_metrics["cr_recommendation_source"]))
        span.set_attribute("app.task.target_suggestion_selection", str(session_metrics["target_suggestion_selection"]))
        span.set_attribute("app.task.status", session_metrics["submission_status"])
        if task_duration_ms is not None:
            span.set_attribute("app.task.duration_ms", task_duration_ms)

    _first_draft_accuracy_raw = session_metrics["first_draft_accuracy"]
    _first_draft_accuracy_pct: float | None = None
    if isinstance(_first_draft_accuracy_raw, dict):
        _pct_val = _first_draft_accuracy_raw.get("pct")
        if isinstance(_pct_val, (int, float)):
            _first_draft_accuracy_pct = float(_pct_val)

    if _first_draft_accuracy_pct is not None:
        if span is not None and span.is_recording():
            span.set_attribute("app.task.first_draft_accuracy_pct", _first_draft_accuracy_pct)
        _task_first_draft_accuracy_histogram.record(_first_draft_accuracy_pct, attributes=get_env_dimension())

    if task_duration_ms is not None:
        _task_duration_histogram.record(task_duration_ms, attributes=get_env_dimension())
        _task_duration_histogram.record(
            task_duration_ms,
            attributes={**get_env_dimension(), "task_status": session_metrics["submission_status"]},
        )

    # ── Task-level cumulative token/cost totals (reducer fields summed by
    # LangGraph across every node call, including across resumed invocations) ──
    task_input_tokens = state.get("task_input_tokens", 0)
    task_output_tokens = state.get("task_output_tokens", 0)
    task_cost_usd = state.get("task_cost_usd", 0.0)
    if span is not None and span.is_recording():
        span.set_attribute("app.task.input_tokens", task_input_tokens)
        span.set_attribute("app.task.output_tokens", task_output_tokens)
        span.set_attribute("app.task.cost_usd", task_cost_usd)
    _task_token_usage_histogram.record(
        task_input_tokens, attributes={**get_env_dimension(), "gen_ai.token.type": "input"}
    )
    _task_token_usage_histogram.record(
        task_output_tokens, attributes={**get_env_dimension(), "gen_ai.token.type": "output"}
    )
    _task_cost_usd_histogram.record(task_cost_usd, attributes=get_env_dimension())

    _task_completed_counter.add(1, attributes=get_env_dimension())

    # Collapse ranks past 5 so the metric's cardinality stays bounded
    _raw_cycle_selection = str(session_metrics["cycle_id_selection"])
    _cycle_rank_match = re.fullmatch(r"rank_(\d+)", _raw_cycle_selection)
    _cycle_selection_bucket = (
        "rank_>5" if _cycle_rank_match and int(_cycle_rank_match.group(1)) > 5 else _raw_cycle_selection
    )
    _emit_one_hot_counter(
        _task_cycle_id_selection_counter,
        "cycle_id_selection",
        _cycle_selection_bucket,
        _CYCLE_ID_SELECTION_VALUES,
    )
    _emit_one_hot_counter(
        _task_cr_recommendation_source_counter,
        "cr_recommendation_source",
        str(session_metrics["cr_recommendation_source"]),
        _CR_RECOMMENDATION_SOURCE_VALUES,
    )
    _emit_one_hot_counter(
        _task_target_suggestion_selection_counter,
        "target_suggestion_selection",
        str(session_metrics["target_suggestion_selection"]),
        _TARGET_SUGGESTION_SELECTION_VALUES,
    )
    _emit_one_hot_counter(
        _task_end_without_draft_counter,
        "end_without_draft",
        session_metrics["end_without_draft"],
        _END_WITHOUT_DRAFT_VALUES,
    )
    _emit_one_hot_counter(
        _task_submission_counter,
        "submission_status",
        session_metrics["submission_status"],
        _SUBMISSION_STATUS_VALUES,
    )

    return {"metrics": metrics}


# ─────────────────────────────────────────────────────────────────────────────
# NODE 6 — Build Draft (heavy logic)
# Uses LLM + State attributes (template_id data, jira_id data, reason_for_change,
# description_of_change, additional_information, SOP instructions) to populate
# the draft attribute of State.
# ─────────────────────────────────────────────────────────────────────────────
def node_6_build_draft(state: AgentState) -> dict:
    logger.info("NODE 6: build_draft")

    sop = _load_sop()
    # Use default=_safe_json_default to handle DateTime objects
    # returned by Neo4j (posting_date, changed_at, etc.)
    _tmpl_source = (
        "cr_id" if state["cr_id"].get("data")
        else ("template_id" if state["template_id"].get("data") else "none")
    )
    logger.info("NODE 6: template source=%s", _tmpl_source)
    template_data = json.dumps(
        state["cr_id"].get("data") or state["template_id"].get("data") or {},
        indent=2, default=_safe_json_default
    )
    jira_data = json.dumps(
        state["jira_id"].get("data") or {}, indent=2, default=_safe_json_default
    )

    # ── Build source labels for each user-provided field ─────────────────────
    _jira_val   = state["jira_id"].get("value", "")
    _jira_valid = state["jira_id"].get("valid", False)
    _crid_val   = state["cr_id"].get("value", "")
    _tmpl_val   = state["template_id"].get("value", "")
    _src_label  = (
        f"CR {_crid_val}" if _crid_val
        else (f"Template {_tmpl_val}" if _tmpl_val else "user input")
    )
    _reason_src = (
        f"auto-generated from JIRA {_jira_val}" if _jira_valid and not state["reason_for_change"].get("given")
        else "user-provided"
    )
    _desc_src = (
        f"auto-generated from JIRA {_jira_val}" if _jira_valid and not state["description_of_change"].get("given")
        else "user-provided"
    )

    prompt = f"""You are a Change Request (CR) writer for SAP Solution Manager. Build a complete, professional CR draft.

=== Build Context ===
Baseline template source: {_src_label}
JIRA ticket used: {_jira_val if _jira_valid else "none"}
Platform: {state["platform"]["value"]}
Target System: {state["target_system"]["value"]}

Field definitions:
- Reason for Change: The business justification — WHY this change is needed, its impact, and the risk of NOT doing it. 2-4 sentences, no bullets.
- Description of Change: The technical WHAT — exactly what will be done in the system. 2-4 sentences, no bullets.
- Additional Information: Supporting context such as risk level, testing approach, or rollback plan.

=== Template / Baseline CR Data ({_src_label}) ===
{template_data}

=== JIRA Ticket Data ({_jira_val if _jira_valid else "not provided"}) ===
{jira_data}

=== User-Provided Fields ===
Reason for Change ({_reason_src}): {state["reason_for_change"]["value"]}
Description of Change ({_desc_src}): {state["description_of_change"]["value"]}
Additional Information (user-provided): {state["additional_information"]["value"]}
Target System (user-provided): {state["target_system"]["value"]}
Platform (user-provided): {state["platform"]["value"]}

=== SOP Instructions ===
{sop}

IMPORTANT STRUCTURE RULE:
The draft MUST open with a summary section (before any other sections) containing
exactly these three fields in this order:
1. Reason for Change
2. Description of Change
3. Target System

Use the template data as the structural baseline. Replace or enrich its fields using
the user-provided values above. Do NOT copy template text verbatim if it belongs to
a different change — adapt it to this specific change request.

Generate a complete, professional CR draft following the template structure and SOP.
Return only the draft text in Markdown format.
"""
    # Plain invoke — allows draft text to stream token-by-token to the UI
    response = get_llm().invoke(prompt)
    draft_text = response.content

    # Convert Markdown → HTML instantly in Python (no LLM round-trip needed)
    draft_html = _markdown.markdown(draft_text, extensions=["tables", "fenced_code"])

    patch: dict = {
        "draft": draft_text,
        "draft_ui": {
            **state["draft_ui"],
            "draft_html": draft_html,
        },
        "iteration": state.get("iteration", 0) + 1,
    }

    # On first build, if no recommendation flow was used, the user came in directly
    # (provided template_id / cr_id upfront via cond_edge_a → node_6).
    if state.get("first_draft_snapshot") is None and not state.get("cr_recommendation_source"):
        patch["cr_recommendation_source"] = "direct"

    # Capture snapshot on the very first node_6 run.
    # Key namespaces:
    #   EDL field key  — all FIELD_GROUPS fields fetched from Neo4j (e.g. "zzfld00000v_cus")
    #   "text.field"   — the 3 AI-written AgentState text fields
    # Never overwritten — cycle changes and user edits after this run are counted.
    if state.get("first_draft_snapshot") is None:
        _snapshot: dict = {}
        # Fetch all FIELD_GROUPS EDL fields from Neo4j using the template CR id
        _tmpl_id = str(
            state["cr_id"].get("value") or state["template_id"].get("value") or ""
        ).strip()
        _neo4j_props: dict = {}
        if _tmpl_id:
            _neo4j_rows = execute_cypher(
                "MATCH (c:ChangeRequest {object_id: $oid}) RETURN properties(c) AS props LIMIT 1",
                {"oid": _tmpl_id},
            )
            if _neo4j_rows and not _neo4j_rows[0].get("error") and _neo4j_rows[0].get("props"):
                _neo4j_props = dict(_neo4j_rows[0]["props"])
        for _sec_fields in FIELD_GROUPS.values():
            for _edl_key in _sec_fields:
                _raw = _neo4j_props.get(_edl_key)
                _snapshot[_edl_key] = str(_raw).strip() if _raw is not None else ""
        # Override cycle-related EDL keys with API values (same source as node_12 overlay)
        # so snapshot and comparison use identical format — prevents false-positive cycle changes.
        _IS_TO_EDL_SNAP = _IS_TO_EDL
        _tmpl_api_data = {}
        _template_api = state["template_id"].get("data") or {}
        _cr_api = state["cr_id"].get("data") or {}
        if isinstance(_template_api, dict):
            _tmpl_api_data = _deep_merge_dict(_tmpl_api_data, _template_api)
        if isinstance(_cr_api, dict):
            _tmpl_api_data = _deep_merge_dict(_tmpl_api_data, _cr_api)
        for _grp_k, _fld_map_s in _IS_TO_EDL_SNAP.items():
            _grp_s = _tmpl_api_data.get(_grp_k, {}) if isinstance(_tmpl_api_data, dict) else {}
            if isinstance(_grp_s, dict):
                for _api_f, _edl_f in _fld_map_s.items():
                    _v = _grp_s.get(_api_f)
                    if _v is not None:
                        _snapshot[_edl_f] = str(_v).strip()
        # Also overlay ALL ODATA_FIELD_MAP fields from cr_id.data (same as node_12)
        # so snapshot and comparison use identical format for zzfld* fields —
        # prevents false positives when non-cycle template fields differ between
        # Neo4j format and API format (e.g. "N/A" vs "").
        # Only overlay keys that are in FIELD_DISPLAY_NAMES (i.e. in FIELD_GROUPS) —
        # excludes text fields like description_of_change/reason_for_change which
        # are tracked separately as text.* keys.
        for (_grp_snap_all, _api_snap_all), _edl_snap_all in ODATA_FIELD_MAP.items():
            if _edl_snap_all in FIELD_DISPLAY_NAMES and _edl_snap_all not in FIELD_GROUPS.get("Details", {}):
                _grp_data_snap = (_tmpl_api_data.get(_grp_snap_all) or {}) if isinstance(_tmpl_api_data, dict) else {}
                if isinstance(_grp_data_snap, dict):
                    _v_snap = _grp_data_snap.get(_api_snap_all)
                    if _v_snap is not None:
                        _snapshot[_edl_snap_all] = str(_v_snap).strip()
        # 3 AI-written text fields (not in FIELD_GROUPS / Neo4j)
        for _tf in ("reason_for_change", "description_of_change", "additional_information"):
            _snapshot[f"text.{_tf}"] = str((state[_tf].get("value") or "")).strip()  # type: ignore[literal-required]
        if _snapshot:
            patch["first_draft_snapshot"] = _snapshot
            _edl_count = sum(1 for k in _snapshot if not k.startswith("text."))
            logger.info(
                "NODE 6: captured first_draft_snapshot — %d total fields (%d EDL + 3 text)",
                len(_snapshot), _edl_count,
            )

    return patch


# ─────────────────────────────────────────────────────────────────────────────
# NODE 7 — Suggest Similar CRs
# Uses description_of_change, reason_for_change, jira_id to formulate
# a query embedding, then runs GraphDB cypher.
# Checks baseline_crs.mentioned_object_ids to avoid re-recommending.
# ─────────────────────────────────────────────────────────────────────────────
def node_7_suggest_similar_crs(state: AgentState) -> dict:
    """
    Hybrid approach:
      Step 1 — LLM extracts a clean natural-language search query from user inputs
      Step 2 — Azure OpenAI embeds the search query into a vector
      Step 3 — Hardcoded correct Neo4j vector similarity Cypher runs with that vector
      Step 4 — Results stored in baseline_crs slots (cr_1..cr_5) with real scores
    """
    logger.info("NODE 7: suggest_similar_crs")

    already_mentioned: list[str] = state["baseline_crs"].get("mentioned_object_ids", [])

    # ── Canonical platform / target_system values for reranking ─────────────
    # validate_platform returns resolved_name (not canonical) — check both keys.
    _plat_state = state["platform"]
    _plat_data = _plat_state.get("data") or {}
    plat_canonical = (
        (_plat_data.get("canonical") or _plat_data.get("resolved_name") or _plat_state.get("value", ""))
        .strip().lower()
    )
    _tgt_state = state["target_system"]
    _tgt_data = _tgt_state.get("data") or {}
    tgt_canonical = (
        (_tgt_data.get("canonical") or _tgt_data.get("resolved_name") or _tgt_state.get("value", ""))
        .strip().lower()
    )

    # ── STEP 1: Build search text directly from user inputs (no LLM round-trip) ─
    search_text = (
        f"{state['description_of_change']['value']} "
        f"{state['reason_for_change']['value']}"
    ).strip()

    # Fallback: if user-provided text is empty, use platform + target_system context
    if not search_text:
        _plat_fb = (_plat_state.get("data") or {}).get("resolved_name") or _plat_state.get("value", "")
        _tgt_fb  = (_tgt_state.get("data")  or {}).get("resolved_name") or _tgt_state.get("value", "")
        search_text = f"{_plat_fb} {_tgt_fb}".strip()
        logger.warning("NODE 7: search_text was empty — falling back to platform/target context: %r", search_text)

    logger.info("NODE 7: search_text = %s", search_text[:80])

    # ── STEP 2: Embed the search text using Azure OpenAI ─────────────────────
    try:
        from config.settings import get_settings
        from openai import AzureOpenAI

        settings = get_settings()
        client = AzureOpenAI(
            api_key=settings.azure_embedding_api_key,
            azure_endpoint=settings.azure_embedding_endpoint,
            api_version=settings.azure_embedding_api_version,
        )
        response = client.embeddings.create(
            input=[search_text],
            model=settings.azure_embedding_deployment,
        )
        query_embedding = response.data[0].embedding
        logger.info("NODE 7: embedding generated (%d dims)", len(query_embedding))
    except Exception as exc:
        logger.error("NODE 7: embedding failed: %s", exc)
        # Fallback — store empty results with error
        new_baseline = dict(state["baseline_crs"])
        new_baseline["query_embedding"] = search_text
        for i, slot in enumerate(["cr_1", "cr_2", "cr_3", "cr_4", "cr_5"]):
            new_baseline[slot] = {
                "object_id":           f"CR_{i}",
                "ranking_score":       0.0,
                "platform_match":      False,
                "target_system_match": False,
                "ui":                  empty_ui(),
                "error":               f"Embedding failed: {exc}",
            }
        return {"baseline_crs": new_baseline}

    # ── STEP 3: Hardcoded correct Neo4j vector similarity Cypher ─────────────
    # This is the ONLY correct way to do vector similarity in Neo4j 5.x
    # LLM cannot reliably generate this because:
    #   - requires passing 3072-float embedding as $embedding parameter
    #   - exact syntax is Neo4j-version-specific
    #   - schema (TextLog, PART_OF, text_embedding) must be exact
    # Use db.index.vector.queryNodes — directly uses vector index (fast)
    # Fetch 500 candidates so reranking has enough headroom to pick the best 5
    VECTOR_SEARCH_CYPHER = """
CALL db.index.vector.queryNodes(
    'textlog_text_embedding_index', 500, $embedding
) YIELD node AS t, score
MATCH (t)-[:PART_OF]->(c:ChangeRequest)
WHERE NOT c.object_id IN $excluded
WITH c, max(score) AS score
RETURN
    c.object_id                  AS object_id,
    score,
    toString(c.platform)         AS platform,
    toString(c.configuration_descr) AS target_system,
    toString(c.description)      AS description,
    toString(c.project_title_ctx) AS title
ORDER BY score DESC
LIMIT 500
"""

    rows = execute_cypher(
        VECTOR_SEARCH_CYPHER,
        {"embedding": query_embedding, "excluded": already_mentioned},
    )

    logger.info("NODE 7: vector search returned %d rows", len(rows))

    # ── STEP 4: Rerank by platform/target_system match, then store top 5 ──────
    # Bonuses on top of similarity score:
    #   Both match → +0.35  Platform only → +0.20  Target only → +0.15  Neither → +0.00
    _PLATFORM_BONUS      = 2.00   # dominant — any platform match always beats non-match
    _TARGET_SYSTEM_BONUS = 0.50   # secondary boost within platform-matched CRs

    cr_slots     = ["cr_1", "cr_2", "cr_3", "cr_4", "cr_5"]
    new_baseline = dict(state["baseline_crs"])
    new_baseline["query_embedding"] = search_text

    for slot in cr_slots:
        new_baseline[slot] = None

    valid_rows = [r for r in rows if not r.get("error") and r.get("object_id")]

    def _rerank_score(row: dict) -> float:
        sim   = float(row.get("score", 0.0))
        bonus = 0.0
        if plat_canonical and str(row.get("platform", "")).strip().lower() == plat_canonical:
            bonus += _PLATFORM_BONUS
        if tgt_canonical and str(row.get("target_system", "")).strip().lower() == tgt_canonical:
            bonus += _TARGET_SYSTEM_BONUS
        return sim + bonus

    if valid_rows:
        valid_rows.sort(key=_rerank_score, reverse=True)
        logger.info("NODE 7: reranked %d rows — plat=%r tgt=%r", len(valid_rows), plat_canonical, tgt_canonical)

    for i, row in enumerate(valid_rows[:5]):
        plat_match = bool(plat_canonical and str(row.get("platform", "")).strip().lower() == plat_canonical)
        tgt_match  = bool(tgt_canonical  and str(row.get("target_system", "")).strip().lower() == tgt_canonical)
        new_baseline[cr_slots[i]] = {
            "object_id":           str(row["object_id"]),
            "ranking_score":       float(row.get("score", 0.0)),
            "platform_match":      plat_match,
            "target_system_match": tgt_match,
            "platform":            str(row.get("platform") or "").strip(),
            "target_system":       str(row.get("target_system") or "").strip(),
            "description":         str(row.get("description") or "").strip(),
            "title":               str(row.get("title") or "").strip(),
            "ui":                  empty_ui(),
            "error":               None,
        }

    if not valid_rows:
        logger.warning("NODE 7: no valid results from vector search — Neo4j may have no embeddings")
        for i, slot in enumerate(cr_slots):
            new_baseline[slot] = {
                "object_id":           f"CR_{i}",
                "ranking_score":       0.0,
                "platform_match":      False,
                "target_system_match": False,
                "ui":                  empty_ui(),
                "error":               "No embeddings found — run ingestion pipeline first",
            }

    return {
        "baseline_crs": new_baseline,
    }
