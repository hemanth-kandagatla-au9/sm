"""
agents/nodes/nodes_intake.py

Information-gathering phase nodes:
  node_1_extract_field_values
  node_2_validate_and_gather_data
  cond_edge_a
  node_3_request_information
  node_4_hitl_wait
"""
from __future__ import annotations

import re

from observability import get_logger
from langchain_core.messages import AIMessage, HumanMessage
from langgraph.types import Command, interrupt

from config.config import MAX_ATTEMPTS
from state.state import AgentState, FieldState, empty_field, build_initial_state

# AG-UI registered-component contract. Every ui_component payload in this module
# is built through these helpers — never as an inline dict — so the frontend
# registry and the agent stay in lockstep. See agui/ui_contract.py.
from agui import ui_contract
from tools.tools import (
    execute_cypher,
    generate_cr_fields_from_jira,
    generate_cr_fields_from_narrative,
    get_jira_data,
    get_template,
    get_valid_field_values,
    validate_change_scope,
    validate_platform,
    validate_target_system,
)
from utils.schemas import ExtractedFields, RelevanceCheck, RequestInfoOutput
from utils.llm import llm_fast_with_output
from ._helpers import (
    _state_summary,
    _fetch_target_system_candidates,
    _KNOWN_PLATFORMS,
    _PLATFORM_ALIASES_LIST,
)

logger = get_logger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# NODE 1 — Extract Field Values
# LLM reads the conversation and populates "given" + "value" for every field.
# ─────────────────────────────────────────────────────────────────────────────
def node_1_extract_field_values(state: AgentState) -> dict:
    logger.info("NODE 1: extract_field_values")

    # AG-UI's runtime only seeds "messages" on a fresh thread — backfill the rest.
    _seed = {} if "reason_for_change" in state else {
        k: v for k, v in build_initial_state("").items() if k != "messages"
    }
    state = {**_seed, **state}

    conversation = "\n".join(
        f"{m.type.upper()}: {m.content}" for m in state["messages"]
    )

    # ── If platform is already known/valid, fetch its known target systems from
    # the DB (no LLM call) and inject them into THIS SAME extraction prompt below,
    # so the LLM can normalize a fuzzy/punctuated user-given target_system (e.g.
    # "HMD MBOX,." or "HWBM  9999990001") to the exact DB string in one pass —
    # instead of needing a second LLM call later in tools.py.
    _plat_state_for_extract: FieldState = state.get("platform")  # type: ignore
    _tgt_candidates_block = ""
    if _plat_state_for_extract and _plat_state_for_extract.get("valid"):
        _plat_resolved_for_extract = (
            (_plat_state_for_extract.get("data") or {}).get("resolved_name")
            or _plat_state_for_extract.get("value", "")
        ).strip()
        _tgt_candidates = _fetch_target_system_candidates(_plat_resolved_for_extract)
        logger.info(
            "NODE 1: fetched %d target-system candidates for platform=%r to aid extraction",
            len(_tgt_candidates), _plat_resolved_for_extract,
        )
        if _tgt_candidates:
            _candidates_str = "\n".join(f"  - {c}" for c in _tgt_candidates)
            _tgt_candidates_block = f"""
  Known valid target systems for platform '{_plat_resolved_for_extract}':
{_candidates_str}
  If the user's text for target_system closely matches one of the systems above
  (same system, differing only by punctuation, spacing, or a minor typo), set
  value to the EXACT string from this list rather than the user's raw text.
  Only do this if you are confident it is the SAME system — do not force a match
  to an unrelated system.
"""

    prompt = f"""You are extracting Change Request (CR) fields from a conversation.

Conversation:
{conversation}
Extract the following fields. For each, set:
- given=true if the user has mentioned it at all, false otherwise
- value=the raw text the user provided (empty string if not given)

Field definitions — read carefully before extracting:

- platform: The SAP ERP platform name.
  Canonical platform names: {_KNOWN_PLATFORMS}.
  Also recognised as platform (alias names): {_PLATFORM_ALIASES_LIST}.
  If the user types ANY of the canonical names OR any alias name (or a close variant),
  classify it as `platform`, NOT as `target_system`.
  Examples: "HMD", "Hospital Medical Devices ERP (HMD)", "CFIN",
  "Central Finance SAP (CFIN)", "Back to Basics SAP", "Transcend MT2.0",
  "eWM GMED", "Vista LATAM" — all go in `platform`.

- target_system: A specific SAP system/landscape identifier WITHIN a platform.
  This is typically a short alphanumeric code or landscape name
  (e.g. "EJ1 100", "CONSSMP230", "P01", "EJ1 0020230804 100").
  NEVER put a platform name or alias here.
{_tgt_candidates_block}

- template_id: A SAP CR template ID — 5 to 7 digits (e.g. "65669", "656280", "656484").
  Only classify a number as template_id if it is between 5 and 7 digits long AND it appears
  as a standalone token (not embedded inside a target system string like "PC1 0020137783 000").

- cr_id: An existing SAP Change Request ID — exactly 8 digits (e.g. "50417365", "50376081").
  Only classify a number as cr_id if it is exactly 8 digits long AND it appears as a standalone
  token explicitly provided by the user (e.g. "CR 50417365", "change request 50417365", or just
  "50417365" on its own).
  NEVER extract cr_id or template_id digits from within a target system string.
  A target system string has the pattern: letters+digits optionally followed by spaces and more
  numbers (e.g. "PC1 0020137783 000", "EJ1 0020230804 100") — the numbers inside are part of
  the target system, NOT cr_id or template_id.
  The user may explicitly say "CR ID", "change request ID", or just provide the 8-digit number.
  cr_id takes priority over template_id when the draft is built.

CRITICAL DIGIT RULE:
  5-7 digit standalone number → template_id
  8-digit standalone number   → cr_id
  Any other pure number, or number embedded in a target system → additional_information
  Never swap these based on context or labels alone — digit count is the deciding rule.
  Never extract cr_id/template_id from inside a target system identifier string.

- jira_id: A Jira ticket key with a project prefix and number (e.g. "PROJ-1234", "CR-567", "AAZM-11112").
  Must contain letters, a dash, and a number. Pure numbers are NOT jira_id.
  CRITICAL OVERRIDE: If the user provides a LETTERS-NUMBER token (e.g. "AAZM-11112", "ABC-999") in ANY
  context — even if they say "use X for reason for change", "reason is X", "description is X", or
  "use X for description" — ALWAYS classify it as jira_id, NEVER as reason_for_change or
  description_of_change. Jira ticket keys are references to be fetched, not literal text values.

- reason_for_change: The business justification or WHY the change is needed.
  Extract the high-level business reason here.
  NEVER put a Jira ticket key (LETTERS-NUMBER pattern) here — those always go in jira_id.

- description_of_change: The technical details of WHAT will actually be changed.
  If the user gives one sentence covering both why and what, duplicate it into both fields.

- additional_information: ONLY extract this if the user EXPLICITLY provides supplementary
  context using labels like "additional info:", "additional information:", "also note:",
  "FYI:", or similar explicit markers.
  CRITICAL: Do NOT extract additional_information from a general narrative sentence that
  was already used for reason_for_change or description_of_change. If no explicit
  "additional info" label exists in the user's message, set given=false and value="".
  Never duplicate reason/description text into this field as a fallback.

CRITICAL RULE: Platform names and their aliases are NEVER a target_system.
  When in doubt between platform and target_system, check the alias list above first.
"""
    result: ExtractedFields = llm_fast_with_output(ExtractedFields).invoke(prompt)  # fast model — simple extraction

    patch: dict[str, FieldState] = {}
     
    for field_name in [
        "reason_for_change", "description_of_change", "additional_information",
        "target_system", "platform", "template_id", "cr_id", "jira_id",
    ]:
        extracted = getattr(result, field_name)
        existing: FieldState = state.get(field_name, empty_field())  # type: ignore[literal-required]
        
        # ── CRITICAL: Don't overwrite fields already confirmed by user (valid=True) ──
        # If target_system is already valid (e.g., user selected from dropdown),
        # preserve it exactly as-is. Don't let LLM extraction modify it.

        if field_name == "target_system" and existing.get("valid"):
            patch[field_name] = existing
            continue

        patch[field_name] = {
            **existing,
            # Preserve given=True if the field was already confirmed in a previous turn
            # (e.g. auto-filled from JIRA). LLM re-extraction on subsequent turns
            # may return given=False if the user never explicitly typed the value.
            "given": extracted.given or existing["given"],
            "value": extracted.value if extracted.value else existing["value"],
        }

    # ── Safety net: rescue Jira keys misclassified into text fields ──────────
    # If the LLM put a LETTERS-NUMBER token (e.g. "AAZM-11112") into reason_for_change,
    # description_of_change, or additional_information instead of jira_id, move it.
    _JIRA_KEY_RE = re.compile(r'\b([A-Z][A-Z0-9]+-\d+)\b')
    _current_jira_id = (patch.get("jira_id", {}).get("value") or "").strip()
    if not _current_jira_id:
        for _text_field in ["reason_for_change", "description_of_change", "additional_information"]:
            _field_val = patch.get(_text_field, {}).get("value", "")
            _m = _JIRA_KEY_RE.search(_field_val)
            if _m:
                _jira_key = _m.group(1)
                patch["jira_id"] = {**patch.get("jira_id", state.get("jira_id", empty_field())), "given": True, "value": _jira_key}  # type: ignore
                # Restore existing state value if it already holds real JIRA-generated content —
                # same logic as the "clear text fields" block below, applied here to the safety net.
                _sn_state_val = (state[_text_field].get("value") or "").strip()  # type: ignore[literal-required]
                if _sn_state_val and _sn_state_val.upper() != _jira_key.upper():
                    patch[_text_field] = {**patch.get(_text_field, {}), "given": True, "value": _sn_state_val}
                    logger.info(
                        "node_1: rescued jira_id=%s from '%s', preserved existing state value",
                        _jira_key, _text_field,
                    )
                else:
                    patch[_text_field] = {**patch.get(_text_field, {}), "given": False, "value": ""}
                    logger.info(
                        "node_1: rescued jira_id=%s from misclassified field '%s'",
                        _jira_key, _text_field,
                    )
                _current_jira_id = _jira_key
                break

    # ── Final safety net: scan raw last human message ────────────────────────
    # Catches JIRA keys the LLM completely dropped (not placed in jira_id OR
    # any text field). Covers all digit counts: AAZM-1, AAZM-12, AAZM-466, etc.
    if not _current_jira_id:
        _last_human = next(
            (m.content for m in reversed(state["messages"]) if isinstance(m, HumanMessage)),
            "",
        )
        _m = _JIRA_KEY_RE.search(_last_human)
        if _m:
            _jira_key = _m.group(1)
            patch["jira_id"] = {**patch.get("jira_id", state["jira_id"]), "given": True, "value": _jira_key}  # type: ignore
            _current_jira_id = _jira_key
            logger.info("node_1: rescued jira_id=%s from raw user message", _jira_key)

    # ── Clear text fields that contain the confirmed jira_id as a literal value ──
    # Handles "use AAZM-11112 for Reason for Change" — LLM may set both jira_id
    # AND reason_for_change to the same Jira key. Clearing the text field here
    # forces node_2 to treat it as missing and generate it from the Jira fetch.
    if _current_jira_id:
        for _text_field in ["reason_for_change", "description_of_change", "additional_information"]:
            _field_val = (patch.get(_text_field, {}).get("value") or "").strip()
            _key_in_field = _JIRA_KEY_RE.search(_field_val)
            if _key_in_field and _key_in_field.group(1).upper() == _current_jira_id.upper():
                # If the existing state already holds a real JIRA-generated value
                # (not the jira_id string itself), restore it. This prevents subsequent
                # turns from wiping values that node_2 already generated — which happens
                # because node_1 re-reads the full conversation history on every turn and
                # the LLM re-extracts the JIRA key into a text field.
                _state_val = (state[_text_field].get("value") or "").strip()  # type: ignore[literal-required]
                if _state_val and _state_val.upper() != _current_jira_id.upper():
                    patch[_text_field] = {**patch.get(_text_field, {}), "given": True, "value": _state_val}
                    logger.info(
                        "node_1: preserved existing '%s' — jira_id re-extracted from history, restored state value",
                        _text_field,
                    )
                else:
                    patch[_text_field] = {**patch.get(_text_field, {}), "given": False, "value": ""}
                    logger.info(
                        "node_1: cleared jira_id value from text field '%s' — will be generated from Jira fetch",
                        _text_field,
                    )

    # Differentiate reason_for_change / description_of_change when identical
    _reason_val = (patch.get("reason_for_change", {}).get("value") or "").strip()
    _desc_val   = (patch.get("description_of_change", {}).get("value") or "").strip()
    if _reason_val and _desc_val and _reason_val.lower() == _desc_val.lower():
        logger.info("node_1: reason_for_change and description_of_change are identical — differentiating via LLM")
        _differentiated = generate_cr_fields_from_narrative(_reason_val)
        _new_reason = _differentiated.get("reason_for_change", "")
        _new_desc   = _differentiated.get("description_of_change", "")
        if _new_reason and _new_desc and _new_reason.strip().lower() != _new_desc.strip().lower():
            patch["reason_for_change"] = {**patch["reason_for_change"], "value": _new_reason}
            patch["description_of_change"] = {**patch["description_of_change"], "value": _new_desc}
            logger.info("node_1: reason_for_change and description_of_change differentiated successfully")
        else:
            logger.warning("node_1: narrative differentiation did not produce distinct fields — keeping duplicated text")

    return {**_seed, **patch}


# ─────────────────────────────────────────────────────────────────────────────
# NODE 2 — Validate and Gather Data
# Calls tools: get_template, get_jira, validate_platform, validate_target_system
# Populates "valid", "data", "error" on each FieldState.
# ─────────────────────────────────────────────────────────────────────────────
def node_2_validate_and_gather_data(state: AgentState) -> dict:
    logger.info("NODE 2: validate_and_gather_data")

    # ── LLM scope guard (runs once — skipped on subsequent turns) ────────
    patch: dict = {}

    if not state.get("scope_confirmed", False):
        last_human = next(
            (m.content for m in reversed(state["messages"]) if isinstance(m, HumanMessage)),
            "",
        )
        scope = validate_change_scope(last_human)
        _classification = scope.get("classification", "UNCLEAR")
        _reason         = scope.get("reason", "")
        _redirect       = scope.get("redirect")
        del scope

        if _classification == "OUT_OF_SCOPE":
            _out_count = state.get("scope_out_count", 0) + 1
            # First OUT_OF_SCOPE hit — do NOT end session, let it continue
            logger.info(
                "NODE 2: OUT_OF_SCOPE hit %d/2 — continuing to allow retry",
                _out_count,
            )
            patch["scope_out_count"] = _out_count
            # Fall through to scope_confirmed = True so we don't re-check next turn
        else:
            # IN_SCOPE or UNCLEAR — reset counter
            patch["scope_out_count"] = 0
        # Mark confirmed so we never call this LLM again
        patch["scope_confirmed"] = True
    else:
        logger.info("NODE 2: scope already confirmed — skipping scope check")

    # ── cr_id (user-provided 8-digit CR ID — higher priority than template_id) ──
    crid_state: FieldState = dict(state["cr_id"])  # type: ignore
    if crid_state["given"] and crid_state["value"] and not crid_state["valid"]:
        data = get_template(crid_state["value"])
        if "error" in data and data.get("error"):
            crid_state["valid"] = False
            crid_state["error"] = data["error"]
        else:
            crid_state["valid"] = True
            crid_state["data"] = data
            crid_state["error"] = None
            _meta = execute_cypher(
                "MATCH (c:ChangeRequest {object_id: $oid}) "
                "RETURN c.project_title_ctx AS cycle, c.slan_name_ctx AS landscape, "
                "c.configuration_descr AS tgt LIMIT 1",
                {"oid": crid_state["value"]},
            )
            _meta0     = _meta[0] if _meta and not _meta[0].get("error") else {}
            _cycle     = str(_meta0.get("cycle")     or "").strip()
            _landscape = str(_meta0.get("landscape") or "").strip()
            _tgt_from_template = str(_meta0.get("tgt") or "").strip()
            _meta_parts = [f"✅ CR **{crid_state['value']}** validated"]
            if _cycle:
                _meta_parts.append(f"**Change Cycle:** {_cycle}")
            if _landscape:
                _meta_parts.append(f"**Landscape:** {_landscape}")
            _confirm_parts = [" | ".join(_meta_parts)]
            # ── Req 8: override target_system with template value if available ─
            # Guard: only override if template target is compatible with user's platform
            if _tgt_from_template:
                _user_plat = str(state["platform"].get("value") or "").strip()
                if _user_plat:
                    _plat_compat = execute_cypher(
                        "MATCH (c:ChangeRequest) WHERE c.platform = $plat "
                        "AND c.configuration_descr = $tgt RETURN count(*) AS cnt",
                        {"plat": _user_plat, "tgt": _tgt_from_template},
                    )
                    _plat_compat_cnt = int(
                        (_plat_compat[0].get("cnt") or 0)
                        if _plat_compat and not _plat_compat[0].get("error") else 0
                    )
                    if _plat_compat_cnt == 0:
                        logger.info(
                            "NODE 2: Req 8 override skipped — template target '%s' not valid for platform '%s'",
                            _tgt_from_template, _user_plat,
                        )
                        _tgt_from_template = ""  # neutralize — don't override
            if _tgt_from_template:
                _user_tgt = str(state["target_system"].get("value") or "").strip()
                _tgt_state_override = dict(state["target_system"])  # type: ignore
                _tgt_state_override["given"] = True
                _tgt_state_override["valid"] = True
                _tgt_state_override["value"] = _tgt_from_template
                _tgt_state_override["error"] = None
                patch["target_system"] = _tgt_state_override
                if _user_tgt and _user_tgt.lower() != _tgt_from_template.lower():
                    _confirm_parts.append(
                        f"ℹ️ Target system updated to **{_tgt_from_template}** (from template; "
                        f"overrides your input '{_user_tgt}')"
                    )
                else:
                    _confirm_parts.append(f"**Target System:** {_tgt_from_template}")
            patch.setdefault("messages", []).append(
                AIMessage(content="  \n".join(_confirm_parts))
            )
        logger.info(
            "NODE 2: cr_id fetched — value=%s valid=%s fields=%d",
            crid_state["value"], crid_state["valid"], len(crid_state.get("data") or {}),
        )
    patch["cr_id"] = crid_state

    # ── template_id ──────────────────────────────────────────────────────────
    tid_state: FieldState = dict(state["template_id"])  # type: ignore
    if tid_state["given"] and tid_state["value"] and not tid_state["valid"]:
        data = get_template(tid_state["value"])
        if "error" in data and data.get("error"):
            tid_state["valid"] = False
            tid_state["error"] = data["error"]
        else:
            tid_state["valid"] = True
            tid_state["data"] = data
            tid_state["error"] = None
            _meta = execute_cypher(
                "MATCH (c:ChangeRequest {object_id: $oid}) "
                "RETURN c.project_title_ctx AS cycle, c.slan_name_ctx AS landscape, "
                "c.configuration_descr AS tgt LIMIT 1",
                {"oid": tid_state["value"]},
            )
            _meta0     = _meta[0] if _meta and not _meta[0].get("error") else {}
            _cycle     = str(_meta0.get("cycle")     or "").strip()
            _landscape = str(_meta0.get("landscape") or "").strip()
            _tgt_from_template = str(_meta0.get("tgt") or "").strip()
            _meta_parts = [f"✅ Template **{tid_state['value']}** validated"]
            if _cycle:
                _meta_parts.append(f"**Change Cycle:** {_cycle}")
            if _landscape:
                _meta_parts.append(f"**Landscape:** {_landscape}")
            _confirm_parts = [" | ".join(_meta_parts)]
            # ── Req 8: override target_system with template value if available ─
            # Guard: only override if template target is compatible with user's platform
            if _tgt_from_template:
                _user_plat = str(state["platform"].get("value") or "").strip()
                if _user_plat:
                    _plat_compat = execute_cypher(
                        "MATCH (c:ChangeRequest) WHERE c.platform = $plat "
                        "AND c.configuration_descr = $tgt RETURN count(*) AS cnt",
                        {"plat": _user_plat, "tgt": _tgt_from_template},
                    )
                    _plat_compat_cnt = int(
                        (_plat_compat[0].get("cnt") or 0)
                        if _plat_compat and not _plat_compat[0].get("error") else 0
                    )
                    if _plat_compat_cnt == 0:
                        logger.info(
                            "NODE 2: Req 8 override skipped — template target '%s' not valid for platform '%s'",
                            _tgt_from_template, _user_plat,
                        )
                        _tgt_from_template = ""  # neutralize — don't override
            if _tgt_from_template:
                _user_tgt = str(state["target_system"].get("value") or "").strip()
                _tgt_state_override = dict(state["target_system"])  # type: ignore
                _tgt_state_override["given"] = True
                _tgt_state_override["valid"] = True
                _tgt_state_override["value"] = _tgt_from_template
                _tgt_state_override["error"] = None
                patch["target_system"] = _tgt_state_override
                if _user_tgt and _user_tgt.lower() != _tgt_from_template.lower():
                    _confirm_parts.append(
                        f"ℹ️ Target system updated to **{_tgt_from_template}** (from template; "
                        f"overrides your input '{_user_tgt}')"
                    )
                else:
                    _confirm_parts.append(f"**Target System:** {_tgt_from_template}")
            patch.setdefault("messages", []).append(
                AIMessage(content="  \n".join(_confirm_parts))
            )
    patch["template_id"] = tid_state

    # ── jira_id ──────────────────────────────────────────────────────────────
    jira_state: FieldState = dict(state["jira_id"])  # type: ignore
    if jira_state["given"] and jira_state["value"] and not jira_state["valid"]:
        data = get_jira_data(jira_state["value"])
        if "error" in data and data.get("error"):
            logger.warning("NODE 2: jira fetch failed — %s", data["error"])
            jira_state["valid"] = False
            jira_state["error"] = data["error"]
            patch.setdefault("messages", []).append(
                AIMessage(content=(
                    f"⚠️ Could not fetch Jira ticket **{jira_state['value']}**. "
                    f"Please provide the **Reason for Change** and **Description of Change** manually."
                ))
            )
        else:
            jira_summary     = (data.get("summary") or "").strip()
            jira_description = (data.get("description") or "").strip()
            # Only treat jira as valid if it returned usable content.
            # An HTTP 200 with blank summary + description is treated as no-data.
            jira_has_content = bool(jira_summary or jira_description)
            jira_state["valid"] = jira_has_content
            jira_state["data"]  = data
            jira_state["error"] = None if jira_has_content else "Jira ticket returned no summary or description"
            if not jira_has_content:
                patch.setdefault("messages", []).append(
                    AIMessage(content=(
                        f"⚠️ Jira ticket **{jira_state['value']}** was found but returned no content. "
                        f"Please provide the **Reason for Change** and **Description of Change** manually."
                    ))
                )
            logger.info(
                "NODE 2: jira fetch %s — summary=%r description_len=%d",
                "✓" if jira_has_content else "⚠ empty",
                jira_summary[:80],
                len(jira_description),
            )

            # ── Auto-populate reason_for_change and description_of_change ────
            # Use LLM to transform raw JIRA content into formal CR language.
            # Only if the user has NOT already provided these manually.
            reason_state: FieldState = dict(state["reason_for_change"])  # type: ignore
            desc_state: FieldState   = dict(state["description_of_change"])  # type: ignore

            reason_missing = not reason_state["given"] or not str(reason_state["value"]).strip()
            desc_missing   = not desc_state["given"]   or not str(desc_state["value"]).strip()

            if reason_missing or desc_missing:
                if jira_summary or jira_description:
                    logger.info("NODE 2: generating CR fields from JIRA via LLM")
                    generated = generate_cr_fields_from_jira(jira_summary, jira_description)

                    if reason_missing and generated.get("reason_for_change"):
                        reason_state["given"] = True
                        reason_state["value"] = generated["reason_for_change"]
                        reason_state["valid"] = True
                        reason_state["error"] = None
                        logger.info("NODE 2: reason_for_change generated from JIRA via LLM")
                        patch["reason_for_change"] = reason_state

                    if desc_missing and generated.get("description_of_change"):
                        desc_state["given"] = True
                        desc_state["value"] = generated["description_of_change"]
                        desc_state["valid"] = True
                        desc_state["error"] = None
                        logger.info("NODE 2: description_of_change generated from JIRA via LLM")
                        patch["description_of_change"] = desc_state

            # ── Auto-populate Jira-derived EDL fields ─────────────────────────
            # planned_impl_dt_adtnl ← fields.duedate
            due_date = (data.get("due_date") or "").strip()
            pidt_state: FieldState = dict(state["planned_impl_dt_adtnl"])  # type: ignore
            if due_date and not pidt_state["given"]:
                pidt_state["given"] = True
                pidt_state["value"] = due_date
                pidt_state["valid"] = True
                pidt_state["error"] = None
                logger.info("NODE 2: planned_impl_dt_adtnl set from JIRA due_date=%r", due_date)
            patch["planned_impl_dt_adtnl"] = pidt_state

            # zzfld00000v_cus / zzfld00004y ← fields.customfield_10104 (Regression Test ID)
            reg_id = (data.get("regression_test_id") or "").strip()
            reg_qas_state: FieldState = dict(state["zzfld00000v_cus"])  # type: ignore
            reg_ref_state: FieldState = dict(state["zzfld00004y"])       # type: ignore
            if not reg_qas_state["given"]:
                reg_qas_state["given"] = True
                reg_qas_state["value"] = "Yes" if reg_id else "No"
                reg_qas_state["valid"] = True
                reg_qas_state["error"] = None
                logger.info("NODE 2: zzfld00000v_cus (Regression Test QAS) = %r", reg_qas_state["value"])
            if reg_id and not reg_ref_state["given"]:
                reg_ref_state["given"] = True
                reg_ref_state["value"] = reg_id
                reg_ref_state["valid"] = True
                reg_ref_state["error"] = None
                logger.info("NODE 2: zzfld00004y (Regression Test Reference) = %r", reg_id)
            patch["zzfld00000v_cus"] = reg_qas_state
            patch["zzfld00004y"]     = reg_ref_state

            # zzfld00000w_cus / zzfld00004x ← fields.customfield_10105 (UAT Test ID)
            uat_id = (data.get("uat_test_id") or "").strip()
            uat_qas_state: FieldState = dict(state["zzfld00000w_cus"])  # type: ignore
            uat_ref_state: FieldState = dict(state["zzfld00004x"])       # type: ignore
            if not uat_qas_state["given"]:
                uat_qas_state["given"] = True
                uat_qas_state["value"] = "Yes" if uat_id else "No"
                uat_qas_state["valid"] = True
                uat_qas_state["error"] = None
                logger.info("NODE 2: zzfld00000w_cus (UAT QAS) = %r", uat_qas_state["value"])
            if uat_id and not uat_ref_state["given"]:
                uat_ref_state["given"] = True
                uat_ref_state["value"] = uat_id
                uat_ref_state["valid"] = True
                uat_ref_state["error"] = None
                logger.info("NODE 2: zzfld00004x (UAT Test Reference) = %r", uat_id)
            patch["zzfld00000w_cus"] = uat_qas_state
            patch["zzfld00004x"]     = uat_ref_state

    patch["jira_id"] = jira_state

    # ── platform ─────────────────────────────────────────────────────────────
    plat_state: FieldState = dict(state["platform"])  # type: ignore
    if plat_state["given"] and plat_state["value"] and not plat_state["valid"]:
        result = validate_platform(plat_state["value"])
        plat_state["valid"] = result["valid"]
        plat_state["data"] = result
        plat_state["error"] = result.get("error")
        if result["valid"] and result.get("resolved_name"):
            # CRITICAL: sync value to the canonical resolved name. The LLM extraction in
            # node_1 can silently strip/alter punctuation (e.g. trailing dashes), but
            # validate_platform's fuzzy match still resolves the correct canonical name.
            # Without this sync, the stale/altered value would be used later (e.g. in the
            # platform/target compatibility EXACT-match Cypher check), causing a false
            # mismatch even though the user's answer was valid.
            plat_state["value"] = result["resolved_name"]
    patch["platform"] = plat_state

    # ── target_system ────────────────────────────────────────────────────────
    # Skip if already set by Req 8 template override (cr_id / template_id block above)
    if "target_system" not in patch:
        tgt_state: FieldState = dict(state["target_system"])  # type: ignore
        if tgt_state["given"] and tgt_state["value"] and not tgt_state["valid"]:
            plat_resolved = ((plat_state.get("data") or {}).get("resolved_name") or plat_state.get("value", "")).strip()
            result = validate_target_system(tgt_state["value"], platform=plat_resolved if plat_state["valid"] else None)
            tgt_state["valid"] = result["valid"]
            tgt_state["data"] = result
            tgt_state["error"] = result.get("error")
            if result["valid"] and result.get("resolved_name"):
                # CRITICAL: sync value to the canonical resolved name (see comment above for
                # platform). e.g. user types/agent-suggests "HMD MBOX ----" for platform Atlas;
                # node_1's LLM extraction strips it to "HMD MBOX"; validate_target_system's
                # fuzzy STARTS WITH/CONTAINS fallback still resolves the real DB value
                # "HMD MBOX ----" into resolved_name. Without this sync, the truncated
                # "HMD MBOX" stays in tgt_state["value"] and is used by the platform/target
                # compatibility EXACT-match Cypher check right after — causing a false
                # "mismatch" even though the user's answer was valid and already confirmed.
                tgt_state["value"] = result["resolved_name"]
        patch["target_system"] = tgt_state

    # ── Platform / Target System compatibility check ──────────────────────────
    # Run only when BOTH are freshly valid, the user hasn't already overridden,
    # and a pending check isn't already in flight.
    _plat_ok = patch["platform"].get("valid") and patch["platform"].get("given")
    _tgt_ok  = patch["target_system"].get("valid") and patch["target_system"].get("given")
    if (
        _plat_ok and _tgt_ok
        and not state.get("platform_tgt_overridden")
        and not state.get("platform_tgt_pending")
    ):
        _plat_resolved = (
            (patch["platform"].get("data") or {}).get("resolved_name")
            or patch["platform"].get("value", "")
        ).strip()
        _tgt_value = patch["target_system"].get("value", "").strip()

        _compat_rows = execute_cypher(
            """
            MATCH (c:ChangeRequest)
            WHERE c.platform = $platform
              AND c.configuration_descr = $target_system
            RETURN count(*) AS cnt
            """,
            {"platform": _plat_resolved, "target_system": _tgt_value},
        )
        _compat_cnt = int(
            (_compat_rows[0].get("cnt") or 0)
            if _compat_rows and not _compat_rows[0].get("error")
            else 0
        )
        if _compat_cnt == 0:
            # Target system not seen under this platform → fetch top 5 alternatives
            _top5_rows = execute_cypher(
                """
                MATCH (c:ChangeRequest)
                WHERE c.platform = $platform
                  AND c.configuration_descr IS NOT NULL
                  AND c.configuration_descr <> ''
                RETURN c.configuration_descr AS target_system, count(*) AS cnt
                ORDER BY cnt DESC
                LIMIT 5
                """,
                {"platform": _plat_resolved},
            )
            _options = [
                {"target_system": str(r["target_system"]).strip(), "cnt": int(r.get("cnt", 0))}
                for r in _top5_rows
                if r.get("target_system") and not r.get("error")
            ]
            patch["platform_tgt_pending"] = {
                "options":          _options,
                "original_target":  _tgt_value,
                "platform":         _plat_resolved,
            }
            # Force target invalid so cond_edge_a routes to node_3
            _tgt_copy = dict(patch["target_system"])
            _tgt_copy["valid"] = False
            patch["target_system"] = _tgt_copy
            logger.info(
                "NODE 2: platform-target mismatch — platform=%r target=%r options=%d",
                _plat_resolved, _tgt_value, len(_options),
            )
        else:
            patch.setdefault("platform_tgt_pending", None)

    # ── Free text fields — valid=True if user provided any value ─────────────
    # These fields have no database to validate against.
    # Green means "user has provided this field" — not "database validated".
    # Skip fields already patched above (e.g. auto-filled from JIRA).
    for free_field in ["reason_for_change", "description_of_change", "additional_information"]:
        if free_field in patch:
            continue  # already set (e.g. auto-filled from JIRA)
        fs: FieldState = dict(state[free_field])  # type: ignore
        if fs["given"] and str(fs["value"]).strip():
            fs["valid"] = True   # provided = valid
            fs["error"] = None
        patch[free_field] = fs

    return patch


# ─────────────────────────────────────────────────────────────────────────────
# CONDITIONAL EDGE A — deterministic rule-based routing
# Returns the name of the next node.
# ─────────────────────────────────────────────────────────────────────────────
def cond_edge_a(state: AgentState) -> str:
    """
    Deterministic routing based on required fields.

    Rules:
      1. platform not given OR invalid                        → node_3 (request info)
      2. target_system not given OR invalid                   → node_3 (request info)
      3. reason_for_change not given AND jira not valid       → node_3 (request info)
      4. description_of_change not given AND jira not valid   → node_3 (request info)
      5. all above satisfied + template_id given              → node_6 (build draft)
      6. all above satisfied + template_id NOT given          → node_7 (similarity search)

    NOTE: If jira_id was successfully fetched (jira_valid=True), node_2 will have
    already auto-populated reason_for_change and description_of_change from the JIRA
    ticket, so checks 3 and 4 will pass naturally. The jira_valid shortcut here is a
    safety net in case that auto-fill hasn't propagated yet.
    """
    # Out-of-scope early exit — node_2 set end_session=True → go straight to node_5
    if state.get("end_session"):
        logger.info("COND A → node_5 (end_session=True — out of scope)")
        return "node_5"

    platform_valid: bool    = state["platform"]["given"] and state["platform"]["valid"]
    target_valid: bool       = state["target_system"]["given"] and state["target_system"]["valid"]
    template_given: bool     = state["template_id"]["given"] or state["cr_id"]["given"]

    # Check actual populated values — not just given/jira_valid flags.
    # jira_valid=True does NOT guarantee values were filled (EvResponse can be empty).
    reason_value: str       = str(state["reason_for_change"]["value"] or "").strip()
    description_value: str  = str(state["description_of_change"]["value"] or "").strip()

    if not platform_valid:
        logger.info("COND A → node_3 (platform missing or invalid)")
        return "node_3"

    if not target_valid:
        logger.info("COND A → node_3 (target_system missing or invalid)")
        return "node_3"

    if not reason_value:
        logger.info("COND A → node_3 (reason_for_change is empty)")
        return "node_3"

    if not description_value:
        logger.info("COND A → node_3 (description_of_change is empty)")
        return "node_3"

    if template_given:
        _src = "template_id" if state["template_id"]["given"] else "cr_id"
        logger.info("COND A → node_6 (%s given)", _src)
        return "node_6"

    logger.info("COND A → node_7 (template_id not given — similarity search)")
    return "node_7"


# ─────────────────────────────────────────────────────────────────────────────
# NODE 3 — Request Information
# LLM formulates an output message telling the user what is missing and why,
# using the error values currently in State.
# ─────────────────────────────────────────────────────────────────────────────
def node_3_request_information(state: AgentState) -> dict:
    logger.info("NODE 3: request_information")

    # ── Special case: platform / target_system compatibility alert ────────────
    pending = state.get("platform_tgt_pending")
    if pending:
        options         = pending.get("options", [])
        original_target = pending.get("original_target", "")
        plat_resolved   = pending.get("platform", "")
        if options:
            alert_msg = (
                f"⚠️ **Platform / Target System mismatch**\n\n"
                f"Target system **{original_target}** has not been used with platform **{plat_resolved}** "
                f"in our records.\n\n"
                "Please select one of the valid target systems below to continue."
            )
        else:
            alert_msg = (
                f"⚠️ **Platform / Target System mismatch**\n\n"
                f"Target system **{original_target}** has not been used with platform **{plat_resolved}** "
                f"in our records, and no alternatives were found.\n\n"
                "Please type a different target system for this platform."
            )
        logger.info("NODE 3: showing platform-target compatibility alert")
        _btn_opts = [
            {"label": o["target_system"], "value": f"Target system is {o['target_system']}"}
            for o in options
        ] if options else []
        return {
            "messages": [AIMessage(content=alert_msg)],
            "exhausted_attempts": 0,
            "clickable_options": _btn_opts,
        }

    summary = _state_summary(state)

    # ── Fetch real examples for missing/invalid fields from Neo4j ────────────
    plat_state = state["platform"]
    plat_value = plat_state.get("data", {}) or {}
    plat_resolved = (
        plat_value.get("resolved_name") or plat_value.get("canonical") or plat_state.get("value", "")
    ).strip()

    plat_examples: list[str] = []
    plat_examples_narrowed: bool = False
    tgt_examples: list[str] = []
    tgt_examples_narrowed: bool = False
    tgt_scope_label: str = ""

    if not plat_state["given"] or not plat_state["valid"]:
        # If validate_platform found close/ambiguous candidates (fuzzy match with
        # multiple ties, or a low-confidence single match), show ONLY those
        # candidates instead of the entire platform list — e.g. user typed "AS"
        # and it's ambiguous between "AS SolMan" and "AS GRC".
        _plat_suggestions = plat_value.get("suggestions") if isinstance(plat_value, dict) else None
        if _plat_suggestions:
            plat_examples = _plat_suggestions
            plat_examples_narrowed = True
            logger.info(
                "NODE 3: using narrowed platform suggestions instead of full list: %s",
                plat_examples,
            )
        else:
            plat_examples = get_valid_field_values("platform", limit=1000)

    tgt_state = state["target_system"]
    tgt_value = tgt_state.get("data", {}) or {}
    if not tgt_state["given"] or not tgt_state["valid"]:
        # If validate_target_system found multiple ambiguous partial/fuzzy matches
        # (e.g. user typed "PJS" and it matches both "PJS 0021237113" and
        # "PJS 0021237113 100"), show ONLY those candidates instead of the entire
        # target-system list for the platform.
        _tgt_suggestions = tgt_value.get("suggestions") if isinstance(tgt_value, dict) else None
        if _tgt_suggestions:
            tgt_examples = _tgt_suggestions
            tgt_examples_narrowed = True
            logger.info(
                "NODE 3: using narrowed target_system suggestions instead of full list: %s",
                tgt_examples,
            )
        elif plat_resolved and plat_state["valid"]:
            tgt_examples = get_valid_field_values("target_system", limit=1000, platform=plat_resolved)
            tgt_scope_label = f" for {plat_resolved}"
        else:
            tgt_examples = get_valid_field_values("target_system", limit=1000)

    prompt = f"""You are a helpful CR assistant having a friendly chat conversation.

Current field status:
{summary}

IMPORTANT: jira_id and template_id are OPTIONAL — never ask for them or mention them as missing.
Required fields are: platform, target_system, reason_for_change, description_of_change.

Write a SHORT, conversational chat message (2-4 sentences max) that:
- Mentions only what is missing or invalid among the REQUIRED fields (skip fields that are fine, skip jira_id entirely)
- Does NOT list any examples — the full valid options list will be appended separately
- Ends with a simple question asking for the missing values

Do NOT use headers, numbered lists, bullet points, or formal document structure.
Write like you are texting a colleague — brief, friendly, natural.
"""
    result: RequestInfoOutput = llm_fast_with_output(RequestInfoOutput).invoke(prompt)

    # ── Strip trailing count "(824)" from target system strings ───────────────
    def _strip_count(t: str) -> str:
        return re.sub(r'\s*\(\d+\)\s*$', '', t).strip()

    # ── Append full valid-options lists in code (never truncated by LLM) ─────
    # Lists are shown as clickable buttons — no need to repeat them in chat text.

    final_message = result.output_message

    if plat_examples:
        _btn_opts = [{"label": p, "value": f"Platform is {p}"} for p in plat_examples]
        if plat_examples_narrowed:
            final_message = (
                "Here are the top matched platforms for your platform input — "
                "select one below, or you can also type the platform name directly.\n\n"
                + final_message.lstrip()
            )
        else:
            final_message = final_message.rstrip() + "\n\nHere are the available platforms — select one below or type the name directly."
    elif tgt_examples:
        _btn_opts = [
            {"label": _strip_count(t), "value": f"Target system is {_strip_count(t)}"}
            for t in tgt_examples
        ]
        if tgt_examples_narrowed:
            final_message = (
                "Here are the top matched target systems for your target system input — "
                "select one below, or you can also type the target system name directly.\n\n"
                + final_message.lstrip()
            )
        else:
            _scope_note = f" for **{plat_resolved}**" if plat_resolved and plat_state["valid"] else ""
            final_message = final_message.rstrip() + f"\n\nHere are the top matched target systems{_scope_note} — select one below or type the target system name directly."
    else:
        _btn_opts = []
    return {
        "messages": [AIMessage(content=final_message)],
        "exhausted_attempts": 0,
        "clickable_options": _btn_opts or None,
        # AG-UI: name the registered component for this checkpoint and supply its props.
        "ui_component": ui_contract.field_prompt(
            message=final_message,
            options=ui_contract.options_from_clickable(_btn_opts),
        ),
    }


# ─────────────────────────────────────────────────────────────────────────────
def _missing_fields_prompt(state: AgentState) -> str:
    """Return a specific message naming which required fields are still missing."""
    _FIELD_LABELS = {
        "platform":              "platform",
        "target_system":         "target system",
        "reason_for_change":     "reason for change",
        "description_of_change": "description of change",
    }
    missing = [
        label
        for field, label in _FIELD_LABELS.items()
        if not state[field]["given"] or not state[field]["valid"]
    ]
    if not missing:
        return "Please provide the missing information."
    if len(missing) == 1:
        return f"Please provide the {missing[0]}."
    fields_str = ", ".join(missing[:-1]) + f" and {missing[-1]}"
    return f"Please provide the {fields_str}."


# NODE 4 — HITL Wait (after Node 3: request info)
# Command node: interrupt(), check relevance up to MAX_ATTEMPTS times.
# Relevant response → reset exhausted_attempts, goto node_1
# Irrelevant ×MAX_ATTEMPTS → goto node_5
# ─────────────────────────────────────────────────────────────────────────────
def node_4_hitl_wait(state: AgentState) -> Command:
    logger.info("NODE 4: hitl_wait")

    # ── Special case: platform / target_system compatibility selection ────────
    pending = state.get("platform_tgt_pending")
    if pending:
        options         = pending.get("options", [])
        original_target = pending.get("original_target", "")
        n               = len(options)

        prompt = (
            "Please select one of the suggested target systems below "
            "(click an option or type the target system full name.)."
        ) if n else (
            "No suggested target systems are available for this platform. "
            "Please type a different target system name."
        )

        # Append note about any other required fields still missing
        _EXTRA_REQUIRED = {
            "reason_for_change":     "reason for change",
            "description_of_change": "description of change",
        }
        _still_missing = [
            label for field, label in _EXTRA_REQUIRED.items()
            if not state[field]["given"] or not state[field]["valid"]
        ]
        if _still_missing:
            _fields_str = " and ".join(_still_missing) if len(_still_missing) > 1 else _still_missing[0]
            prompt += f"\n\nAlso, please provide the {_fields_str} once you've confirmed the target system."

        user_response: str = interrupt(prompt)

        raw        = user_response.strip()
        lower_resp = raw.lower()
        chosen_target: str | None = None

        if n:
            option_names = [o["target_system"] for o in options]
            # 1) Target system name appears anywhere in the response
            for oname in option_names:
                if oname.lower() in raw.lower():
                    chosen_target = oname
                    break
            # 2) Bare number
            if chosen_target is None and raw.isdigit():
                idx = int(raw) - 1
                if 0 <= idx < n:
                    chosen_target = options[idx]["target_system"]
            # 3) Number embedded in text
            if chosen_target is None:
                _m = re.search(r'\b([1-9])\b', raw)
                if _m:
                    idx = int(_m.group(1)) - 1
                    if 0 <= idx < n:
                        chosen_target = options[idx]["target_system"]
        else:
            if len(raw) >= 2 and lower_resp not in {
                "no", "n", "nope", "neither", "none",
                "yes", "y", "yep", "keep", "proceed", "continue", "skip",
            }:
                chosen_target = raw
                logger.info("NODE 4: free-form target system entered (no suggestions available): %r", chosen_target)

        updated_tgt = dict(state["target_system"])
        if chosen_target:
            updated_tgt["value"] = chosen_target
            updated_tgt["valid"] = True   # marks as valid — node_2 will skip re-validation
            updated_tgt["error"] = None
            updated_tgt["data"]  = None
            logger.info("NODE 4: user selected target_system=%r", chosen_target)
            _tgt_rank = next(
                (i + 1 for i, o in enumerate(options) if o["target_system"] == chosen_target),
                None,
            )
            _tgt_selection = f"rank_{_tgt_rank}" if _tgt_rank else "user_typed"
            logger.info("NODE 4: user selected target_system=%r (selection=%s)", chosen_target, _tgt_selection)
            
            return Command(
                update={
                    "messages":                    [HumanMessage(content=user_response)],
                    "target_system":               updated_tgt,
                    "platform_tgt_pending":        None,
                    "target_suggestion_selection": _tgt_selection,
                },
                goto="node_1",
            )
        else:
            if n:
                # User input did not map to any valid suggested option.
                plat_name = (
                    (state["platform"].get("data") or {}).get("resolved_name")
                    or state["platform"].get("value", "")
                ).strip()
                option_names_list = ", ".join(
                    f"**{o['target_system']}**" for o in options
                )
                logger.info(
                    "NODE 4: invalid target selection for platform=%r — re-prompting with suggestions",
                    plat_name,
                )
                _rejection_msg = (
                    f"⚠️ **{original_target}** is not a valid target system for platform **{plat_name}**.\n\n"
                    f"Please select one of the valid options: {option_names_list}."
                )
                _btn_opts = [
                    {"label": o["target_system"], "value": f"Target system is {o['target_system']}"}
                    for o in options
                ]
                return Command(
                    update={
                        "messages": [
                            HumanMessage(content=user_response),
                            AIMessage(content=_rejection_msg),
                        ],
                        "clickable_options": _btn_opts or None,
                        # Keep platform_tgt_pending so node_3/node_4 re-enter the
                        # platform-target flow on the next turn
                    },
                    goto="node_3",
                )
            else:
                # No suggestions are available; request a different target system value.
                plat_name = (
                    (state["platform"].get("data") or {}).get("resolved_name")
                    or state["platform"].get("value", "")
                ).strip()
                logger.info(
                    "NODE 4: no suggestions available for platform=%r — prompting for a different target",
                    plat_name,
                )
                _rejection_msg = (
                    f"⚠️ **{original_target}** is not a valid target system for platform **{plat_name}**.\n\n"
                    "Please provide a different target system name."
                )
                return Command(
                    update={
                        "messages": [
                            HumanMessage(content=user_response),
                            AIMessage(content=_rejection_msg),
                        ],
                        "clickable_options": None,
                        # Keep platform_tgt_pending so node_3/node_4 re-enter the
                        # platform-target flow on the next turn
                    },
                    goto="node_3",
                )

    # ── Generic HITL (missing required fields) ────────────────────────────────
    attempts: int = state.get("exhausted_attempts", 0)

    if attempts >= MAX_ATTEMPTS:
        return Command(
            update={
                "messages": [
                    AIMessage(
                        content=(
                            "It seems we're having trouble moving forward. "
                            "Please start a new session when you're ready."
                        )
                    )
                ]
            },
            goto="node_5",
        )

    if attempts == 0:
        # Use node_3's conversational LLM message directly — it already states what's missing.
        # (node_3 also appends context about the clickable options when showing them.)
        _last_ai = next(
            (m.content.strip() for m in reversed(state["messages"]) if isinstance(m, AIMessage) and m.content),
            "",
        )
        user_response: str = interrupt(_last_ai if _last_ai else _missing_fields_prompt(state))
    else:
        user_response = interrupt(
            "That doesn't seem related to the Change Request. "
            "Please provide the required field information."
        )

    # ── Shortcut: agent just presented a list of options (clickable_options set).
    # Any reply — whether typed or clicked — is an attempt to answer the question.
    # Skip the LLM relevance check entirely and send straight to node_1.
    # Clear clickable_options so this guard only fires once per option presentation.
    if state.get("clickable_options"):
        # Normalise: if the user typed just the label text (e.g. "RPG 0020397110 100")
        # instead of the full value sentence (e.g. "Target system is RPG 0020397110 100"),
        # substitute the full value so node_1 LLM always receives clear context.
        _raw_resp = user_response.strip()
        _opts = state.get("clickable_options") or []
        _normalised = user_response
        for _opt in _opts:
            _label = str(_opt.get("label", "")).strip()
            _value = str(_opt.get("value", "")).strip()
            if _label and _raw_resp.lower() == _label.lower():
                _normalised = _value
                logger.info(
                    "NODE 4: normalised bare label %r → full value %r",
                    _raw_resp, _normalised,
                )
                break
        return Command(
            update={
                "messages":           [HumanMessage(content=_normalised)],
                "exhausted_attempts": 0,
                "clickable_options":  None,
            },
            goto="node_1",
        )

    relevance: RelevanceCheck = llm_fast_with_output(RelevanceCheck).invoke(  # fast model — simple classification
        f"""Is this user message relevant to providing missing CR field data?
User said: {user_response}
Context: We need platform, reason_for_change, description_of_change, target_system, template_id, or jira_id."""
    )

    if relevance.is_relevant:
        return Command(
            update={
                "messages": [HumanMessage(content=user_response)],
                "exhausted_attempts": 0,
            },
            goto="node_1",
        )

    return Command(
        update={
            "messages": [
                HumanMessage(content=user_response),
                AIMessage(
                    content=(
                        "That doesn't seem related to providing the CR information. "
                        f"Attempt {attempts + 1}/{MAX_ATTEMPTS}."
                    )
                ),
            ],
            "exhausted_attempts": attempts + 1,
        },
        goto="node_4",
    )
