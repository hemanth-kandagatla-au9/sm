"""
agents/nodes/_metrics.py

OpenTelemetry metric instruments and value tuples for task-level observability.
These are initialised once at import time and used by nodes_draft.node_5_gather_metrics.
"""
from __future__ import annotations

from observability import get_meter, get_env_dimension

# Task-level OTel metric instruments for node_5 (task end)
_meter = get_meter()
_task_first_draft_accuracy_histogram = _meter.create_histogram(
    name="app.task.first_draft_accuracy",
    unit="1",
    description="First-draft accuracy score per task",
)
_task_duration_histogram = _meter.create_histogram(
    name="app.task.duration_ms",
    unit="ms",
    description="Task duration (task start to task end) in milliseconds",
)
_task_token_usage_histogram = _meter.create_histogram(
    name="app.task.token_usage",
    unit="{token}",
    description="Cumulative task-level LLM token usage, split by gen_ai.token.type=input|output",
)
_task_cost_usd_histogram = _meter.create_histogram(
    name="app.task.cost_usd",
    unit="USD",
    description="Cumulative task-level estimated USD cost",
)
_task_cycle_id_selection_counter = _meter.create_counter(
    name="app.task.cycle_id_selection.count",
    unit="{task}",
    description="Count of completed tasks, tagged by cycle_id_selection",
)
_task_cr_recommendation_source_counter = _meter.create_counter(
    name="app.task.cr_recommendation_source.count",
    unit="{task}",
    description="Count of completed tasks, tagged by cr_recommendation_source",
)
_task_target_suggestion_selection_counter = _meter.create_counter(
    name="app.task.target_suggestion_selection.count",
    unit="{task}",
    description="Count of completed tasks, tagged by target_suggestion_selection",
)
_task_end_without_draft_counter = _meter.create_counter(
    name="app.task.end_without_draft.count",
    unit="{task}",
    description="Count of completed tasks, tagged by end_without_draft",
)
_task_submission_counter = _meter.create_counter(
    name="app.task.submission_count",
    unit="{submission}",
    description="Count of CR submission attempts, tagged by outcome (success|failed|n/a)",
)
_task_completed_counter = _meter.create_counter(
    name="app.task.completed.count",
    unit="{task}",
    description="Total count of completed tasks (no outcome dimension)",
)

_CYCLE_ID_SELECTION_VALUES = ("default", "rank_1", "rank_2", "rank_3", "rank_4", "rank_5", "rank_>5", "N/A")
_CR_RECOMMENDATION_SOURCE_VALUES = (
    "direct", "rank_1", "rank_2", "rank_3", "rank_4", "rank_5",
    "user_template_id", "user_cr_id", "none_selected", "N/A",
)
_TARGET_SUGGESTION_SELECTION_VALUES = ("rank_1", "rank_2", "rank_3", "rank_4", "rank_5", "user_typed", "N/A")
_SUBMISSION_STATUS_VALUES = ("success", "failed", "ended_without_submission")
_END_WITHOUT_DRAFT_VALUES = ("true", "false")


def _emit_one_hot_counter(counter, attr_name: str, actual_value: str, possible_values: tuple[str, ...]) -> None:
    """Add 1 for the realized value and 0 for every other possible value."""
    for _value in possible_values:
        counter.add(
            1 if actual_value == _value else 0,
            attributes={**get_env_dimension(), attr_name: _value},
        )
