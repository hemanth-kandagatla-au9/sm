"""
graph/builder.py  — StateGraph wiring exactly matching the architecture diagram.
"""
from __future__ import annotations
import os
import re
from typing import Callable

from langgraph.graph import END, START, StateGraph

from observability import get_logger, trace_node, trace_edge
from langgraph_checkpoint_aws import AgentCoreMemorySaver

MEMORY_ID_RE = re.compile(r"^[a-zA-Z][a-zA-Z0-9-_]{0,99}-[a-zA-Z0-9]{10}$")


from agents.nodes import (
    cond_edge_a,
    cond_edge_b,
    cond_edge_c,
    node_0_show_entry,
    node_0_wait,
    node_1_extract_field_values,
    node_2_validate_and_gather_data,
    node_3_request_information,
    node_4_hitl_wait,
    node_5_gather_metrics,
    node_6_build_draft,
    node_7_suggest_similar_crs,
    node_8_present_draft,
    node_9_hitl_wait,
    node_10_parse_update_intent,
    node_10c_handle_rejection,
    node_11_get_information,
    node_12_submit,
    node_13_apply_update,
    node_15_failed,
    node_16_success,
    node_17_present_top_5,
    node_18_hitl_wait,
    node_19_no_recommendations,
    node_20_cycle_id_check,
    node_20b_cycle_id_hitl,
    cond_edge_20,
    node_s_output_answer,
)
from state.state import AgentState


def build_graph():
    """
    Build and compile the CR Agent StateGraph with MemorySaver checkpointer.

    The checkpointer is REQUIRED for:
      - interrupt() / HITL nodes (4, 9, 18)
      - graph.get_state(config) calls in the HITL resume loop
      - Command(resume=...) to work correctly
    """
    builder = StateGraph(AgentState)

    # ── Register all nodes — each wrapped in an OTel "node.<name>" span ──────
    # (trace_node adds tracing without touching agents/nodes.py bodies)
    _node_funcs: dict[str, Callable] = {
        "node_0_show_entry": node_0_show_entry,
        "node_0_wait":       node_0_wait,
        "node_1":       node_1_extract_field_values,
        "node_2":       node_2_validate_and_gather_data,
        "node_3":       node_3_request_information,
        "node_4":       node_4_hitl_wait,
        "node_5":       node_5_gather_metrics,
        "node_6":       node_6_build_draft,
        "node_7":       node_7_suggest_similar_crs,
        "node_8":       node_8_present_draft,
        "node_9":       node_9_hitl_wait,
        "node_10":      node_10_parse_update_intent,
        "node_10c":     node_10c_handle_rejection,
        "node_11":      node_11_get_information,
        "node_12":      node_12_submit,
        "node_13":      node_13_apply_update,
        "node_15":      node_15_failed,
        "node_16":      node_16_success,
        "node_17":      node_17_present_top_5,
        "node_18":      node_18_hitl_wait,
        "node_19":      node_19_no_recommendations,
        "node_20":      node_20_cycle_id_check,
        "node_20b":     node_20b_cycle_id_hitl,
        "node_s":       node_s_output_answer,
        # Passthrough nodes so Command nodes can goto "cond_edge_b" / "cond_edge_c"
        "cond_edge_b":  _cond_edge_b_passthrough,
        "cond_edge_c":  _cond_edge_c_passthrough,
    }
    for _name, _fn in _node_funcs.items():
        builder.add_node(_name, trace_node(_name, _fn))

    # ── START ─────────────────────────────────────────────────────────────────
    # node_0_show_entry sets the opening card (mode choice); node_0_wait then
    # interrupt()s on whatever card is showing and Command-routes to itself
    # (mode choice ↔ coming-soon ↔ intake form) or to node_1 once the intake
    # form is submitted — same interrupt()/Command pattern as node_3 → node_4.
    builder.add_edge(START, "node_0_show_entry")
    builder.add_edge("node_0_show_entry", "node_0_wait")

    # ── Screenshot 1 flow ─────────────────────────────────────────────────────
    builder.add_edge("node_1", "node_2")

    builder.add_conditional_edges(
        "node_2", trace_edge("cond_edge_a", cond_edge_a),
        {"node_3": "node_3", "node_6": "node_6", "node_7": "node_7", "node_5": "node_5"},
    )

    # node_3 → node_4 (HITL) — node_4 Command-routes to node_1 / node_4 / node_5
    builder.add_edge("node_3", "node_4")

    # node_5 → END (all terminal paths)
    builder.add_edge("node_5", END)

    # ── Screenshot 2 — node_6 branch ─────────────────────────────────────────
    builder.add_edge("node_6", "node_20")  # node_20 = cycle_id_check
    builder.add_conditional_edges(
        "node_20", trace_edge("cond_edge_20", cond_edge_20),
        {"node_8": "node_8", "node_20b": "node_20b"},
    )  # node_20b = cycle_id HITL (Command)
    builder.add_edge("node_8", "node_9")
    # node_9 Command-routes to cond_edge_b / node_9 / node_5

    builder.add_conditional_edges(
        "cond_edge_b", trace_edge("cond_edge_b", cond_edge_b),
        {"node_10": "node_10", "node_11": "node_11", "node_12": "node_12", "node_10c": "node_10c"},
    )

    # Approval path: node_12 Command-routes to node_15 or node_16
    builder.add_edge("node_15", "node_5")
    builder.add_edge("node_16", "node_5")

    # Question path: node_11 → node_s → node_9
    builder.add_edge("node_11", "node_s")
    builder.add_edge("node_s",  "node_9")

    # Rejection path: node_10c → node_9 (re-prompts user for specific feedback)
    builder.add_edge("node_10c", "node_9")

    # Update path: node_10 Command-routes to node_13 or node_8
    builder.add_edge("node_13", "node_8")   # ★ Apply update → re-present draft

    # ── Screenshot 3 — node_7 branch ─────────────────────────────────────────
    builder.add_edge("node_7",  "node_17")
    builder.add_edge("node_17", "node_18")
    # node_18 Command-routes to cond_edge_c / node_18 / node_5 ★

    builder.add_conditional_edges(
        "cond_edge_c", trace_edge("cond_edge_c", cond_edge_c),
        {"node_6": "node_6", "node_7": "node_7", "node_19": "node_19"},
    )

    builder.add_edge("node_19", "node_5")

    # ── Compile WITH checkpointer (required for HITL interrupt + get_state) ──
    _builder_log = get_logger("cr_agent.builder")

    use_agentcore = os.environ.get("USE_AGENTCORE_MEMORY", "").strip().lower() == "true"

    if use_agentcore:
        memory_id_raw = os.environ.get("MEMORY_ID", "").strip()

        if not memory_id_raw:
            raise RuntimeError(
                "MEMORY_ID must be set when USE_AGENTCORE_MEMORY=true"
            )

        # Accept plain memory ID or full ARN (extract ID from ARN)
        # e.g. arn:aws:bedrock-agentcore:...:memory/dev_crco_a2a-hklXfqHkYC
        if "memory/" in memory_id_raw:
            memory_id = memory_id_raw.split("memory/", 1)[1].strip()
        else:
            memory_id = memory_id_raw

        # Validate memory ID format
        if not MEMORY_ID_RE.match(memory_id):
            raise RuntimeError(
                "Invalid AgentCore memory id. "
                "Expected format: ^[a-zA-Z][a-zA-Z0-9-_]{0,99}-[a-zA-Z0-9]{10}$. "
                f"Got: {memory_id_raw}"
            )

        region = os.environ.get("AWS_REGION", "us-east-1").strip() or "us-east-1"
        checkpointer = AgentCoreMemorySaver(
            memory_id=memory_id,
            region_name=region,
        )
        _builder_log.info(
            "CHECKPOINTER: AgentCoreMemorySaver — memory_id=%s region=%s",
            memory_id, region,
        )
    else:
        raise RuntimeError(
            "USE_AGENTCORE_MEMORY is not set to 'true'. "
            "Set USE_AGENTCORE_MEMORY=true and MEMORY_ID=<your-memory-id> "
            "to use AgentCore persistent memory. Local MemorySaver is not supported."
        )

    return builder.compile(checkpointer=checkpointer)


# ── Passthrough nodes for cond edges (needed so Command.goto works) ───────────
def _cond_edge_b_passthrough(state: AgentState) -> dict:
    return {}

def _cond_edge_c_passthrough(state: AgentState) -> dict:
    return {}