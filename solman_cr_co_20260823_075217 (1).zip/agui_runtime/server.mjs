/**
 * agui_runtime/server.mjs
 *
 * CopilotKit Runtime bridge.
 *
 * The React app talks CopilotKit's GraphQL protocol; agui_server.py speaks AG-UI
 * over SSE. This process sits between them: it registers the Python agent as an
 * AG-UI HttpAgent and exposes the CopilotKit runtime endpoint the frontend
 * expects.
 *
 *     React (:8005)  ──►  this bridge (:8006)  ──►  agui_server.py (:8084)
 *
 * Ports are env-configurable so this can run alongside main.py without either
 * process fighting for a port:
 *
 *     AGUI_RUNTIME_PORT   port this bridge listens on        (default 8006)
 *     AGUI_BACKEND_URL    Python AG-UI endpoint to proxy to  (default http://localhost:8084/copilotkit)
 *     AGUI_AGENT_NAME     must match LangGraphAGUIAgent(name=…) in agui_server.py
 *                         AND AGUI_AGENT_NAME in frontend/src/agent-ui/config.ts
 *                                                            (default local_agent)
 *
 * Note on newer CopilotKit versions: some can point `runtimeUrl` straight at the
 * Python endpoint and skip this process entirely. If that works on your version,
 * set VITE_AGUI_RUNTIME_URL=http://localhost:8084/copilotkit and don't run this.
 * The bridge is kept because it is the configuration that is known to work with
 * the pinned @copilotkit 1.67.x in frontend/package.json.
 */
import express from "express";
import cors from "cors";
import {
  CopilotRuntime,
  copilotRuntimeNodeHttpEndpoint,
  ExperimentalEmptyAdapter,
} from "@copilotkit/runtime";
import { HttpAgent } from "@ag-ui/client";

// Temporary diagnostic: patch global fetch to confirm whether/when an
// outbound call to the Python backend is actually made, since CopilotRuntime's
// internal call path into HttpAgent doesn't go through a patchable .run().
const _origFetch = globalThis.fetch;
globalThis.fetch = async (url, opts) => {
  const urlStr = typeof url === "string" ? url : url?.url ?? String(url);
  console.log("[DEBUG-BRIDGE] outbound fetch ->", urlStr, "method:", opts?.method, "body:", String(opts?.body ?? "").slice(0, 500));
  try {
    const res = await _origFetch(url, opts);
    console.log("[DEBUG-BRIDGE] outbound fetch <-", urlStr, "status:", res.status);
    return res;
  } catch (err) {
    console.error("[DEBUG-BRIDGE] outbound fetch threw:", urlStr, err);
    throw err;
  }
};

const PORT = Number(process.env.AGUI_RUNTIME_PORT || 8006);
const BACKEND_URL =
  process.env.AGUI_BACKEND_URL || "http://localhost:8084/copilotkit";
const AGENT_NAME = process.env.AGUI_AGENT_NAME || "local_agent";

const app = express();

// Vite dev server origin. Narrow rather than "*" — credentials will be involved
// once the platform's auth is wired in. Any host is allowed (not just
// localhost/127.0.0.1) so this also works when the frontend is reached over a
// LAN IP, matching the port allow-list agui_server.py's CORS middleware uses.
app.use(
  cors({
    origin: /^https?:\/\/[^/]+:8005$/,
    credentials: true,
  })
);

const _pythonAgent = new HttpAgent({ url: BACKEND_URL });
const runtime = new CopilotRuntime({
  agents: {
    [AGENT_NAME]: _pythonAgent,
  },
});

// Temporary diagnostic: confirms every request the bridge receives, and
// whether it's actually reaching/erroring against the Python backend.
// Listens on 'data' only (doesn't consume/replace the body) so the actual
// handler downstream still gets to read the full request stream itself.
app.use((req, _res, next) => {
  console.log(`[DEBUG-BRIDGE] ${req.method} ${req.originalUrl}`);
  if (req.method === "POST") {
    const chunks = [];
    req.on("data", (c) => chunks.push(c));
    req.on("end", () => {
      const body = Buffer.concat(chunks).toString("utf-8");
      console.log(`[DEBUG-BRIDGE] request body: ${body.slice(0, 1000)}`);
    });
  }
  next();
});

const _origRun = _pythonAgent.run?.bind(_pythonAgent) ?? _pythonAgent.runAgent?.bind(_pythonAgent);
if (_pythonAgent.run) {
  _pythonAgent.run = async (...args) => {
    console.log("[DEBUG-BRIDGE] HttpAgent.run() called, args:", JSON.stringify(args).slice(0, 500));
    try {
      const result = await _origRun(...args);
      console.log("[DEBUG-BRIDGE] HttpAgent.run() completed");
      return result;
    } catch (err) {
      console.error("[DEBUG-BRIDGE] HttpAgent.run() threw:", err);
      throw err;
    }
  };
} else {
  console.log("[DEBUG-BRIDGE] WARNING: HttpAgent has no .run method to wrap — check available methods:", Object.getOwnPropertyNames(Object.getPrototypeOf(_pythonAgent)));
}
// Registered before the copilotkit mount below — that handler swallows every
// request it receives (no next() call on a miss), so anything after it in the
// same path space never gets reached.
app.get("/health", (_req, res) =>
  res.json({ ok: true, agent: AGENT_NAME, backend: BACKEND_URL })
);

// Mounted at "/", not "/api/copilotkit" — copilotRuntimeNodeHttpEndpoint routes
// on the full `endpoint` path itself, so a path-scoped app.use() here strips
// that prefix before the handler sees it and every request 404s.
app.use(
  copilotRuntimeNodeHttpEndpoint({
    endpoint: "/api/copilotkit",
    runtime,
    // The agent does its own LLM calls inside LangGraph — the runtime needs no
    // model adapter of its own, it is purely transport here.
    serviceAdapter: new ExperimentalEmptyAdapter(),
  })
);

app.listen(PORT, () => {
  console.log(`[agui-runtime] listening on http://localhost:${PORT}/api/copilotkit`);
  console.log(`[agui-runtime] agent "${AGENT_NAME}" -> ${BACKEND_URL}`);
});
