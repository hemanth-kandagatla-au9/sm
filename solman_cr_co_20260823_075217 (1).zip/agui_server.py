"""
agui_server.py

AG-UI host for the SolMan CR/CO agent.

Two surfaces:

  1. /copilotkit — the AG-UI event stream (CopilotKit + LangGraph). Component
     selection rides on AgentState["ui_component"], which the graph writes via
     agui.ui_contract builders and the frontend renders from its registry.

  2. /api/*      — small deterministic REST helpers: contract discovery
     (/api/ui-contract) and dropdown/lookup data (platforms, target systems,
     templates, Jira pre-fill) for the intake form. The opening mode-choice and
     intake-form screens themselves are graph nodes (node_0_show_entry /
     node_0_wait in agents/nodes/nodes_gateway.py) — they ride the /copilotkit
     stream via AgentState["ui_component"] like every other HITL card.
"""
import logging
import os
import re
import sys
import uuid
from functools import lru_cache
from typing import Any, Dict, Optional

# Third-party imports
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from copilotkit import LangGraphAGUIAgent
from ag_ui_langgraph import add_langgraph_fastapi_endpoint

# Local imports
from config.ssm_bootstrap import resolve_ssm_parameters
resolve_ssm_parameters()
from graph.builder import build_graph
from observability import configure_logging, get_logger
from tools.tools import execute_cypher, get_jira_data, generate_cr_fields_from_jira
from agents.nodes._helpers import _fetch_target_system_candidates
from agui import ui_contract

# ── Constants for local testing ───────────────────────────────────────────────
ACTOR_ID = f"anon_{uuid.uuid4()}"
WWID = "12345678"

# Same shape node_2 recognises server-side (e.g. "AAZM-11112"). Kept here so the
# frontend regex and this one can be asserted identical in tests.
JIRA_KEY_PATTERN = r"^[A-Za-z][A-Za-z0-9]+-\d+$"
_JIRA_KEY_RE = re.compile(JIRA_KEY_PATTERN)

# ── Logging setup ─────────────────────────────────────────────────────────────
LOG_DIR = os.environ.get("AGENT_LOG_DIR", "/tmp")
os.makedirs(LOG_DIR, exist_ok=True)
_log_file = os.path.join(LOG_DIR, "agui_agent.log")
configure_logging(_log_file)
logger = get_logger("cr_agent.ag_ui")
logger.info("agui_agent.log started — %s", _log_file)

# Temporary diagnostic: the app's own handlers are INFO-only, which hides
# ag_ui_langgraph's DEBUG logs (STATE_SNAPSHOT emit/suppress decisions,
# schema-key fallback) — give that logger its own DEBUG-level handler.
_agui_debug_handler = logging.StreamHandler(sys.stderr)
_agui_debug_handler.setLevel(logging.DEBUG)
_agui_debug_handler.setFormatter(logging.Formatter("%(asctime)s [DEBUG-AGUI] %(name)s: %(message)s"))
_agui_lib_logger = logging.getLogger("ag_ui_langgraph")
_agui_lib_logger.setLevel(logging.DEBUG)
_agui_lib_logger.addHandler(_agui_debug_handler)

# ── FastAPI App setup ──────────────────────────────────────────────────────────
app = FastAPI(title="SolMan CR/CO AG-UI host")

_DEV_ORIGINS = [
    "http://localhost:8005",
    "http://127.0.0.1:8005",
]
app.add_middleware(
    CORSMiddleware,
    allow_origins=_DEV_ORIGINS,
    allow_origin_regex=r"^https?://[^/]+:8005$",
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ─────────────────────────────────────────────────────────────────────────────
# Contract discovery — the platform team hits this to generate/verify their
# registry. Beats emailing a spec that goes stale.
# ─────────────────────────────────────────────────────────────────────────────
@app.get("/api/ui-contract")
def get_ui_contract() -> Dict[str, Any]:
    return ui_contract.contract_document()


# ─────────────────────────────────────────────────────────────────────────────
# NOTE: the opening mode-choice and intake-form screens (formerly /api/entry
# and /api/cr-mode) are now graph nodes — see agents/nodes/nodes_gateway.py
# (node_0_show_entry / node_0_wait). They ride the /copilotkit event stream
# via AgentState["ui_component"] + interrupt(), same as every other HITL card.
# Only pure lookup/tooling endpoints remain here as REST.
# ─────────────────────────────────────────────────────────────────────────────


# ─────────────────────────────────────────────────────────────────────────────
# Dropdown data endpoints (frontend intake form)
# ─────────────────────────────────────────────────────────────────────────────
@lru_cache(maxsize=1)
def _fetch_platform_names() -> tuple[str, ...]:
    rows = execute_cypher("MATCH (p:Platform) RETURN p.name AS name ORDER BY p.name")
    if rows and isinstance(rows[0], dict) and rows[0].get("error"):
        # Surface the outage instead of silently returning an empty dropdown that
        # reads to the user as "no platforms exist".
        logger.error("platform lookup failed: %s", rows[0]["error"])
        raise HTTPException(status_code=503, detail="Platform directory is unavailable")
    return tuple(r["name"] for r in rows if r.get("name") and not r.get("error"))


@app.get("/api/platforms")
def get_platforms() -> Dict[str, Any]:
    return {"platforms": list(_fetch_platform_names())}


@app.get("/api/target-systems")
def get_target_systems(platform: str) -> Dict[str, Any]:
    if not platform.strip():
        raise HTTPException(status_code=400, detail="platform query parameter is required")
    return {"target_systems": _fetch_target_system_candidates(platform)}


@app.get("/api/templates")
def get_templates(platform: Optional[str] = None, limit: int = 50) -> Dict[str, Any]:
    """Template IDs for the templateOrCrPicker dropdown."""
    limit = max(1, min(int(limit), 200))
    if platform and platform.strip():
        rows = execute_cypher(
            "MATCH (c:ChangeRequest) "
            "WHERE c.object_id IS NOT NULL AND c.object_id <> '' "
            "AND (c.platform = $platform OR toLower(c.platform) CONTAINS toLower($platform)) "
            "RETURN DISTINCT c.object_id AS id ORDER BY id LIMIT $limit",
            {"platform": platform.strip(), "limit": limit},
        )
    else:
        rows = execute_cypher(
            "MATCH (c:ChangeRequest) "
            "WHERE c.object_id IS NOT NULL AND c.object_id <> '' "
            "RETURN DISTINCT c.object_id AS id ORDER BY id LIMIT $limit",
            {"limit": limit},
        )
    if rows and isinstance(rows[0], dict) and rows[0].get("error"):
        logger.error("template lookup failed: %s", rows[0]["error"])
        raise HTTPException(status_code=503, detail="Template directory is unavailable")
    return {"templates": [r["id"] for r in rows if r.get("id") and not r.get("error")]}


# ─────────────────────────────────────────────────────────────────────────────
# Jira pre-fill lookup
# ─────────────────────────────────────────────────────────────────────────────
# The frontend debounces typing and only calls once the key matches
# JIRA_KEY_PATTERN. This endpoint re-validates rather than trusting that, so a
# malformed key never reaches the Jira proxy.
#
# Reuses the exact tools node_2 uses later (get_jira_data +
# generate_cr_fields_from_jira), so the authoritative fetch during the real CR
# flow stays consistent with what the user saw prefilled here.
@app.get("/api/jira-lookup")
def jira_lookup(jira_id: str) -> Dict[str, Any]:
    jira_id = (jira_id or "").strip()
    if not jira_id:
        raise HTTPException(status_code=400, detail="jira_id query parameter is required")
    if not _JIRA_KEY_RE.match(jira_id):
        raise HTTPException(
            status_code=422,
            detail=f"'{jira_id}' is not a valid Jira key (expected e.g. AAZM-11112)",
        )

    data = get_jira_data(jira_id)
    if data.get("error"):
        logger.warning("jira-lookup: fetch failed for %s — %s", jira_id, data["error"])
        return {"found": False, "error": data["error"]}

    summary = (data.get("summary") or "").strip()
    description = (data.get("description") or "").strip()
    if not summary and not description:
        # get_jira_data returns an empty-but-successful dict when it exhausts its
        # retries, so this is the only place that case becomes visible.
        logger.warning("jira-lookup: %s returned no summary or description", jira_id)
        return {"found": False, "error": "Jira ticket returned no summary or description"}

    generated = generate_cr_fields_from_jira(summary, description)
    # generate_cr_fields_from_jira falls back to the raw Jira text on LLM failure and
    # signals it via `error`. Pass that through so the UI can label the provenance
    # rather than implying the text was LLM-derived when it was not.
    return {
        "found": True,
        "reason_for_change": generated.get("reason_for_change") or summary,
        "description_of_change": generated.get("description_of_change") or description,
        "generated": not generated.get("error"),
        "note": generated.get("error"),
    }


# ─────────────────────────────────────────────────────────────────────────────
# Graph build and AG-UI endpoint
# ─────────────────────────────────────────────────────────────────────────────
_graph = build_graph()

# TODO: derive actor_id and wwid from the validated JWT rather than constants.
agent = LangGraphAGUIAgent(
    name="local_agent",
    description="SolMan CR/CO agent over AG-UI",
    graph=_graph,
    config={"configurable": {"actor_id": ACTOR_ID, "wwid": WWID}},
)


add_langgraph_fastapi_endpoint(app=app, agent=agent, path="/copilotkit")


def main() -> None:
    import uvicorn
    # Deliberately NOT `PORT` — set_env.sh sets PORT=8081 for main.py, and reusing
    # it here would make the two servers fight over the same port when both are run
    # from a sourced environment.
    port = int(os.environ.get("AGUI_PORT", 8084))
    logger.info("CR Agent AG-UI server starting on http://0.0.0.0:%s", port)
    uvicorn.run(app, host="0.0.0.0", port=port, log_level="warning")


if __name__ == "__main__":
    main()
