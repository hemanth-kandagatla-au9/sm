##Dev Runtime Values
##Environment Variables
environment_variables = {
    RESOLVE_SSM_PARAMS                    = "true"
    AWS_REGION                            = "us-east-1"
    AZURE_OPENAI_API_KEY                  = "JJYY-CRCO-DEV-AZURE_OPENAI_API_KEY"
    AZURE_OPENAI_EMBEDDING_API_KEY        = "JJYY-CRCO-DEV-AZURE_OPENAI_EMBEDDING_API_KEY"
    NEO4J_PASSWORD                        = "JJYY-CRCO-DEV-NEO4J-PASSWORD"
    NEO4J_USER                            = "JJYY-CRCO-DEV-NEO4J_USER"
    OAUTH_CLIENT_ID                       = "JJYY-CRCO-DEV-OAUTH_CLIENT_ID_NEW"
    OAUTH_SCOPE                           = "JJYY-CRCO-DEV-OAUTH_SCOPE_NEW"
    OAUTH_TOKEN_URL                       = "JJYY-CRCO-DEV-OAUTH_TOKEN_URL"
    SOLMAN_API_KEY                        = "JJYY-CRCO-DEV-SOLMAN_API_KEY"
    SOLMAN_READ_PASSWORD                  = "JJYY-CRCO-DEV-SOLMAN_READ_PASSWORD"
    SOLMAN_READ_USERNAME                  = "JJYY-CRCO-DEV-SOLMAN_READ_USERNAME"
    AGENTCORE_PROTOCOL                    = "HTTP"
    AGENTCORE_INBOUND_PROTOCOL            = "HTTP"
    MEMORY_ID                             = "crco_dev-OZOs4sHuv7"
    MEMORY_ID_HTTP                        = "crco_dev-OZOs4sHuv7"
    AZURE_OPENAI_API_VERSION              = "2024-10-21"
    AZURE_OPENAI_DEPLOYMENT               = "gpt-5.4-mini-global"
    AZURE_OPENAI_ENDPOINT                 = "https://genaiapimna.jnj.com/openai-gpt-5"
    AZURE_OPENAI_EMBEDDING_API_VERSION    = "2024-10-21"
    AZURE_OPENAI_EMBEDDING_DEPLOYMENT     = "text-embedding-3-large"
    AZURE_OPENAI_EMBEDDING_ENDPOINT       = "https://genaiapimna.jnj.com/openai-embeddings/openai/deployments/text-embedding-3-large/embeddings?api-version=2024-10-21-preview%22"
    JIRA_BASE_URL                         = "https://solman-dev.jnj.com/sap/opu/odata/sap/ZJIRA_SRV"
    JIRA_USERNAME                         = "JJYY-CRCO-DEV-SOLMAN_READ_USERNAME"
    JIRA_PASSWORD                         = "JJYY-CRCO-DEV-SOLMAN_READ_PASSWORD"
    NEO4J_URI                             = "bolt://awseucnval0003.jnj.com:7687"
    NEO4J_DATABASE                        = "neo4j"
    SOLMAN_READ_BASE_URL                  = "https://solman-dev.jnj.com"
    SOLMAN_READ_VERIFY_SSL                = "false"
    SOP_PATH                              = "sop_instructions.txt"
    USE_AGENTCORE_MEMORY                  = "true"
    JIRA_RESOURCE_PATH                    =  "JIRAIssueSet"
    SOLMAN_ODATA_PATH                     = "/sap/opu/odata/sap/ZCHM_RFC_SRV/ChangeRequestSet"
    OTEL_SERVICE_NAME                     = "cr-agent"
    OTEL_PROPAGATORS                      = "xray,tracecontext"
    OTEL_TRACES_SAMPLER                   = "parentbased_always_on"
    OTEL_PYTHON_DISTRO                    = "aws_distro"
    OTEL_PYTHON_CONFIGURATOR              = "aws_configurator"
    AGENT_OBSERVABILITY_ENABLED           = "true"
    OTEL_PYTHON_DISABLED_INSTRUMENTATIONS = "logging"
    OTEL_EXPORTER_OTLP_LOGS_HEADERS       = "x-aws-log-group=/aws/bedrock-agentcore/runtimes/crco_dev-pbHu1QBr4l-DEFAULT,x-aws-log-stream=otel-rt-logs,x-aws-metric-namespace=cr-agent-dev"
    LOG_FORMAT                            = "json"
    ENVIRONMENT                           = "dev"
} 
 
environment = "dev"
subnet_ids = ["subnet-043d05c12386d0833"]
security_group_ids = ["sg-0cef7f8d2a83c5832", "sg-01ef518e63e9d70e1", "sg-04348fed5d68ca553"]
 
entra_client_id = "42ea229d-727a-4405-83b9-fb414fcfc934"

dashboard_log_group_name              = "/aws/bedrock-agentcore/runtimes/crco_dev-pbHu1QBr4l-DEFAULT"
metric_namespace                      = "cr-agent-dev"
 
# from pipeline
# image_tag = 
# application =