##Dev Runtime Values
##Environment Variables
environment_variables = {
    RESOLVE_SSM_PARAMS                 = "true"
    AWS_REGION                         = "us-east-1"
    AZURE_OPENAI_API_KEY               = "JJYY-CRCO-PROD-AZURE_OPENAI_API_KEY"
    AZURE_OPENAI_EMBEDDING_API_KEY     = "JJYY-CRCO-PROD-AZURE_OPENAI_EMBEDDING_API_KEY"
    JIRA_API_TOKEN                     = "JJYY-CRCO-PROD-JIRA_API_TOKEN"
    NEO4J_PASSWORD                     = "JJYY-CRCO-PROD-NEO4J-PASSWORD"
    NEO4J_USER                         = "JJYY-CRCO-PROD-NEO4J_USER"
    OAUTH_CLIENT_ID                    = "JJYY-CRCO-PROD-OAUTH_CLIENT_ID"
    OAUTH_SCOPE                        = "JJYY-CRCO-PROD-OAUTH_SCOPE"
    OAUTH_TOKEN_URL                    = "JJYY-CRCO-PROD-OAUTH_TOKEN_URL"   
    SOLMAN_API_KEY                     = "JJYY-CRCO-PROD-SOLMAN_API_KEY"
    SOLMAN_BASE_URL                    = "JJYY-CRCO-PROD-SOLMAN_BASE_URL"
    AGENTCORE_PROTOCOL                 = "HTTP"
    AGENTCORE_INBOUND_PROTOCOL         = "HTTP"
    AZURE_OPENAI_API_VERSION           = "2024-10-21"
    AZURE_OPENAI_DEPLOYMENT            = "gpt-5.4-mini-global"
    AZURE_OPENAI_ENDPOINT              = "https://genaiapimna.jnj.com/openai-gpt-5"
    AZURE_OPENAI_EMBEDDING_API_VERSION = "2024-10-21"
    AZURE_OPENAI_EMBEDDING_DEPLOYMENT  = "text-embedding-3-large"
    AZURE_OPENAI_EMBEDDING_ENDPOINT    = "https://genaiapimna.jnj.com/openai-embeddings/openai/deployments/text-embedding-3-large/embeddings?api-version=2024-10-21-preview%22"
    JIRA_BASE_URL                      = "https://solman.jnj.com/sap/opu/odata/sap/ZJIRA_SRV"
    JIRA_USERNAME                      = "JJYY-CRCO-PROD-SOLMAN_READ_USERNAME"
    JIRA_PASSWORD                      = "JJYY-CRCO-PROD-SOLMAN_READ_PASSWORD"
    NEO4J_URI                          = "bolt://awsfcpnval0002.jnj.com:7687"
    NEO4J_DATABASE                     = "neo4j"
    SOLMAN_READ_BASE_URL               = "https://solman.jnj.com"
    SOLMAN_READ_USERNAME               = "JJYY-CRCO-PROD-SOLMAN_READ_USERNAME"
    SOLMAN_READ_PASSWORD               = "JJYY-CRCO-PROD-SOLMAN_READ_PASSWORD"
    SOLMAN_READ_VERIFY_SSL             = "false"
    SOP_PATH                           = "sop_instructions.txt"
    USE_AGENTCORE_MEMORY               = "true"
    JIRA_RESOURCE_PATH                 = "JIRAIssueSet"
    SOLMAN_ODATA_PATH                  = "/sap/opu/odata/sap/ZCHM_RFC_SRV/ChangeRequestSet"
    
    OTEL_SERVICE_NAME                     = "cr-agent"
    OTEL_PROPAGATORS                      = "xray,tracecontext"
    OTEL_TRACES_SAMPLER                   = "parentbased_always_on"
    OTEL_PYTHON_DISTRO                    = "aws_distro"
    OTEL_PYTHON_CONFIGURATOR              = "aws_configurator"
    AGENT_OBSERVABILITY_ENABLED           = "true"
    OTEL_PYTHON_DISABLED_INSTRUMENTATIONS = "logging"
    OTEL_EXPORTER_OTLP_LOGS_HEADERS       = "x-aws-log-group=/aws/bedrock-agentcore/runtimes/crco_prod-ceu4Y1G0WD-DEFAULT,x-aws-log-stream=otel-rt-logs,x-aws-metric-namespace=cr-agent-prod"
    LOG_FORMAT                            = "json"
    ENVIRONMENT                           = "prod"
}

environment = "prod"
subnet_ids = ["subnet-03e7ba003795e4d4a"]
security_group_ids = ["sg-08fd52c1e8a20b5be", "sg-08e2f89d2a695c1cd", "sg-0e5891041cc737f85"]

entra_client_id = "b5b13c8d-4d87-4dfa-a245-b316584288f0"

dashboard_log_group_name              = "/aws/bedrock-agentcore/runtimes/crco_prod-ceu4Y1G0WD-DEFAULT"
metric_namespace                      = "cr-agent-prod"

# from pipeline
# image_tag = 
# application = 
