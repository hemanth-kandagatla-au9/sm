##Dev Runtime Values
##Environment Variables
environment_variables = {
    RESOLVE_SSM_PARAMS                 = "true"
    AWS_REGION                         = "us-east-1"
    AZURE_OPENAI_API_KEY               = "JJYY-CRCO-QA-AZURE_OPENAI_API_KEY"
    AZURE_OPENAI_EMBEDDING_API_KEY     = "JJYY-CRCO-QA-AZURE_OPENAI_EMBEDDING_API_KEY"
    JIRA_API_TOKEN                     = "JJYY-CRCO-QA-JIRA_API_TOKEN"
    NEO4J_PASSWORD                     = "JJYY-CRCO-QA-NEO4J-PASSWORD"
    NEO4J_USER                         = "JJYY-CRCO-QA-NEO4J_USER"
    OAUTH_CLIENT_ID                    = "JJYY-CRCO-QA-OAUTH_CLIENT_ID"
    OAUTH_SCOPE                        = "JJYY-CRCO-QA-OAUTH_SCOPE"
    OAUTH_TOKEN_URL                    = "JJYY-CRCO-QA-OAUTH_TOKEN_URL"   
    SOLMAN_API_KEY                     = "JJYY-CRCO-QA-SOLMAN_API_KEY"
    SOLMAN_BASE_URL                    = "JJYY-CRCO-QA-SOLMAN_BASE_URL"
    #SOLMAN_READ_PASSWORD              = "JJYY-CRCO-DEV-SOLMAN_READ_PASSWORD"
    #SOLMAN_READ_USERNAME              = "JJYY-CRCO-DEV-SOLMAN_READ_USERNAME"
    AGENTCORE_PROTOCOL                 = "HTTP"
    AGENTCORE_INBOUND_PROTOCOL         = "HTTP"
    # MEMORY_ID                          = "crco_dev-OZOs4sHuv7"
    # MEMORY_ID_HTTP                     = "crco_dev-OZOs4sHuv7"
    AZURE_OPENAI_API_VERSION           = "2024-10-21"
    AZURE_OPENAI_DEPLOYMENT            = "gpt-5.4-mini-global"
    AZURE_OPENAI_ENDPOINT              = "https://genaiapimna.jnj.com/openai-gpt-5"
    AZURE_OPENAI_EMBEDDING_API_VERSION = "2024-10-21"
    AZURE_OPENAI_EMBEDDING_DEPLOYMENT  = "text-embedding-3-large"
    AZURE_OPENAI_EMBEDDING_ENDPOINT    = "https://genaiapimna.jnj.com/openai-embeddings/openai/deployments/text-embedding-3-large/embeddings?api-version=2024-10-21-preview%22"
    JIRA_BASE_URL                      = "https://solman-qa.jnj.com/sap/opu/odata/sap/ZJIRA_SRV"
    JIRA_USERNAME                      = "JJYY-CRCO-QA-SOLMAN_READ_USERNAME"
    JIRA_PASSWORD                      = "JJYY-CRCO-QA-SOLMAN_READ_PASSWORD"
    NEO4J_URI                          = "bolt://awsfcpnval0001.jnj.com:7687"
    NEO4J_DATABASE                     = "neo4j"
    SOLMAN_READ_BASE_URL               = "https://solman-qa.jnj.com"
    SOLMAN_READ_USERNAME               = "JJYY-CRCO-QA-SOLMAN_READ_USERNAME"
    SOLMAN_READ_PASSWORD               = "JJYY-CRCO-QA-SOLMAN_READ_PASSWORD"
    SOLMAN_READ_VERIFY_SSL             = "false"
    SOP_PATH                           = "sop_instructions.txt"
    USE_AGENTCORE_MEMORY               = "true"
    JIRA_RESOURCE_PATH                 = "JIRAIssueSet"
    SOLMAN_ODATA_PATH                  = "/sap/opu/odata/sap/ZCHM_RFC_SRV/ChangeRequestSet"

    OTEL_SERVICE_NAME                     = "cr-agent"
    OTEL_PROPAGATORS                      = "xray,tracecontext"
    OTEL_TRACES_SAMPLER                   = "parentbased_always_on"
    OTEL_PYTHON_DISTRO                    = "aws_distro"
    OTEL_PYTHON_CONFIGURATOR              = "aws_configurator"
    AGENT_OBSERVABILITY_ENABLED           = "true"
    OTEL_PYTHON_DISABLED_INSTRUMENTATIONS = "logging"
    OTEL_EXPORTER_OTLP_LOGS_HEADERS       = "x-aws-log-group=/aws/bedrock-agentcore/runtimes/crco_qa-quYvxtEVDm-DEFAULT,x-aws-log-stream=otel-rt-logs,x-aws-metric-namespace=cr-agent-qa"
    LOG_FORMAT                            = "json"
    ENVIRONMENT                           = "qa"
}

environment = "qa"
subnet_ids = ["subnet-03e7ba003795e4d4a"]
security_group_ids = ["sg-034ea5de56abcba01", "sg-08e2f89d2a695c1cd", "sg-0e5891041cc737f85"]

entra_client_id = "37aab520-9f09-436a-a007-a1901e03f3c1"
dashboard_log_group_name              = "/aws/bedrock-agentcore/runtimes/crco_qa-quYvxtEVDm-DEFAULT"
metric_namespace                      = "cr-agent-qa"

# from pipeline
# image_tag = 
# application =