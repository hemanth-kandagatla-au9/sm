import { useCallback, useEffect, useId, useRef, useState } from "react";
import CardShell from "./CardShell";
import { API_BASE_URL } from "../agent-ui/config";
import type { AgentComponentHandlers, CrIntakeFormProps } from "../agent-ui/types";

/**
 * Registered component: "crIntakeForm"
 *
 * Screen 1 — the opening Create Change Request form.
 *
 * Jira behaviour (the bit with the moving parts):
 *   1. The user types. Nothing fires while they are still typing.
 *   2. JIRA_DEBOUNCE_MS after the last keystroke — or immediately on blur, since
 *      leaving the field means they are done — the value is tested against
 *      JIRA_KEY_RE.
 *   3. Only a matching key triggers GET /api/jira-lookup. A non-matching value
 *      is left alone with no request and no error, because a half-typed key is
 *      not a mistake yet.
 *   4. On success, Reason and Description are filled — but only where the user
 *      has not typed their own text. Anything they edited by hand is never
 *      overwritten by a later lookup.
 *
 * Requests are sequence-numbered so a slow response for an old key can never
 * overwrite a newer one.
 *
 * IRIS has no backing API yet. The field renders (per the design) but stays
 * disabled until `iris_enabled` flips server-side.
 */

// Must stay identical to agui_server.JIRA_KEY_PATTERN.
const JIRA_KEY_RE = /^[A-Za-z][A-Za-z0-9]+-\d+$/;
const JIRA_DEBOUNCE_MS = 600;

interface FormValues {
  platform: string;
  targetSystem: string;
  jiraId: string;
  irisId: string;
  reasonForChange: string;
  descriptionOfChange: string;
}

const EMPTY: FormValues = {
  platform: "",
  targetSystem: "",
  jiraId: "",
  irisId: "",
  reasonForChange: "",
  descriptionOfChange: "",
};

type LookupStatus = "idle" | "loading" | "success" | "error";

export default function CrIntakeForm({
  props,
  handlers,
}: {
  props: CrIntakeFormProps;
  handlers: AgentComponentHandlers;
}) {
  const {
    title,
    subtitle,
    hint,
    platforms,
    target_systems,
    values: initialValues,
    errors,
    iris_enabled,
    meta,
  } = props;
  const { respond, answered } = handlers;

  const listId = useId();
  const [values, setValues] = useState<FormValues>({
    ...EMPTY,
    platform: initialValues?.platform ?? "",
    targetSystem: initialValues?.target_system ?? "",
    jiraId: initialValues?.jira_id ?? "",
    irisId: initialValues?.iris_id ?? "",
    reasonForChange: initialValues?.reason_for_change ?? "",
    descriptionOfChange: initialValues?.description_of_change ?? "",
  });
  const [targetSystems, setTargetSystems] = useState<string[]>(target_systems ?? []);
  const [status, setStatus] = useState<LookupStatus>("idle");
  const [lookupError, setLookupError] = useState<string | null>(null);
  const [lookupNote, setLookupNote] = useState<string | null>(null);

  // Text last written by an auto-fill, so a later lookup only overwrites fields
  // the user has not since edited by hand.
  const autofillRef = useRef<{ reason: string; description: string } | null>(null);
  const seqRef = useRef(0);

  /* ── Target systems follow the selected platform ────────────────────────── */
  useEffect(() => {
    if (!values.platform) {
      setTargetSystems([]);
      return;
    }
    let cancelled = false;
    fetch(`${API_BASE_URL}/api/target-systems?platform=${encodeURIComponent(values.platform)}`)
      .then((r) => r.json())
      .then((d) => {
        if (!cancelled) setTargetSystems(d.target_systems || []);
      })
      .catch(() => {
        if (!cancelled) setTargetSystems([]);
      });
    return () => {
      cancelled = true;
    };
  }, [values.platform]);

  /* ── Jira lookup ────────────────────────────────────────────────────────── */
  const runJiraLookup = useCallback((rawId: string) => {
    const jiraId = rawId.trim();
    if (!JIRA_KEY_RE.test(jiraId)) return;

    const seq = ++seqRef.current;
    setStatus("loading");
    setLookupError(null);
    setLookupNote(null);

    fetch(`${API_BASE_URL}/api/jira-lookup?jira_id=${encodeURIComponent(jiraId)}`)
      .then(async (res) => {
        if (!res.ok) {
          const body = await res.json().catch(() => ({}));
          throw new Error(body.detail || `Lookup failed (${res.status})`);
        }
        return res.json();
      })
      .then((data) => {
        if (seq !== seqRef.current) return; // superseded by a newer key
        if (!data.found) {
          setStatus("error");
          setLookupError(data.error || "Could not fetch Jira ticket");
          return;
        }
        setValues((prev) => {
          const tag = autofillRef.current;
          const reasonUntouched =
            !prev.reasonForChange.trim() || prev.reasonForChange === tag?.reason;
          const descUntouched =
            !prev.descriptionOfChange.trim() || prev.descriptionOfChange === tag?.description;
          return {
            ...prev,
            reasonForChange: reasonUntouched ? data.reason_for_change : prev.reasonForChange,
            descriptionOfChange: descUntouched
              ? data.description_of_change
              : prev.descriptionOfChange,
          };
        });
        autofillRef.current = {
          reason: data.reason_for_change,
          description: data.description_of_change,
        };
        setStatus("success");
        // The server tells us when it fell back to raw Jira text instead of the
        // LLM-derived wording — surface it rather than implying it was generated.
        setLookupNote(data.generated === false ? "Raw Jira text used" : null);
      })
      .catch((err: Error) => {
        if (seq !== seqRef.current) return;
        setStatus("error");
        setLookupError(err.message || "Could not reach Jira lookup service");
      });
  }, []);

  // Debounced trigger — fires once the user pauses.
  useEffect(() => {
    const jiraId = values.jiraId.trim();

    if (!jiraId) {
      seqRef.current += 1; // invalidate anything in flight
      setStatus("idle");
      setLookupError(null);
      setLookupNote(null);
      autofillRef.current = null;
      return;
    }
    if (!JIRA_KEY_RE.test(jiraId)) {
      // Still mid-typing — not an error, just nothing to do yet.
      setStatus("idle");
      setLookupError(null);
      return;
    }

    const timer = setTimeout(() => runJiraLookup(jiraId), JIRA_DEBOUNCE_MS);
    return () => clearTimeout(timer);
  }, [values.jiraId, runJiraLookup]);

  // Leaving the field means they are definitely done — don't wait out the debounce.
  const handleJiraBlur = () => {
    const jiraId = values.jiraId.trim();
    if (jiraId && JIRA_KEY_RE.test(jiraId) && status === "idle") {
      runJiraLookup(jiraId);
    }
  };

  /* ── Form plumbing ──────────────────────────────────────────────────────── */
  const set =
    (field: keyof FormValues) =>
    (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
      const next = e.target.value;
      setValues((prev) => ({
        ...prev,
        [field]: next,
        ...(field === "platform" ? { targetSystem: "" } : {}),
      }));
    };

  const reset = () => {
    seqRef.current += 1;
    autofillRef.current = null;
    setValues(EMPTY);
    setStatus("idle");
    setLookupError(null);
    setLookupNote(null);
  };

  const filledCount = Object.values(values).filter((v) => v.trim()).length;
  const totalCount = Object.keys(values).length;

  // Platform + target system are required. Beyond that the agent needs either a
  // Jira key to derive the narrative from, or the narrative typed directly.
  const canSubmit =
    !answered &&
    !!values.platform.trim() &&
    !!values.targetSystem.trim() &&
    (!!values.jiraId.trim() ||
      (!!values.reasonForChange.trim() && !!values.descriptionOfChange.trim()));

  const jiraMalformed = !!values.jiraId.trim() && !JIRA_KEY_RE.test(values.jiraId.trim());

  const submit = () => {
    if (!canSubmit) return;
    // The agent parses this from the opening user turn — node_1's extraction
    // prompt reads these exact labels.
    const lines = [
      "Create a CR.",
      `Platform: ${values.platform.trim()}`,
      `Target System: ${values.targetSystem.trim()}`,
    ];
    if (values.jiraId.trim()) lines.push(`Jira: ${values.jiraId.trim()}`);
    if (values.reasonForChange.trim())
      lines.push(`Reason for change: ${values.reasonForChange.trim()}`);
    if (values.descriptionOfChange.trim())
      lines.push(`Description of change: ${values.descriptionOfChange.trim()}`);
    respond(lines.join("\n"));
  };

  const isAutofilled = (field: "reason" | "description") =>
    autofillRef.current !== null &&
    (field === "reason"
      ? values.reasonForChange === autofillRef.current.reason
      : values.descriptionOfChange === autofillRef.current.description) &&
    !!values[field === "reason" ? "reasonForChange" : "descriptionOfChange"].trim();

  return (
    <CardShell
      title={title}
      subtitle={subtitle}
      meta={meta}
      headerAction={
        <button type="button" className="ac-reset" onClick={reset} disabled={answered}>
          <span aria-hidden>↺</span> Reset Form
        </button>
      }
    >
      <form
        onSubmit={(e) => {
          e.preventDefault();
          submit();
        }}
      >
        <div className="ac-grid">
          <label className="ac-field">
            <span className="ac-label">
              Platform <span className="ac-req">*</span>
            </span>
            <select
              className={`ac-control${errors?.platform ? " ac-invalid" : ""}`}
              value={values.platform}
              onChange={set("platform")}
              disabled={answered}
              required
            >
              <option value="">Select Platform</option>
              {platforms.map((p) => (
                <option key={p} value={p}>
                  {p}
                </option>
              ))}
            </select>
            {errors?.platform && <span className="ac-error-text">{errors.platform}</span>}
          </label>

          <label className="ac-field">
            <span className="ac-label">
              Target System <span className="ac-req">*</span>
            </span>
            {/* Free text with suggestions rather than a hard select: the graph
                validates and can disambiguate, and users often know a system
                that is not yet in the graph. */}
            <input
              type="text"
              className={`ac-control${errors?.target_system ? " ac-invalid" : ""}`}
              value={values.targetSystem}
              onChange={set("targetSystem")}
              placeholder="Enter Target System"
              list={`${listId}-targets`}
              disabled={answered || !values.platform}
              required
            />
            <datalist id={`${listId}-targets`}>
              {targetSystems.map((t) => (
                <option key={t} value={t} />
              ))}
            </datalist>
            {errors?.target_system && (
              <span className="ac-error-text">{errors.target_system}</span>
            )}
          </label>
        </div>

        {hint && <p className="ac-hint">{hint}</p>}

        <div className="ac-grid">
          <label className="ac-field">
            <span className="ac-label">Jira ID</span>
            <input
              type="text"
              className={`ac-control${jiraMalformed ? " ac-invalid" : ""}`}
              value={values.jiraId}
              onChange={set("jiraId")}
              onBlur={handleJiraBlur}
              placeholder="Enter Jira ID"
              disabled={answered}
              inputMode="text"
              autoComplete="off"
              spellCheck={false}
            />
            {status === "loading" && (
              <span className="ac-status ac-status-loading">Fetching from Jira…</span>
            )}
            {status === "success" && (
              <span className="ac-status ac-status-success">
                ✓ Auto-filled from Jira{lookupNote ? ` — ${lookupNote}` : ""}
              </span>
            )}
            {status === "error" && (
              <span className="ac-status ac-status-error">⚠ {lookupError}</span>
            )}
          </label>

          <label className="ac-field">
            <span className="ac-label">
              IRIS ID{" "}
              {!iris_enabled && <span className="ac-optional">(coming soon)</span>}
            </span>
            <input
              type="text"
              className="ac-control"
              value={values.irisId}
              onChange={set("irisId")}
              placeholder="Enter Iris ID"
              // No IRIS API exists yet — rendered per the design, inert until it does.
              disabled={answered || !iris_enabled}
            />
          </label>
        </div>

        <div className="ac-grid" style={{ marginTop: 16 }}>
          <label className="ac-field">
            <span className="ac-label">
              Reason For Change
              {isAutofilled("reason") && <span className="ac-badge">Auto-filled</span>}
            </span>
            <input
              type="text"
              className="ac-control"
              value={values.reasonForChange}
              onChange={set("reasonForChange")}
              placeholder="Enter Reason"
              disabled={answered}
            />
          </label>

          <label className="ac-field">
            <span className="ac-label">
              Description For Change
              {isAutofilled("description") && <span className="ac-badge">Auto-filled</span>}
            </span>
            <input
              type="text"
              className="ac-control"
              value={values.descriptionOfChange}
              onChange={set("descriptionOfChange")}
              placeholder="Enter Description"
              disabled={answered}
            />
          </label>
        </div>

        <div className="ac-actions-row">
          <span className="ac-fill-status">
            {filledCount === 0
              ? "No Fields Filled"
              : `${filledCount} of ${totalCount} fields filled`}
          </span>
          <div className="ac-actions">
            <button
              type="button"
              className="ac-btn ac-btn-ghost"
              onClick={reset}
              disabled={answered}
            >
              Cancel
            </button>
            <button type="submit" className="ac-btn ac-btn-primary" disabled={!canSubmit}>
              Submit
            </button>
          </div>
        </div>
      </form>
    </CardShell>
  );
}
