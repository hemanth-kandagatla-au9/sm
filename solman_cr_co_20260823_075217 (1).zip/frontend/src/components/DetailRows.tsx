import type { DetailRow } from "../agent-ui/types";

/**
 * Shared renderer for expansion panels.
 *
 * Both the CR picker and the draft review expand rows into label/value lists, so
 * the two use the same markup — an expanded CR and an expanded field should not
 * look like they came from different applications.
 *
 * `tone` is set by the agent, never inferred here. A "positive" Platform row on a
 * CR recommendation means the agent matched it against the user's platform; the
 * frontend has no business deciding that on its own.
 */
export default function DetailRows({ rows }: { rows: DetailRow[] }) {
  if (!rows || rows.length === 0) return null;
  return (
    <div className="ac-details">
      {rows.map((r, i) => (
        <div className={`ac-detail${r.wide ? " ac-detail-wide" : ""}`} key={`${r.label}-${i}`}>
          <span className="ac-detail-label">{r.label}</span>
          <span
            className={`ac-detail-value${
              r.tone && r.tone !== "neutral" ? ` ac-tone-${r.tone}` : ""
            }`}
          >
            {r.tone === "positive" && (
              <span className="ac-tone-dot" aria-label="match" title="Matches your input" />
            )}
            {r.value || "—"}
          </span>
        </div>
      ))}
    </div>
  );
}
