import type { ReactNode } from "react";
import type { CardMeta } from "../agent-ui/types";

/**
 * Shared chrome for every agent card: bordered surface, title row, optional
 * reset affordance, and the meta footer (timestamp + processing/token/cost
 * pills) that the agent supplies via `meta`.
 *
 * The footer only renders when the agent actually sent meta, so cards do not
 * show an empty strip during local development.
 */

export function CardMetaBar({ meta }: { meta?: CardMeta | null }) {
  if (!meta) return null;
  const { timestamp, processing_time, tokens, cost } = meta;
  const hasPills =
    processing_time != null || tokens != null || cost != null;
  if (!timestamp && !hasPills) return null;

  return (
    <div className="ac-meta">
      <span className="ac-meta-time">{timestamp ?? ""}</span>
      {hasPills && (
        <span className="ac-meta-pills">
          {processing_time != null && (
            <span className="ac-pill">
              <span className="ac-pill-label">Processing Time: </span>
              {processing_time}
            </span>
          )}
          {tokens != null && (
            <span className="ac-pill">
              <span className="ac-pill-label">Token: </span>
              {tokens}
            </span>
          )}
          {cost != null && (
            <span className="ac-pill">
              <span className="ac-pill-label">Cost: </span>
              {cost}
            </span>
          )}
        </span>
      )}
    </div>
  );
}

interface CardShellProps {
  title?: string | null;
  subtitle?: string | null;
  /** Right-hand action in the title row, e.g. "Reset Form". */
  headerAction?: ReactNode;
  meta?: CardMeta | null;
  wide?: boolean;
  children: ReactNode;
}

export function CardShell({
  title,
  subtitle,
  headerAction,
  meta,
  wide,
  children,
}: CardShellProps) {
  return (
    <div className={wide ? "ac-card ac-card-wide" : "ac-card"}>
      <div className="ac-card-body">
        {(title || headerAction) && (
          <div className="ac-card-head">
            {title ? <h2 className="ac-card-title">{title}</h2> : <span />}
            {headerAction}
          </div>
        )}
        {subtitle && <p className="ac-card-subtitle">{subtitle}</p>}
        {children}
      </div>
      <CardMetaBar meta={meta} />
    </div>
  );
}

export function Chevron({ className }: { className?: string }) {
  return (
    <svg
      className={className}
      width="12"
      height="8"
      viewBox="0 0 12 8"
      fill="none"
      aria-hidden
    >
      <path
        d="M1 1.5 6 6.5 11 1.5"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export default CardShell;
