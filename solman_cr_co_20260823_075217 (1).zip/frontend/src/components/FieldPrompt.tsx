import { useState } from "react";
import CardShell from "./CardShell";
import type { AgentComponentHandlers, FieldPromptProps } from "../agent-ui/types";

/**
 * Registered component: "fieldPrompt"
 *
 * The generic ask-the-user card, used wherever the graph needs a value it does
 * not have a bespoke screen for (missing platform, ambiguous target system,
 * disambiguation follow-ups).
 *
 * Options and free text are both offered when the agent allows it: the option
 * list is frequently a top-N shortlist rather than the full set, so forcing a
 * choice would strand users whose real answer is not on it.
 */
export default function FieldPrompt({
  props,
  handlers,
}: {
  props: FieldPromptProps;
  handlers: AgentComponentHandlers;
}) {
  const { title, message, options, allow_free_text, placeholder, meta } = props;
  const { respond, answered } = handlers;
  const [text, setText] = useState("");

  const send = (value: string) => {
    const trimmed = value.trim();
    if (answered || !trimmed) return;
    respond(trimmed);
  };

  return (
    <CardShell title={title} meta={meta} wide>
      <p className="ac-prompt-msg">{message}</p>

      {options.length > 0 && (
        <div className="ac-option-grid">
          {options.map((opt) => (
            <button
              key={opt.value}
              type="button"
              title={opt.label}
              className="ac-option-btn"
              disabled={answered || opt.disabled}
              onClick={() => send(opt.value)}
            >
              {opt.label}
            </button>
          ))}
        </div>
      )}

      {allow_free_text !== false && (
        <form
          className="ac-reply"
          onSubmit={(e) => {
            e.preventDefault();
            send(text);
          }}
        >
          <input
            className="ac-control"
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder={placeholder ?? "Type your reply…"}
            disabled={answered}
          />
          <button
            type="submit"
            className="ac-btn ac-btn-primary"
            disabled={answered || !text.trim()}
          >
            Send
          </button>
        </form>
      )}
    </CardShell>
  );
}
