import { useState } from "react";
import CardShell from "./CardShell";
import type { AgentComponentHandlers, CrModeChoiceProps } from "../agent-ui/types";

/**
 * Registered component: "crModeChoice"
 *
 * Opening screen — Single vs Bulk change request.
 *
 * Note the Bulk tile is deliberately NOT blocked client-side. It stays clickable
 * and calls respond("bulk"); the backend answers with the `featureComingSoon`
 * card. That keeps the "feature available soon" decision on the server, so when
 * bulk actually ships nothing in this component changes.
 */
export default function CrModeChoice({
  props,
  handlers,
}: {
  props: CrModeChoiceProps;
  handlers: AgentComponentHandlers;
}) {
  const { title, subtitle, modes, meta } = props;
  const { respond, answered } = handlers;
  const [selected, setSelected] = useState<string | null>(null);

  const choose = (value: string) => {
    if (answered) return;
    setSelected(value);
    respond(value);
  };

  return (
    <CardShell title={title} subtitle={subtitle} meta={meta}>
      <div className="ac-mode-grid">
        {modes.map((mode) => {
          const comingSoon = mode.enabled === false;
          return (
            <button
              key={mode.value}
              type="button"
              onClick={() => choose(mode.value)}
              disabled={answered}
              className={`ac-mode-tile${selected === mode.value ? " ac-selected" : ""}`}
            >
              <span className="ac-mode-label">
                {mode.label}
                {comingSoon && <span className="ac-soon-tag">Soon</span>}
              </span>
              {mode.description && (
                <span className="ac-mode-desc">{mode.description}</span>
              )}
            </button>
          );
        })}
      </div>
    </CardShell>
  );
}
