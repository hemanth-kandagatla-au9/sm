import { useMemo, useState } from "react";
import CardShell, { Chevron } from "./CardShell";
import type { AgentComponentHandlers, DraftReviewProps, FieldRow } from "../agent-ui/types";

/**
 * Registered component: "draftReview"
 *
 * Screen 4 — the approval checkpoint. This is the card the user's approval is
 * recorded against, so two rules apply:
 *
 *   1. Every value that will be submitted is reachable here. Sections collapse
 *      for scanning, but nothing is hidden — expanding a section shows its
 *      fields, and expanding a field shows why it holds that value and what it
 *      will accept.
 *   2. The action buttons emit the literal tokens the graph routes on
 *      (`approve` / `reject`), never free text. cond_edge_b's approval guard is
 *      a substring test, and typed prose is exactly what trips it.
 *
 * Two levels of disclosure:
 *
 *   section  →  field list (label + value, empty values marked)
 *   field    →  edit rules: type, accepted values, section, lock reason
 *
 * The field level matters on a regulated form. A locked field that simply
 * refuses to change, with no stated reason, reads as a bug; showing
 * `lock_reason` turns it into a visible control. The accepted-values list is the
 * same set node_10 validates edits against, so what the user reads here is the
 * ruleset that will actually accept or reject their change.
 */

function lockLabel(f: FieldRow): string | null {
  if (f.lock_type) return f.lock_type.replace(/_/g, " ");
  if (f.editable === false) return "locked";
  return null;
}

function FieldEntry({ field }: { field: FieldRow }) {
  const [open, setOpen] = useState(false);

  const lock = lockLabel(field);
  const allowed = field.allowed_values ?? [];
  // Only offer a disclosure when there is something behind it.
  const hasDetail = !!(field.lock_reason || allowed.length > 0 || field.field_type || field.section);

  return (
    <div className={`ac-field-entry${open ? " ac-open" : ""}`}>
      <div className="ac-kv">
        <span className="ac-kv-label">
          {hasDetail ? (
            <button
              type="button"
              className="ac-kv-toggle"
              onClick={() => setOpen(!open)}
              aria-expanded={open}
              title={open ? "Hide field details" : "Show field details"}
            >
              <Chevron className={`ac-kv-chev${open ? " ac-rot" : ""}`} />
              <span>{field.label}</span>
            </button>
          ) : (
            <span className="ac-kv-toggle ac-kv-static">{field.label}</span>
          )}
          {lock && (
            <span className="ac-lock" title={field.lock_reason || lock}>
              {lock}
            </span>
          )}
        </span>
        <span className={`ac-kv-value${field.empty || !field.value ? " ac-empty" : ""}`}>
          {field.value || "Not set"}
        </span>
      </div>

      {open && hasDetail && (
        <div className="ac-field-detail">
          {field.field_type && (
            <div className="ac-detail">
              <span className="ac-detail-label">Field type</span>
              <span className="ac-detail-value">{field.field_type}</span>
            </div>
          )}
          {field.section && (
            <div className="ac-detail">
              <span className="ac-detail-label">Section</span>
              <span className="ac-detail-value">{field.section}</span>
            </div>
          )}
          {field.key && (
            <div className="ac-detail">
              <span className="ac-detail-label">SolMan field</span>
              <span className="ac-detail-value ac-mono">{field.key}</span>
            </div>
          )}
          {allowed.length > 0 && (
            <div className="ac-detail ac-detail-wide">
              <span className="ac-detail-label">Accepted values</span>
              <span className="ac-detail-value">
                <span className="ac-chips">
                  {allowed.map((v) => (
                    <span
                      key={v}
                      className={`ac-chip${
                        v.toLowerCase() === field.value.trim().toLowerCase()
                          ? " ac-chip-active"
                          : ""
                      }`}
                    >
                      {v}
                    </span>
                  ))}
                </span>
              </span>
            </div>
          )}
          {field.lock_reason && (
            <div className="ac-detail ac-detail-wide">
              <span className="ac-detail-label">Why locked</span>
              <span className="ac-detail-value">{field.lock_reason}</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function SectionAccordion({
  name,
  fields,
  open,
  onToggle,
}: {
  name: string;
  fields: FieldRow[];
  open: boolean;
  onToggle: () => void;
}) {
  const filled = useMemo(
    () => fields.filter((f) => !!(f.value || "").trim()).length,
    [fields]
  );

  return (
    <div className={`ac-accordion${open ? " ac-open" : ""}`}>
      <button type="button" className="ac-accordion-head" onClick={onToggle} aria-expanded={open}>
        <span>{name}</span>
        <span className="ac-accordion-right">
          <span className="ac-count">
            {filled}/{fields.length}
          </span>
          <Chevron className="ac-accordion-chev" />
        </span>
      </button>
      {open && (
        <div className="ac-accordion-body">
          {fields.length === 0 ? (
            <div className="ac-kv">
              <span className="ac-kv-value ac-empty">No fields in this section.</span>
            </div>
          ) : (
            fields.map((f) => <FieldEntry key={f.key || f.label} field={f} />)
          )}
        </div>
      )}
    </div>
  );
}

export default function DraftReviewCard({
  props,
  handlers,
}: {
  props: DraftReviewProps;
  handlers: AgentComponentHandlers;
}) {
  const {
    title,
    subtitle,
    sections,
    confirm_text,
    question_text,
    notices,
    actions,
    meta,
  } = props;
  const { respond, answered } = handlers;
  const [openSection, setOpenSection] = useState<string | null>(null);
  const [allOpen, setAllOpen] = useState(false);

  const buttonClass = (value: string) => {
    if (value === "approve") return "ac-btn ac-btn-soft";
    if (value === "submit_for_approval") return "ac-btn ac-btn-primary";
    return "ac-btn ac-btn-ghost";
  };

  const toggleAll = () => {
    setAllOpen(!allOpen);
    setOpenSection(null);
  };

  return (
    <CardShell
      title={title}
      subtitle={subtitle}
      meta={meta}
      wide
      headerAction={
        <button type="button" className="ac-reset" onClick={toggleAll}>
          {allOpen ? "Collapse all" : "Expand all"}
        </button>
      }
    >
      {notices && notices.length > 0 && (
        <div className="ac-notices">
          {notices.map((n, i) => (
            <div className="ac-notice" key={i}>
              {n}
            </div>
          ))}
        </div>
      )}

      <div className="ac-accordion-grid">
        {sections.map((s) => (
          <SectionAccordion
            key={s.name}
            name={s.name}
            fields={s.fields}
            open={allOpen || openSection === s.name}
            onToggle={() => {
              if (allOpen) {
                // Leaving expand-all: keep the one they clicked open.
                setAllOpen(false);
                setOpenSection(s.name);
                return;
              }
              setOpenSection(openSection === s.name ? null : s.name);
            }}
          />
        ))}
      </div>

      {confirm_text && <p className="ac-confirm">{confirm_text}</p>}
      {question_text && <p className="ac-question">{question_text}</p>}

      <div className="ac-actions-row">
        <div className="ac-actions">
          {actions.map((a) => (
            <button
              key={a.value}
              type="button"
              className={buttonClass(a.value)}
              disabled={answered || a.disabled}
              onClick={() => respond(a.value)}
            >
              {a.label}
            </button>
          ))}
        </div>
      </div>
    </CardShell>
  );
}
