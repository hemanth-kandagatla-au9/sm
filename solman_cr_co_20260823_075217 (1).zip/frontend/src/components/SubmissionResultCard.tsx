import CardShell from "./CardShell";
import type { AgentComponentHandlers, SubmissionResultProps } from "../agent-ui/types";

/**
 * Registered component: "submissionResult"
 *
 * Terminal card after a SolMan write.
 *
 * A `success` status with no cr_id is rendered as an error, not a success:
 * solman_write can return success:true with cr_id null when none of the
 * EvObjectID lookups hit, and telling a user their CR was created while having
 * no identifier to reconcile it against is worse than telling them to check.
 */
export default function SubmissionResultCard({
  props,
  handlers,
}: {
  props: SubmissionResultProps;
  handlers: AgentComponentHandlers;
}) {
  const { status, message, cr_id, meta } = props;
  const { respond, answered } = handlers;

  const missingId = status === "success" && !cr_id;
  const ok = status === "success" && !missingId;

  return (
    <CardShell meta={meta}>
      <div className="ac-state">
        <div className={`ac-state-icon ${ok ? "ac-ok" : "ac-bad"}`} aria-hidden>
          {ok ? "✓" : "!"}
        </div>
        <div className="ac-state-title">
          {ok
            ? "Submitted Successfully"
            : missingId
              ? "Submitted — but no CR ID was returned"
              : "Submission Failed"}
        </div>
        <p className="ac-state-msg">
          {missingId
            ? "SolMan accepted the request but did not return a Change Request ID, so this submission cannot be reconciled automatically. Please verify in SolMan before retrying — retrying may create a duplicate."
            : message}
        </p>
        {cr_id && <div className="ac-cr-chip">CR ID {cr_id}</div>}

        {!ok && (
          <button
            type="button"
            className="ac-btn ac-btn-ghost"
            style={{ marginTop: 6 }}
            disabled={answered}
            onClick={() => respond("start over")}
          >
            Start a new request
          </button>
        )}
      </div>
    </CardShell>
  );
}
