import { useState } from "react";
import CardShell from "./CardShell";
import type { AgentComponentHandlers, CycleIdPickerProps } from "../agent-ui/types";

/**
 * Registered component: "cycleIdPicker"
 *
 * Screen 3 — deployment cycle selection.
 *
 * The agent sends the intro sentence only; the option grid is this card's job.
 * (node_20 also composes a markdown table of the same options for the chat
 * transcript — ui_contract.cycle_id_picker deliberately strips it so the user
 * does not see the same list twice in two formats.)
 *
 * The "keep current" option, when present, is separated onto its own full-width
 * row: it is a different kind of answer from picking a specific cycle, and
 * mixing it into the grid makes it easy to hit by accident.
 */
export default function CycleIdPicker({
  props,
  handlers,
}: {
  props: CycleIdPickerProps;
  handlers: AgentComponentHandlers;
}) {
  const { message, options, draft_cycle_id, keep_current_label, meta } = props;
  const { respond, answered } = handlers;
  const [selected, setSelected] = useState<string | null>(null);

  const choose = (value: string) => {
    if (answered) return;
    setSelected(value);
    respond(value);
  };

  const keepOption = keep_current_label
    ? options.find((o) => o.label === keep_current_label)
    : undefined;
  const cycleOptions = options.filter((o) => o !== keepOption);

  return (
    <CardShell meta={meta} wide>
      <p className="ac-prompt-msg">{message}</p>

      {draft_cycle_id && (
        <p className="ac-card-subtitle" style={{ margin: "10px 0 0" }}>
          Draft cycle: <strong>{draft_cycle_id}</strong>
        </p>
      )}

      <div className="ac-option-grid">
        {cycleOptions.map((opt) => (
          <button
            key={opt.value}
            type="button"
            title={opt.label}
            className={`ac-option-btn${selected === opt.value ? " ac-selected" : ""}`}
            disabled={answered || opt.disabled}
            onClick={() => choose(opt.value)}
          >
            {opt.label}
          </button>
        ))}

        {keepOption && (
          <button
            key={keepOption.value}
            type="button"
            className={`ac-option-btn ac-option-keep${
              selected === keepOption.value ? " ac-selected" : ""
            }`}
            disabled={answered}
            onClick={() => choose(keepOption.value)}
          >
            {keepOption.label}
          </button>
        )}
      </div>
    </CardShell>
  );
}
