import { useEffect, useState } from "react";
import CardShell, { Chevron } from "./CardShell";
import DetailRows from "./DetailRows";
import { API_BASE_URL } from "../agent-ui/config";
import type {
  AgentComponentHandlers,
  AgentOption,
  TemplateOrCrPickerProps,
} from "../agent-ui/types";

/**
 * Registered component: "templateOrCrPicker"
 *
 * Screen 2 — pick a Template ID, or a reference Change Request to base the draft
 * on. The two are mutually exclusive: choosing one clears the other, because the
 * graph treats template_id and cr_id as competing baselines (cr_id wins if both
 * are set, which would silently discard the user's template choice).
 *
 * Each reference CR expands to its own data — similarity score, platform, target
 * system, change cycle, description — so the user can inspect a candidate before
 * committing to it. Expanding and selecting are separate actions: the chevron
 * toggles the panel, the row body selects. Picking a baseline CR determines every
 * field of the resulting draft, so it should not be possible to select one as a
 * side effect of trying to read it.
 *
 * `details` is supplied by the agent (ui_contract.reference_options_from_baseline).
 * A row without details renders no disclosure control at all.
 */

function ReferenceRow({
  option,
  selected,
  expanded,
  disabled,
  onSelect,
  onToggle,
}: {
  option: AgentOption;
  selected: boolean;
  expanded: boolean;
  disabled: boolean;
  onSelect: () => void;
  onToggle: () => void;
}) {
  const hasDetails = !!option.details && option.details.length > 0;
  const isOpen = hasDetails && expanded;

  return (
    <div
      className={`ac-ref-card${selected ? " ac-selected" : ""}${
        isOpen ? " ac-expanded" : ""
      }`}
    >
      <div className="ac-ref-head">
        <label className="ac-ref-select">
          <input
            type="radio"
            name="reference-cr"
            value={option.value}
            checked={selected}
            onChange={onSelect}
            disabled={disabled || option.disabled}
          />
          <span className="ac-radio-label" title={option.label}>
            {option.label}
          </span>
        </label>

        {option.badge && <span className="ac-radio-badge">{option.badge}</span>}

        {hasDetails && (
          <button
            type="button"
            className="ac-disclose"
            onClick={onToggle}
            aria-expanded={expanded}
            aria-label={expanded ? "Hide details" : "Show details"}
            title={expanded ? "Hide details" : "Show details"}
          >
            <Chevron className={`ac-accordion-chev${expanded ? " ac-rot" : ""}`} />
          </button>
        )}
      </div>

      {isOpen && (
        <div className="ac-ref-body">
          <DetailRows rows={option.details!} />
        </div>
      )}
    </div>
  );
}

export default function TemplateOrCrPicker({
  props,
  handlers,
}: {
  props: TemplateOrCrPickerProps;
  handlers: AgentComponentHandlers;
}) {
  const {
    title,
    subtitle,
    template_label,
    template_optional,
    template_options,
    reference_label,
    reference_options,
    selected_template,
    selected_reference,
    meta,
  } = props;
  const { respond, answered } = handlers;

  const [template, setTemplate] = useState(selected_template ?? "");
  const [reference, setReference] = useState(selected_reference ?? "");
  const [expanded, setExpanded] = useState<string | null>(null);
  const [templates, setTemplates] = useState<string[]>(template_options ?? []);

  // The agent sends an empty list when it has not preloaded templates (the graph
  // has no cheap way to enumerate them mid-run) — fetch them here instead.
  useEffect(() => {
    if (template_options && template_options.length > 0) {
      setTemplates(template_options);
      return;
    }
    let cancelled = false;
    fetch(`${API_BASE_URL}/api/templates`)
      .then((r) => (r.ok ? r.json() : { templates: [] }))
      .then((d) => {
        if (!cancelled) setTemplates(d.templates || []);
      })
      .catch(() => {
        if (!cancelled) setTemplates([]);
      });
    return () => {
      cancelled = true;
    };
  }, [template_options]);

  const chooseTemplate = (value: string) => {
    setTemplate(value);
    if (value) setReference(""); // mutually exclusive — see docstring
  };

  const chooseReference = (value: string) => {
    setReference(value);
    if (value) setTemplate("");
  };

  const selection = template || reference;

  return (
    <CardShell title={title} subtitle={subtitle} meta={meta} wide>
      <label className="ac-field">
        <span className="ac-label">
          {template_label ?? "Template ID"}{" "}
          {template_optional && <span className="ac-optional">(Optional)</span>}
        </span>
        <select
          className="ac-control"
          value={template}
          onChange={(e) => chooseTemplate(e.target.value)}
          disabled={answered}
        >
          <option value="">Select Template ID</option>
          {templates.map((t) => (
            <option key={t} value={t}>
              {t}
            </option>
          ))}
        </select>
      </label>

      {reference_options.length > 0 && (
        <>
          <div className="ac-divider">OR</div>

          <span className="ac-label">{reference_label ?? "Reference Change Request ID"}</span>
          <div className="ac-ref-grid">
            {reference_options.map((opt) => (
              <ReferenceRow
                key={opt.value}
                option={opt}
                selected={reference === opt.value}
                expanded={expanded === opt.value}
                disabled={answered}
                onSelect={() => chooseReference(opt.value)}
                onToggle={() => setExpanded(expanded === opt.value ? null : opt.value)}
              />
            ))}
          </div>
        </>
      )}

      <div className="ac-actions-row">
        <span className="ac-fill-status">
          {selection ? `Selected: ${selection}` : "Nothing selected"}
        </span>
        <div className="ac-actions">
          <button
            type="button"
            className="ac-btn ac-btn-primary"
            disabled={answered || !selection}
            onClick={() => respond(selection)}
          >
            Continue
          </button>
        </div>
      </div>
    </CardShell>
  );
}
