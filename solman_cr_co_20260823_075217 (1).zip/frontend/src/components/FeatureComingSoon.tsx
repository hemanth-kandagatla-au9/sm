import CardShell from "./CardShell";
import type { AgentComponentHandlers, FeatureComingSoonProps } from "../agent-ui/types";

/**
 * Registered component: "featureComingSoon"
 *
 * Generic not-yet-available card. Currently reached by choosing Bulk CR, but it
 * carries no bulk-specific content — any future gated feature can render it by
 * name with its own title/message.
 */
export default function FeatureComingSoon({
  props,
  handlers,
}: {
  props: FeatureComingSoonProps;
  handlers: AgentComponentHandlers;
}) {
  const { title, message, back_label, meta } = props;
  const { respond, answered } = handlers;

  return (
    <CardShell meta={meta}>
      <div className="ac-state">
        <div className="ac-state-icon" aria-hidden>
          🚧
        </div>
        <div className="ac-state-title">{title}</div>
        <p className="ac-state-msg">{message}</p>
        {back_label && (
          <button
            type="button"
            className="ac-btn ac-btn-ghost"
            style={{ marginTop: 6 }}
            disabled={answered}
            onClick={() => respond("single")}
          >
            {back_label}
          </button>
        )}
      </div>
    </CardShell>
  );
}
