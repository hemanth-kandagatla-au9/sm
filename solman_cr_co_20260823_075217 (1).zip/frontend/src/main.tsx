import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// No StrictMode: CopilotKit's SSE/interrupt subscriptions aren't idempotent,
// so dev-mode double-invoking effects duplicated prompts and caused scroll jumps.
createRoot(document.getElementById("root")!).render(<App />);
