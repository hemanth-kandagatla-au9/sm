/// <reference types="vite/client" />

declare module "@copilotkit/react-ui/styles.css";
