import { useEffect, useRef, useState } from "react";
import { useLangGraphInterrupt } from "@copilotkit/react-core";

/**
 * agent-ui/useHitlInterrupt.tsx
 *
 * Bridges every LangGraph `interrupt()` to a single resume channel.
 *
 * This hook used to render a card itself and sniff agent state to work out which
 * screen belonged to which interrupt. It does neither now: the backend names the
 * component via AgentState.ui_component and AgentComponentHost renders it. All
 * this hook does is expose the pending prompt (so the UI knows the graph is
 * actually waiting) and the resolve function.
 *
 * `resolve` must be used instead of appendMessage — appendMessage starts a NEW
 * run, whereas the graph is blocked waiting on the Command(resume=...) that only
 * this interrupt's resolve delivers.
 *
 * The ref-then-effect dance is deliberate. CopilotKit's transport reconnects
 * occasionally (same thread, new runId) while an interrupt is pending, which
 * briefly clears and re-delivers the same interrupt. Committing render() output
 * straight to state made the card flicker and the chat jump-scroll on every
 * reconnect; capturing into a ref and committing via an effect keeps it stable.
 */
export function useHitlInterrupt(agentId: string): {
  prompt: string | null;
  /**
   * The interrupt's raw value. Every node in this graph calls `interrupt(ui)`
   * with the ui_component object itself, so this IS the component to render —
   * needed because a reconnect to an already-pending interrupt never gets a
   * STATE_SNAPSHOT (see ag_ui_langgraph prepare_stream's early-return path),
   * so state.ui_component alone is not a reliable render source.
   */
  component: unknown;
  resolve: (value: string) => void;
} {
  const latestRef = useRef<{ prompt: string; component: unknown; resolve: (v: string) => void } | null>(null);
  const [current, setCurrent] = useState<{
    prompt: string;
    component: unknown;
    resolve: (v: string) => void;
  } | null>(null);

  useLangGraphInterrupt<string>({
    agentId,
    render: ({ event, resolve }) => {
      const raw = event.value;
      console.log("[gateway] useHitlInterrupt received on_interrupt event, raw value:", raw);
      latestRef.current = {
        prompt: typeof raw === "string" ? raw : JSON.stringify(raw),
        component: raw,
        resolve,
      };
      // Rendering is AgentComponentHost's job — this hook contributes no DOM.
      return <></>;
    },
  });

  useEffect(() => {
    setCurrent(latestRef.current);
  });

  const resolve = (value: string) => {
    const trimmed = value.trim();
    if (!current || !trimmed) return;
    current.resolve(trimmed);
    setCurrent(null);
    latestRef.current = null;
  };

  return { prompt: current?.prompt ?? null, component: current?.component ?? null, resolve };
}

export default useHitlInterrupt;
