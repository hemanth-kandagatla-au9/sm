/**
 * agent-ui/config.ts
 *
 * Endpoints. Both are overridable at build time so the platform team can point
 * the cards at their own hosts without touching component code.
 *
 *   VITE_AGUI_API_BASE     → FastAPI host (agui_server.py) for /api/* helpers
 *   VITE_AGUI_RUNTIME_URL  → CopilotKit runtime bridge for the AG-UI event stream
 */

export const API_BASE_URL: string =
  (import.meta.env?.VITE_AGUI_API_BASE as string | undefined) ?? "http://localhost:8084";

export const AGUI_RUNTIME_URL: string =
  (import.meta.env?.VITE_AGUI_RUNTIME_URL as string | undefined) ??
  "http://localhost:8006/api/copilotkit";

export const AGUI_AGENT_NAME = "local_agent";
