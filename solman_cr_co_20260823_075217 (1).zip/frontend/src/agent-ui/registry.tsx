/**
 * agent-ui/registry.tsx
 *
 * ── THE REGISTRY ──────────────────────────────────────────────────────────────
 * This is the file the platform team owns and merges into their app.
 *
 * The agent never ships UI. It names one of these components and supplies props.
 * Anything not in this map cannot be rendered — which is the whole point: the
 * host app decides what the agent is allowed to put on screen.
 *
 * To add a component:
 *   1. Add the name + prop schema in agui/ui_contract.py (backend)
 *   2. Add the props interface in ./types.ts
 *   3. Add the component here
 * All three must agree. `assertRegistryMatchesContract()` below checks 1↔3 at
 * runtime in dev against GET /api/ui-contract, so drift surfaces immediately
 * instead of as a blank card in QA.
 */
import type { ComponentType } from "react";

import CrModeChoice from "../components/CrModeChoice";
import FeatureComingSoon from "../components/FeatureComingSoon";
import CrIntakeForm from "../components/CrIntakeForm";
import TemplateOrCrPicker from "../components/TemplateOrCrPicker";
import CycleIdPicker from "../components/CycleIdPicker";
import DraftReviewCard from "../components/DraftReviewCard";
import FieldPrompt from "../components/FieldPrompt";
import SubmissionResultCard from "../components/SubmissionResultCard";

import type { AgentComponentHandlers, AgentComponentName } from "./types";

/**
 * Every registered component takes the same two-prop shape: its typed `props`
 * from the agent, and `handlers` for talking back. Props are validated at the
 * contract boundary, so components receive them already-typed.
 */
export type RegisteredComponent = ComponentType<{
  // Intentionally `any` at the registry boundary only — each component narrows
  // it to its own typed props interface. Keeping the map homogeneous is what
  // lets the host look a component up by a runtime string.
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  props: any;
  handlers: AgentComponentHandlers;
}>;

export const COMPONENT_REGISTRY: Record<AgentComponentName, RegisteredComponent> = {
  crModeChoice: CrModeChoice,
  featureComingSoon: FeatureComingSoon,
  crIntakeForm: CrIntakeForm,
  templateOrCrPicker: TemplateOrCrPicker,
  cycleIdPicker: CycleIdPicker,
  draftReview: DraftReviewCard,
  fieldPrompt: FieldPrompt,
  submissionResult: SubmissionResultCard,
};

export const REGISTERED_NAMES = Object.keys(COMPONENT_REGISTRY) as AgentComponentName[];

export function isRegistered(name: string): name is AgentComponentName {
  return Object.prototype.hasOwnProperty.call(COMPONENT_REGISTRY, name);
}

/**
 * Dev-time drift check. Fetches the backend contract and logs any component the
 * agent can emit but this app cannot render (and vice versa). Cheap insurance
 * against the two sides being deployed out of step.
 */
export async function assertRegistryMatchesContract(apiBaseUrl: string): Promise<void> {
  try {
    const res = await fetch(`${apiBaseUrl}/api/ui-contract`);
    if (!res.ok) return;
    const doc = await res.json();
    const backendNames: string[] = Object.keys(doc.components ?? {});

    const missingHere = backendNames.filter((n) => !isRegistered(n));
    const missingThere = REGISTERED_NAMES.filter((n) => !backendNames.includes(n));

    if (missingHere.length) {
      console.error(
        "[agent-ui] Agent can emit components this app cannot render:",
        missingHere,
        "— these will render the fallback card."
      );
    }
    if (missingThere.length) {
      console.warn(
        "[agent-ui] Registered components the agent never emits (dead registrations):",
        missingThere
      );
    }
    if (!missingHere.length && !missingThere.length) {
      console.info(
        `[agent-ui] Registry matches contract v${doc.contract_version} (${backendNames.length} components).`
      );
    }
  } catch {
    // Contract endpoint unreachable — not fatal, the fallback card still covers us.
  }
}
