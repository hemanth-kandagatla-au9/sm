/**
 * agent-ui/types.ts
 *
 * TypeScript mirror of agui/ui_contract.py. These types ARE the contract as far
 * as the frontend is concerned — if the backend adds a component or changes a
 * prop, it changes here first and the compiler finds every render site.
 *
 * Keep CONTRACT_VERSION in sync with ui_contract.CONTRACT_VERSION. The host
 * renders a fallback (not a crash) on a version it does not recognise, so the
 * agent and this app can deploy independently.
 */

export const CONTRACT_VERSION = 1;

export interface CardMeta {
  timestamp?: string | null;
  processing_time?: string | null;
  tokens?: number | string | null;
  cost?: string | null;
}

/**
 * One line inside an expanded panel. `tone` lets the agent mark a row as a
 * positive/negative signal (e.g. "Platform match") without the frontend having
 * to interpret the value itself.
 */
export interface DetailRow {
  label: string;
  value: string;
  tone?: "neutral" | "positive" | "negative" | null;
  /** Render full-width — for long free text like a CR description. */
  wide?: boolean;
}

export interface AgentOption {
  label: string;
  value: string;
  /** Right-aligned pill, e.g. the platform name ("Galaxy") on a CR row. */
  badge?: string | null;
  disabled?: boolean;
  /**
   * Present → the row is expandable and shows these when opened.
   * Absent/empty → no disclosure control is rendered at all.
   */
  details?: DetailRow[] | null;
}

export type FieldType = "text" | "boolean" | "dropdown";

export interface FieldRow {
  key: string;
  label: string;
  /** Display value, exactly as it will be submitted. */
  value: string;
  editable?: boolean;
  /** system_readonly | compliance_locked | session_locked */
  lock_type?: string | null;

  /* ── expansion payload (all optional) ─────────────────────────────────── */
  field_type?: FieldType | null;
  /** For dropdown/boolean fields — the values SolMan will accept. */
  allowed_values?: string[] | null;
  section?: string | null;
  /** Human-readable reason the field is locked. */
  lock_reason?: string | null;
  /** True when no value will be submitted for this field. */
  empty?: boolean;
}

/* ── Per-component props ──────────────────────────────────────────────────── */

export interface CrModeChoiceProps {
  title: string;
  subtitle?: string | null;
  modes: {
    value: "single" | "bulk";
    label: string;
    description?: string | null;
    enabled?: boolean;
  }[];
  meta?: CardMeta | null;
}

export interface FeatureComingSoonProps {
  title: string;
  message: string;
  back_label?: string | null;
  meta?: CardMeta | null;
}

export interface CrIntakeFormValues {
  platform?: string | null;
  target_system?: string | null;
  jira_id?: string | null;
  iris_id?: string | null;
  reason_for_change?: string | null;
  description_of_change?: string | null;
}

export interface CrIntakeFormProps {
  title: string;
  subtitle?: string | null;
  hint?: string | null;
  platforms: string[];
  target_systems?: string[] | null;
  values?: CrIntakeFormValues | null;
  errors?: Record<string, string> | null;
  /** IRIS has no backing API yet — the field renders but stays inert. */
  iris_enabled?: boolean;
  meta?: CardMeta | null;
}

export interface TemplateOrCrPickerProps {
  title: string;
  subtitle?: string | null;
  template_label?: string | null;
  template_optional?: boolean;
  template_options: string[];
  reference_label?: string | null;
  reference_options: AgentOption[];
  selected_template?: string | null;
  selected_reference?: string | null;
  meta?: CardMeta | null;
}

export interface CycleIdPickerProps {
  message: string;
  options: AgentOption[];
  draft_cycle_id?: string | null;
  keep_current_label?: string | null;
  meta?: CardMeta | null;
}

export interface DraftReviewProps {
  title: string;
  subtitle?: string | null;
  sections: { name: string; fields: FieldRow[] }[];
  confirm_text?: string | null;
  question_text?: string | null;
  notices?: string[] | null;
  actions: AgentOption[];
  meta?: CardMeta | null;
}

export interface FieldPromptProps {
  title?: string | null;
  message: string;
  options: AgentOption[];
  allow_free_text?: boolean;
  placeholder?: string | null;
  meta?: CardMeta | null;
}

export interface SubmissionResultProps {
  status: "success" | "failed";
  message: string;
  cr_id?: string | null;
  meta?: CardMeta | null;
}

/* ── Discriminated union over the whole registry ──────────────────────────── */

export type AgentComponent =
  | { version: number; name: "crModeChoice"; props: CrModeChoiceProps }
  | { version: number; name: "featureComingSoon"; props: FeatureComingSoonProps }
  | { version: number; name: "crIntakeForm"; props: CrIntakeFormProps }
  | { version: number; name: "templateOrCrPicker"; props: TemplateOrCrPickerProps }
  | { version: number; name: "cycleIdPicker"; props: CycleIdPickerProps }
  | { version: number; name: "draftReview"; props: DraftReviewProps }
  | { version: number; name: "fieldPrompt"; props: FieldPromptProps }
  | { version: number; name: "submissionResult"; props: SubmissionResultProps };

export type AgentComponentName = AgentComponent["name"];

/**
 * Every registered component receives exactly this alongside its typed props.
 *
 * `respond` is the single channel back to the agent. For components rendered at
 * a LangGraph interrupt() it resumes the graph; for pre-graph cards the host
 * wires it to the relevant /api call. Components never know which — they just
 * call respond(value).
 */
export interface AgentComponentHandlers {
  respond: (value: string) => void;
  /** True once respond() has fired for this render — components disable their controls. */
  answered: boolean;
}
