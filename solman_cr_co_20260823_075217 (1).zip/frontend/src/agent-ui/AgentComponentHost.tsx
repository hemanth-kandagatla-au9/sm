import { useCallback, useMemo, useState } from "react";
import { COMPONENT_REGISTRY, isRegistered } from "./registry";
import { CONTRACT_VERSION } from "./types";
import type { AgentComponent, AgentComponentHandlers } from "./types";

/**
 * agent-ui/AgentComponentHost.tsx
 *
 * Renders whichever registered component the agent named.
 *
 * The host is deliberately thin — it resolves a name to a component, hands over
 * props and a `respond` channel, and does nothing else. All three failure modes
 * degrade to a visible fallback card rather than a blank screen or a crash:
 *
 *   • unknown component name  → the agent is ahead of this app's registry
 *   • unknown contract version → breaking prop change not deployed here yet
 *   • malformed envelope       → nothing to render
 *
 * That matters because this sits on a regulated approval path: a user must never
 * be left staring at an empty panel wondering whether their CR went through.
 */

interface AgentComponentHostProps {
  component: AgentComponent | null | undefined;
  /** Sends the user's answer back to the agent (resumes the graph, or calls the relevant API). */
  onRespond: (value: string) => void;
  /**
   * Changes whenever a new checkpoint begins. The host re-arms `answered` on
   * change, so a fresh card is interactive even though the previous one was
   * consumed. Without this, two consecutive fieldPrompts would leave the second
   * one disabled.
   */
  turnKey?: string;
}

export function AgentComponentHost({
  component,
  onRespond,
  turnKey,
}: AgentComponentHostProps) {
  const [answeredFor, setAnsweredFor] = useState<string | null>(null);

  console.log("[gateway] AgentComponentHost received component:", component, "turnKey:", turnKey);

  const currentKey = useMemo(
    () => `${turnKey ?? ""}::${component?.name ?? ""}`,
    [turnKey, component?.name]
  );

  const respond = useCallback(
    (value: string) => {
      if (answeredFor === currentKey) return; // guard double-submit
      setAnsweredFor(currentKey);
      onRespond(value);
    },
    [answeredFor, currentKey, onRespond]
  );

  const handlers: AgentComponentHandlers = useMemo(
    () => ({ respond, answered: answeredFor === currentKey }),
    [respond, answeredFor, currentKey]
  );

  if (!component || typeof component !== "object" || !component.name) {
    return null;
  }

  if (typeof component.version === "number" && component.version > CONTRACT_VERSION) {
    return (
      <div className="ac-fallback">
        This step needs a newer version of the interface (contract v
        {component.version}; this app supports v{CONTRACT_VERSION}). Please refresh, or
        contact support if it persists.
      </div>
    );
  }

  if (!isRegistered(component.name)) {
    return (
      <div className="ac-fallback">
        No renderer registered for <code>{component.name}</code>. The agent is ahead of
        this application's component registry.
      </div>
    );
  }

  const Component = COMPONENT_REGISTRY[component.name];
  return <Component props={component.props} handlers={handlers} />;
}

export default AgentComponentHost;
