import { useCallback, useEffect, useRef } from "react";
import { CopilotKit, useCoAgent, useCopilotChat } from "@copilotkit/react-core";
import { CopilotChat, AssistantMessage } from "@copilotkit/react-ui";
import type { AssistantMessageProps } from "@copilotkit/react-ui";
import "@copilotkit/react-ui/styles.css";

import AgentComponentHost from "./agent-ui/AgentComponentHost";
import { assertRegistryMatchesContract } from "./agent-ui/registry";
import { API_BASE_URL, AGUI_RUNTIME_URL, AGUI_AGENT_NAME } from "./agent-ui/config";
import type { AgentComponent } from "./agent-ui/types";
import { useHitlInterrupt } from "./agent-ui/useHitlInterrupt";
import "./styles/agent-cards.css";
import "./form-shell.css";

/**
 * App.tsx
 *
 * One phase, one renderer.
 *
 * The mode-choice card, the intake form, and every in-graph HITL card are all
 * driven the same way: the agent names ONE component via AgentState.ui_component
 * and this app renders it through the SAME AgentComponentHost against the SAME
 * registry. The backend names the component in every case; the frontend never
 * decides which screen to show. Nothing here inspects props to guess a stage —
 * if you find yourself adding a heuristic in this file, the fix belongs in
 * agui/ui_contract.py instead.
 *
 * The graph is started once on mount via an empty kickoff message (appendMessage) —
 * there is no pre-graph REST phase anymore. node_0_show_entry / node_0_wait (in
 * agents/nodes/nodes_gateway.py) render the opening cards as ordinary
 * interrupt()-driven turns, identical to every other HITL card downstream.
 */

// node_17 pushes an intro line whose options the recommendation card already
// renders; node_20 does the same with a markdown table. Both would otherwise
// appear twice — once as chat text, once as a card.
const TOP5_REDUNDANT_MARKER = "You can choose from the options below or type a CR ID directly.";
const CYCLE_ID_TABLE_MARKER = "Select one of the options below";

function FilteredAssistantMessage(props: AssistantMessageProps) {
  const content = props.message?.content ?? "";
  if (content.includes(TOP5_REDUNDANT_MARKER)) return null;
  const tableIdx = content.indexOf(CYCLE_ID_TABLE_MARKER);
  if (tableIdx !== -1 && props.message) {
    return (
      <AssistantMessage
        {...props}
        message={{ ...props.message, content: content.slice(0, tableIdx).trim() }}
      />
    );
  }
  return <AssistantMessage {...props} />;
}

interface CRAgentState {
  ui_component?: AgentComponent | null;
}

function AppShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="shell-root ac-scope">
      <aside className="shell-sidebar">
        <div className="shell-logo">J&amp;J</div>
        <button type="button" disabled className="shell-new-chat">
          + New Chat
        </button>
        <div className="shell-section-label">AVAILABLE AGENTS</div>
        <div className="shell-nav">
          <div className="shell-nav-item">SASA</div>
          <div className="shell-nav-item">Workshop Assist</div>
          <div className="shell-nav-item active">
            <span>CR/CO Agent</span>
            <span className="shell-nav-dot" />
          </div>
          <div className="shell-nav-sub">Create Change Re…</div>
        </div>
        <div className="shell-section-label">RECENT CONVERSATIONS</div>
        <div className="shell-recent-title">Treasury</div>
        <div className="shell-recent-time">11 Feb, 21:12</div>
      </aside>

      <div className="shell-main">
        <header className="shell-header">
          <div>
            <div className="shell-title">AI SDLC Orchestration</div>
            <div className="shell-breadcrumb">
              Projects <strong>&gt; Treasury</strong>
            </div>
          </div>
          <div className="shell-user">
            <div>
              <div className="shell-user-name">Kelvin Johnson</div>
              <div className="shell-user-role">Admin User</div>
            </div>
            <div className="shell-avatar">KJ</div>
          </div>
        </header>
        <div className="shell-content">{children}</div>
      </div>
    </div>
  );
}

function CRFlow() {
  const { visibleMessages } = useCopilotChat();
  const { resolve: resolveInterrupt, prompt: interruptPrompt, component: interruptComponent } = useHitlInterrupt(AGUI_AGENT_NAME);
  const { state } = useCoAgent<CRAgentState>({ name: AGUI_AGENT_NAME, initialState: {} });

  const turnRef = useRef(0);

  useEffect(() => {
    if (import.meta.env?.DEV) void assertRegistryMatchesContract(API_BASE_URL);
  }, []);

  // Every card — mode choice, intake form, or any downstream HITL screen —
  // resumes the pending interrupt(). appendMessage would start a NEW run
  // instead of delivering the Command(resume=...) the graph is blocked on.
  const handleAgentRespond = useCallback(
    (value: string) => {
      turnRef.current += 1;
      resolveInterrupt(value);
    },
    [resolveInterrupt]
  );

  // state.ui_component is the normal render source, but a reconnect to an
  // already-pending interrupt never gets a STATE_SNAPSHOT — fall back to the
  // interrupt's own value (which every node passes its ui_component into).
  const agentComponent = state?.ui_component ?? (interruptComponent as AgentComponent | null) ?? null;
  const awaitingUser = !!interruptPrompt;

  useEffect(() => {
    console.log(
      "[gateway] state changed",
      state,
      "interruptPrompt:",
      interruptPrompt,
      "interruptComponent:",
      interruptComponent,
      "resolved agentComponent:",
      agentComponent
    );
  }, [state, interruptPrompt, interruptComponent, agentComponent]);

  const realMessageCount = (visibleMessages ?? []).length;

  // Before the intake form is submitted there is no real conversation yet —
  // show the card full-page in the shell. This is driven by whether any chat
  // messages exist, not by inspecting the component's name.
  if (realMessageCount === 0) {
    return (
      <AppShell>
        <AgentComponentHost
          component={agentComponent}
          onRespond={handleAgentRespond}
          turnKey={`entry-${turnRef.current}`}
        />
      </AppShell>
    );
  }

  /* ── Chat + card split view ───────────────────────────────────────────── */
  return (
    <div className="ac-scope" style={{ height: "100vh", display: "flex" }}>
      <div
        className={awaitingUser ? "hide-default-input" : undefined}
        style={{ flex: agentComponent ? "1 1 50%" : "1 1 100%", minWidth: 0, height: "100%" }}
      >
        <CopilotChat
          labels={{ title: "SolMan CR Agent", initial: "" }}
          AssistantMessage={FilteredAssistantMessage}
        />
      </div>

      {agentComponent && (
        <div
          style={{
            flex: "1 1 50%",
            minWidth: 0,
            height: "100%",
            borderLeft: "1px solid var(--ac-border)",
            background: "var(--ac-surface-alt)",
            padding: "16px 20px",
            display: "flex",
            justifyContent: "center",
            overflowY: "auto",
          }}
        >
          <AgentComponentHost
            component={agentComponent}
            onRespond={handleAgentRespond}
            turnKey={`graph-${turnRef.current}-${awaitingUser ? "live" : "idle"}`}
          />
        </div>
      )}
    </div>
  );
}

export default function App() {
  return (
    <CopilotKit runtimeUrl={AGUI_RUNTIME_URL} agent={AGUI_AGENT_NAME}>
      <CRFlow />
    </CopilotKit>
  );
}
