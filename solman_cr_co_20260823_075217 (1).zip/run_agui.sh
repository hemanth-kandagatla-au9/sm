#!/usr/bin/env bash
# run_agui.sh — bring up the three AG-UI processes for local testing.
#
#   usage:  source set_env.sh && ./run_agui.sh
#
# Starts, in order:
#   1. agui_server.py        :8084   Python AG-UI host (the agent)
#   2. agui_runtime/         :8006   CopilotKit runtime bridge (Node)
#   3. frontend/             :8005   Vite dev server (the cards)
#
# Ctrl-C stops all three. Logs go to .agui-logs/.
#
# Ports are overridable:  AGUI_PORT, AGUI_RUNTIME_PORT, FRONTEND_PORT
# Note this deliberately does NOT use $PORT — set_env.sh sets that to 8081 for
# main.py, and the two servers must not collide.

set -euo pipefail
cd "$(dirname "$0")"

AGUI_PORT="${AGUI_PORT:-8084}"
AGUI_RUNTIME_PORT="${AGUI_RUNTIME_PORT:-8006}"
FRONTEND_PORT="${FRONTEND_PORT:-8005}"
LOG_DIR=".agui-logs"

export AGUI_PORT AGUI_RUNTIME_PORT
export AGUI_BACKEND_URL="http://localhost:${AGUI_PORT}/copilotkit"
export VITE_AGUI_API_BASE="http://localhost:${AGUI_PORT}"
export VITE_AGUI_RUNTIME_URL="http://localhost:${AGUI_RUNTIME_PORT}/api/copilotkit"

mkdir -p "$LOG_DIR"
PIDS=()

cleanup() {
  echo ""
  echo "→ shutting down…"
  for pid in "${PIDS[@]:-}"; do
    kill "$pid" 2>/dev/null || true
  done
  wait 2>/dev/null || true
}
trap cleanup EXIT INT TERM

require_port_free() {
  if command -v lsof >/dev/null 2>&1 && lsof -i ":$1" -sTCP:LISTEN >/dev/null 2>&1; then
    echo "✗ port $1 is already in use — stop whatever is on it, or override the port env var" >&2
    exit 1
  fi
}

# ── preflight ────────────────────────────────────────────────────────────────
if [[ -z "${RESOLVE_SSM_PARAMS:-}" ]]; then
  echo "⚠  set_env.sh does not look sourced (RESOLVE_SSM_PARAMS unset)."
  echo "   Run:  source set_env.sh && ./run_agui.sh"
  echo ""
fi

for p in "$AGUI_PORT" "$AGUI_RUNTIME_PORT" "$FRONTEND_PORT"; do
  require_port_free "$p"
done

# ── 1. Python AG-UI host ─────────────────────────────────────────────────────
echo "→ [1/3] agui_server.py on :$AGUI_PORT"
python agui_server.py > "$LOG_DIR/agui_server.log" 2>&1 &
PIDS+=($!)

# Wait for it to answer before starting the bridge — the bridge does not retry
# a dead backend, it just fails every request with an opaque error.
echo -n "      waiting for backend"
for i in $(seq 1 45); do
  if curl -sf "http://localhost:${AGUI_PORT}/api/ui-contract" >/dev/null 2>&1; then
    echo " ✓"
    break
  fi
  if ! kill -0 "${PIDS[0]}" 2>/dev/null; then
    echo ""
    echo "✗ agui_server.py exited during startup. Last lines:"
    tail -25 "$LOG_DIR/agui_server.log"
    exit 1
  fi
  echo -n "."
  sleep 1
  if [[ $i -eq 45 ]]; then
    echo ""
    echo "✗ backend did not come up in 45s. Last lines:"
    tail -25 "$LOG_DIR/agui_server.log"
    exit 1
  fi
done

# ── 2. CopilotKit runtime bridge ─────────────────────────────────────────────
echo "→ [2/3] agui_runtime bridge on :$AGUI_RUNTIME_PORT"
if [[ ! -d agui_runtime/node_modules ]]; then
  echo "      installing bridge deps (first run)…"
  (cd agui_runtime && npm install --no-audit --no-fund) >> "$LOG_DIR/agui_runtime.log" 2>&1
fi
(cd agui_runtime && npm start) >> "$LOG_DIR/agui_runtime.log" 2>&1 &
PIDS+=($!)

# ── 3. Vite dev server ───────────────────────────────────────────────────────
echo "→ [3/3] frontend on :$FRONTEND_PORT"
if [[ ! -d frontend/node_modules ]]; then
  echo "      installing frontend deps (first run)…"
  (cd frontend && npm install --no-audit --no-fund) >> "$LOG_DIR/frontend.log" 2>&1
fi
(cd frontend && npm run dev -- --port "$FRONTEND_PORT" --host) >> "$LOG_DIR/frontend.log" 2>&1 &
PIDS+=($!)

sleep 2
echo ""
echo "─────────────────────────────────────────────────────────"
echo "  open  http://localhost:${FRONTEND_PORT}"
echo ""
echo "  contract  http://localhost:${AGUI_PORT}/api/ui-contract"
echo "  bridge    http://localhost:${AGUI_RUNTIME_PORT}/health"
echo "  logs      $LOG_DIR/"
echo "─────────────────────────────────────────────────────────"
echo "  Ctrl-C to stop all three."
echo ""

wait
