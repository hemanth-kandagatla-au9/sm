from __future__ import annotations

import operator
import time
import uuid
from typing import Annotated, Any, Optional
from typing_extensions import TypedDict

from langchain_core.messages import AnyMessage
from langgraph.graph.message import add_messages


# ─────────────────────────────────────────────
# Sub-state: individual field
# ─────────────────────────────────────────────
class FieldState(TypedDict):
    given: bool
    valid: Optional[bool]
    value: str
    data: Optional[dict]
    error: Optional[str]


def empty_field() -> FieldState:
    return {
        "given": False,
        "valid": None,
        "value": "",
        "data": None,
        "error": None,
    }


# ─────────────────────────────────────────────
# Sub-state: metrics
# ─────────────────────────────────────────────
class MetricsState(TypedDict):
    X: Any
    Y: Any
    Z: Any


def empty_metrics() -> MetricsState:
    return {"X": None, "Y": None, "Z": None}


# ─────────────────────────────────────────────
# Sub-state: UI rendered to user
# ─────────────────────────────────────────────
class UIState(TypedDict):
    draft_html: Optional[str]
    recommendations_html: Optional[str]
    output_text: Optional[str]


def empty_ui() -> UIState:
    return {
        "draft_html": None,
        "recommendations_html": None,
        "output_text": None,
    }


# ─────────────────────────────────────────────
# Sub-state: a single similar CR recommendation
# ─────────────────────────────────────────────
class SimilarCRState(TypedDict):
    object_id: str
    ranking_score: float
    platform_match: bool        # True if CR's platform matches user-provided platform
    target_system_match: bool   # True if CR's target_system matches user-provided target_system
    description: Optional[str]  # CR description text from Neo4j
    title: Optional[str]        # CR project title from Neo4j
    ui: UIState
    error: Optional[str]


# ─────────────────────────────────────────────
# Sub-state: baseline CR recommendation tracker
# ─────────────────────────────────────────────
class BaselineCRState(TypedDict):
    query_embedding: str
    mentioned_object_ids: list[str]
    max_attempts: int
    cr_1: Optional[SimilarCRState]
    cr_2: Optional[SimilarCRState]
    cr_3: Optional[SimilarCRState]
    cr_4: Optional[SimilarCRState]
    cr_5: Optional[SimilarCRState]


def empty_baselines() -> BaselineCRState:
    return {
        "query_embedding": "",
        "mentioned_object_ids": [],
        "max_attempts": 15,
        "cr_1": None,
        "cr_2": None,
        "cr_3": None,
        "cr_4": None,
        "cr_5": None,
    }


# ─────────────────────────────────────────────
# Main AgentState — everything the graph carries
# ─────────────────────────────────────────────
class AgentState(TypedDict):
    # ── conversation history ──────────────────
    messages: Annotated[list[AnyMessage], add_messages]

    # ── CR fields (each is a FieldState) ─────
    reason_for_change: FieldState
    description_of_change: FieldState
    additional_information: FieldState
    target_system: FieldState
    platform: FieldState
    template_id: FieldState
    cr_id: FieldState          # set by Node 18 when user selects from recommendations
    jira_id: FieldState

    # ── Jira-derived EDL fields (auto-populated from Jira fetch) ─────────────
    planned_impl_dt_adtnl: FieldState   # fields.duedate → Planned Implementation Date
    zzfld00000v_cus: FieldState         # "Yes"/"No" → Regression Test (QAS)
    zzfld00004y: FieldState             # regression test ID string → 2. Test Reference
    zzfld00000w_cus: FieldState         # "Yes"/"No" → UAT (QAS)
    zzfld00004x: FieldState             # UAT test ID string → 3. Test Reference

    # ── draft & iteration ─────────────────────
    draft: Optional[str]
    iteration: int
    exhausted_attempts: int

    # ── metrics, UI, baselines ────────────────
    metrics: MetricsState
    draft_ui: UIState
    baseline_crs: BaselineCRState

    # ── submission outcome ────────────────────
    submission_result: Optional[dict]

    # ── first draft accuracy ──────────────────
    first_draft_snapshot: Optional[dict]  # flat {field: value} captured at first draft
    first_draft_accuracy: Optional[dict]  # {total, unchanged, changed, changed_fields, pct}

    # ── scope guard cache ────────────────────────
    scope_confirmed: bool  # True once scope validated — skips re-check on every turn
    scope_out_count: int   # consecutive OUT_OF_SCOPE hits — ends session only at 2

    # ── cycle ID mismatch check (node_20 → node_20b) ──────────────────────────
    cycle_id_pending: Optional[dict]  # {"draft_cycle_id": str, "most_common": str} when mismatch found
    cycle_confirmed: bool  # True once user made a cycle decision — skips re-check on rebuild
    cycle_hitl_attempts: int  # out-of-context attempt counter for node_20b

    # ── AG-UI registered-component channel ─────────────────────────────────────
    # {"version": int, "name": str, "props": dict} — the agent names ONE registered
    # frontend component and supplies its props. Built exclusively via the builders
    # in agui/ui_contract.py; never constructed inline at a call site.
    ui_component: Optional[dict]

    # ── out-of-scope early exit ────────────────────────────────────────────────
    end_session: bool  # True when node_2 detects out-of-scope → routes to node_5

    # ── platform / target_system compatibility check (node_2 → node_3 → node_4) ──
    platform_tgt_pending: Optional[dict]   # {"options": [...], "original_target": str} when incompatible
    platform_tgt_overridden: bool          # True when user chose to keep original despite incompatibility

    # ── clickable options — rendered as buttons in chat below agent message ──
    clickable_options: Optional[list]      # list of str options for click-to-select buttons

    # ── session-level quality metrics (logged in node_5 for CloudWatch) ──────
    cycle_id_selection: Optional[str] # "default" | "rank_1"–"rank_30" | "N/A" (set by node_20/20b)
    cr_recommendation_source: Optional[str]  # "direct" | "rank_1"–"rank_5" | "user_template_id" | "user_cr_id" | "none_selected" | "N/A"
    target_suggestion_selection: Optional[str]  # "rank_1"–"rank_5" | "user_typed" | "N/A" (set by node_4)

    # ── pending update — set when node_10 detects an ambiguous field name ────
    pending_update: Optional[dict]         # {"value": str, "candidates": [{"field_key", "display_name", "section"}]}

    # ── requestor identity — SAP WWID passed in the request payload ──────────
    wwid: str  # SAP user WWID used as IvRequestor in CR submission

    # ── Transaction Type Rules (node_21 / node_22 — after cycle ID confirmation) ──
    aprv_proc:        FieldState   # user-selected Approval Process (J&J Approval / J&J Emergency Approval / blank)
    transaction_type: FieldState   # user-selected Transaction Type (Urgent / Standard Change / etc.)

    # ── task-scoped correlation id + timing (one CR-creation attempt) ────────
    task_id: str          # generated once per fresh task; persists across HITL resumes
    task_start_ts: float  # time.time() captured at task start (used for app.task.duration_ms)

    # ── task-scoped cumulative token/cost totals (reducer fields — summed by
    # LangGraph across every node call, including across resumed invocations) ──
    task_input_tokens: Annotated[int, operator.add]
    task_output_tokens: Annotated[int, operator.add]
    task_cost_usd: Annotated[float, operator.add]


def build_initial_state(user_input: str, wwid: str = "", task_id: str | None = None) -> AgentState:
    from langchain_core.messages import HumanMessage

    return {
        "messages": [HumanMessage(content=user_input)],
        "reason_for_change": empty_field(),
        "description_of_change": empty_field(),
        "additional_information": empty_field(),
        "target_system": empty_field(),
        "platform": empty_field(),
        "template_id": empty_field(),
        "cr_id": empty_field(),
        "jira_id": empty_field(),
        "planned_impl_dt_adtnl": empty_field(),
        "zzfld00000v_cus": empty_field(),
        "zzfld00004y": empty_field(),
        "zzfld00000w_cus": empty_field(),
        "zzfld00004x": empty_field(),
        "draft": None,
        "iteration": 0,
        "exhausted_attempts": 0,
        "metrics": empty_metrics(),
        "draft_ui": empty_ui(),
        "baseline_crs": empty_baselines(),
        "submission_result": None,
        "first_draft_snapshot": None,
        "first_draft_accuracy": None,
        "scope_confirmed": False,
        "scope_out_count": 0,
        "ui_component": None,
        "end_session": False,
        "cycle_id_pending": None,
        "cycle_confirmed": False,
        "cycle_hitl_attempts": 0,
        "platform_tgt_pending": None,
        "platform_tgt_overridden": False,
        "clickable_options": None,
        "cycle_id_selection": None,
        "cr_recommendation_source": None,
        "target_suggestion_selection": None,
        "wwid": wwid,
        "aprv_proc":        empty_field(),
        "transaction_type": empty_field(),
        "task_id": task_id or uuid.uuid4().hex,
        "task_start_ts": time.time(),
        "task_input_tokens": 0,
        "task_output_tokens": 0,
        "task_cost_usd": 0.0,
    }