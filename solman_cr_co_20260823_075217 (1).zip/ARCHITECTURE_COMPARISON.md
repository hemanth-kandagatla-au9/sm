# SolMan CR/CO Agent — Architecture Comparison
### Old Implementation vs. New Implementation

---

## 1. Executive Summary

Both versions of the application connect three pieces together:

```mermaid
flowchart LR
    A["React Frontend<br/>(:8005)"] --> B["CopilotKit Bridge<br/>(:8006)"]
    B --> C["Python AI Agent<br/>(:8084)"]
```

- The **frontend** is what the user sees in the browser.
- The **bridge** is a small translator process that lets the frontend and the AI agent talk to each other.
- The **AI agent** (LangGraph) does the actual thinking/decision-making and decides what screen the user should see next.

The two implementations differ in **how the AI agent tells the frontend what to display**, and in a few smaller but important **plumbing/wiring** details. The new implementation is a more robust, more maintainable design — the old one worked, but relied on fragile guesswork.

---

## 2. The Core Difference: How the Agent Controls the UI

### Old Approach — "Frontend Guesses"

In the old system, the AI agent doesn't explicitly say *"show the draft review screen"* or *"show the CR picker screen."* Instead, it just sends back raw data (chat text, a list of clickable options, some form fields), and the **frontend has to guess** what kind of screen that data represents by inspecting its shape.

Examples of this guesswork found in the old frontend code:

| What the frontend sees | What it assumes it means |
|---|---|
| Every clickable option's label contains the text "Similarity score:" | "This must be the CR recommendation picker screen" |
| One of the clickable options has the value "approve" | "This must be the draft approval screen" |
| A specific internal flag plus a pending question | "This must be the Cycle ID confirmation screen" |
| Chat message contains a specific hardcoded sentence | "This sentence is duplicate text I should hide" |

**Why this is risky:**
- It's brittle — if the wording of a message or an option label ever changes slightly, the frontend silently breaks (shows the wrong screen or no screen at all).
- There's no formal, written-down agreement between the backend and frontend about what data should look like.
- Every new screen requires writing a new "detective" rule in the frontend to figure out when to show it.

### New Approach — "Agent Explicitly Tells the UI What to Show"

In the new system, the AI agent explicitly names the screen it wants and provides validated data for it. Think of it like the agent sending a labeled package:

```
{
  "component": "draftReview",
  "data": { ...validated fields for that screen... }
}
```

This is powered by a single **"contract" file** (`agui/ui_contract.py`) that:
- Lists every valid screen name (e.g. `draftReview`, `cycleIdPicker`, `crIntakeForm`, `submissionResult`, etc.)
- Defines exactly what data each screen expects (like a form template), and validates it before sending
- Provides one shared function per screen so every part of the agent builds that screen's data the same, correct way

On the frontend, there's a matching **"registry"** (`registry.tsx`) — a simple lookup table that maps each screen name to the actual React component that draws it. When the agent says `"draftReview"`, the frontend just looks it up and renders it — no guessing required.

```mermaid
flowchart TB
    subgraph OLD["Old: Frontend Guesses"]
        O1["Agent sends raw data"] --> O2["Frontend inspects shape<br/>+ hardcoded string matching"] --> O3["Frontend guesses which<br/>screen to show"]
    end
    subgraph NEW["New: Agent Decides"]
        N1["Agent explicitly names<br/>the screen + validated data"] --> N2["Frontend looks up<br/>name in registry"] --> N3["Correct screen<br/>shown, guaranteed"]
    end
```

**Why this matters for the client:**
- **More reliable** — screens can't accidentally show the wrong thing due to a wording change.
- **Easier to extend** — adding a new screen means adding one entry to the contract and one entry to the registry, instead of writing new detective logic.
- **Self-documenting** — the contract file is a live, enforced specification of every screen the agent can produce, which is useful for onboarding new developers or for compliance/audit purposes.

---

## 3. Bridge / Plumbing Differences (Behind the Scenes)

There's also a difference in the small "bridge" program that sits between the frontend and the agent. This is invisible to end users but matters for reliability and maintainability.

| | Old Bridge | New Bridge |
|---|---|---|
| Library used to connect to agent | Older CopilotKit-specific connector | Standard AG-UI connector (`HttpAgent`) |
| How the network path is set up | Path-stripping style (must be set to `/` internally) | Direct path matching (path set to the real API path) |

**In plain terms:** the new implementation uses the more current, standard way of wiring the pieces together, which is less prone to a class of "wrong URL / 404 not found" bugs that we actually encountered and fixed with the old-style wiring approach during development.

---

## 4. Other Notable UX/Layout Differences

| Aspect | Old | New |
|---|---|---|
| Chat vs. active screen layout | Draft/review screen **overlays** or **replaces** the chat area | Chat and the active screen are shown **side-by-side**, so users keep chat history visible while reviewing a form/draft |
| "Agent is working..." indicator | Uses a CopilotKit built-in feature to show "Running: `<step name>`" inline in the chat | Not present — cleaner chat feed, screen changes communicate progress instead |
| Duplicate text prevention | Some hardcoded sentence-matching to hide duplicate text (kept in new version too, for two known cases) | Same two known cases preserved; no other guesswork remains |

---

## 5. Summary for Presentation

**One-line summary:**
> The old system worked by having the frontend *infer* what to display from raw data patterns; the new system has the AI agent *explicitly declare* what to display through a validated, versioned contract — making the application more predictable, easier to extend with new screens, and less prone to silent UI bugs.

**Recommended talking points for the client:**
1. Both versions are functionally equivalent from the end-user's perspective today.
2. The new architecture is a **foundational improvement** — it reduces technical risk for future features.
3. Adding new interactive screens in the future is now a matter of registering a new entry in a contract file and a lookup table, rather than writing new custom detection logic each time.
4. The side-by-side chat/screen layout also improves usability by keeping conversation context visible during multi-step review workflows.

---

## 6. Running the New Application Locally (3 Terminals)

The new stack has three processes that must run at the same time: the Python agent, the CopilotKit bridge, and the React frontend.

**Terminal 1 — Python AG-UI agent (`agui_server.py`, port 8084)**
```bash
cd /home/ythakkal/agent_agui/solman_cr_co
source set_env.sh
python agui_server.py
```

**Terminal 2 — CopilotKit bridge (`agui_runtime/`, port 8006)**
```bash
cd /home/ythakkal/agent_agui/solman_cr_co
export AGUI_BACKEND_URL="http://localhost:8084/copilotkit"
cd agui_runtime
node server.mjs
```

**Terminal 3 — Frontend (`frontend/`, port 8005)**
```bash
cd /home/ythakkal/agent_agui/solman_cr_co/frontend
export VITE_AGUI_API_BASE="http://localhost:8084"
export VITE_AGUI_RUNTIME_URL="http://localhost:8006/api/copilotkit"
npm run dev
```

Start Terminal 1 first and wait until `curl http://localhost:8084/api/ui-contract` returns JSON before starting Terminal 2 — the bridge does not retry a dead backend. Start Terminal 3 last, then open `http://localhost:8005`.

A single-script alternative that starts all three at once is also available: `source set_env.sh && ./run_agui.sh`.
