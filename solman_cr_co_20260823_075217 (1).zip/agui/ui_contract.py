"""
agui/ui_contract.py

SINGLE SOURCE OF TRUTH for the agent → frontend component contract.

── The model ──────────────────────────────────────────────────────────────────
The frontend (platform team) registers a fixed set of React components by name.
The agent NEVER ships UI. The agent only:

    1. picks a registered component by name, and
    2. supplies a JSON props payload that conforms to that component's schema.

Everything the agent wants rendered goes through `AgentState["ui_component"]`:

    {
      "version": 1,
      "name":    "crIntakeForm",          # must exist in the frontend registry
      "props":   { ... }                  # must conform to PROP_SCHEMAS[name]
    }

The frontend reads this off the AG-UI STATE_SNAPSHOT / STATE_DELTA stream and
renders `registry[name]` with `props`. An unknown name renders the fallback card
rather than crashing — see `AgentComponentHost.tsx`.

── Why this file exists ───────────────────────────────────────────────────────
This is the handover artifact. The platform team needs exactly three things from
us and they are all here:

    COMPONENT_NAMES  — what they must register
    PROP_SCHEMAS     — the JSON Schema each component's props conform to
    EXAMPLES         — a valid example payload per component, for their fixtures

Run `python -m agui.ui_contract` to dump the whole contract as JSON.

── Versioning ─────────────────────────────────────────────────────────────────
`CONTRACT_VERSION` is bumped on any breaking prop change. The frontend renders
the fallback card (not a crash) when it sees a version it does not understand,
so agent and frontend can deploy independently.
"""
from __future__ import annotations

from typing import Any, Optional

CONTRACT_VERSION = 1

# ─────────────────────────────────────────────────────────────────────────────
# Component names — these strings are the API. Renaming one is a breaking change.
# ─────────────────────────────────────────────────────────────────────────────
CR_MODE_CHOICE = "crModeChoice"
FEATURE_COMING_SOON = "featureComingSoon"
CR_INTAKE_FORM = "crIntakeForm"
TEMPLATE_OR_CR_PICKER = "templateOrCrPicker"
CYCLE_ID_PICKER = "cycleIdPicker"
DRAFT_REVIEW = "draftReview"
FIELD_PROMPT = "fieldPrompt"
SUBMISSION_RESULT = "submissionResult"

COMPONENT_NAMES: tuple[str, ...] = (
    CR_MODE_CHOICE,
    FEATURE_COMING_SOON,
    CR_INTAKE_FORM,
    TEMPLATE_OR_CR_PICKER,
    CYCLE_ID_PICKER,
    DRAFT_REVIEW,
    FIELD_PROMPT,
    SUBMISSION_RESULT,
)


# ─────────────────────────────────────────────────────────────────────────────
# Shared sub-schemas
# ─────────────────────────────────────────────────────────────────────────────
# A single label/value line inside an expanded panel. `tone` lets the agent mark a
# row as a positive/negative signal (e.g. "Platform match") without the frontend
# having to interpret the value.
_DETAIL_ROW = {
    "type": "object",
    "required": ["label", "value"],
    "additionalProperties": False,
    "properties": {
        "label": {"type": "string"},
        "value": {"type": "string"},
        "tone": {"type": ["string", "null"], "enum": ["neutral", "positive", "negative", None]},
        "wide": {"type": "boolean", "default": False, "description": "Render full-width (long free text)"},
    },
}

_OPTION = {
    "type": "object",
    "required": ["label", "value"],
    "additionalProperties": False,
    "properties": {
        "label": {"type": "string"},
        "value": {"type": "string"},
        "badge": {"type": ["string", "null"], "description": "Optional right-aligned pill, e.g. platform name"},
        "disabled": {"type": "boolean", "default": False},
        # Populated → the row is expandable and renders these when opened.
        # Absent/empty → the row has no disclosure control at all.
        "details": {"type": ["array", "null"], "items": _DETAIL_ROW},
    },
}

# Every card renders the same footer strip (timestamp + cost pills). The agent
# supplies it so the frontend never has to guess or compute it.
_CARD_META = {
    "type": ["object", "null"],
    "additionalProperties": False,
    "properties": {
        "timestamp": {"type": ["string", "null"], "description": "Display string, e.g. '11th Feb, 26  21:12 pm'"},
        "processing_time": {"type": ["string", "null"], "description": "e.g. '30 sec'"},
        "tokens": {"type": ["integer", "string", "null"]},
        "cost": {"type": ["string", "null"], "description": "Pre-formatted, e.g. '$0.0023'"},
    },
}

_FIELD_ROW = {
    "type": "object",
    "required": ["key", "label", "value"],
    "additionalProperties": True,
    "properties": {
        "key": {"type": "string", "description": "EDL key, e.g. zzfld00000v_cus"},
        "label": {"type": "string"},
        "value": {"type": "string", "description": "Display value, exactly as it will be submitted"},
        "editable": {"type": "boolean", "default": True},
        "lock_type": {
            "type": ["string", "null"],
            "description": "system_readonly | compliance_locked | session_locked",
        },
        # ── expansion payload ────────────────────────────────────────────────
        # A field row expands to show provenance and edit rules. All optional:
        # a row with none of these still renders, just without a disclosure.
        "field_type": {"type": ["string", "null"], "enum": ["text", "boolean", "dropdown", None]},
        "allowed_values": {
            "type": ["array", "null"],
            "items": {"type": "string"},
            "description": "For dropdown/boolean fields — the values SolMan will accept",
        },
        "section": {"type": ["string", "null"]},
        "lock_reason": {"type": ["string", "null"], "description": "Human-readable reason the field is locked"},
        "empty": {"type": "boolean", "default": False, "description": "True when no value will be submitted"},
    },
}


# ─────────────────────────────────────────────────────────────────────────────
# Prop schemas — one per registered component
# ─────────────────────────────────────────────────────────────────────────────
PROP_SCHEMAS: dict[str, dict[str, Any]] = {

    CR_MODE_CHOICE: {
        "type": "object",
        "required": ["title", "modes"],
        "additionalProperties": False,
        "properties": {
            "title": {"type": "string"},
            "subtitle": {"type": ["string", "null"]},
            "modes": {
                "type": "array",
                "minItems": 1,
                "items": {
                    "type": "object",
                    "required": ["value", "label"],
                    "additionalProperties": False,
                    "properties": {
                        "value": {"type": "string", "enum": ["single", "bulk"]},
                        "label": {"type": "string"},
                        "description": {"type": ["string", "null"]},
                        "enabled": {"type": "boolean", "default": True},
                    },
                },
            },
            "meta": _CARD_META,
        },
    },

    FEATURE_COMING_SOON: {
        "type": "object",
        "required": ["title", "message"],
        "additionalProperties": False,
        "properties": {
            "title": {"type": "string"},
            "message": {"type": "string"},
            "back_label": {"type": ["string", "null"], "default": "Back"},
            "meta": _CARD_META,
        },
    },

    CR_INTAKE_FORM: {
        "type": "object",
        "required": ["title", "platforms"],
        "additionalProperties": False,
        "properties": {
            "title": {"type": "string"},
            "subtitle": {"type": ["string", "null"]},
            "hint": {"type": ["string", "null"], "description": "Blue helper line under the first row"},
            "platforms": {"type": "array", "items": {"type": "string"}},
            # Target systems are fetched per-platform from /api/target-systems, so the
            # agent does not need to preload them. Supplied only when already known.
            "target_systems": {"type": ["array", "null"], "items": {"type": "string"}},
            "values": {
                "type": ["object", "null"],
                "description": "Prefilled values, e.g. on re-entry after a validation error",
                "additionalProperties": False,
                "properties": {
                    "platform": {"type": ["string", "null"]},
                    "target_system": {"type": ["string", "null"]},
                    "jira_id": {"type": ["string", "null"]},
                    "iris_id": {"type": ["string", "null"]},
                    "reason_for_change": {"type": ["string", "null"]},
                    "description_of_change": {"type": ["string", "null"]},
                },
            },
            "errors": {
                "type": ["object", "null"],
                "description": "Field-level server-side validation errors, keyed by field name",
                "additionalProperties": {"type": "string"},
            },
            # IRIS has no backing API yet — rendered but inert. Flip to true when it lands.
            "iris_enabled": {"type": "boolean", "default": False},
            "meta": _CARD_META,
        },
    },

    TEMPLATE_OR_CR_PICKER: {
        "type": "object",
        "required": ["title"],
        "additionalProperties": False,
        "properties": {
            "title": {"type": "string"},
            "subtitle": {"type": ["string", "null"]},
            "template_label": {"type": ["string", "null"], "default": "Template ID"},
            "template_optional": {"type": "boolean", "default": True},
            "template_options": {"type": "array", "items": {"type": "string"}},
            "reference_label": {"type": ["string", "null"], "default": "Reference Change Request ID"},
            "reference_options": {"type": "array", "items": _OPTION},
            "selected_template": {"type": ["string", "null"]},
            "selected_reference": {"type": ["string", "null"]},
            "meta": _CARD_META,
        },
    },

    CYCLE_ID_PICKER: {
        "type": "object",
        "required": ["message", "options"],
        "additionalProperties": False,
        "properties": {
            "message": {"type": "string"},
            "options": {"type": "array", "items": _OPTION},
            "draft_cycle_id": {"type": ["string", "null"]},
            "keep_current_label": {"type": ["string", "null"]},
            "meta": _CARD_META,
        },
    },

    DRAFT_REVIEW: {
        "type": "object",
        "required": ["title", "sections"],
        "additionalProperties": False,
        "properties": {
            "title": {"type": "string"},
            "subtitle": {"type": ["string", "null"]},
            "sections": {
                "type": "array",
                "items": {
                    "type": "object",
                    "required": ["name", "fields"],
                    "additionalProperties": False,
                    "properties": {
                        "name": {"type": "string"},
                        "fields": {"type": "array", "items": _FIELD_ROW},
                    },
                },
            },
            "confirm_text": {"type": ["string", "null"], "description": "e.g. 'These inputs will raise a change request for CR ID 45678987.'"},
            "question_text": {"type": ["string", "null"], "default": "Are you sure to proceed?"},
            "notices": {"type": ["array", "null"], "items": {"type": "string"}},
            "actions": {"type": "array", "items": _OPTION},
            "meta": _CARD_META,
        },
    },

    FIELD_PROMPT: {
        "type": "object",
        "required": ["message"],
        "additionalProperties": False,
        "properties": {
            "title": {"type": ["string", "null"]},
            "message": {"type": "string"},
            "options": {"type": "array", "items": _OPTION},
            "allow_free_text": {"type": "boolean", "default": True},
            "placeholder": {"type": ["string", "null"]},
            "meta": _CARD_META,
        },
    },

    SUBMISSION_RESULT: {
        "type": "object",
        "required": ["status", "message"],
        "additionalProperties": False,
        "properties": {
            "status": {"type": "string", "enum": ["success", "failed"]},
            "message": {"type": "string"},
            "cr_id": {"type": ["string", "null"]},
            "meta": _CARD_META,
        },
    },
}


# ─────────────────────────────────────────────────────────────────────────────
# Builders — the ONLY supported way to construct a ui_component payload.
# Nodes call these; nothing constructs the dict by hand.
# ─────────────────────────────────────────────────────────────────────────────
def _envelope(name: str, props: dict[str, Any]) -> dict[str, Any]:
    if name not in COMPONENT_NAMES:
        raise ValueError(f"Unknown UI component {name!r}. Known: {', '.join(COMPONENT_NAMES)}")
    return {"version": CONTRACT_VERSION, "name": name, "props": props}


def _meta(
    timestamp: Optional[str] = None,
    processing_time: Optional[str] = None,
    tokens: Optional[int] = None,
    cost: Optional[str] = None,
) -> Optional[dict[str, Any]]:
    if timestamp is None and processing_time is None and tokens is None and cost is None:
        return None
    return {
        "timestamp": timestamp,
        "processing_time": processing_time,
        "tokens": tokens,
        "cost": cost,
    }


def cr_mode_choice(*, bulk_enabled: bool = False, meta: Optional[dict] = None) -> dict[str, Any]:
    """Opening screen — single vs bulk CR."""
    return _envelope(CR_MODE_CHOICE, {
        "title": "Create Change Request",
        "subtitle": "How would you like to proceed?",
        "modes": [
            {
                "value": "single",
                "label": "Single Change Request",
                "description": "Raise one change request against a platform and target system.",
                "enabled": True,
            },
            {
                "value": "bulk",
                "label": "Bulk Change Request",
                "description": "Raise multiple change requests from a single upload.",
                "enabled": bulk_enabled,
            },
        ],
        "meta": meta,
    })


def feature_coming_soon(
    *,
    title: str = "Bulk Change Request",
    message: str = "Feature available soon.",
    back_label: str = "Back to Single Change Request",
    meta: Optional[dict] = None,
) -> dict[str, Any]:
    return _envelope(FEATURE_COMING_SOON, {
        "title": title,
        "message": message,
        "back_label": back_label,
        "meta": meta,
    })


def cr_intake_form(
    *,
    platforms: list[str],
    target_systems: Optional[list[str]] = None,
    values: Optional[dict] = None,
    errors: Optional[dict] = None,
    iris_enabled: bool = False,
    meta: Optional[dict] = None,
) -> dict[str, Any]:
    return _envelope(CR_INTAKE_FORM, {
        "title": "Create Change Request",
        "subtitle": "To GET STARTED, please fill in the following information.",
        "hint": (
            "Please fill the Reason For Change and Description for change "
            "Or Jira ID/ IRIS ID to fetch the information"
        ),
        "platforms": platforms,
        "target_systems": target_systems,
        "values": values,
        "errors": errors,
        "iris_enabled": iris_enabled,
        "meta": meta,
    })


def template_or_cr_picker(
    *,
    template_options: Optional[list[str]] = None,
    reference_options: Optional[list[dict]] = None,
    selected_template: Optional[str] = None,
    selected_reference: Optional[str] = None,
    meta: Optional[dict] = None,
) -> dict[str, Any]:
    return _envelope(TEMPLATE_OR_CR_PICKER, {
        "title": "To proceed ahead,",
        "subtitle": "Please fill in the following information.",
        "template_label": "Template ID",
        "template_optional": True,
        "template_options": template_options or [],
        "reference_label": "Reference Change Request ID",
        "reference_options": reference_options or [],
        "selected_template": selected_template,
        "selected_reference": selected_reference,
        "meta": meta,
    })


def cycle_id_picker(
    *,
    message: str,
    options: list[dict],
    draft_cycle_id: Optional[str] = None,
    keep_current_label: Optional[str] = None,
    meta: Optional[dict] = None,
) -> dict[str, Any]:
    return _envelope(CYCLE_ID_PICKER, {
        "message": message,
        "options": options,
        "draft_cycle_id": draft_cycle_id,
        "keep_current_label": keep_current_label,
        "meta": meta,
    })


def draft_review(
    *,
    sections: list[dict],
    confirm_text: Optional[str] = None,
    notices: Optional[list[str]] = None,
    meta: Optional[dict] = None,
) -> dict[str, Any]:
    return _envelope(DRAFT_REVIEW, {
        "title": "Please review the Change Request Draft and update the information if required.",
        "subtitle": "By clicking on proceed, your change request will be raised successfully.",
        "sections": sections,
        "confirm_text": confirm_text,
        "question_text": "Are you sure to proceed?",
        "notices": notices,
        "actions": [
            {"label": "Reject", "value": "reject"},
            {"label": "Submit", "value": "approve"},
            {"label": "Submit for Approval", "value": "submit_for_approval"},
        ],
        "meta": meta,
    })


def field_prompt(
    *,
    message: str,
    options: Optional[list[dict]] = None,
    title: Optional[str] = None,
    allow_free_text: bool = True,
    placeholder: Optional[str] = "Type your reply…",
    meta: Optional[dict] = None,
) -> dict[str, Any]:
    return _envelope(FIELD_PROMPT, {
        "title": title,
        "message": message,
        "options": options or [],
        "allow_free_text": allow_free_text,
        "placeholder": placeholder,
        "meta": meta,
    })


def submission_result(
    *,
    status: str,
    message: str,
    cr_id: Optional[str] = None,
    meta: Optional[dict] = None,
) -> dict[str, Any]:
    if status not in ("success", "failed"):
        raise ValueError(f"status must be 'success' or 'failed', got {status!r}")
    return _envelope(SUBMISSION_RESULT, {
        "status": status,
        "message": message,
        "cr_id": cr_id,
        "meta": meta,
    })


# ─────────────────────────────────────────────────────────────────────────────
# Adapters — turn existing AgentState shapes into component props.
# Keeps node call sites to a single line and keeps all shape knowledge here.
# ─────────────────────────────────────────────────────────────────────────────
# Lock types → the sentence shown when a user expands a locked field. Without
# this a locked field just refuses to change with no stated reason, which on a
# regulated form reads as a bug rather than a control.
_LOCK_REASONS: dict[str, str] = {
    "system_readonly": "Set by SolMan and cannot be changed through this agent.",
    "compliance_locked": "Locked for compliance — changing it requires a formal change to the CR process.",
    "session_locked": "Fixed for this session by an earlier answer. Start a new request to change it.",
}


def enrich_field_row(row: dict) -> dict:
    """
    Add the expansion payload to one {key,label,value} row from field_groups.

    Everything here is derived from config (the same metadata node_10 enforces
    updates against), so what the user sees when they expand a field is the same
    ruleset that will accept or reject their edit. Fields that live on AgentState
    rather than in FIELD_GROUPS (reason_for_change and friends) have no metadata —
    they are returned as plain editable text.
    """
    from config.config import DROPDOWN_FIELDS, get_field_metadata

    key = str(row.get("key") or "")
    value = str(row.get("value") or "")
    out: dict[str, Any] = {
        "key": key,
        "label": row.get("label") or key,
        "value": value,
        "empty": not value.strip(),
    }

    meta = get_field_metadata(key) if key else None
    if not meta:
        # AgentState-backed narrative fields — editable free text, no SolMan rules.
        out["editable"] = True
        out["lock_type"] = None
        out["field_type"] = "text"
        return out

    lock_type = meta.get("lock_type")
    field_type = meta.get("field_type") or "text"

    out["editable"] = bool(meta.get("is_editable", True))
    out["lock_type"] = lock_type
    out["field_type"] = field_type
    out["section"] = meta.get("section")
    if lock_type:
        out["lock_reason"] = _LOCK_REASONS.get(lock_type, "This field cannot be changed.")

    if field_type == "dropdown":
        out["allowed_values"] = list(DROPDOWN_FIELDS.get(key, {}).keys())
    elif field_type == "boolean":
        out["allowed_values"] = ["Yes", "No"]

    return out


def sections_from_field_groups(field_groups: Optional[dict]) -> list[dict]:
    """
    AgentState["draft_ui"]["field_groups"] is {section: [{key,label,value}, ...]}.

    DRAFT_REVIEW wants an ordered list so the frontend renders sections in a
    stable order rather than dict-iteration order, and each field enriched with
    its edit rules so the user can expand any field to see why it holds the value
    it does and what it will accept.
    """
    if not field_groups:
        return []
    return [
        {"name": section, "fields": [enrich_field_row(f) for f in (fields or []) if isinstance(f, dict)]}
        for section, fields in field_groups.items()
    ]


def options_from_clickable(clickable: Optional[list]) -> list[dict]:
    """
    AgentState["clickable_options"] is a list of either {label,value} dicts or
    bare strings. Normalise to the _OPTION shape.
    """
    out: list[dict] = []
    for opt in clickable or []:
        if isinstance(opt, dict):
            label = str(opt.get("label") or opt.get("value") or "").strip()
            value = str(opt.get("value") or opt.get("label") or "").strip()
            if not label and not value:
                continue
            row: dict[str, Any] = {"label": label or value, "value": value or label}
            if opt.get("badge"):
                row["badge"] = str(opt["badge"])
            out.append(row)
        elif opt:
            out.append({"label": str(opt), "value": str(opt)})
    return out


def _cr_detail_rows(cr: dict) -> list[dict]:
    """Expansion panel for one recommended CR — what the user needs to judge it."""
    rows: list[dict] = []

    score = cr.get("ranking_score")
    if isinstance(score, (int, float)):
        rows.append({"label": "Similarity score", "value": f"{score:.3f}", "tone": "neutral"})

    platform = str(cr.get("platform") or "").strip()
    if platform:
        rows.append({
            "label": "Platform",
            "value": platform,
            "tone": "positive" if cr.get("platform_match") else "neutral",
        })

    target = str(cr.get("target_system") or "").strip()
    if target:
        rows.append({
            "label": "Target System",
            "value": target,
            "tone": "positive" if cr.get("target_system_match") else "neutral",
        })

    title = str(cr.get("title") or "").strip()
    if title:
        rows.append({"label": "Change Cycle", "value": title})

    description = str(cr.get("description") or "").strip()
    if description:
        rows.append({"label": "Description", "value": description, "wide": True})

    return rows


def reference_options_from_baseline(baseline_crs: Optional[dict]) -> list[dict]:
    """
    node_7 populates baseline_crs.cr_1..cr_5. Render each as a radio row with the
    platform as the right-hand badge (the 'Galaxy' pill in the design), expandable
    to the CR's own data so the user can inspect a candidate before choosing it.

    Slots carrying an `error` are skipped — node_7 writes placeholder rows with
    fabricated object_ids on embedding failure, and those must never be offered
    to a user as if they were real change requests.
    """
    out: list[dict] = []
    for slot in ("cr_1", "cr_2", "cr_3", "cr_4", "cr_5"):
        cr = (baseline_crs or {}).get(slot)
        if not isinstance(cr, dict) or cr.get("error"):
            continue
        oid = str(cr.get("object_id") or "").strip()
        if not oid:
            continue
        details = _cr_detail_rows(cr)
        row: dict[str, Any] = {
            "label": f"CR ID {oid}",
            "value": oid,
            "badge": str(cr.get("platform") or "").strip() or None,
        }
        # Only attach when there is something to show — an empty list would give
        # the row a disclosure control that expands to nothing.
        if details:
            row["details"] = details
        out.append(row)
    return out


# ─────────────────────────────────────────────────────────────────────────────
# Contract export — `python -m agui.ui_contract` dumps this for the platform team
# ─────────────────────────────────────────────────────────────────────────────
EXAMPLES: dict[str, dict[str, Any]] = {
    CR_MODE_CHOICE: cr_mode_choice(),
    FEATURE_COMING_SOON: feature_coming_soon(),
    CR_INTAKE_FORM: cr_intake_form(platforms=["HMD", "TIME", "Back to basics"]),
    TEMPLATE_OR_CR_PICKER: template_or_cr_picker(
        template_options=["Temp45678", "Temp45679"],
        reference_options=reference_options_from_baseline({
            "cr_1": {
                "object_id": "654678", "ranking_score": 0.912,
                "platform": "Galaxy", "platform_match": True,
                "target_system": "PJS 0021237113", "target_system_match": False,
                "title": "GAI_4_Tier_ECC_Landscape",
                "description": "Config change to the treasury posting rules.",
            },
        }),
    ),
    CYCLE_ID_PICKER: cycle_id_picker(
        message=(
            "I've analyzed your Platform, Target System, and Change details. "
            "Please select among the following deployment cycles available for this project."
        ),
        options=[{"label": "GAI_4_Tier_ECC_Landscape", "value": "0000012345"}],
    ),
    DRAFT_REVIEW: draft_review(
        sections=sections_from_field_groups({
            "Details": [{"key": "zzfld00000v_cus", "label": "Risk", "value": "Low"}],
        }),
        confirm_text="These inputs will raise a change request for CR ID 45678987.",
    ),
    FIELD_PROMPT: field_prompt(
        message="Which platform is this change for?",
        options=[{"label": "HMD", "value": "HMD"}],
    ),
    SUBMISSION_RESULT: submission_result(
        status="success", message="Successfully submitted.", cr_id="45678987"
    ),
}


def contract_document() -> dict[str, Any]:
    return {
        "contract_version": CONTRACT_VERSION,
        "components": {
            name: {"props_schema": PROP_SCHEMAS[name], "example": EXAMPLES[name]["props"]}
            for name in COMPONENT_NAMES
        },
    }


if __name__ == "__main__":  # pragma: no cover
    import json
    print(json.dumps(contract_document(), indent=2))
