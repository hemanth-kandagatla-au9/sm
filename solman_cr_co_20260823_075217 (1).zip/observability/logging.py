"""
structured logging with per-request/per-task context.

- set_request_context(session_id, wwid) / get_request_context() — per-request
- set_task_context(task_id)                                     — per-task
- configure_logging(log_file)                                   — call once at startup

LOG_FORMAT=json emits one JSON line per record (CloudWatch Logs Insights);
LOG_FORMAT=text is human-readable for local dev. Every record is stamped with
session_id, wwid, task_id, and OTel trace/span IDs.
"""
from __future__ import annotations

import contextvars
import json
import logging
import os
import sys

from opentelemetry import trace as _otel_trace

_ctx_session_id: contextvars.ContextVar[str] = contextvars.ContextVar("session_id", default="")
_ctx_wwid: contextvars.ContextVar[str] = contextvars.ContextVar("wwid", default="")
_ctx_task_id: contextvars.ContextVar[str] = contextvars.ContextVar("task_id", default="")

_SERVICE_NAME: str = os.environ.get("OTEL_SERVICE_NAME", "")


def set_request_context(session_id: str, wwid: str = "") -> None:
    """Bind session_id and wwid for the current async task / thread.
    Also stamps the active OTel span with ``session.id``
    """
    _ctx_session_id.set(session_id)
    _ctx_wwid.set(wwid)

    span = _otel_trace.get_current_span()
    if span.get_span_context().is_valid:
        span.set_attribute("session.id", session_id)


def set_task_context(task_id: str) -> None:
    """Bind task_id for the current async task / thread."""
    _ctx_task_id.set(task_id)


def get_request_context() -> tuple[str, str]:
    """Return ``(session_id, wwid)`` bound to the current request."""
    return _ctx_session_id.get(), _ctx_wwid.get()


class ContextualFilter(logging.Filter):
    """Stamps every LogRecord with session_id, wwid, and OTEL trace fields."""

    def filter(self, record: logging.LogRecord) -> bool:
        record.session_id = _ctx_session_id.get()
        record.wwid = _ctx_wwid.get()
        record.task_id = _ctx_task_id.get()

        span = _otel_trace.get_current_span()
        ctx = span.get_span_context()
        if ctx.is_valid:
            record.otelTraceID = format(ctx.trace_id, "032x")
            record.otelSpanID = format(ctx.span_id, "016x")
            record.otelTraceSampled = str(ctx.trace_flags.sampled).lower()
        else:
            record.otelTraceID = ""
            record.otelSpanID = ""
            record.otelTraceSampled = ""

        record.otelServiceName = _SERVICE_NAME
        return True


class JsonFormatter(logging.Formatter):
    """Emits each log record as a single JSON line."""

    def format(self, record: logging.LogRecord) -> str:
        entry: dict = {
            "timestamp": self.formatTime(record, self.datefmt),
            "level": record.levelname,
            "logger": record.name,
            "session_id": getattr(record, "session_id", ""),
            "wwid": getattr(record, "wwid", ""),
            "task_id": getattr(record, "task_id", ""),
            "trace_id": getattr(record, "otelTraceID", ""),
            "span_id": getattr(record, "otelSpanID", ""),
            "trace_sampled": getattr(record, "otelTraceSampled", ""),
            "service": getattr(record, "otelServiceName", ""),
            "message": record.getMessage(),
        }
        if record.exc_info:
            entry["exception"] = self.formatException(record.exc_info)
        return json.dumps(entry, ensure_ascii=False)


def configure_logging(log_file: str) -> None:
    """Configure the root logger with the contextual filter and chosen formatter."""

    log_format = os.environ.get("LOG_FORMAT", "text").lower()
    contextual_filter = ContextualFilter()

    if log_format == "json":
        formatter: logging.Formatter = JsonFormatter()
    else:
        formatter = logging.Formatter(
            "%(asctime)s [%(levelname)s] %(name)s"
            " [session=%(session_id)s wwid=%(wwid)s task_id=%(task_id)s"
            " trace_id=%(otelTraceID)s span_id=%(otelSpanID)s]: %(message)s"
        )

    console_handler = logging.StreamHandler(sys.stderr)
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(formatter)
    console_handler.addFilter(contextual_filter)

    file_handler = logging.FileHandler(log_file, encoding="utf-8")
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(formatter)
    file_handler.addFilter(contextual_filter)

    logging.root.setLevel(logging.INFO)
    logging.root.addHandler(console_handler)
    logging.root.addHandler(file_handler)


def get_logger(name: str) -> logging.Logger:
    """Return a stdlib logger by name."""
    return logging.getLogger(name)
