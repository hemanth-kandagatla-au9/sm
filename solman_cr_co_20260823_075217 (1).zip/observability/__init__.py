"""
observability — structured logging + OpenTelemetry helpers for the CR agent.

Submodules:
  observability.logging        — session/task-scoped log context, JSON formatter
  observability.tracing         — span helpers + LangGraph node/edge tracing
  observability.token_tracking — per-call LLM token/cost metrics + accumulator
"""

from observability.logging import (
    configure_logging,
    set_request_context,
    set_task_context,
    get_request_context,
    get_logger,
)

from observability.tracing import (
    BUSINESS_TRACE_FIELDS,
    get_business_trace_values,
    set_span_attributes,
    attach_business_baggage,
    log_business_trace_context,
    patch_otel_callback_handler,
    trace_node,
    trace_edge,
    derive_task_status,
)

from observability.token_tracking import (
    TokenCostCallbackHandler,
    reset_token_accumulator,
    get_token_accumulator,
    get_meter,
    get_env_dimension,
)

__all__ = [
    # logging
    "configure_logging",
    "set_request_context",
    "set_task_context",
    "get_request_context",
    "get_logger",
    # tracing
    "BUSINESS_TRACE_FIELDS",
    "get_business_trace_values",
    "set_span_attributes",
    "attach_business_baggage",
    "log_business_trace_context",
    "patch_otel_callback_handler",
    "trace_node",
    "trace_edge",
    "derive_task_status",
    # token/cost tracking
    "TokenCostCallbackHandler",
    "reset_token_accumulator",
    "get_token_accumulator",
    "get_meter",
    "get_env_dimension",
]
