"""
per-call LLM token/cost capture.

Records input/output token counts + estimated USD cost per LLM call via
TokenCostCallbackHandler, exposes a per-request accumulator, and provides
get_env_dimension() so every OTel metric carries a low-cardinality
`environment` dimension.
"""
from __future__ import annotations

import contextvars
import os
from typing import Any, Optional

from opentelemetry import metrics, trace
from langchain_core.callbacks import BaseCallbackHandler

import logging

from config.pricing import estimate_cost

logger = logging.getLogger(__name__)

# ── Environment dimension ──────────────────────────────
# Lets multiple deployments (dev/qa/prod/etc.) share the same CloudWatch
# namespace without their datapoints interleaving into the same time series
ENVIRONMENT: str = os.environ.get("ENVIRONMENT", "unknown")


def get_env_dimension() -> dict[str, str]:
    """Return the {"environment": ...} attribute dict to merge into every metric call."""
    return {"environment": ENVIRONMENT}

# ── Per-request token/cost accumulator (contextvar — isolated per async task) ─
_ctx_token_totals: contextvars.ContextVar[dict[str, float]] = contextvars.ContextVar(
    "token_totals", default=None,
)


def _empty_totals() -> dict[str, float]:
    return {
        "input_tokens": 0,
        "output_tokens": 0,
        "total_tokens": 0,
        "cost_usd": 0.0,
        "call_count": 0,
    }


def reset_token_accumulator() -> None:
    """Start a fresh, zeroed accumulator for the current request/task."""
    _ctx_token_totals.set(_empty_totals())


def get_token_accumulator() -> dict[str, float]:
    """Return the current accumulator totals (a copy; safe to read repeatedly)."""
    totals = _ctx_token_totals.get()
    if totals is None:
        totals = _empty_totals()
        _ctx_token_totals.set(totals)
    return dict(totals)


def _add_to_accumulator(input_tokens: int, output_tokens: int, cost_usd: float) -> None:
    totals = _ctx_token_totals.get()
    if totals is None:
        totals = _empty_totals()
    totals["input_tokens"] += input_tokens
    totals["output_tokens"] += output_tokens
    totals["total_tokens"] += input_tokens + output_tokens
    totals["cost_usd"] += cost_usd
    totals["call_count"] += 1
    _ctx_token_totals.set(totals)


# ── OTel meter (shared with other observability modules) ─────────────
_meter = metrics.get_meter(__name__)


def get_meter():
    """Return the shared meter so other modules can reuse it."""
    return _meter


def _extract_usage(response: Any) -> tuple[int, int, str]:
    """Best-effort extraction of (input_tokens, output_tokens, model) from an LLMResult."""
    input_tokens = 0
    output_tokens = 0
    model = ""

    llm_output = getattr(response, "llm_output", None) or {}
    model = llm_output.get("model_name") or llm_output.get("model") or ""

    generations = getattr(response, "generations", None) or []
    for gen_list in generations:
        for gen in gen_list:
            message = getattr(gen, "message", None)
            usage_metadata = getattr(message, "usage_metadata", None) if message else None
            if usage_metadata:
                input_tokens += usage_metadata.get("input_tokens", 0) or 0
                output_tokens += usage_metadata.get("output_tokens", 0) or 0
                if not model:
                    response_metadata = getattr(message, "response_metadata", None) or {}
                    model = response_metadata.get("model_name") or response_metadata.get("model") or model

    if not input_tokens and not output_tokens:
        # Fallback: OpenAI-style dict shape on llm_output
        token_usage = llm_output.get("token_usage") or {}
        input_tokens = token_usage.get("prompt_tokens", 0) or 0
        output_tokens = token_usage.get("completion_tokens", 0) or 0

    if not model:
        from config.config import MODEL_NAME
        model = MODEL_NAME

    return input_tokens, output_tokens, model


class TokenCostCallbackHandler(BaseCallbackHandler):
    """
    LangChain callback that records token usage + estimated cost per LLM call.
    """

    def on_llm_end(self, response: Any, **kwargs: Any) -> None:
        try:
            input_tokens, output_tokens, model = _extract_usage(response)
            if not input_tokens and not output_tokens:
                return 

            cost_usd = estimate_cost(model, input_tokens, output_tokens)

            span = trace.get_current_span()
            if span is not None and span.is_recording():
                span.set_attribute("gen_ai.usage.input_tokens", input_tokens)
                span.set_attribute("gen_ai.usage.output_tokens", output_tokens)
                span.set_attribute("gen_ai.usage.cost_usd", cost_usd)
                span.set_attribute("gen_ai.request.model", model)

            _add_to_accumulator(input_tokens, output_tokens, cost_usd)
        except Exception:
            logger.exception("TokenCostCallbackHandler.on_llm_end failed")

    def on_llm_error(self, error: BaseException, **kwargs: Any) -> None:
        logger.warning("LLM call errored — token usage not recorded for this call: %s", error)
