"""
OTel span helpers + LangGraph node/edge tracing.

- get_business_trace_values / set_span_attributes / attach_business_baggage /
  log_business_trace_context — business-trace context on the root span
- derive_task_status(submission_result)   — shared "ended_without_submission"/"success"/"failed" label
- trace_node(name, fn) / trace_edge(name, fn) — wrap LangGraph nodes/edges in
  node.*/edge.* spans, tag app.task.id, and accumulate per-call token/cost deltas
"""
from __future__ import annotations

import functools
import importlib
import logging
from typing import Any, Callable, Optional

from opentelemetry import baggage, trace
from opentelemetry.context import attach
from opentelemetry.trace import Status, StatusCode

from observability.token_tracking import get_token_accumulator
from observability.logging import set_task_context

_logger = logging.getLogger(__name__)

_OTEL_HANDLER_CANDIDATES = [
    ("amazon.opentelemetry.distro.instrumentation.langchain.callback_handler", "OpenTelemetryCallbackHandler"),
]

# Fields extracted from the request payload
BUSINESS_TRACE_FIELDS: dict[str, str] = {
    "project_id":        "app.project_id",
    "agent_family_name": "app.agent_family_name",
    "workflow_type_id":  "app.workflow_type_id",
    "active_role_id":    "app.active_role_id",
    "chat_workflow_id":  "app.chat_workflow_id",
}


def get_business_trace_values(payload: dict[str, Any]) -> dict[str, str]:
    """Return non-empty business-trace fields extracted from payload."""
    values: dict[str, str] = {}
    for payload_key, trace_key in BUSINESS_TRACE_FIELDS.items():
        value = payload.get(payload_key)
        if value is not None and value != "":
            values[trace_key] = str(value)
    return values


def set_span_attributes(span: Any, attributes: dict[str, str]) -> None:
    """Bulk-set a dict of key/value pairs as attributes on span."""
    for key, value in attributes.items():
        span.set_attribute(key, value)


def derive_task_status(submission_result: Optional[dict]) -> str:
    """
    Derive the `app.task.status` label from a task's `submission_result` state field.
    Only call this once the task has actually ended (see main.py's _is_still_waiting check).
    """
    if submission_result is None:
        return "ended_without_submission"
    if submission_result.get("success"):
        return "success"
    return "failed"


def attach_business_baggage(values: dict[str, str]):
    """Propagate values as OTel baggage so they flow into all child spans."""
    ctx = None
    for trace_key, value in values.items():
        ctx = baggage.set_baggage(trace_key, value, context=ctx)
    if ctx is None:
        return None
    return attach(ctx)


def log_business_trace_context(
    logger: logging.Logger,
    payload: dict[str, Any],
    session_id: str,
    wwid: str,
) -> None:
    """
    Emit the business-trace context as both a log line and a span event.
    """
    project_id        = payload.get("project_id")
    agent_family_name = payload.get("agent_family_name")
    workflow_type_id  = payload.get("workflow_type_id")
    active_role_id    = payload.get("active_role_id")
    chat_workflow_id  = payload.get("chat_workflow_id")

    logger.info(
        "Business trace context: project_id=%s, agent_family_name=%s, "
        "workflow_type_id=%s, active_role_id=%s, chat_workflow_id=%s, "
        "session_id=%s, wwid=%s",
        project_id, agent_family_name, workflow_type_id,
        active_role_id, chat_workflow_id, session_id, wwid,
    )

    span = trace.get_current_span()
    if span and span.is_recording():
        event_attrs: dict[str, str] = {"session_id": session_id, "wwid": wwid}
        if project_id is not None:
            event_attrs["project_id"] = str(project_id)
        if agent_family_name is not None:
            event_attrs["agent_family_name"] = str(agent_family_name)
        if workflow_type_id is not None:
            event_attrs["workflow_type_id"] = str(workflow_type_id)
        if active_role_id is not None:
            event_attrs["active_role_id"] = str(active_role_id)
        if chat_workflow_id is not None:
            event_attrs["chat_workflow_id"] = str(chat_workflow_id)
        span.add_event("business_trace_context", attributes=event_attrs)


def patch_otel_callback_handler() -> None:
    """Patch the missing HITL callbacks on OpenTelemetryCallbackHandler."""

    handler_class = None
    for module_path, class_name in _OTEL_HANDLER_CANDIDATES:
        try:
            mod = importlib.import_module(module_path)
            candidate = getattr(mod, class_name, None)
            if candidate is not None:
                handler_class = candidate
                _logger.debug("patch_otel_callback_handler: found %s in %s", class_name, module_path)
                break
        except ImportError:
            continue

    if handler_class is None:
        _logger.warning(
            "patch_otel_callback_handler: OpenTelemetryCallbackHandler not found "
            "in any known location — HITL callback patch skipped. "
            "Tried: %s", [m for m, _ in _OTEL_HANDLER_CANDIDATES]
        )
        return

    patched = []

    if not hasattr(handler_class, "on_interrupt"):
        def on_interrupt(self, interrupt=None, **kwargs: Any) -> None:
            span = trace.get_current_span()
            if span and span.is_recording():
                span.add_event(
                    "agent.interrupted",
                    {"interrupt.value": str(interrupt)[:500] if interrupt else ""},
                )
        handler_class.on_interrupt = on_interrupt
        patched.append("on_interrupt")

    if not hasattr(handler_class, "on_resume"):
        def on_resume(self, input=None, **kwargs: Any) -> None:
            span = trace.get_current_span()
            if span and span.is_recording():
                span.add_event(
                    "agent.resumed",
                    {"resume.input": str(input)[:200] if input else ""},
                )
        handler_class.on_resume = on_resume
        patched.append("on_resume")

    if patched:
        _logger.info("patch_otel_callback_handler: patched %s on %s", patched, handler_class.__qualname__)
    else:
        _logger.debug("patch_otel_callback_handler: nothing to patch, methods already present")


_tracer = trace.get_tracer(__name__)


def trace_node(name: str, fn: Callable) -> Callable:
    """
    Wrap a LangGraph node function with an OTel span ("node.<name>").
    """
    @functools.wraps(fn)
    def wrapper(*args, **kwargs):
        state = args[0] if args else kwargs.get("state")
        task_id = state.get("task_id", "") if isinstance(state, dict) else ""
        if task_id:
            set_task_context(task_id)

        with _tracer.start_as_current_span(
            f"node.{name}", record_exception=False, set_status_on_exception=False,
        ) as span:
            span.set_attribute("app.node_name", name)
            span.set_attribute("app.task.id", task_id)
            before = get_token_accumulator()
            try:
                result = fn(*args, **kwargs)
            except Exception as exc:
                if "Interrupt" in type(exc).__name__:
                    span.add_event("graph.interrupt", attributes={"exception.message": str(exc)})
                else:
                    span.record_exception(exc)
                    span.set_status(Status(StatusCode.ERROR, str(exc)))
                raise
            finally:
                after = get_token_accumulator()
                delta_input_tokens = after["input_tokens"] - before["input_tokens"]
                delta_output_tokens = after["output_tokens"] - before["output_tokens"]
                delta_cost_usd = after["cost_usd"] - before["cost_usd"]
                span.set_attribute("gen_ai.usage.input_tokens", delta_input_tokens)
                span.set_attribute("gen_ai.usage.output_tokens", delta_output_tokens)
                span.set_attribute("gen_ai.usage.cost_usd", delta_cost_usd)
            if isinstance(result, dict):
                result = {
                    **result,
                    "task_input_tokens": delta_input_tokens,
                    "task_output_tokens": delta_output_tokens,
                    "task_cost_usd": delta_cost_usd,
                }
            return result
    return wrapper


def trace_edge(name: str, fn: Callable) -> Callable:
    """
    Wrap a LangGraph conditional-edge routing function with an OTel span ("edge.<name>")
    """
    @functools.wraps(fn)
    def wrapper(*args, **kwargs):
        state = args[0] if args else kwargs.get("state")
        task_id = state.get("task_id", "") if isinstance(state, dict) else ""
        if task_id:
            set_task_context(task_id)

        with _tracer.start_as_current_span(
            f"edge.{name}", record_exception=False, set_status_on_exception=False,
        ) as span:
            span.set_attribute("app.node_name", name)
            span.set_attribute("app.task.id", task_id)
            before = get_token_accumulator()
            try:
                result = fn(*args, **kwargs)
            except Exception as exc:
                if "Interrupt" in type(exc).__name__:
                    span.add_event("graph.interrupt", attributes={"exception.message": str(exc)})
                else:
                    span.record_exception(exc)
                    span.set_status(Status(StatusCode.ERROR, str(exc)))
                raise
            finally:
                after = get_token_accumulator()
                span.set_attribute(
                    "gen_ai.usage.input_tokens",
                    after["input_tokens"] - before["input_tokens"],
                )
                span.set_attribute(
                    "gen_ai.usage.output_tokens",
                    after["output_tokens"] - before["output_tokens"],
                )
                span.set_attribute(
                    "gen_ai.usage.cost_usd",
                    after["cost_usd"] - before["cost_usd"],
                )
            return result
    return wrapper
