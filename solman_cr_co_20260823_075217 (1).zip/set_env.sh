#!/usr/bin/env bash
# set_env.sh — Export all environment variables for local EC2 dev/testing.
# Usage: source set_env.sh
#
# SSM-backed secrets (AZURE_OPENAI_API_KEY, NEO4J_PASSWORD, etc.) hold
# SSM parameter *names* here. ssm_bootstrap.py resolves them to real values
# at runtime when RESOLVE_SSM_PARAMS=true.

# ── Server port (8080 is taken by another process on EC2) ────────────────────
export PORT=8081
export AGUI_PORT=8084

# ── Logging (avoid /tmp — may contain a stale file owned by another user) ────
export AGENT_LOG_DIR="$HOME/agent_agui/logs"
mkdir -p "$AGENT_LOG_DIR"

# ── Control flags ─────────────────────────────────────────────────────────────
export USE_AGENTCORE_MEMORY=true
export RESOLVE_SSM_PARAMS=true
export AWS_REGION=us-east-1

# ── Memory ────────────────────────────────────────────────────────────────────
export MEMORY_ID=crco_dev-OZOs4sHuv7

# ── Azure OpenAI (non-secret) ─────────────────────────────────────────────────
export AZURE_OPENAI_ENDPOINT=https://genaiapimna.jnj.com/openai-gpt-5
export AZURE_OPENAI_API_VERSION=2024-10-21
export AZURE_OPENAI_DEPLOYMENT=gpt-5.4-mini-global
export AZURE_OPENAI_EMBEDDING_ENDPOINT=https://genaiapimna.jnj.com/openai-embeddings/openai/deployments/text-embedding-3-large/embeddings?api-version=2024-10-21-preview
export AZURE_OPENAI_EMBEDDING_API_VERSION=2024-10-21
export AZURE_OPENAI_EMBEDDING_DEPLOYMENT=text-embedding-3-large

# ── Neo4j (non-secret) ────────────────────────────────────────────────────────
export NEO4J_URI=bolt://awseucnval0003.jnj.com:7687
export NEO4J_DATABASE=neo4j

# ── Other non-secret ──────────────────────────────────────────────────────────
export JIRA_BASE_URL=https://solman-dev.jnj.com/sap/opu/odata/sap/ZJIRA_SRV
export JIRA_RESOURCE_PATH=JIRAIssueSet
export SOLMAN_READ_BASE_URL=https://solman-dev.jnj.com
export SOLMAN_ODATA_PATH=/sap/opu/odata/sap/ZCHM_RFC_SRV/ChangeRequestSet
export SOLMAN_READ_VERIFY_SSL=false
export SOP_PATH=sop_instructions.txt

# ── SSM-backed Solman QA read credentials (resolved at startup) ─────────────────
export SOLMAN_READ_USERNAME="JJYY-CRCO-DEV-SOLMAN_READ_USERNAME"
export SOLMAN_READ_PASSWORD="JJYY-CRCO-DEV-SOLMAN_READ_PASSWORD"

# ── SSM-backed JIRA QA credentials (resolved at startup) ───────────────────────
export JIRA_USERNAME="JJYY-CRCO-DEV-SOLMAN_READ_USERNAME"
export JIRA_PASSWORD="JJYY-CRCO-DEV-SOLMAN_READ_PASSWORD"

# ── SSM-backed secrets (ssm_bootstrap resolves these to real values at startup) ─
export AZURE_OPENAI_API_KEY="JJYY-CRCO-DEV-AZURE_OPENAI_API_KEY"
export AZURE_OPENAI_EMBEDDING_API_KEY="JJYY-CRCO-DEV-AZURE_OPENAI_EMBEDDING_API_KEY"
export NEO4J_PASSWORD="JJYY-CRCO-DEV-NEO4J-PASSWORD"
export NEO4J_USER="JJYY-CRCO-DEV-NEO4J_USER"
export OAUTH_CLIENT_ID="JJYY-CRCO-DEV-OAUTH_CLIENT_ID"
export OAUTH_SCOPE="JJYY-CRCO-DEV-OAUTH_SCOPE"
export OAUTH_TOKEN_URL="JJYY-CRCO-DEV-OAUTH_TOKEN_URL"
export SOLMAN_API_KEY="JJYY-CRCO-DEV-SOLMAN_API_KEY"
export SOLMAN_BASE_URL="JJYY-CRCO-DEV-SOLMAN_BASE_URL"

# ── Frontend build-time config (frontend-baseline, Next.js) ──────────────────
export AGUI_BACKEND_URL="http://localhost:${AGUI_PORT}/copilotkit"
export AGUI_API_BASE="http://localhost:${AGUI_PORT}"
export AGUI_AGENT_NAME="local_agent"

echo "Environment variables set for cr_agent (dev endpoints)"
echo "  main.py    -> :$PORT"
echo "  AG-UI host -> :$AGUI_PORT"
