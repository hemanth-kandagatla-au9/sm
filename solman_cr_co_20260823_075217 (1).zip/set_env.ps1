# set_env.ps1 — PowerShell equivalent of set_env.sh, for Windows dev/testing.
#
#   usage:   . .\set_env.ps1          <-- note the leading dot + space
#
# The dot is required. Running `.\set_env.ps1` starts a child process and the
# variables vanish when it exits; dot-sourcing runs it in your current session
# so the variables stick.
#
# SSM-backed secrets hold SSM parameter *names* here. ssm_bootstrap.py resolves
# them to real values at startup when RESOLVE_SSM_PARAMS=true, which needs AWS
# credentials available to this session (see RUNNING_ON_WINDOWS.md).

# ── Ports ─────────────────────────────────────────────────────────────────────
# PORT is main.py (the AgentCore runtime). AGUI_PORT is the AG-UI host. They are
# separate on purpose so both can run at once.
$env:PORT      = "8081"
$env:AGUI_PORT = "8084"

# ── Control flags ─────────────────────────────────────────────────────────────
$env:USE_AGENTCORE_MEMORY = "true"
$env:RESOLVE_SSM_PARAMS   = "true"
$env:AWS_REGION           = "us-east-1"

# ── Memory ────────────────────────────────────────────────────────────────────
$env:MEMORY_ID = "crco_dev-OZOs4sHuv7"

# ── Azure OpenAI (non-secret) ─────────────────────────────────────────────────
$env:AZURE_OPENAI_ENDPOINT              = "https://genaiapimna.jnj.com/openai-gpt-5"
$env:AZURE_OPENAI_API_VERSION           = "2024-10-21"
$env:AZURE_OPENAI_DEPLOYMENT            = "gpt-5.4-mini-global"
$env:AZURE_OPENAI_EMBEDDING_ENDPOINT    = "https://genaiapimna.jnj.com/openai-embeddings/openai/deployments/text-embedding-3-large/embeddings?api-version=2024-10-21-preview"
$env:AZURE_OPENAI_EMBEDDING_API_VERSION = "2024-10-21"
$env:AZURE_OPENAI_EMBEDDING_DEPLOYMENT  = "text-embedding-3-large"

# ── Neo4j (non-secret) ────────────────────────────────────────────────────────
$env:NEO4J_URI      = "bolt://awseucnval0003.jnj.com:7687"
$env:NEO4J_DATABASE = "neo4j"

# ── Other non-secret ──────────────────────────────────────────────────────────
$env:JIRA_BASE_URL           = "https://solman-dev.jnj.com/sap/opu/odata/sap/ZJIRA_SRV"
$env:JIRA_RESOURCE_PATH      = "JIRAIssueSet"
$env:SOLMAN_READ_BASE_URL    = "https://solman-dev.jnj.com"
$env:SOLMAN_ODATA_PATH       = "/sap/opu/odata/sap/ZCHM_RFC_SRV/ChangeRequestSet"
$env:SOLMAN_READ_VERIFY_SSL  = "false"
$env:SOP_PATH                = "sop_instructions.txt"

# ── SSM-backed Solman read credentials (resolved at startup) ──────────────────
$env:SOLMAN_READ_USERNAME = "JJYY-CRCO-DEV-SOLMAN_READ_USERNAME"
$env:SOLMAN_READ_PASSWORD = "JJYY-CRCO-DEV-SOLMAN_READ_PASSWORD"

# ── SSM-backed JIRA credentials (resolved at startup) ─────────────────────────
$env:JIRA_USERNAME = "JJYY-CRCO-DEV-SOLMAN_READ_USERNAME"
$env:JIRA_PASSWORD = "JJYY-CRCO-DEV-SOLMAN_READ_PASSWORD"

# ── SSM-backed secrets ────────────────────────────────────────────────────────
$env:AZURE_OPENAI_API_KEY           = "JJYY-CRCO-DEV-AZURE_OPENAI_API_KEY"
$env:AZURE_OPENAI_EMBEDDING_API_KEY = "JJYY-CRCO-DEV-AZURE_OPENAI_EMBEDDING_API_KEY"
$env:NEO4J_PASSWORD                 = "JJYY-CRCO-DEV-NEO4J-PASSWORD"
$env:NEO4J_USER                     = "JJYY-CRCO-DEV-NEO4J_USER"
$env:OAUTH_CLIENT_ID                = "JJYY-CRCO-DEV-OAUTH_CLIENT_ID"
$env:OAUTH_SCOPE                    = "JJYY-CRCO-DEV-OAUTH_SCOPE"
$env:OAUTH_TOKEN_URL                = "JJYY-CRCO-DEV-OAUTH_TOKEN_URL"
$env:SOLMAN_API_KEY                 = "JJYY-CRCO-DEV-SOLMAN_API_KEY"
$env:SOLMAN_BASE_URL                = "JJYY-CRCO-DEV-SOLMAN_BASE_URL"

# ── Frontend build-time config (read by Vite) ─────────────────────────────────
$env:AGUI_RUNTIME_PORT     = "8006"
$env:FRONTEND_PORT         = "8005"
$env:AGUI_BACKEND_URL      = "http://localhost:$($env:AGUI_PORT)/copilotkit"
$env:VITE_AGUI_API_BASE    = "http://localhost:$($env:AGUI_PORT)"
$env:VITE_AGUI_RUNTIME_URL = "http://localhost:$($env:AGUI_RUNTIME_PORT)/api/copilotkit"

Write-Host "Environment variables set for cr_agent (dev endpoints)" -ForegroundColor Green
Write-Host "  main.py    -> :$($env:PORT)"
Write-Host "  AG-UI host -> :$($env:AGUI_PORT)"
Write-Host "  bridge     -> :$($env:AGUI_RUNTIME_PORT)"
Write-Host "  frontend   -> :$($env:FRONTEND_PORT)"

if (-not (Test-Path $env:SOP_PATH)) {
    Write-Host ""
    Write-Host "WARNING: SOP_PATH points at '$($env:SOP_PATH)' which does not exist here." -ForegroundColor Yellow
    Write-Host "         The SOP-8794 scope check will fall back to the model's general" -ForegroundColor Yellow
    Write-Host "         knowledge instead of the actual SOP text, silently. Copy the file" -ForegroundColor Yellow
    Write-Host "         into the repo root before testing scope behaviour." -ForegroundColor Yellow
}
