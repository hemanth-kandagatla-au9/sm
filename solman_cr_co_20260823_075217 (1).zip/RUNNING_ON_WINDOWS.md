# Running the AG-UI stack on a Windows VM (VS Code)

## TL;DR

```powershell
# once
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt

# every time
. .\set_env.ps1      # leading dot matters
.\run_agui.ps1
```

Then open **http://localhost:8005**.

In VS Code: **Ctrl+Shift+P → Tasks: Run Task → `AG-UI: Run all`** does the same thing (it dot-sources `set_env.ps1` for you).

---

## 1. Prerequisites

| | Version | Check |
|---|---|---|
| Python | 3.10+ | `python --version` |
| Node.js | 18+ (20 LTS recommended) | `node --version` |
| VS Code | any recent | — |

Install the recommended extensions when VS Code prompts (`.vscode/extensions.json` lists them) — you need at minimum **Python**, **Pylance**, and **PowerShell**.

If `python` opens the Microsoft Store instead of running, use the launcher (`py -3.11`) or turn off the App Execution Alias: *Settings → Apps → Advanced app settings → App execution aliases → python.exe off*.

## 2. One-time setup

Open the repo folder in VS Code, then in the integrated terminal (PowerShell):

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass

python -m venv .venv
.\.venv\Scripts\Activate.ps1

pip install --upgrade pip
pip install -r requirements.txt
```

Node dependencies install themselves on first run of `run_agui.ps1`, or do it up front:

```powershell
npm install --prefix frontend
npm install --prefix agui_runtime
```

Or run the VS Code task **`AG-UI: Install all deps`**, which does all of the above.

Pick the interpreter so Pylance resolves imports: **Ctrl+Shift+P → Python: Select Interpreter → `.\.venv\Scripts\python.exe`**.

## 3. Environment

`set_env.ps1` is the PowerShell translation of `set_env.sh`. **Dot-source it** — the leading dot is not optional:

```powershell
. .\set_env.ps1
```

Without the dot, PowerShell runs it in a child process and every variable disappears when that process exits.

### AWS credentials

`RESOLVE_SSM_PARAMS=true` means the secrets in `set_env.ps1` are *SSM parameter names*, resolved at startup. That needs AWS credentials in the session:

```powershell
aws configure           # or
$env:AWS_PROFILE = "your-profile"
```

Verify before starting:

```powershell
aws sts get-caller-identity
aws ssm get-parameter --name "JJYY-CRCO-DEV-NEO4J_USER" --with-decryption
```

If that second command fails, the agent will start and then fail on its first Neo4j or Azure call — with the literal parameter name used as the credential.

### Network reachability

The VM has to reach the internal endpoints. Worth checking before you debug anything else:

```powershell
Test-NetConnection solman-dev.jnj.com -Port 443
Test-NetConnection awseucnval0003.jnj.com -Port 7687
Test-NetConnection genaiapimna.jnj.com -Port 443
```

A Windows VM on a different network segment than the EC2 box may not have the same access. If Neo4j (7687) is unreachable the platform dropdown comes back empty and the intake form has nothing to select.

### `sop_instructions.txt`

`SOP_PATH=sop_instructions.txt` but **that file is not in the repo**. When it is missing, the SOP-8794 scope check silently substitutes the model's general knowledge for the actual SOP text — no error, no warning in the log. `set_env.ps1` prints a warning about this. Copy the file into the repo root before testing anything scope-related.

## 4. Running

### Option A — one task (usual)

**Ctrl+Shift+P → Tasks: Run Task → `AG-UI: Run all`**

Starts all three processes in a dedicated panel, waits for the backend to answer before starting the bridge, and stops everything on Ctrl+C.

### Option B — terminal

```powershell
. .\set_env.ps1
.\run_agui.ps1
```

Useful flags:

```powershell
.\run_agui.ps1 -SkipBridge          # frontend hits Python directly
.\run_agui.ps1 -AguiPort 9084       # different ports
.\run_agui.ps1 -NoInstall           # skip the npm install check
.\run_agui.ps1 -Python .\.venv\Scripts\python.exe
```

### Option C — three terminals

Sometimes easier when you're iterating on one piece. Tasks `AG-UI: Backend only`, `Bridge only`, `Frontend only`, or by hand:

```powershell
# terminal 1
. .\set_env.ps1; python agui_server.py

# terminal 2
. .\set_env.ps1; cd agui_runtime; npm start

# terminal 3
. .\set_env.ps1; cd frontend; npm run dev -- --host
```

## 5. Debugging

**F5 → `AG-UI: Debug backend + bridge`** starts the Python host under debugpy and the Node bridge together. Start the frontend separately (`AG-UI: Frontend only`), then set breakpoints in `agents/nodes/*.py` and click through the real UI — execution stops inside the graph.

`justMyCode: false` is set, so you can also step into LangGraph and CopilotKit internals.

For the React side, `AG-UI: Debug frontend (Chrome)` attaches to the Vite dev server with source maps.

## 6. Ports

| Process | Port | Override |
|---|---|---|
| Vite frontend | 8005 | `FRONTEND_PORT` |
| CopilotKit bridge | 8006 | `AGUI_RUNTIME_PORT` |
| AG-UI backend | 8084 | `AGUI_PORT` |
| `main.py` (unchanged) | 8081 | `PORT` |

`agui_server.py` reads **`AGUI_PORT`, not `PORT`** — `set_env` sets `PORT=8081` for `main.py`, and sharing it would make the two collide.

Find whatever is holding a port:

```powershell
Get-NetTCPConnection -LocalPort 8084 -State Listen |
  Select-Object OwningProcess, @{n='Name';e={(Get-Process -Id $_.OwningProcess).ProcessName}}
```

## 7. Health checks

```powershell
Invoke-RestMethod http://localhost:8084/api/ui-contract | ConvertTo-Json -Depth 5
Invoke-RestMethod http://localhost:8006/health
Invoke-RestMethod "http://localhost:8084/api/platforms"
Invoke-RestMethod "http://localhost:8084/api/jira-lookup?jira_id=AAZM-11112"
```

The browser console also logs whether the frontend registry matches the backend contract in dev.

Logs: `.agui-logs\agui_server.log`, `agui_runtime.log`, `frontend.log` (plus `.err.log` for each).

```powershell
Get-Content .agui-logs\agui_server.log -Wait -Tail 50    # or task "AG-UI: Tail backend log"
```

## 8. Troubleshooting

**"running scripts is disabled on this system"**
```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```
Session-scoped, no admin needed, resets when you close the terminal.

**Variables missing after `set_env.ps1`** — you ran `.\set_env.ps1` instead of `. .\set_env.ps1`.

**Backend exits immediately** — check `.agui-logs\agui_server.err.log`. Usually a missing pip dependency (`pip install -r requirements.txt`) or SSM resolution failing (`aws sts get-caller-identity`).

**Platform dropdown empty / 503 from `/api/platforms`** — Neo4j unreachable. `Test-NetConnection awseucnval0003.jnj.com -Port 7687`. The endpoint deliberately returns 503 rather than an empty list, so this shows up as an error instead of looking like "no platforms exist".

**Frontend loads but the chat never responds** — the bridge isn't reaching the backend. `Invoke-RestMethod http://localhost:8006/health` shows what it's pointed at. If your CopilotKit version supports it, try `-SkipBridge`.

**"No renderer registered for X"** in a card — the agent emitted a component this build doesn't have. Compare `/api/ui-contract` against `frontend/src/agent-ui/registry.tsx`; the dev-mode console check reports the mismatch directly.

**npm install fails behind the proxy** — `frontend/.npmrc` exists for registry config; add proxy settings there or set `npm config set proxy`.

**Ctrl+C leaves a port held** — `run_agui.ps1` kills process trees on exit, but if something survives:
```powershell
Get-NetTCPConnection -LocalPort 8005,8006,8084 -State Listen |
  ForEach-Object { Stop-Process -Id $_.OwningProcess -Force }
```

## 9. Git Bash / WSL instead

If you'd rather use the bash scripts, they work unchanged under Git Bash or WSL:

```bash
source set_env.sh && ./run_agui.sh
```

Set VS Code's terminal to Git Bash (**Ctrl+Shift+P → Terminal: Select Default Profile**). Note that under WSL the services bind inside the WSL network namespace — usually still reachable at `localhost` from Windows, but `--host` on the Vite server (already set) matters there.
