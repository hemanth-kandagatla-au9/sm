from __future__ import annotations

import os
from functools import lru_cache
from typing import Type, TypeVar

from langchain_openai import AzureChatOpenAI
from pydantic import BaseModel

from config.config import (
    AZURE_OPENAI_API_KEY,
    AZURE_OPENAI_ENDPOINT,
    AZURE_OPENAI_API_VERSION,
    MODEL_NAME,
)

T = TypeVar("T", bound=BaseModel)


@lru_cache(maxsize=1)
def get_llm() -> AzureChatOpenAI:
    """
    Return the heavy LLM instance (GPT-5 or configured model).
    Used for complex tasks: draft building, semantic search, question answering.
    """
    return AzureChatOpenAI(
        azure_deployment=MODEL_NAME,
        azure_endpoint=AZURE_OPENAI_ENDPOINT,
        api_key=AZURE_OPENAI_API_KEY,
        api_version=AZURE_OPENAI_API_VERSION,
        streaming=True,
    )


@lru_cache(maxsize=1)
def get_llm_fast() -> AzureChatOpenAI:
    """
    Return the fast LLM instance.
    Uses the same endpoint as the main model until a separate fast endpoint
    is confirmed working. To enable a fast model, set CR_FAST_ENDPOINT,
    CR_FAST_API_KEY and CR_MODEL_FAST in .env AND ensure those env vars
    are not lingering in the shell session from a previous run.
    """
    # fast_endpoint = AZURE_OPENAI_ENDPOINT
    # fast_api_key  = AZURE_OPENAI_API_KEY
    # fast_model    = os.environ.get("CR_MODEL_FAST") or MODEL_NAME
    fast_endpoint = AZURE_OPENAI_ENDPOINT
    fast_api_key  = AZURE_OPENAI_API_KEY
    fast_model    = MODEL_NAME
    return AzureChatOpenAI(

        azure_deployment=fast_model,
        azure_endpoint=fast_endpoint,
        api_key=fast_api_key,
        api_version=AZURE_OPENAI_API_VERSION,
        streaming=True,
    )


def llm_with_output(schema: Type[T]) -> AzureChatOpenAI:
    """Return heavy LLM bound to produce structured output matching schema."""
    return get_llm().with_structured_output(schema, method="function_calling")


def llm_fast_with_output(schema: Type[T]) -> AzureChatOpenAI:
    """Return fast LLM bound to produce structured output matching schema."""
    return get_llm_fast().with_structured_output(schema, method="function_calling")