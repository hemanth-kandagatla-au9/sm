"""
Pydantic V2 schemas for all structured LLM outputs.

Uses ConfigDict to ensure compatibility with LangChain's
with_structured_output() which requires json_schema method support.
"""
from __future__ import annotations

from typing import List, Literal, Optional
from pydantic import BaseModel, Field, ConfigDict


class _Base(BaseModel):
    """All schemas inherit this to ensure LangChain structured output compatibility."""
    model_config = ConfigDict(
        populate_by_name=True,
        arbitrary_types_allowed=True,
    )


# ── Node 1: Extract field values ──────────────────────────────────────────────
class ExtractedField(_Base):
    given: bool = Field(description="Whether the user mentioned this field at all")
    value: str = Field(description="The raw value the user provided, empty string if not given")


class ExtractedFields(_Base):
    reason_for_change: ExtractedField
    description_of_change: ExtractedField
    additional_information: ExtractedField
    target_system: ExtractedField
    platform: ExtractedField
    template_id: ExtractedField
    cr_id: ExtractedField
    jira_id: ExtractedField


# ── Relevance check (Nodes 4, 9, 18) ─────────────────────────────────────────
class RelevanceCheck(_Base):
    is_relevant: bool = Field(
        description="True if the user message is relevant to the current CR workflow step"
    )
    reasoning: str = Field(description="Short explanation")


# ── Node 3: Request information output ────────────────────────────────────────
class RequestInfoOutput(_Base):
    output_message: str = Field(
        description="Message to the user explaining what information is needed and why"
    )


# ── Node 6: Build draft ───────────────────────────────────────────────────────
class BuildDraftOutput(_Base):
    draft: str = Field(description="The full CR draft text")
    draft_html: str = Field(description="HTML-formatted draft for display")


# ── Node 8: Present draft ─────────────────────────────────────────────────────
class PresentDraftOutput(_Base):
    output_text: str = Field(
        description="Message asking the user to review the draft; must mention they can approve, ask questions, or request modifications"
    )
    draft_html: str = Field(description="Updated HTML rendering of the draft")


# ── Cond Edge B: intent router ────────────────────────────────────────────────
class IntentRouterB(_Base):
    intent: Literal["approval", "question", "update", "reject"] = Field(
        description="approval=user is happy and wants to submit, question=user wants more info, update=user wants to change a specific named field, reject=user is dissatisfied with the overall draft without naming a specific field to change"
    )
    reasoning: str


# ── Node 10: Parse update intent ─────────────────────────────────────────────
class FieldUpdateItem(_Base):
    field_name: str = Field(description="Which field to update — for zzfld* fields return the EDL key (e.g. 'zzfld00000v_cus'), for text fields return the canonical key")
    new_value: str = Field(description="The new value to set")
    group_hint: str = Field(default="", description="If the user mentioned a group name (e.g., 'Validation Requirements', 'Testing Requirements', 'Documentation Requirements'), extract it here. Empty string if no group mentioned.")
    is_locked: bool = Field(default=False, description="Whether this field cannot be changed")
    field_type: str = Field(default="locked", description="One of: 'text' (reason/description/additional_information), 'zzfld_writable' (editable template field), 'compliance_locked' (GxP/SOX/SOD/Security/RICEF), 'system_readonly' (server-assigned), 'locked' (session-locked)")


class ParseUpdateIntent(_Base):
    updates: List[FieldUpdateItem] = Field(
        description="ALL field+value pairs the user wants to update. Extract EVERY field and value mentioned in the message, not just the first one."
    )


# ── Node 11: Get information ──────────────────────────────────────────────────
class GetInformationOutput(_Base):
    cypher_query: str = Field(description="Cypher query to run against GraphDB, or empty string if not needed")
    output_text: str = Field(description="Answer text to show the user")


# ── Node 13: Apply update ─────────────────────────────────────────────────────
class ApplyUpdateOutput(_Base):
    updated_draft: str = Field(description="The full draft with the update applied")
    updated_draft_html: str = Field(description="HTML rendering of the updated draft")
    update_summary: str = Field(description="One-sentence summary of what changed")


# ── Node 7: Suggest similar CRs ──────────────────────────────────────────────
class SuggestCRsOutput(_Base):
    query_text: str = Field(description="Natural language text used to form the embedding query")
    cypher_query: str = Field(description="Cypher query for GraphDB vector similarity search")


# ── Node 17: Present top 5 ────────────────────────────────────────────────────
class PresentRecsOutput(_Base):
    # output_text is built in code (node_17), not by the LLM — optional so the
    # LLM omitting it (as instructed) never fails validation.
    output_text: Optional[str] = Field(default=None, description="Unused — built separately in code")
    recommendations_html: str = Field(description="HTML element showcasing all 5 CRs")


# ── Cond Edge C: recommendation intent router ─────────────────────────────────
class IntentRouterC(_Base):
    intent: Literal["approve_cr", "recommend_more", "max_hit"] = Field(
        description=(
            "approve_cr=user selected a CR to use as basis, "
            "recommend_more=user wants more recommendations, "
            "max_hit=recommendation limit reached"
        )
    )
    selected_cr_id: Optional[str] = Field(
        default=None,
        description="The object_id of the CR the user approved (only when intent=approve_cr)"
    )
    reasoning: str


# ── Node 18: Validate selected CR ────────────────────────────────────────────
class ValidateSelectedCR(_Base):
    is_valid_selection: bool = Field(
        description="True if the user is approving a CR that has not been mentioned before"
    )
    selected_cr_id: Optional[str] = Field(default=None)
    reasoning: str


# ── FieldCompletenessCheck (internal use) ─────────────────────────────────────
class FieldCompletenessCheck(_Base):
    platform_given: bool
    template_id_given: bool
    all_required_given: bool
    missing_fields: List[str]