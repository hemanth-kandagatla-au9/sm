# (c) 2026 Amazon Web Services, Inc. or its affiliates. All Rights Reserved.
# This AWS Content is provided subject to the terms of the AWS Customer Agreement
# available at http://aws.amazon.com/agreement or other written agreement between
# Customer and Amazon Web Services, Inc.

# ============================================================================
# Runtime Configuration
# ============================================================================

variable "agent_name" {
  description = "Name of the AgentCore Runtime"
  type        = string
  validation {
    condition     = can(regex("^[a-zA-Z][a-zA-Z0-9-]{0,47}$", var.agent_name))
    error_message = "Agent name must start with a letter, max 48 characters, alphanumeric and hyphens only."
  }
}

variable "agent_description" {
  description = "Description of the agent runtime"
  type        = string
  default     = "AgentCore Runtime deployed via Terraform"
}

variable "idle_session_timeout" {
  description = "Idle session timeout in seconds (60-28800)"
  type        = number
  default     = 1800
  validation {
    condition     = var.idle_session_timeout >= 60 && var.idle_session_timeout <= 28800
    error_message = "Idle session timeout must be between 60 and 28800 seconds."
  }
}

variable "max_lifetime" {
  description = "Maximum runtime lifetime in seconds (60-28800)"
  type        = number
  default     = 3600
  validation {
    condition     = var.max_lifetime >= 60 && var.max_lifetime <= 28800
    error_message = "Max lifetime must be between 60 and 28800 seconds."
  }
}

variable "log_level" {
  description = "Log level for the agent runtime"
  type        = string
  default     = "INFO"
  validation {
    condition     = contains(["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"], var.log_level)
    error_message = "Log level must be DEBUG, INFO, WARNING, ERROR, or CRITICAL."
  }
}

variable "environment_variables" {
  description = "Additional environment variables for the agent runtime"
  type        = map(string)
  default     = {}
}

variable "environment" {
  description = "Environment name (predev, dev, qa, stg, prod)"
  type        = string
  validation {
    condition     = contains(["predev", "dev", "qa", "stg", "prod"], var.environment)
    error_message = "Environment must be predev, dev, qa, stg, or prod."
  }
}

# Deployment method
variable "deployment_method" {
  description = "Deployment method for the agent (container or direct)"
  type        = string
  default     = "container"
  validation {
    condition     = contains(["container", "direct"], var.deployment_method)
    error_message = "Deployment method must be either 'container' or 'direct'."
  }
}

# Protocol Configuration
variable "protocol_configuration" {
  description = "AgentCore Runtime Protocol Configuration"
  type = string
  default = "HTTP"
  validation {
    condition     = contains(["HTTP", "A2A", "MCP"], var.protocol_configuration)
    error_message = "AgentCore Runtime Protocol Configuration must be HTTP, A2A, or MCP."
  }
}

# Container deployment variables
variable "ecr_name" {
  description = "ECR container name"
  type        = string
  default     = ""
}

variable "image_tag" {
  description = "ECR container tag"
  type        = string
  default     = ""
}

# Direct code deployment variables
variable "code_s3_bucket" {
  description = "S3 bucket containing agent code (required for direct deployment)"
  type        = string
  default     = ""
}

variable "code_s3_key" {
  description = "S3 key/prefix for agent code zip file (required for direct deployment)"
  type        = string
  default     = ""
}

variable "code_entry_point" {
  description = "Entry point file for direct deployment"
  type        = list(string)
  default     = ["agentcore.py"]
}

variable "python_runtime" {
  description = "Python runtime version for direct deployment"
  type        = string
  default     = "PYTHON_3_13"
  validation {
    condition     = contains(["PYTHON_3_10", "PYTHON_3_11", "PYTHON_3_12", "PYTHON_3_13", "PYTHON_3_14"], var.python_runtime)
    error_message = "Python runtime must be PYTHON_3_10, PYTHON_3_11, PYTHON_3_12, PYTHON_3_13, or PYTHON_3_14."
  }
}

# Memory
variable "memory_event_expiry_duration" {
  type    = number
  default = 60
  validation {
    condition     = var.memory_event_expiry_duration >= 7 && var.memory_event_expiry_duration <= 365
    error_message = "Must be between 7 and 365 days."
  }
}
# Logging
variable "application_logs_delivery_record_fields" {
  description = "The list of record fields to be delivered to the destination, in order."
  type        = list(string)
  default     = ["body", "account_id", "request_id", "trace_id", "span_id", "resource", "attributes"]
}

variable "usage_logs_delivery_record_fields" {
  description = "The list of record fields to be delivered to the destination, in order."
  type        = list(string)
  default     = []
}

variable "log_retention_in_days" {
  description = "Number of days to retain logs in CloudWatch Log Groups. Valid values are 0 (indefinite), 1, 3, 5, 7, 14, 30, 60, 90, 120, 150, 180, 365."
  type        = number
  default     = 30
}

# Networking
variable "subnet_ids" {
  description = "List of private Subnets for AgentCore Runtimes"
  type        = list(string)
}

variable "security_group_ids" {
  description = "List of security groups for AgentCore Runtimes"
  type        = list(string)
}

# ============================================================================
# Tags
# ============================================================================

# Required Tags
variable "application" {
  description = "Application Id"
  type        = string
}

variable "use_case_id" {
  description = "Use Case Id"
  type        = string
}

variable "xena_asx_project" {
  description = "Xena ASX Project Id"
  type        = string
}

variable "additional_tags" {
  description = "Additional tags for the agent runtime"
  type        = map(string)
  default     = {}
}

# ============================================================================
# Auth
# ============================================================================
variable "entra_tenant_id" {
  description = "Microsoft Entra ID tenant ID. Set to null to skip JWT authorizer."
  type        = string
  default     = null
  sensitive   = true
}

variable "entra_client_id" {
  description = "Entra ID application (client) ID for allowed audience"
  type        = string
  default     = null
  sensitive   = true
}

variable "request_header_allowlist" {
  description = "List of request headers to allow through to the runtime"
  type        = list(string)
  default     = []
}

variable "entra_token_version" {
  description = "Entra ID access token version (v1 or v2). Check accessTokenAcceptedVersion in your app manifest."
  type        = string
  default     = "v2"

  validation {
    condition     = contains(["v1", "v2"], var.entra_token_version)
    error_message = "entra_token_version must be 'v1' or 'v2'."
  }
}
