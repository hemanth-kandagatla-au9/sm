# (c) 2026 Amazon Web Services, Inc. or its affiliates. All Rights Reserved.
# This AWS Content is provided subject to the terms of the AWS Customer Agreement
# available at http://aws.amazon.com/agreement or other written agreement between
# Customer and Amazon Web Services, Inc.

# ============================================================================
# AgentCore Infrastructure
# ============================================================================
# This file contains the core infrastructure required for the Bedrock AgentCore
# Runtime to function, including KMS, IAM, and the runtime.
# ============================================================================

# ============================================================================
# KMS Key for Infrastructure Encryption
# ============================================================================

# Data sources to get current AWS account ID and region
data "aws_caller_identity" "current" {}
data "aws_region" "current" {}

locals {
  agent_name = replace("${var.agent_name}_${var.environment}", "-", "_")
}

resource "aws_kms_key" "agentcore_kms" {
  description             = "KMS key for Bedrock AgentCore Platform encryption"
  deletion_window_in_days = 7
  enable_key_rotation     = true

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "Enable IAM User Permissions"
        Effect = "Allow"
        Principal = {
          AWS = "arn:aws:iam::${data.aws_caller_identity.current.account_id}:root"
        }
        Action   = "kms:*"
        Resource = "*"
      },
      {
        Sid    = "Allow AWS services to use the key"
        Effect = "Allow"
        Principal = {
          Service = [
            "s3.amazonaws.com",
            "lambda.amazonaws.com",
            "logs.amazonaws.com",
            "sqs.amazonaws.com",
            "sns.amazonaws.com",
            "bedrock.amazonaws.com",
            "ecr.amazonaws.com",
            "opensearch.amazonaws.com"
          ]
        }
        Action = [
          "kms:Encrypt",
          "kms:Decrypt",
          "kms:ReEncrypt*",
          "kms:GenerateDataKey*",
          "kms:DescribeKey"
        ]
        Resource = "*"
        Condition = {
          StringEquals = {
            "kms:ViaService" = [
              "s3.${data.aws_region.current.id}.amazonaws.com",
              "lambda.${data.aws_region.current.id}.amazonaws.com",
              "logs.${data.aws_region.current.id}.amazonaws.com",
              "sqs.${data.aws_region.current.id}.amazonaws.com",
              "sns.${data.aws_region.current.id}.amazonaws.com",
              "bedrock.${data.aws_region.current.id}.amazonaws.com",
              "ecr.${data.aws_region.current.id}.amazonaws.com",
              "es.${data.aws_region.current.id}.amazonaws.com"
            ]
          }
        }
      },
      {
        Sid    = "Allow CloudWatch Logs to use the key"
        Effect = "Allow"
        Principal = {
          Service = "logs.${data.aws_region.current.id}.amazonaws.com"
        }
        Action = [
          "kms:Encrypt",
          "kms:Decrypt",
          "kms:ReEncrypt*",
          "kms:GenerateDataKey*",
          "kms:CreateGrant",
          "kms:DescribeKey"
        ]
        Resource = "*"
        Condition = {
          ArnLike = {
            "kms:EncryptionContext:aws:logs:arn" = "arn:aws:logs:${data.aws_region.current.id}:${data.aws_caller_identity.current.account_id}:log-group:*"
          }
        }
      }
    ]
  })

  tags = merge(
    {
      Name             = "bedrock-agentcore-${local.agent_name}-key"
      Application      = var.application
      use_case_id      = var.use_case_id
      agent_name       = local.agent_name
      xena_asx_project = var.xena_asx_project
      ManagedBy        = "terraform"
      Module           = "terraform-aws-agentcore"
    },
    var.additional_tags
  )
}

resource "aws_kms_alias" "agentcore_kms" {
  name          = "alias/bedrock-agentcore-${local.agent_name}"
  target_key_id = aws_kms_key.agentcore_kms.key_id
}

# ============================================================================
# IAM Role/Policy for Bedrock AgentCore
# ============================================================================
# IAM Role for Bedrock AgentCore
resource "aws_iam_role" "agentcore_role" {
  name                 = "bedrock-agentcore-${local.agent_name}"
  permissions_boundary = "arn:aws:iam::${data.aws_caller_identity.current.account_id}:policy/itx/core/VpcxPermissionsBoundaryPolicy1"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = "sts:AssumeRole"
        Effect = "Allow"
        Principal = {
          Service = "bedrock-agentcore.amazonaws.com"
        }
      }
    ]
  })

  tags = merge(
    {
      Application      = var.application
      use_case_id      = var.use_case_id
      agent_name       = local.agent_name
      xena_asx_project = var.xena_asx_project
      ManagedBy        = "terraform"
      Module           = "terraform-aws-agentcore"
    },
    var.additional_tags
  )
}

# IAM Policy for Bedrock AgentCore
resource "aws_iam_role_policy" "agentcore_policy" {
  name = "bedrock-agentcore-policy"
  role = aws_iam_role.agentcore_role.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = [
          "bedrock:InvokeModel",
          "bedrock:InvokeModelWithResponseStream",
          "bedrock:InvokeAgent",
          "bedrock:Retrieve",
          "bedrock:RetrieveAndGenerate",
          "xray:PutTraceSegments"
        ]
        Resource = "*"
      },
      {
        Effect = "Allow"
        Action = [
          "bedrock-agentcore:CreateEvent",
          "bedrock-agentcore:GetEvent",
          "bedrock-agentcore:ListEvents"
        ]
        Resource = "*"
      },
      {
        Effect = "Allow"
        Action = [
          "s3:GetObject",
          "s3:PutObject",
          "s3:DeleteObject",
          "s3:ListBucket"
        ]
        Resource = ["*"]
      },
      {
        Effect = "Allow"
        Action = [
          "kms:Encrypt",
          "kms:Decrypt",
          "kms:ReEncrypt*",
          "kms:GenerateDataKey*",
          "kms:DescribeKey",
          "kms:CreateGrant",
          "kms:ListGrants",
          "kms:RevokeGrant"
        ]
        Resource = [
          aws_kms_key.agentcore_kms.arn
        ]
      },
      {
        Effect = "Allow"
        Action = [
          "ecr:BatchCheckLayerAvailability",
          "ecr:GetDownloadUrlForLayer",
          "ecr:BatchGetImage"
        ]
        Resource = ["*"]
      },
      {
        Effect = "Allow"
        Action = [
          "ecr:GetAuthorizationToken"
        ]
        Resource = "*"
      },
      {
        Effect = "Allow"
        Action = [
          "ssm:GetParameter",
          "ssm:GetParameters",
          "ssm:GetParametersByPath"
        ]
        Resource = "*"
      },
      {
        Effect = "Allow"
        Action = [
          "logs:CreateLogGroup",
          "logs:CreateLogStream",
          "logs:PutLogEvents",
          "logs:DescribeLogGroups",
          "logs:DescribeLogStreams"
        ]
        Resource = ["*"]
      }
    ]
  })
}

# ============================================================================
# Bedrock AgentCore Runtime
# ============================================================================
resource "aws_bedrockagentcore_agent_runtime" "agentcore_runtime" {
  agent_runtime_name = local.agent_name
  role_arn           = aws_iam_role.agentcore_role.arn
  description        = var.agent_description

  environment_variables = merge(
    {
      REGION    = data.aws_region.current.id
      KMS_KEY   = aws_kms_key.agentcore_kms.arn
      LOG_LEVEL = var.log_level
      MEMORY_ID = aws_bedrockagentcore_memory.agentcore_memory.id
    },
    var.environment_variables
  )

  dynamic "agent_runtime_artifact" {
    for_each = var.deployment_method == "container" ? [1] : []
    content {
      container_configuration {
        container_uri = "${data.aws_caller_identity.current.account_id}.dkr.ecr.${data.aws_region.current.id}.amazonaws.com/${var.ecr_name}:${var.image_tag}"
      }
    }
  }

  # --- Protocol Configuration (MCP/HTTP/A2A/AGUI) ---
  protocol_configuration {
    server_protocol = var.protocol_configuration
  }

  dynamic "agent_runtime_artifact" {
    for_each = var.deployment_method == "direct" ? [1] : []
    content {
      code_configuration {
        entry_point = var.code_entry_point
        runtime     = var.python_runtime
        code {
          s3 {
            bucket = var.code_s3_bucket
            prefix = var.code_s3_key
          }
        }
      }
    }
  }

  network_configuration {
    network_mode = "VPC"
    network_mode_config {
      security_groups = var.security_group_ids
      subnets         = var.subnet_ids
    }
  }

  lifecycle_configuration {
    idle_runtime_session_timeout = var.idle_session_timeout
    max_lifetime                 = var.max_lifetime
  }

  # --- Entra ID JWT Authorizer ---
  dynamic "authorizer_configuration" {
    for_each = nonsensitive(var.entra_tenant_id != null) ? toset(["entra"]) : toset([])
    content {
      custom_jwt_authorizer {
        discovery_url = var.entra_token_version == "v2" ? (
          "https://login.microsoftonline.com/${var.entra_tenant_id}/v2.0/.well-known/openid-configuration"
          ) : (
          "https://sts.windows.net/${var.entra_tenant_id}/.well-known/openid-configuration"
        )
        # allowed_audience = ["api://${var.entra_client_id}"]

        custom_claim {
          inbound_token_claim_name       = "azp"
          inbound_token_claim_value_type = "STRING"

          authorizing_claim_match_value {
            claim_match_operator = "EQUALS"
            claim_match_value {
              match_value_string = var.entra_client_id
            }
          }
        }

      }
    }
  }

  # --- Request Header Allowlist ---
  dynamic "request_header_configuration" {
    for_each = length(var.request_header_allowlist) > 0 ? toset(["headers"]) : toset([])
    content {
      request_header_allowlist = var.request_header_allowlist
    }
  }

  tags = merge(
    {
      Name             = "${local.agent_name}-runtime"
      Application      = var.application
      use_case_id      = var.use_case_id
      agent_name       = local.agent_name
      xena_asx_project = var.xena_asx_project
      ManagedBy        = "terraform"
      Module           = "terraform-aws-agentcore"
    },
    var.additional_tags
  )

  depends_on = [
    aws_iam_role.agentcore_role,
    aws_iam_role_policy.agentcore_policy
  ]
}
