# (c) 2026 Amazon Web Services, Inc. or its affiliates. All Rights Reserved.
# This AWS Content is provided subject to the terms of the AWS Customer Agreement
# available at http://aws.amazon.com/agreement or other written agreement between
# Customer and Amazon Web Services, Inc.

# Outputs for KMS
output "bedrock_agentcore_kms_key_id" {
  description = "ID of the Agentic AI Platform KMS key"
  value       = aws_kms_key.agentcore_kms.key_id
  sensitive   = true
}

output "bedrock_agentcore_kms_key_arn" {
  description = "ARN of the Agentic AI Platform KMS key"
  value       = aws_kms_key.agentcore_kms.arn
  sensitive   = true
}

output "bedrock_agentcore_kms_key_alias" {
  description = "Alias of the Agentic AI Platform KMS key"
  value       = aws_kms_alias.agentcore_kms.name
}

# Outputs for IAM
output "bedrock_agentcore_role_arn" {
  description = "ARN of the Bedrock AgentCore role"
  value       = aws_iam_role.agentcore_role.arn
}

output "bedrock_agentcore_role_name" {
  description = "Name of the Bedrock AgentCore role"
  value       = aws_iam_role.agentcore_role.name
}

# Outputs for Bedrock AgentCore Runtime
output "bedrock_agentcore_runtime_id" {
  description = "ID of the AgentCore Runtime"
  value       = aws_bedrockagentcore_agent_runtime.agentcore_runtime.agent_runtime_id
}

output "bedrock_agentcore_runtime_arn" {
  description = "ARN of the AgentCore Runtime"
  value       = aws_bedrockagentcore_agent_runtime.agentcore_runtime.agent_runtime_arn
}

output "bedrock_agentcore_runtime_name" {
  description = "Name of the AgentCore Runtime"
  value       = aws_bedrockagentcore_agent_runtime.agentcore_runtime.agent_runtime_name
}

output "bedrock_agentcore_runtime_version" {
  description = "Version of the AgentCore Runtime"
  value       = aws_bedrockagentcore_agent_runtime.agentcore_runtime.agent_runtime_version
}

# Outputs for Bedrock AgentCore Memory
output "bedrock_agentcore_memory_name" {
  description = "Name of the AgentCore Memory Name"
  value       = aws_bedrockagentcore_memory.agentcore_memory.name
}

output "bedrock_agentcore_memory_arn" {
  description = "Name of the AgentCore Memory Arn"
  value       = aws_bedrockagentcore_memory.agentcore_memory.arn
}