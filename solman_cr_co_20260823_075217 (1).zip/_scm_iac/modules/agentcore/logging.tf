# (c) 2026 Amazon Web Services, Inc. or its affiliates. All Rights Reserved.
# This AWS Content is provided subject to the terms of the AWS Customer Agreement
# available at http://aws.amazon.com/agreement or other written agreement between
# Customer and Amazon Web Services, Inc.

# ============================================================================
# CloudWatch APPLICATION_LOGS
# ============================================================================
# CloudWatch Log Group for Runtime Application Logs
resource "aws_cloudwatch_log_group" "agentcore_runtime_app_log_grp" {
  name              = "/aws/vendedlogs/bedrock-agentcore/agent-runtime/APPLICATION_LOGS/${local.agent_name}"
  retention_in_days = var.log_retention_in_days
  kms_key_id        = aws_kms_key.agentcore_kms.arn

  tags = merge(
    {
      Name             = "${local.agent_name}-runtime-app-log-grp"
      Application      = var.application
      use_case_id      = var.use_case_id
      agent_name       = local.agent_name
      xena_asx_project = var.xena_asx_project
      ManagedBy        = "terraform"
      Module           = "terraform-aws-agentcore"
    },
    var.additional_tags
  )
}

# CloudWatch Log Delivery Source for Runtime Application
resource "aws_cloudwatch_log_delivery_source" "agentcore_runtime_app_log_dlv_src" {
  name         = "${local.agent_name}-app-logs"
  log_type     = "APPLICATION_LOGS"
  resource_arn = aws_bedrockagentcore_agent_runtime.agentcore_runtime.agent_runtime_arn

  tags = merge(
    {
      Name             = "${local.agent_name}-runtime-app-log-dlv-src"
      Application      = var.application
      use_case_id      = var.use_case_id
      agent_name       = local.agent_name
      xena_asx_project = var.xena_asx_project
      ManagedBy        = "terraform"
      Module           = "terraform-aws-agentcore"
    },
    var.additional_tags
  )
}

# CloudWatch Log Delivery Destination for Runtime Application
resource "aws_cloudwatch_log_delivery_destination" "agent_runtime_app_log_dlv_dest" {
  name = "${local.agent_name}-app-logs"

  delivery_destination_configuration {
    destination_resource_arn = aws_cloudwatch_log_group.agentcore_runtime_app_log_grp.arn
  }

  output_format = "json"

  tags = merge(
    {
      Name             = "${local.agent_name}-runtime-app-log-dlv-dest"
      Application      = var.application
      use_case_id      = var.use_case_id
      agent_name       = local.agent_name
      xena_asx_project = var.xena_asx_project
      ManagedBy        = "terraform"
      Module           = "terraform-aws-agentcore"
    },
    var.additional_tags
  )
}

# CloudWatch Log Delivery Configuration for Runtime Application
resource "aws_cloudwatch_log_delivery" "agent_runtime_app_log_dlv_conf" {
  delivery_source_name     = aws_cloudwatch_log_delivery_source.agentcore_runtime_app_log_dlv_src.name
  delivery_destination_arn = aws_cloudwatch_log_delivery_destination.agent_runtime_app_log_dlv_dest.arn
  record_fields            = concat(["resource_arn", "event_timestamp"], var.application_logs_delivery_record_fields)

  tags = merge(
    {
      Name             = "${local.agent_name}-runtime-app-log-dlv-conf"
      Application      = var.application
      use_case_id      = var.use_case_id
      agent_name       = local.agent_name
      xena_asx_project = var.xena_asx_project
      ManagedBy        = "terraform"
      Module           = "terraform-aws-agentcore"
    },
    var.additional_tags
  )
}

# ============================================================================
# CloudWatch USAGE_LOGS
# ============================================================================
# CloudWatch Log Group for Runtime Usage Logs
resource "aws_cloudwatch_log_group" "agentcore_runtime_usage_log_grp" {
  name              = "/aws/vendedlogs/bedrock-agentcore/agent-runtime/USAGE_LOGS/${local.agent_name}"
  retention_in_days = var.log_retention_in_days
  kms_key_id        = aws_kms_key.agentcore_kms.arn

  tags = merge(
    {
      Name             = "${local.agent_name}-runtime-usage-log-grp"
      Application      = var.application
      use_case_id      = var.use_case_id
      agent_name       = local.agent_name
      xena_asx_project = var.xena_asx_project
      ManagedBy        = "terraform"
      Module           = "terraform-aws-agentcore"
    },
    var.additional_tags
  )
}

# CloudWatch Log Delivery Source for Runtime
resource "aws_cloudwatch_log_delivery_source" "agentcore_runtime_usage_log_dlv_src" {
  name         = "${local.agent_name}-usage-logs"
  log_type     = "USAGE_LOGS"
  resource_arn = aws_bedrockagentcore_agent_runtime.agentcore_runtime.agent_runtime_arn

  tags = merge(
    {
      Name             = "${local.agent_name}-runtime-usage-log-dlv-src"
      Application      = var.application
      use_case_id      = var.use_case_id
      agent_name       = local.agent_name
      xena_asx_project = var.xena_asx_project
      ManagedBy        = "terraform"
      Module           = "terraform-aws-agentcore"
    },
    var.additional_tags
  )
}

# CloudWatch Log Delivery Destination for Runtime
resource "aws_cloudwatch_log_delivery_destination" "agent_runtime_usage_log_dlv_dest" {
  name = "${local.agent_name}-usage-logs"

  delivery_destination_configuration {
    destination_resource_arn = aws_cloudwatch_log_group.agentcore_runtime_usage_log_grp.arn
  }

  output_format = "json"

  tags = merge(
    {
      Name             = "${local.agent_name}-runtime-usage-log-dlv-dest"
      Application      = var.application
      use_case_id      = var.use_case_id
      agent_name       = local.agent_name
      xena_asx_project = var.xena_asx_project
      ManagedBy        = "terraform"
      Module           = "terraform-aws-agentcore"
    },
    var.additional_tags
  )
}

# CloudWatch Log Delivery Configuration for Runtime
resource "aws_cloudwatch_log_delivery" "agent_runtime_usage_log_dlv_conf" {
  delivery_source_name     = aws_cloudwatch_log_delivery_source.agentcore_runtime_usage_log_dlv_src.name
  delivery_destination_arn = aws_cloudwatch_log_delivery_destination.agent_runtime_usage_log_dlv_dest.arn
  record_fields            = concat(["resource_arn", "event_timestamp", "resource", "attributes", "metrics"], var.usage_logs_delivery_record_fields)

  tags = merge(
    {
      Name             = "${local.agent_name}-runtime-usage-log-dlv-conf"
      Application      = var.application
      use_case_id      = var.use_case_id
      agent_name       = local.agent_name
      xena_asx_project = var.xena_asx_project
      ManagedBy        = "terraform"
      Module           = "terraform-aws-agentcore"
    },
    var.additional_tags
  )
}