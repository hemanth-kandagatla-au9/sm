# (c) 2026 Amazon Web Services, Inc. or its affiliates. All Rights Reserved.
# This AWS Content is provided subject to the terms of the AWS Customer Agreement
# available at http://aws.amazon.com/agreement or other written agreement between
# Customer and Amazon Web Services, Inc.

# ============================================================================
# Bedrock AgentCore Memory
# ============================================================================
# Short Term Memory
resource "aws_bedrockagentcore_memory" "agentcore_memory" {
  name                      = local.agent_name
  event_expiry_duration     = var.memory_event_expiry_duration
  encryption_key_arn        = aws_kms_key.agentcore_kms.arn
  memory_execution_role_arn = aws_iam_role.agentcore_role.arn

  tags = merge(
    {
      Name             = "${local.agent_name}-memory"
      Application      = var.application
      use_case_id      = var.use_case_id
      agent_name       = local.agent_name
      xena_asx_project = var.xena_asx_project
      ManagedBy        = "terraform"
      Module           = "terraform-aws-agentcore"
    },
    var.additional_tags
  )
}