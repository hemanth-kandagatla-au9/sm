resource "aws_cloudwatch_dashboard" "agentcore_dashboard" {

  dashboard_name = "${var.environment}-dashboard"

  dashboard_body = templatefile(
    "${path.module}/dashboard.json.tpl",
    {
      log_group_name = var.log_group_name
      environment = var.environment
      metric_namespace = var.metric_namespace
    }
  )
}