variable "environment" {
  type = string
}

variable "log_group_name" {
  type = string
}

variable "metric_namespace" {
  type = string
}