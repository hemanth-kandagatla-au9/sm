{
    "widgets": [
        {
            "type": "metric",
            "x": 12,
            "y": 0,
            "width": 12,
            "height": 3,
            "properties": {
                "metrics": [
                    [ "${metric_namespace}", "gen_ai.client.token.usage", "environment", "${environment}", "gen_ai.request.model", "gpt-5.4-mini-2026-03-17", "gen_ai.token.type", "output", { "yAxis": "left", "region": "us-east-1", "visible": false } ],
                    [ "...", "input", { "region": "us-east-1", "visible": false } ],
                    [ ".", "app.task.token_usage", ".", ".", "gen_ai.token.type", "input", { "region": "us-east-1" } ],
                    [ "...", "output", { "region": "us-east-1" } ]
                ],
                "view": "singleValue",
                "stacked": false,
                "region": "us-east-1",
                "singleValueFullPrecision": false,
                "liveData": false,
                "stat": "Average",
                "period": 300,
                "title": "CR Creation Average Token Count"
            }
        },
        {
            "type": "metric",
            "x": 0,
            "y": 3,
            "width": 6,
            "height": 3,
            "properties": {
                "metrics": [
                    [ "${metric_namespace}", "app.task.cost_usd", "environment", "${environment}", { "region": "us-east-1", "label": "cost in usd" } ]
                ],
                "sparkline": true,
                "view": "singleValue",
                "region": "us-east-1",
                "title": "CR Creation Average Token Cost Incurred",
                "period": 300,
                "stat": "Average",
                "setPeriodToTimeRange": true,
                "stacked": false
            }
        },
        {
            "type": "metric",
            "x": 12,
            "y": 3,
            "width": 6,
            "height": 3,
            "properties": {
                "metrics": [
                    [ "${metric_namespace}", "app.task.first_draft_accuracy", "environment", "${environment}", { "label": "%" } ]
                ],
                "view": "singleValue",
                "stacked": false,
                "region": "us-east-1",
                "stat": "Average",
                "period": 300,
                "title": "CR Creation Average First Draft Accuracy"
            }
        },
        {
            "type": "metric",
            "x": 6,
            "y": 3,
            "width": 6,
            "height": 3,
            "properties": {
                "metrics": [
                    [ "${metric_namespace}", "app.task.duration_ms", "environment", "${environment}", "task_status", "failed", { "label": "Time Taken", "region": "us-east-1", "visible": false } ],
                    [ ".", ".", ".", ".", { "label": "Time" } ]
                ],
                "view": "singleValue",
                "stacked": false,
                "region": "us-east-1",
                "stat": "Average",
                "period": 300,
                "title": "CR Creation Average Duration"
            }
        },
        {
            "type": "metric",
            "x": 0,
            "y": 6,
            "width": 8,
            "height": 7,
            "properties": {
                "metrics": [
                    [ "${metric_namespace}", "app.task.duration_ms", "environment", "${environment}", "task_status", "failed", { "region": "us-east-1" } ],
                    [ "...", "success", { "region": "us-east-1" } ],
                    [ "...", "ended_without_submission" ]
                ],
                "view": "pie",
                "stacked": false,
                "region": "us-east-1",
                "setPeriodToTimeRange": true,
                "stat": "SampleCount",
                "period": 300,
                "title": "CR Creation Completion Status"
            }
        },
        {
            "type": "metric",
            "x": 16,
            "y": 6,
            "width": 8,
            "height": 7,
            "properties": {
                "metrics": [
                    [ "${metric_namespace}", "app.task.cr_recommendation_source.count", "environment", "${environment}", "cr_recommendation_source", "direct", { "region": "us-east-1" } ],
                    [ "...", "N/A", { "region": "us-east-1" } ],
                    [ "...", "rank_1", { "region": "us-east-1" } ],
                    [ "...", "rank_2", { "region": "us-east-1" } ],
                    [ "...", "user_template_id", { "region": "us-east-1" } ],
                    [ "...", "user_cr_id", { "region": "us-east-1" } ],
                    [ "...", "rank_5", { "region": "us-east-1" } ],
                    [ "...", "rank_4", { "region": "us-east-1" } ],
                    [ "...", "rank_3", { "region": "us-east-1" } ]
                ],
                "view": "pie",
                "stacked": false,
                "region": "us-east-1",
                "stat": "Sum",
                "period": 300,
                "setPeriodToTimeRange": true,
                "title": "CR Selection Source"
            }
        },
        {
            "type": "metric",
            "x": 18,
            "y": 3,
            "width": 6,
            "height": 3,
            "properties": {
                "metrics": [
                    [ "${metric_namespace}", "app.task.end_without_draft.count", "environment", "${environment}", "end_without_draft", "false", { "visible": false } ],
                    [ "...", "true", { "label": "count" } ]
                ],
                "view": "singleValue",
                "stacked": false,
                "region": "us-east-1",
                "stat": "Sum",
                "period": 300,
                "setPeriodToTimeRange": true,
                "title": "CR Creation Ended Without Draft"
            }
        },
        {
            "type": "metric",
            "x": 0,
            "y": 0,
            "width": 6,
            "height": 3,
            "properties": {
                "metrics": [
                    [ "${metric_namespace}", "app.task.completed.count", "environment", "${environment}", { "region": "us-east-1", "label": "count" } ]
                ],
                "sparkline": true,
                "view": "singleValue",
                "region": "us-east-1",
                "stat": "Sum",
                "period": 300,
                "stacked": false,
                "setPeriodToTimeRange": true,
                "title": "Total CR Creation Attempted"
            }
        },
        {
            "type": "metric",
            "x": 8,
            "y": 6,
            "width": 8,
            "height": 7,
            "properties": {
                "metrics": [
                    [ "${metric_namespace}", "app.task.cycle_id_selection.count", "environment", "${environment}", "cycle_id_selection", "rank_5", { "region": "us-east-1" } ],
                    [ "...", "rank_4", { "region": "us-east-1" } ],
                    [ "...", "rank_3", { "region": "us-east-1" } ],
                    [ "...", "rank_2", { "region": "us-east-1" } ],
                    [ "...", "rank_1", { "region": "us-east-1" } ],
                    [ "...", "default", { "region": "us-east-1" } ],
                    [ "...", "N/A" ],
                    [ "...", "rank_>5" ]
                ],
                "view": "pie",
                "stacked": false,
                "region": "us-east-1",
                "stat": "Sum",
                "period": 300,
                "setPeriodToTimeRange": true,
                "title": "Cycle ID Selection Source"
            }
        },
        {
            "type": "metric",
            "x": 0,
            "y": 13,
            "width": 6,
            "height": 6,
            "properties": {
                "metrics": [
                    [ "${metric_namespace}", "app.task.submission_count", "environment", "${environment}", "submission_status", "success", { "region": "us-east-1" } ],
                    [ "...", "failed", { "region": "us-east-1" } ]
                ],
                "view": "timeSeries",
                "region": "us-east-1",
                "stat": "Sum",
                "period": 604800,
                "title": "Task Status Per Week",
                "stacked": true,
                "setPeriodToTimeRange": true,
                "start": "-PT672H",
                "end": "P0D"
            }
        },
        {
            "type": "metric",
            "x": 6,
            "y": 13,
            "width": 6,
            "height": 6,
            "properties": {
                "metrics": [
                    [ "${metric_namespace}", "app.task.submission_count", "environment", "${environment}", "submission_status", "success", { "region": "us-east-1" } ],
                    [ "...", "failed", { "region": "us-east-1" } ]
                ],
                "view": "timeSeries",
                "region": "us-east-1",
                "stat": "Sum",
                "period": 2592000,
                "title": "Task Status Per Month",
                "start": "-PT4320H",
                "end": "P0D",
                "stacked": true
            }
        },
        {
            "type": "log",
            "x": 12,
            "y": 13,
            "width": 12,
            "height": 6,
            "properties": {
                "query": "SOURCE \"${log_group_name}\" |\nfields @timestamp, wwid\n| filter message like /NODE 5: SESSION_METRICS/\n| stats count_distinct(wwid) as unique_users by bin(7d)",
                "region": "us-east-1",
                "stacked": false,
                "view": "timeSeries",
                "title": "Unique Users per Week",
                "start": "-P4W",
                "end": "P0D"
            }
        },
        {
            "type": "log",
            "x": 0,
            "y": 19,
            "width": 12,
            "height": 6,
            "properties": {
                "query": "SOURCE \"${log_group_name}\" |\nfields @timestamp, wwid\n| filter message like /NODE 5: SESSION_METRICS/\n| stats count_distinct(wwid) as unique_users by bin(30d)",
                "region": "us-east-1",
                "stacked": false,
                "view": "timeSeries",
                "title": "Unique Users per Month",
                "start": "-P6M",
                "end": "P0D"
            }
        },
        {
            "type": "log",
            "x": 12,
            "y": 19,
            "width": 12,
            "height": 6,
            "properties": {
                "query": "SOURCE \"${log_group_name}\" |\nfields @timestamp, wwid, message\n| filter message like /NODE 5: SESSION_METRICS/\n| filter message like /\"submission_status\":\"success\"/\n| stats count() as successful_crs by wwid\n| sort successful_crs desc",
                "region": "us-east-1",
                "stacked": false,
                "view": "table",
                "title": "User to Successful CR Creation Table"
            }
        },
        {
            "type": "log",
            "x": 0,
            "y": 25,
            "width": 12,
            "height": 6,
            "properties": {
                "query": "SOURCE \"${log_group_name}\" |\nfields @timestamp, wwid, message\n| filter message like /NODE 5: SESSION_METRICS/\n| filter message like /\"submission_status\":\"success\"/\n| stats count() as successful_tasks, count_distinct(wwid) as active_users, count()/count_distinct(wwid) as crs_per_user by bin(7d)",
                "region": "us-east-1",
                "stacked": false,
                "view": "bar",
                "title": "User to Successful CR Creation Per Week",
                "start": "-P4W",
                "end": "P0D"
            }
        },
        {
            "type": "log",
            "x": 12,
            "y": 25,
            "width": 12,
            "height": 6,
            "properties": {
                "query": "SOURCE \"${log_group_name}\" |\nfields @timestamp, wwid, message\n| filter message like /NODE 5: SESSION_METRICS/\n| filter message like /\"submission_status\":\"success\"/\n| stats count() as successful_tasks, count_distinct(wwid) as active_users, count()/count_distinct(wwid) as crs_per_user by bin(30d)",
                "region": "us-east-1",
                "stacked": false,
                "view": "bar",
                "title": "User to Successful CR Creation Per Month",
                "start": "-P6M",
                "end": "P0D"
            }
        },
        {
            "type": "metric",
            "x": 6,
            "y": 0,
            "width": 6,
            "height": 3,
            "properties": {
                "metrics": [
                    [ { "expression": "(m2 * 0.883333 - m1 / 3600000) * 33", "label": "in usd", "id": "e1" } ],
                    [ "${metric_namespace}", "app.task.duration_ms", "environment", "${environment}", "task_status", "success", { "stat": "Sum", "id": "m1", "visible": false } ],
                    [ "...", { "id": "m2", "visible": false } ]
                ],
                "sparkline": false,
                "view": "singleValue",
                "region": "us-east-1",
                "stat": "SampleCount",
                "period": 300,
                "setPeriodToTimeRange": true,
                "title": "Cost Savings"
            }
        }
    ]
}
