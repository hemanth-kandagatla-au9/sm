# (c) 2026 Amazon Web Services, Inc. or its affiliates. All Rights Reserved.
# This AWS Content is provided subject to the terms of the AWS Customer Agreement
# available at http://aws.amazon.com/agreement or other written agreement between
# Customer and Amazon Web Services, Inc.

# ============================================================================
# Runtime Configuration
# ============================================================================

variable "agent_name" {
  description = "Name of the AgentCore Runtime"
  type        = string
  default     = "crco"
  validation {
    condition     = can(regex("^[a-zA-Z][a-zA-Z0-9-]{0,47}$", var.agent_name))
    error_message = "Agent name must start with a letter, max 48 characters, alphanumeric and hyphens only."
  }
}

variable "agent_description" {
  description = "Description of the agent runtime"
  type        = string
  default     = "AgentCore Runtime for CRCO Agent deployed via Terraform"
}

variable "environment_variables" {
  description = "Additional environment variables for the agent runtime"
  type        = map(string)
  default     = {}
}

variable "environment" {
  description = "Environment name (predev, dev, qa, stg, prod)"
  type        = string
  validation {
    condition     = contains(["predev", "dev", "qa", "stg", "prod"], var.environment)
    error_message = "Environment must be predev, dev, qa, stg, or prod."
  }
}

# Deployment method
variable "deployment_method" {
  description = "Deployment method for the agent (container or direct)"
  type        = string
  default     = "container"
  validation {
    condition     = contains(["container", "direct"], var.deployment_method)
    error_message = "Deployment method must be either 'container' or 'direct'."
  }
}

# Protocol Configuration
variable "protocol_configuration" {
  description = "AgentCore Runtime Protocol Configuration"
  type        = string
  default     = "HTTP"
  validation {
    condition     = contains(["HTTP", "A2A", "MCP"], var.protocol_configuration)
    error_message = "AgentCore Runtime Protocol Configuration must be HTTP, A2A, or MCP."
  }
}

# Container deployment variables
variable "ecr_name" {
  description = "ECR container name"
  type        = string
  default     = "agentcore-crco"
}

variable "image_tag" {
  description = "ECR container tag"
  type        = string
  default     = ""
}


variable "code_entry_point" {
  description = "Entry point file for direct deployment"
  type        = list(string)
  default     = ["main.py"]
}

variable "python_runtime" {
  description = "Python runtime version for direct deployment"
  type        = string
  default     = "PYTHON_3_12"
  validation {
    condition     = contains(["PYTHON_3_10", "PYTHON_3_11", "PYTHON_3_12", "PYTHON_3_13", "PYTHON_3_14"], var.python_runtime)
    error_message = "Python runtime must be PYTHON_3_10, PYTHON_3_11, PYTHON_3_12, PYTHON_3_13, or PYTHON_3_14."
  }
}

# Networking
variable "subnet_ids" {
  description = "List of private Subnets for AgentCore Runtimes"
  type        = list(string)
}

variable "security_group_ids" {
  description = "List of security groups for AgentCore Runtimes"
  type        = list(string)
}

#===========================================================================
# Cloudwatch Dashboard
#===========================================================================

variable "dashboard_log_group_name" {
  type = string
}

variable "metric_namespace" {
  type = string
}
# ============================================================================
# Tags
# ============================================================================

# Required Tags
variable "application" {
  description = "Application Id"
  type        = string
}

variable "use_case_id" {
  description = "Use Case Id"
  type        = string
  default     = "jjyy"
}

variable "xena_asx_project" {
  description = "Xena ASX Project Id"
  type        = string
  default     = "asx-jjyy"
}

variable "additional_tags" {
  description = "Additional tags for the agent runtime"
  type        = map(string)
  default     = {}
}

# ============================================================================
# Auth
# ============================================================================
variable "entra_tenant_id" {
  description = "Microsoft Entra ID tenant ID. Set to null to skip JWT authorizer."
  type        = string
  default     = "3ac94b33-9135-4821-9502-eafda6592a35"
  sensitive   = true
}

variable "entra_client_id" {
  description = "Entra ID application (client) ID for allowed audience"
  type        = string
  default     = null
  sensitive   = true
}

variable "request_header_allowlist" {
  description = "List of request headers to allow through to the runtime"
  type        = list(string)
  default     = []
}