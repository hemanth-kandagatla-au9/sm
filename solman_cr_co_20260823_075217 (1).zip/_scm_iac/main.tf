# (c) 2026 Amazon Web Services, Inc. or its affiliates. All Rights Reserved.
# This AWS Content is provided subject to the terms of the AWS Customer Agreement
# available at http://aws.amazon.com/agreement or other written agreement between
# Customer and Amazon Web Services, Inc.

# =======================================
# Bedrock AgentCore Module Configuration
# =======================================
module "bedrock_agentcore" {
  # source = "https://artifactrepo.jnj.com/artifactory/jnj-terraform-modules-local/terraform-aws-agentcore-0.2.0.tar.gz"
  source = "./modules/agentcore"
  #Runtime Details
  agent_name        = var.agent_name
  agent_description = var.agent_description
  environment       = var.environment
  deployment_method = "container"

  ##Runtime and Entrypoint
  python_runtime         = var.python_runtime
  code_entry_point       = var.code_entry_point
  protocol_configuration = var.protocol_configuration
  # Environment Variables
  environment_variables = var.environment_variables
  # Optional
  idle_session_timeout = 1800
  max_lifetime         = 3600
  log_level            = "INFO"

  # Container Specific
  ecr_name  = "agentcore-crco"
  image_tag = var.image_tag

  # Network Configuration
  subnet_ids         = var.subnet_ids
  security_group_ids = var.security_group_ids

  # Tags
  application      = var.application
  use_case_id      = var.use_case_id
  xena_asx_project = var.xena_asx_project

  #Auth
  entra_tenant_id          = var.entra_tenant_id
  entra_client_id          = var.entra_client_id
  request_header_allowlist = var.request_header_allowlist
}

#==========================================================================
# Cloudwatch Dashboard
#==========================================================================

module "cloudwatch_dashboard" {
  source = "./modules/cloudwatch-dashboard"

  environment    = var.environment
  log_group_name = var.dashboard_log_group_name
  metric_namespace = var.metric_namespace
}