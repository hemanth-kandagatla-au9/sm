# (c) 2026 Amazon Web Services, Inc. or its affiliates. All Rights Reserved.
# This AWS Content is provided subject to the terms of the AWS Customer Agreement
# available at http://aws.amazon.com/agreement or other written agreement between
# Customer and Amazon Web Services, Inc.

provider "aws" {
  region = "us-east-1"
}

provider "artifactory" {
  url = "https://artifactrepo.jnj.com/artifactory/"
  #check_license = false
}

terraform {
  required_providers {
    artifactory = {
      source  = "registry.terraform.io/jfrog/artifactory"
      version = "~> 6"
    }
  }
  backend "s3" {
    # values passed by manifest.yaml
    encrypt = true
  }
}

