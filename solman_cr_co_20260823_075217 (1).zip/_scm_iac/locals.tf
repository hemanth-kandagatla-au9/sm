# # =======================================
# # Mandatory Tags Definition
# # =======================================
# # Single source of truth for all required tags.
# # Enforced by: tflint (CI), SCP (AWS), pre-commit (local) 
# #
# # Usage:
# #   tags = merge(local.mandatory_tags, {
# #     Name    = "my-resource"
# #     Purpose = "specific purpose"
# #   })

# locals {
#   env = lower(var.environment)

#   application_id_map = {
#     "predev" = "APP000020018200"
#     "dev"    = "APP000020018199"
#     "stg"    = "APP000020019282"
#     "qa"     = "APP000020018319"
#     "prod"   = "APP0000200192xx"
#   }

#   application_id = lookup(local.application_id_map, local.env, "APP000020018200")

#   mandatory_tags = {
#     Application      = local.application_id
#     use_case_id      = "0987654321"
#     xena_asx_project = "JJEV-AGENTCORE"
#     ManagedBy        = "terraform"
#     Module           = "genai-agentcore-test-agent"
#     Environment      = local.env
#     Project          = var.jnj_project
#   }
# }
