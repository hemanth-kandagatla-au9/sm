bucket         = "ai-sdlc-crco-agent-prod-tf-state"
key            = "prod/crco-agent/crco-agentcore.tfstate"
region         = "us-east-1"
encrypt        = true

skip_region_validation      = false
skip_credentials_validation = false
skip_metadata_api_check     = false
skip_requesting_account_id  = false
use_path_style              = false