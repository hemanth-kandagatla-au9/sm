"""
tests/test_cond_edges.py
Unit tests for all three conditional edges:
  cond_edge_a — deterministic field router
  cond_edge_b — LLM draft intent router (LLM mocked)
  cond_edge_c — LLM recommendation intent router (LLM mocked)

External calls mocked: LLM, Neo4j, SolMan, JIRA.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from unittest.mock import patch, MagicMock
import pytest
from langchain_core.messages import HumanMessage, AIMessage

from state.state import build_initial_state, empty_field, empty_baselines


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────
def _valid_field(value: str) -> dict:
    return {"given": True, "valid": True, "value": value, "data": {}, "error": None}


def _full_state(**overrides):
    """Build a state with all required fields valid; override any key via kwargs."""
    state = build_initial_state("test")
    state["platform"]              = _valid_field("Atlas")
    state["target_system"]         = _valid_field("WebMethods")
    state["reason_for_change"]     = _valid_field("Add missing auth.")
    state["description_of_change"] = _valid_field("Adding auth object to GFS role.")
    for k, v in overrides.items():
        state[k] = v
    return state


# ─────────────────────────────────────────────────────────────────────────────
# cond_edge_a
# ─────────────────────────────────────────────────────────────────────────────
class TestCondEdgeA:
    """
    Tests the pure-logic routing function — no LLM, no DB, no mocking needed.
    """

    def _import(self):
        from agents.nodes import cond_edge_a
        return cond_edge_a

    def test_end_session_routes_to_node5(self):
        cond_edge_a = self._import()
        state = build_initial_state("test")
        state["end_session"] = True
        assert cond_edge_a(state) == "node_5"

    def test_missing_platform_routes_to_node3(self):
        cond_edge_a = self._import()
        state = _full_state()
        state["platform"] = empty_field()  # not given
        assert cond_edge_a(state) == "node_3"

    def test_invalid_platform_routes_to_node3(self):
        cond_edge_a = self._import()
        state = _full_state()
        state["platform"] = {"given": True, "valid": False, "value": "bad", "data": None, "error": "not found"}
        assert cond_edge_a(state) == "node_3"

    def test_missing_target_system_routes_to_node3(self):
        cond_edge_a = self._import()
        state = _full_state()
        state["target_system"] = empty_field()
        assert cond_edge_a(state) == "node_3"

    def test_missing_reason_routes_to_node3(self):
        cond_edge_a = self._import()
        state = _full_state()
        state["reason_for_change"] = empty_field()
        assert cond_edge_a(state) == "node_3"

    def test_empty_reason_value_routes_to_node3(self):
        cond_edge_a = self._import()
        state = _full_state()
        state["reason_for_change"] = {"given": True, "valid": True, "value": "   ", "data": None, "error": None}
        assert cond_edge_a(state) == "node_3"

    def test_missing_description_routes_to_node3(self):
        cond_edge_a = self._import()
        state = _full_state()
        state["description_of_change"] = empty_field()
        assert cond_edge_a(state) == "node_3"

    def test_all_valid_with_template_id_routes_to_node6(self):
        cond_edge_a = self._import()
        state = _full_state()
        state["template_id"] = _valid_field("65669")
        assert cond_edge_a(state) == "node_6"

    def test_all_valid_with_cr_id_routes_to_node6(self):
        cond_edge_a = self._import()
        state = _full_state()
        state["cr_id"] = _valid_field("50412496")
        assert cond_edge_a(state) == "node_6"

    def test_all_valid_no_template_routes_to_node7(self):
        cond_edge_a = self._import()
        state = _full_state()
        # template_id and cr_id both not given (default from _full_state)
        assert cond_edge_a(state) == "node_7"


# ─────────────────────────────────────────────────────────────────────────────
# cond_edge_b  (LLM mocked)
# ─────────────────────────────────────────────────────────────────────────────
class TestCondEdgeB:

    def _run(self, intent: str) -> str:
        from utils.schemas import IntentRouterB
        mock_result = MagicMock(spec=IntentRouterB)
        mock_result.intent = intent

        with patch("agents.nodes.nodes_review.llm_with_output") as mock_llm_fn:
            mock_chain = MagicMock()
            mock_chain.invoke.return_value = mock_result
            mock_llm_fn.return_value = mock_chain

            from agents.nodes import cond_edge_b
            state = _full_state()
            state["messages"].append(HumanMessage(content="approve"))
            return cond_edge_b(state)

    def test_approval_routes_to_node12(self):
        assert self._run("approval") == "node_12"

    def test_question_routes_to_node11(self):
        assert self._run("question") == "node_11"

    def test_update_routes_to_node10(self):
        assert self._run("update") == "node_10"


# ─────────────────────────────────────────────────────────────────────────────
# cond_edge_c  (LLM mocked)
# ─────────────────────────────────────────────────────────────────────────────
class TestCondEdgeC:

    def _state_with_mentioned(self, mentioned: list) -> dict:
        state = _full_state()
        state["baseline_crs"] = {
            **empty_baselines(),
            "mentioned_object_ids": mentioned,
        }
        state["messages"].append(HumanMessage(content="use this one"))
        return state

    def _run(self, intent: str, mentioned: list) -> str:
        from utils.schemas import IntentRouterC
        mock_result = MagicMock(spec=IntentRouterC)
        mock_result.intent = intent

        with patch("agents.nodes.nodes_outcome.llm_with_output") as mock_llm_fn:
            mock_chain = MagicMock()
            mock_chain.invoke.return_value = mock_result
            mock_llm_fn.return_value = mock_chain

            from agents.nodes import cond_edge_c
            return cond_edge_c(self._state_with_mentioned(mentioned))

    def test_approve_cr_routes_to_node6(self):
        assert self._run("approve_cr", ["50412496"]) == "node_6"

    def test_recommend_more_routes_to_node7(self):
        assert self._run("recommend_more", ["50412496"]) == "node_7"

    def test_max_recommendations_routes_to_node19(self):
        from config.config import MAX_RECOMMENDATIONS
        # Fill mentioned list to the max
        mentioned = [str(i) for i in range(MAX_RECOMMENDATIONS)]
        # Even with approve_cr intent, max hit takes priority — no LLM call needed
        from agents.nodes import cond_edge_c
        state = self._state_with_mentioned(mentioned)
        result = cond_edge_c(state)
        assert result == "node_19"


# ─────────────────────────────────────────────────────────────────────────────
# cond_edge_20  (deterministic — no LLM)
# Routes to node_20b when cycle_id_pending is set; otherwise to node_8.
# ─────────────────────────────────────────────────────────────────────────────
class TestCondEdge20:

    def test_cycle_pending_routes_to_node_20b(self):
        from agents.nodes import cond_edge_20
        state = _full_state()
        state["cycle_id_pending"] = {"draft_cycle_id": "CYC-123", "options": []}
        assert cond_edge_20(state) == "node_20b"

    def test_no_cycle_pending_routes_to_node_8(self):
        from agents.nodes import cond_edge_20
        state = _full_state()
        state["cycle_id_pending"] = None
        assert cond_edge_20(state) == "node_8"

    def test_cycle_pending_empty_dict_routes_to_node_8(self):
        """An empty dict is falsy — treated as no pending cycle."""
        from agents.nodes import cond_edge_20
        state = _full_state()
        state["cycle_id_pending"] = {}
        assert cond_edge_20(state) == "node_8"
