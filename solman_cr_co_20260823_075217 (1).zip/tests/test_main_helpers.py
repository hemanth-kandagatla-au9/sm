import importlib
import asyncio
import io
import json
import os
import sys
import types
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from langchain_core.messages import AIMessage, HumanMessage


class Snapshot:
    def __init__(self, messages=None, next_nodes=(), interrupts=None, values=None):
        self.values = values if values is not None else {"messages": messages or []}
        self.next = tuple(next_nodes)
        self.tasks = [types.SimpleNamespace(interrupts=interrupts or [])] if interrupts else []


class FakeGraph:
    def __init__(self):
        self.stream_events = []
        self.snapshot = Snapshot()
        self.snapshots = None
        self.last_input = None
        self.last_config = None

    def stream(self, input_or_cmd, config, stream_mode):
        self.last_input = input_or_cmd
        self.last_config = config
        yield from self.stream_events

    def get_state(self, config):
        self.last_config = config
        if self.snapshots is not None:
            index = min(len(self.snapshots) - 1, getattr(self, "_snapshot_index", 0))
            self._snapshot_index = index + 1
            return self.snapshots[index]
        return self.snapshot


def _import_main(monkeypatch, tmp_path, fake_graph=None):
    graph = fake_graph or FakeGraph()

    fake_builder = types.ModuleType("graph.builder")
    fake_builder.build_graph = lambda: graph

    fake_ssm = types.ModuleType("config.ssm_bootstrap")
    fake_ssm.resolve_ssm_parameters = lambda: None

    monkeypatch.setitem(sys.modules, "graph.builder", fake_builder)
    monkeypatch.setitem(sys.modules, "config.ssm_bootstrap", fake_ssm)
    monkeypatch.setenv("AGENT_STATE_DIR", str(tmp_path))
    monkeypatch.setenv("AGENT_LOG_DIR", str(tmp_path))

    sys.modules.pop("main", None)
    main_module = importlib.import_module("main")
    return main_module, graph


def _make_handler(main_module, path, body=None):
    raw_body = body or b""
    handler = main_module.AgentHandler.__new__(main_module.AgentHandler)
    handler.path = path
    handler.headers = {"Content-Length": str(len(raw_body))}
    handler.rfile = io.BytesIO(raw_body)
    handler.wfile = io.BytesIO()
    handler.status_codes = []
    handler.header_calls = []
    handler.ended = False

    def send_response(self, status):
        self.status_codes.append(status)

    def send_header(self, name, value):
        self.header_calls.append((name, value))

    def end_headers(self):
        self.ended = True

    handler.send_response = types.MethodType(send_response, handler)
    handler.send_header = types.MethodType(send_header, handler)
    handler.end_headers = types.MethodType(end_headers, handler)
    return handler


class TestMainHelpers:
    def test_partial_group_override_preserves_template_siblings(self, monkeypatch, tmp_path):
        main_module, _ = _import_main(monkeypatch, tmp_path)

        state_values = {
            "draft": "present",
            "template_id": {
                "data": {
                    "IvTestReq": {
                        "TestReference2": "REF-BASE-002",
                        "RegressionTestQAS": "No",
                    }
                }
            },
            "cr_id": {
                "data": {
                    "IvTestReq": {
                        "RegressionTestQAS": "Yes",
                    }
                }
            },
        }

        sections = main_module._build_expandable_document(state_values)
        testing = next(s for s in sections if s["title"] == "Testing Requirements")
        fields = {f["label"]: f["value"] for f in testing["fields"]}

        assert fields["Regression Test (QAS)"] == "Yes"
        assert fields["2. Test Reference"] == "REF-BASE-002"

    def test_collect_messages_deduplicates_ai_messages(self, monkeypatch, tmp_path):
        main_module, _ = _import_main(monkeypatch, tmp_path)

        seen_ids = set()
        event = {
            "messages": [
                AIMessage(content="First answer", id="a1"),
                AIMessage(content="First answer", id="a1"),
                HumanMessage(content="Ignore me"),
                AIMessage(content="", id="empty"),
            ]
        }

        assert main_module._collect_messages(event, seen_ids) == ["First answer"]
        assert "a1" in seen_ids

    def test_get_interrupt_message(self, monkeypatch, tmp_path):
        main_module, _ = _import_main(monkeypatch, tmp_path)

        snapshot = Snapshot(interrupts=[types.SimpleNamespace(value="Please respond")])
        assert main_module._get_interrupt_message(snapshot) == "Please respond"
        assert main_module._get_interrupt_message(None) == ""

    def test_session_thread_load_save_and_reset(self, monkeypatch, tmp_path):
        main_module, _ = _import_main(monkeypatch, tmp_path)

        threads_file = tmp_path / "threads.json"
        main_module._THREADS_FILE = str(threads_file)
        main_module._session_threads = {}

        assert main_module._load_session_threads() == {}

        thread_id = main_module._get_thread_id("session-1")
        assert thread_id.startswith("session-1-")
        assert json.loads(threads_file.read_text(encoding="utf-8")) == {"session-1": thread_id}

        reset_thread = main_module._reset_thread_id("session-1")
        assert reset_thread != thread_id
        assert json.loads(threads_file.read_text(encoding="utf-8"))["session-1"] == reset_thread

    def test_submission_record_and_recall(self, monkeypatch, tmp_path):
        main_module, _ = _import_main(monkeypatch, tmp_path)

        submissions_file = tmp_path / "submissions.json"
        main_module._SUBMISSIONS_FILE = str(submissions_file)

        state_values = {
            "submission_result": {"cr_id": "12345678"},
            "jira_id": {"value": "PROJ-123"},
            "platform": {"value": "HMD"},
            "description_of_change": {"value": "Fix auth issue"},
        }
        main_module._record_submission("alice", state_values)

        stored = json.loads(submissions_file.read_text(encoding="utf-8"))
        assert stored["alice"][0]["cr_id"] == "12345678"
        assert stored["alice"][0]["jira_id"] == "PROJ-123"

        answer = main_module._answer_recall("what was the last change request I submitted?", "alice")
        assert "CR 12345678" in answer
        assert "PROJ-123" in answer
        assert "Fix auth issue" in answer

    def test_answer_recall_without_history(self, monkeypatch, tmp_path):
        main_module, _ = _import_main(monkeypatch, tmp_path)

        main_module._SUBMISSIONS_FILE = str(tmp_path / "submissions.json")
        assert "I don't have any previously submitted change requests" in main_module._answer_recall(
            "what was the last CR I submitted?",
            "missing-actor",
        )

    def test_run_agent_waiting_and_complete(self, monkeypatch, tmp_path):
        main_module, graph = _import_main(monkeypatch, tmp_path)

        graph.stream_events = [
            {"messages": [AIMessage(content="Draft is ready", id="m1"), HumanMessage(content="ignore")]}
        ]
        graph.snapshot = Snapshot(messages=[AIMessage(content="Draft is ready", id="m1")], next_nodes=())

        complete = main_module.run_agent("hello", session_id="session-a", actor_id="actor-a")
        assert complete["status"] == "complete"
        assert "Draft is ready" in complete["message"]

        graph.stream_events = []
        graph.snapshot = Snapshot(
            messages=[AIMessage(content="Please answer", id="m2")],
            next_nodes=("node_4",),
            interrupts=[types.SimpleNamespace(value="Need input from user")],
        )

        waiting = main_module.run_agent("hello again", session_id="session-b", actor_id="actor-b")
        assert waiting["status"] == "waiting"
        assert "Need input from user" in waiting["message"]

    def test_resume_agent_returns_complete(self, monkeypatch, tmp_path):
        main_module, graph = _import_main(monkeypatch, tmp_path)

        graph.stream_events = [{"messages": [AIMessage(content="Resumed", id="r2")]}]
        graph.snapshot = Snapshot(messages=[], next_nodes=())

        result = main_module.resume_agent("yes", session_id="session-c", actor_id="actor-c")
        assert result["status"] == "complete"
        assert "Resumed" in result["message"]

    def test_asgi_respond_writes_headers_and_body(self, monkeypatch, tmp_path):
        main_module, _ = _import_main(monkeypatch, tmp_path)

        sent = []

        async def send(message):
            sent.append(message)

        asyncio.run(main_module._asgi_respond(send, 201, b"hello", content_type="text/plain"))

        assert sent[0]["type"] == "http.response.start"
        assert sent[0]["status"] == 201
        assert [b"content-type", b"text/plain"] in sent[0]["headers"]
        assert sent[1] == {"type": "http.response.body", "body": b"hello"}

    def test_asgi_app_ping_and_non_http(self, monkeypatch, tmp_path):
        main_module, _ = _import_main(monkeypatch, tmp_path)

        async def receive():
            return {"body": b"", "more_body": False}

        sent = []

        async def send(message):
            sent.append(message)

        asyncio.run(main_module.app({"type": "websocket"}, receive, send))
        assert sent == []

        asyncio.run(main_module.app({"type": "http", "path": "/ping", "method": "GET", "headers": []}, receive, send))
        assert sent[0]["status"] == 200
        assert sent[1]["body"] == b"OK"

    def test_asgi_app_invocations_fresh_conversation(self, monkeypatch, tmp_path):
        main_module, graph = _import_main(monkeypatch, tmp_path)

        graph.snapshots = [
            Snapshot(values={"messages": []}, next_nodes=()),
            Snapshot(values={"draft": "present", "clickable_options": ["Approve", {"label": "Reject", "value": "no"}]}, next_nodes=("node_4",)),
            Snapshot(values={"draft": "present", "clickable_options": ["Approve", {"label": "Reject", "value": "no"}]}, next_nodes=("node_4",)),
        ]

        calls = []
        monkeypatch.setattr(
            main_module,
            "run_agent",
            lambda prompt, session_id, thread_id=None, actor_id=None, wwid="", task_id=None: calls.append(
                (prompt, session_id, thread_id, actor_id, wwid)
            ) or {"message": "Draft ready", "status": "waiting"},
        )
        monkeypatch.setattr(main_module, "resume_agent", lambda *args, **kwargs: {"message": "should not be used", "status": "complete"})
        monkeypatch.setattr(main_module, "_build_draft_document", lambda values: {"type": "doc", "content": [{"type": "text", "text": values.get("draft", "")}]})

        body = json.dumps({"prompt": "Create CR", "wwid": "alice"}).encode()
        receive_calls = {"count": 0}

        async def receive():
            if receive_calls["count"] == 0:
                receive_calls["count"] += 1
                return {"body": body, "more_body": False}
            return {"body": b"", "more_body": False}

        sent = []

        async def send(message):
            sent.append(message)

        scope = {
            "type": "http",
            "path": "/invocations",
            "method": "POST",
            "headers": [
                (b"x-amzn-bedrock-agentcore-runtime-session-id", b"sess-1"),
                (b"x-amzn-bedrock-agentcore-actor-id", b"actor-1"),
            ],
        }

        asyncio.run(main_module.app(scope, receive, send))

        assert calls == [("Create CR", "sess-1", "sess-1", "actor-1", "alice")]
        payload = json.loads(sent[1]["body"].decode())
        assert payload["chat_text"] == "Draft ready"
        assert payload["document"]["type"] == "doc"
        assert payload["clickable_options"] == [
            {"label": "Approve", "value": "Approve"},
            {"label": "Reject", "value": "no"},
        ]

    def test_asgi_app_invocations_resume_pending_interrupt(self, monkeypatch, tmp_path):
        main_module, graph = _import_main(monkeypatch, tmp_path)

        graph.snapshots = [
            Snapshot(values={"messages": []}, next_nodes=("node_18",)),
            Snapshot(values={"draft": "present"}, next_nodes=()),
            Snapshot(values={"draft": "present"}, next_nodes=()),
        ]

        resume_calls = []
        monkeypatch.setattr(main_module, "run_agent", lambda *args, **kwargs: {"message": "should not run", "status": "complete"})
        monkeypatch.setattr(
            main_module,
            "resume_agent",
            lambda prompt, session_id, thread_id=None, actor_id=None: resume_calls.append(
                (prompt, session_id, thread_id, actor_id)
            ) or {"message": "Resumed from HITL", "status": "complete"},
        )
        monkeypatch.setattr(main_module, "_build_draft_document", lambda values: None)

        body = json.dumps({"prompt": "yes", "memoryId": "memory-7"}).encode()
        receive_calls = {"count": 0}

        async def receive():
            if receive_calls["count"] == 0:
                receive_calls["count"] += 1
                return {"body": body, "more_body": False}
            return {"body": b"", "more_body": False}

        sent = []

        async def send(message):
            sent.append(message)

        scope = {
            "type": "http",
            "path": "/invocations",
            "method": "POST",
            "headers": [(b"x-amzn-bedrock-agentcore-runtime-session-id", b"sess-2")],
        }

        asyncio.run(main_module.app(scope, receive, send))

        assert resume_calls == [("yes", "sess-2", "sess-2", "memory-7")]
        payload = json.loads(sent[1]["body"].decode())
        assert payload["chat_text"] == "Resumed from HITL"
        assert payload["document"] is None
        assert payload["clickable_options"] is None

    def test_agent_handler_send_json_writes_status_headers_and_body(self, monkeypatch, tmp_path):
        main_module, _ = _import_main(monkeypatch, tmp_path)
        handler = _make_handler(main_module, "/invocations")

        handler._send_json(201, {"status": "ok"})

        assert handler.status_codes == [201]
        assert ("Content-Type", "application/json") in handler.header_calls
        body = json.loads(handler.wfile.getvalue().decode())
        assert body == {"status": "ok"}
        assert handler.ended is True

    def test_agent_handler_invocations_runs_new_session(self, monkeypatch, tmp_path):
        main_module, _ = _import_main(monkeypatch, tmp_path)
        body = json.dumps({"prompt": "hello", "session_id": "sess-1", "wwid": "alice"}).encode()
        handler = _make_handler(main_module, "/invocations", body)

        run_calls = []
        monkeypatch.setattr(
            main_module,
            "run_agent",
            lambda prompt, session_id, wwid="": run_calls.append((prompt, session_id, wwid)) or {"status": "complete", "message": "Hi"},
        )
        monkeypatch.setattr(main_module, "resume_agent", lambda *args, **kwargs: {"status": "waiting", "message": "Nope"})

        handler.do_POST()

        assert run_calls == [("hello", "sess-1", "alice")]
        assert handler.status_codes == [200]
        assert json.loads(handler.wfile.getvalue().decode())["message"] == "Hi"

    def test_agent_handler_invocations_resume_and_error_paths(self, monkeypatch, tmp_path):
        main_module, _ = _import_main(monkeypatch, tmp_path)

        resume_body = json.dumps({"human_input": "yes", "session_id": "sess-2"}).encode()
        resume_handler = _make_handler(main_module, "/invocations", resume_body)
        resume_calls = []
        monkeypatch.setattr(main_module, "run_agent", lambda *args, **kwargs: {"status": "complete", "message": "unused"})
        monkeypatch.setattr(
            main_module,
            "resume_agent",
            lambda human_input, session_id: resume_calls.append((human_input, session_id)) or {"status": "waiting", "message": "Need more"},
        )

        resume_handler.do_POST()
        assert resume_calls == [("yes", "sess-2")]
        assert resume_handler.status_codes == [200]
        assert json.loads(resume_handler.wfile.getvalue().decode())["message"] == "Need more"

        error_body = json.dumps({"prompt": "boom", "session_id": "sess-3"}).encode()
        error_handler = _make_handler(main_module, "/invocations", error_body)
        monkeypatch.setattr(main_module, "run_agent", lambda *args, **kwargs: (_ for _ in ()).throw(RuntimeError("broken")))

        error_handler.do_POST()
        assert error_handler.status_codes == [500]
        assert json.loads(error_handler.wfile.getvalue().decode())["error"] == "broken"

    def test_agent_handler_ping_404_and_log_message(self, monkeypatch, tmp_path):
        main_module, _ = _import_main(monkeypatch, tmp_path)

        ping_handler = _make_handler(main_module, "/ping")
        ping_handler.do_POST()
        assert ping_handler.status_codes == [200]
        assert ping_handler.wfile.getvalue() == b"OK"

        not_found_handler = _make_handler(main_module, "/other")
        not_found_handler.do_POST()
        assert not_found_handler.status_codes == [404]
        assert not_found_handler.wfile.getvalue() == b""

        assert main_module.AgentHandler.log_message(not_found_handler, "%s", "ignored") is None

    def test_cli_mode_with_input_arg_streams_and_completes(self, monkeypatch, tmp_path):
        main_module, _ = _import_main(monkeypatch, tmp_path)

        graph = FakeGraph()
        graph.stream_events = [{"messages": [AIMessage(content="Agent reply", id="m1")]}]
        graph.snapshot = Snapshot(messages=[], next_nodes=())

        built_state = {"messages": [HumanMessage(content="hello")]}
        monkeypatch.setattr(main_module, "build_graph", lambda: graph)
        monkeypatch.setattr(main_module, "build_initial_state", lambda text: built_state)
        monkeypatch.setattr(
            main_module.argparse.ArgumentParser,
            "parse_args",
            lambda self: types.SimpleNamespace(input="hello"),
        )

        main_module.cli_mode()

        assert graph.last_input == built_state
        assert graph.last_config == {"configurable": {"thread_id": "cr-session-1"}}

    def test_cli_mode_prompt_eof_exits_zero(self, monkeypatch, tmp_path):
        main_module, _ = _import_main(monkeypatch, tmp_path)

        monkeypatch.setattr(
            main_module.argparse.ArgumentParser,
            "parse_args",
            lambda self: types.SimpleNamespace(input=None),
        )
        monkeypatch.setattr("builtins.input", lambda *args, **kwargs: (_ for _ in ()).throw(EOFError()))

        with pytest.raises(SystemExit) as exc:
            main_module.cli_mode()
        assert exc.value.code == 0

    def test_cli_mode_empty_input_exits_one(self, monkeypatch, tmp_path):
        main_module, _ = _import_main(monkeypatch, tmp_path)

        monkeypatch.setattr(
            main_module.argparse.ArgumentParser,
            "parse_args",
            lambda self: types.SimpleNamespace(input=None),
        )
        monkeypatch.setattr("builtins.input", lambda *args, **kwargs: "   ")

        with pytest.raises(SystemExit) as exc:
            main_module.cli_mode()
        assert exc.value.code == 1

    def test_main_cli_flag_routes_to_cli_mode(self, monkeypatch, tmp_path):
        main_module, _ = _import_main(monkeypatch, tmp_path)

        calls = []
        monkeypatch.setattr(main_module, "cli_mode", lambda: calls.append("cli"))
        monkeypatch.setattr(main_module, "sys", types.SimpleNamespace(argv=["main.py", "--cli"]))

        main_module.main()

        assert calls == ["cli"]
        assert "--cli" not in main_module.sys.argv

    def test_main_server_mode_runs_uvicorn_with_port(self, monkeypatch, tmp_path):
        main_module, _ = _import_main(monkeypatch, tmp_path)

        uvicorn_calls = []
        fake_uvicorn = types.ModuleType("uvicorn")
        fake_uvicorn.run = lambda *args, **kwargs: uvicorn_calls.append((args, kwargs))
        monkeypatch.setitem(sys.modules, "uvicorn", fake_uvicorn)
        monkeypatch.setattr(main_module, "sys", types.SimpleNamespace(argv=["main.py"]))
        monkeypatch.setenv("PORT", "9090")

        main_module.main()

        assert uvicorn_calls
        args, kwargs = uvicorn_calls[0]
        assert args[0] is main_module.app
        assert kwargs["host"] == "0.0.0.0"
        assert kwargs["port"] == 9090
        assert kwargs["log_level"] == "warning"


class TestBuildDraftDocument:
    @staticmethod
    def _text_values(doc: dict) -> list[str]:
        values = []

        def walk(node):
            if isinstance(node, dict):
                if node.get("type") == "text" and node.get("text") is not None:
                    values.append(str(node.get("text")))
                for child in node.get("content", []) or []:
                    walk(child)

        walk(doc)
        return values

    def test_returns_none_without_draft(self, monkeypatch, tmp_path):
        main_module, _ = _import_main(monkeypatch, tmp_path)

        assert main_module._build_draft_document({}) is None

    def test_builds_document_with_overlays_and_derived_secondary_area(self, monkeypatch, tmp_path):
        main_module, _ = _import_main(monkeypatch, tmp_path)

        state_values = {
            "draft": "present",
            "reason_for_change": {"value": "Fix auth"},
            "description_of_change": {"value": "Update role mapping"},
            "additional_information": {"value": "None"},
            "platform": {"value": "HMD"},
            "target_system": {"value": "EJ1 100"},
            "cr_id": {
                "data": {
                    "IvDetails": {
                        "CycleId": "CYCLE-1",
                        "CycleType": "QAS",
                        "Landscape": "QA",
                        "ProcessType": "ZMCR",
                    },
                    "IvFunctionalArea": {
                        "PrimaryFunctionalArea": "Finance",
                        "SecondaryFunctionalArea": "",
                        "SfaLogistics": "X",
                    },
                }
            },
        }

        doc = main_module._build_draft_document(state_values)

        assert doc is not None
        assert doc["type"] == "doc"
        texts = self._text_values(doc)
        joined = " | ".join(texts)
        assert "Change Request" in joined
        assert "Reason for Change: " in joined
        assert "Fix auth" in joined
        assert "Platform: " in joined
        assert "HMD" in joined
        assert "CycleId" not in joined
        assert "CYCLE-1" in joined or "CYCLE-1" in texts
        assert "—" in texts
        assert len(texts) > 10

    def test_document_renders_empty_values_as_dash(self, monkeypatch, tmp_path):
        main_module, _ = _import_main(monkeypatch, tmp_path)

        doc = main_module._build_draft_document({"draft": "present", "cr_id": {"data": {}}})
        assert doc is not None
        texts = self._text_values(doc)
        assert "—" in texts

    def test_build_document_uses_template_data_when_cr_id_absent(self, monkeypatch, tmp_path):
        main_module, _ = _import_main(monkeypatch, tmp_path)

        state_values = {
            "draft": "present",
            "reason_for_change": {"value": "Need compliance"},
            "description_of_change": {"value": "Template-based draft"},
            "additional_information": {"value": "None"},
            "template_id": {
                "data": {
                    "IvDetails": {
                        "TransactionNo": "0000659852",
                        "Description": "SolMan test Template",
                        "Priority": "4",
                    },
                    "IvContext": {
                        "CycleID": "0000652829",
                        "Landscape": "SOLMAN_3S",
                    },
                }
            },
            "cr_id": {"data": {}},
        }

        doc = main_module._build_draft_document(state_values)
        assert doc is not None
        texts = self._text_values(doc)
        joined = " | ".join(texts)
        assert "0000659852" in joined
        assert "SolMan test Template" in joined
        assert "0000652829" in joined

    def test_build_document_prefers_cr_id_over_template_data(self, monkeypatch, tmp_path):
        main_module, _ = _import_main(monkeypatch, tmp_path)

        state_values = {
            "draft": "present",
            "reason_for_change": {"value": "Need compliance"},
            "description_of_change": {"value": "Merged source"},
            "additional_information": {"value": "None"},
            "template_id": {
                "data": {
                    "IvContext": {"CycleID": "0000652829"},
                }
            },
            "cr_id": {
                "data": {
                    "IvContext": {"CycleID": "0000652904"},
                }
            },
        }

        doc = main_module._build_draft_document(state_values)
        assert doc is not None
        texts = self._text_values(doc)
        joined = " | ".join(texts)
        assert "0000652904" in joined

    def test_build_document_renders_dropdown_codes_as_display_names(self, monkeypatch, tmp_path):
        main_module, _ = _import_main(monkeypatch, tmp_path)

        state_values = {
            "draft": "present",
            "reason_for_change": {"value": "Need compliance"},
            "description_of_change": {"value": "Mapped display test"},
            "additional_information": {"value": "None"},
            "cr_id": {
                "data": {
                    "IvDetails": {
                        "AprvProc": "ZMCR0001",
                        "AprvProcDesc": "J&J Approval",
                    },
                    "IvScope": {
                        "TransactionType": "YMHF",
                    },
                    "IvLocation": {
                        "Platform": "29",
                    },
                    "IvFunctionalArea": {
                        "PrimaryFunctionalArea": "01",
                    },
                }
            },
        }

        doc = main_module._build_draft_document(state_values)
        assert doc is not None
        texts = self._text_values(doc)
        joined = " | ".join(texts)

        assert "Approval Process: " in joined
        assert "J&J Approval" in joined
        assert "Transaction Type: " in joined
        assert "JnJ-Urgent Change" in joined
        assert "Platform ID: " in joined
        assert "HMD" in joined
        assert "Primary Functional Area: " in joined
        assert "OFM" in joined