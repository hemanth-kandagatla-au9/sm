import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pytest

from config import pricing


@pytest.fixture(autouse=True)
def clear_warned_models():
    pricing._warned_unknown_models.clear()
    yield
    pricing._warned_unknown_models.clear()


class TestEstimateCost:
    def test_known_model_computes_expected_cost(self):
        rates = pricing.MODEL_PRICING["gpt-5.4-mini-global"]
        cost = pricing.estimate_cost("gpt-5.4-mini-global", 1_000_000, 1_000_000)
        assert cost == round(rates["input"] + rates["output"], 6)

    def test_zero_tokens_costs_zero(self):
        assert pricing.estimate_cost("gpt-5.4-mini-global", 0, 0) == 0.0

    def test_unknown_model_falls_back_to_default_pricing(self):
        cost = pricing.estimate_cost("some-unlisted-deployment", 1_000_000, 1_000_000)
        expected = round(pricing.DEFAULT_PRICING["input"] + pricing.DEFAULT_PRICING["output"], 6)
        assert cost == expected

    def test_unknown_model_warns_once(self, caplog):
        with caplog.at_level("WARNING"):
            pricing.estimate_cost("brand-new-deployment", 100, 100)
            pricing.estimate_cost("brand-new-deployment", 100, 100)

        warnings = [r for r in caplog.records if "brand-new-deployment" in r.message]
        assert len(warnings) == 1

    def test_empty_model_name_uses_default_pricing(self):
        cost = pricing.estimate_cost("", 1_000_000, 0)
        assert cost == round(pricing.DEFAULT_PRICING["input"], 6)

    def test_result_rounded_to_six_decimals(self):
        cost = pricing.estimate_cost("gpt-5.4-mini-2026-03-17", 123, 456)
        assert cost == round(cost, 6)
