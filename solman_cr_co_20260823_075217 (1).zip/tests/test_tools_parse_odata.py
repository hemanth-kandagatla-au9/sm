"""
tests/test_tools_parse_odata.py

Unit tests for tools/_parse_odata_response — pure function, zero mocking.

Covers:
  - Format A: ZCHM_RFC_SRV nested Iv* group structure
  - Format B: legacy flat collection with 'results' array
  - Flat fallback: 'd' dict with no Iv* groups and no results array
  - Error paths: non-dict input, empty results, missing 'd' key
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pytest
from tools.tools import _parse_odata_response


# ─────────────────────────────────────────────────────────────────────────────
# Format B — legacy flat collection with 'results' array
# ─────────────────────────────────────────────────────────────────────────────
class TestFormatB:

    def test_first_record_returned(self):
        data = {"d": {"results": [{"object_id": "50339227", "description": "Test CR"}]}}
        result = _parse_odata_response(data, "50339227")
        assert result["object_id"] == "50339227"
        assert result["description"] == "Test CR"

    def test_template_id_injected(self):
        data = {"d": {"results": [{"object_id": "50339227"}]}}
        result = _parse_odata_response(data, "50339227")
        assert result["template_id"] == "50339227"

    def test_metadata_stripped(self):
        data = {"d": {"results": [{"__metadata": {"type": "SAPType"}, "object_id": "123"}]}}
        result = _parse_odata_response(data, "123")
        assert "__metadata" not in result

    def test_empty_results_returns_error(self):
        data = {"d": {"results": []}}
        result = _parse_odata_response(data, "99999")
        assert "error" in result
        assert result.get("template_id") == "99999"

    def test_second_record_ignored(self):
        """Only the first result is used."""
        data = {"d": {"results": [
            {"object_id": "111", "description": "First"},
            {"object_id": "222", "description": "Second"},
        ]}}
        result = _parse_odata_response(data, "111")
        assert result["object_id"] == "111"
        assert result.get("description") == "First"


# ─────────────────────────────────────────────────────────────────────────────
# Format A — ZCHM_RFC_SRV nested Iv* group structure
# ─────────────────────────────────────────────────────────────────────────────
class TestFormatA:

    def _make_format_a(self, **extra_top_level) -> dict:
        """Build a minimal Format A OData payload."""
        d = {
            "IvDetails": {
                "Description": "Test CR",
                "Priority": "4: Low",
                "__metadata": {"type": "SAPType"},
            },
            "IvDocumentation": {
                "BCSet": "Business reason",
                "CodeReview": "Technical document",
            },
            "IvTestReq": {
                "RegressionTestQAS": "X",
                "UATQAS": "X",
            },
        }
        d.update(extra_top_level)
        return {"d": d}

    def test_iv_details_group_preserved(self):
        data = self._make_format_a()
        result = _parse_odata_response(data, "65669")
        assert "IvDetails" in result
        assert result["IvDetails"]["Description"] == "Test CR"

    def test_iv_documentation_group_preserved(self):
        data = self._make_format_a()
        result = _parse_odata_response(data, "65669")
        assert "IvDocumentation" in result
        assert result["IvDocumentation"]["BCSet"] == "Business reason"
        assert result["IvDocumentation"]["CodeReview"] == "Technical document"

    def test_iv_testreq_group_preserved(self):
        data = self._make_format_a()
        result = _parse_odata_response(data, "65669")
        assert "IvTestReq" in result
        assert result["IvTestReq"]["RegressionTestQAS"] == "X"

    def test_metadata_stripped_from_group(self):
        data = self._make_format_a()
        result = _parse_odata_response(data, "65669")
        assert "__metadata" not in result["IvDetails"]

    def test_template_id_injected(self):
        data = self._make_format_a()
        result = _parse_odata_response(data, "65669")
        assert result["template_id"] == "65669"

    def test_none_values_become_empty_string(self):
        data = {"d": {"IvDetails": {"Description": None, "Priority": "4: Low"}}}
        result = _parse_odata_response(data, "123")
        assert result["IvDetails"]["Description"] == ""

    def test_ev_object_id_preserved(self):
        data = self._make_format_a(EvObjectId="50339227")
        result = _parse_odata_response(data, "65669")
        assert result["EvObjectId"] == "50339227"

    def test_ev_object_id_absent_not_in_result(self):
        data = self._make_format_a()
        result = _parse_odata_response(data, "65669")
        assert "EvObjectId" not in result

    def test_iv_template_id_skipped(self):
        """IvTemplateId is a control field and must not appear in result groups."""
        data = {"d": {
            "IvDetails": {"Description": "Test"},
            "IvTemplateId": "65669",
        }}
        result = _parse_odata_response(data, "65669")
        assert "IvTemplateId" not in result

    def test_ev_message_skipped(self):
        data = {"d": {
            "IvDetails": {"Description": "Test"},
            "EvMessage": "Success",
        }}
        result = _parse_odata_response(data, "65669")
        assert "EvMessage" not in result

    def test_non_dict_group_values_skipped(self):
        """If a top-level value is not a dict, it must not appear as a group."""
        data = {"d": {
            "IvDetails": {"Description": "Test"},
            "IvSomeFlag": "true",  # non-dict — not a group
        }}
        result = _parse_odata_response(data, "65669")
        assert "IvSomeFlag" not in result


# ─────────────────────────────────────────────────────────────────────────────
# Flat fallback — 'd' dict with no Iv* groups and no results array
# ─────────────────────────────────────────────────────────────────────────────
class TestFlatFallback:

    def test_flat_props_returned(self):
        data = {"d": {"object_id": "111", "description": "flat record"}}
        result = _parse_odata_response(data, "111")
        assert result["object_id"] == "111"
        assert result["description"] == "flat record"

    def test_metadata_stripped(self):
        data = {"d": {"__metadata": {"type": "x"}, "object_id": "222"}}
        result = _parse_odata_response(data, "222")
        assert "__metadata" not in result

    def test_template_id_injected(self):
        data = {"d": {"object_id": "333"}}
        result = _parse_odata_response(data, "333")
        assert result["template_id"] == "333"

    def test_no_d_key_treated_as_flat(self):
        """When 'd' key is absent, entire dict is treated as flat record."""
        data = {"object_id": "444", "description": "no envelope"}
        result = _parse_odata_response(data, "444")
        assert result.get("object_id") == "444" or "template_id" in result


# ─────────────────────────────────────────────────────────────────────────────
# Error paths
# ─────────────────────────────────────────────────────────────────────────────
class TestErrorPaths:

    def test_non_dict_input_returns_error(self):
        result = _parse_odata_response("not a dict", "123")
        assert "error" in result

    def test_list_input_returns_error(self):
        result = _parse_odata_response([], "123")
        assert "error" in result

    def test_none_input_returns_error(self):
        result = _parse_odata_response(None, "123")
        assert "error" in result

    def test_d_is_not_dict_returns_error(self):
        result = _parse_odata_response({"d": "unexpected string"}, "123")
        assert "error" in result


# ─────────────────────────────────────────────────────────────────────────────
# Format A — real-world fields from ZCHM_RFC_SRV ChangeRequestSet read API
# Based on the actual response structure returned by:
#   ChangeRequestSet('50174731')?$expand=toPartners,toTexts&$format=json
# ─────────────────────────────────────────────────────────────────────────────
class TestFormatARealWorldFields:
    """
    Tests that exercise Format A paths not covered by the minimal helper in
    TestFormatA — specifically the groups and skip-rules visible in a real
    ChangeRequestSet GET response.
    """

    # ── IvContext (cycle data read from the SAP API) ────────────────────────

    def test_iv_context_group_preserved(self):
        """IvContext with CycleID and related fields must survive the parse."""
        data = {"d": {
            "IvDetails": {"Description": "Operate Change Admin Workflow"},
            "IvContext": {
                "__metadata": {"type": "ZCHM_RFC_SRV.IvContext"},
                "ChangeCycle": "SolMan D94 3 system - SP09",
                "ChangeCyclePhase": "Active",
                "CycleType": "Continual Cycle",
                "CycleID": "0000653541",
                "Landscape": "SOLMAN_ECC_D94",
                "Branch": "Maintenance",
            },
        }}
        result = _parse_odata_response(data, "50174731")
        assert "IvContext" in result
        ctx = result["IvContext"]
        assert ctx["CycleID"] == "0000653541"
        assert ctx["ChangeCycle"] == "SolMan D94 3 system - SP09"
        assert ctx["CycleType"] == "Continual Cycle"
        assert ctx["Landscape"] == "SOLMAN_ECC_D94"
        assert ctx["Branch"] == "Maintenance"
        assert "__metadata" not in ctx

    def test_iv_context_cycle_id_empty_becomes_empty_string(self):
        """A None CycleID inside IvContext is normalised to empty string."""
        data = {"d": {
            "IvDetails": {"Description": "Test"},
            "IvContext": {"CycleID": None, "CycleType": "Continual Cycle"},
        }}
        result = _parse_odata_response(data, "50174731")
        assert result["IvContext"]["CycleID"] == ""

    # ── IvScope — ConfigurationItem leading-zero stripping ──────────────────

    def test_iv_scope_configuration_item_leading_zeros_stripped(self):
        """
        ConfigurationItem is stored zero-padded by SAP
        (e.g. '0000000000000000000000000000007100002899').
        _parse_odata_response must strip leading zeros at parse time.
        """
        data = {"d": {
            "IvScope": {
                "__metadata": {"type": "ZCHM_RFC_SRV.IvScope"},
                "TransactionType": "ZHAD",
                "TransactionID": "0050174755",
                "ConfigurationItem": "0000000000000000000000000000007100002899",
                "SID": "D94",
            },
        }}
        result = _parse_odata_response(data, "50174731")
        assert result["IvScope"]["ConfigurationItem"] == "7100002899"

    def test_iv_scope_configuration_item_no_leading_zeros_unchanged(self):
        """ConfigurationItem without leading zeros is returned as-is."""
        data = {"d": {
            "IvScope": {"ConfigurationItem": "7100002899", "SID": "D94"},
        }}
        result = _parse_odata_response(data, "50174731")
        assert result["IvScope"]["ConfigurationItem"] == "7100002899"

    def test_iv_scope_configuration_item_all_zeros_preserved(self):
        """
        When ConfigurationItem is all zeros lstrip('0') would return ''.
        The 'or _raw_ci' fallback must preserve the original value.
        """
        data = {"d": {
            "IvScope": {"ConfigurationItem": "000000000", "SID": "D94"},
        }}
        result = _parse_odata_response(data, "50174731")
        assert result["IvScope"]["ConfigurationItem"] == "000000000"

    # ── toPartners / toTexts — $expand collections must be skipped ───────────

    def test_to_partners_expansion_not_in_result(self):
        """
        toPartners is an OData $expand navigation property (not an Iv* group).
        It must be excluded from the parsed result.
        """
        data = {"d": {
            "IvDetails": {"Description": "Test"},
            "toPartners": {
                "results": [
                    {"PartnerFct": "00000001", "PartnerNo": "121733", "DescriptionName": "TIME GVC"},
                    {"PartnerFct": "SDCR0001", "PartnerNo": "120914", "DescriptionName": "Test SMTQ2"},
                ]
            },
        }}
        result = _parse_odata_response(data, "50174731")
        assert "toPartners" not in result

    def test_to_texts_expansion_not_in_result(self):
        """toTexts is an OData $expand navigation property and must be excluded."""
        data = {"d": {
            "IvDetails": {"Description": "Test"},
            "toTexts": {
                "results": [
                    {"TdID": "ZDS1", "TdIDDescr": "Digital Signature Log", "TextLines": "ITLA"},
                ]
            },
        }}
        result = _parse_odata_response(data, "50174731")
        assert "toTexts" not in result

    # ── EvHasError / IvRequestor — non-Iv* scalar fields skipped ────────────

    def test_ev_has_error_boolean_not_in_result(self):
        """EvHasError is a bool in the real response and must not appear in output."""
        data = {"d": {
            "IvDetails": {"Description": "Test"},
            "EvHasError": False,
        }}
        result = _parse_odata_response(data, "50174731")
        assert "EvHasError" not in result

    def test_iv_requestor_string_not_in_result(self):
        """IvRequestor is an empty string in the real response; non-dict groups are skipped."""
        data = {"d": {
            "IvDetails": {"Description": "Test"},
            "IvRequestor": "",
        }}
        result = _parse_odata_response(data, "50174731")
        assert "IvRequestor" not in result

    # ── IvOthers, IvLocation, IvFunctionalArea ───────────────────────────────

    def test_iv_others_group_preserved(self):
        """IvOthers fields such as GxPRelevant, SOXImpact must be preserved."""
        data = {"d": {
            "IvDetails": {"Description": "Test"},
            "IvOthers": {
                "__metadata": {"type": "ZCHM_RFC_SRV.IvOthers"},
                "GxPRelevant": "0",
                "GxPRelevantT": "No",
                "SecurityChange": "0",
                "SOXImpact": "0",
                "DefectReference": "N/A",
                "RICEF": "N/A",
            },
        }}
        result = _parse_odata_response(data, "50174731")
        assert "IvOthers" in result
        others = result["IvOthers"]
        assert others["GxPRelevant"] == "0"
        assert others["SOXImpact"] == "0"
        assert others["DefectReference"] == "N/A"
        assert "__metadata" not in others

    def test_iv_location_group_preserved(self):
        """IvLocation with Platform and Site fields must be preserved."""
        data = {"d": {
            "IvDetails": {"Description": "Test"},
            "IvLocation": {
                "__metadata": {"type": "ZCHM_RFC_SRV.IvLocation"},
                "Platform": "19",
                "PlatformT": "AS SolMan",
                "Site": "",
            },
        }}
        result = _parse_odata_response(data, "50174731")
        assert "IvLocation" in result
        assert result["IvLocation"]["Platform"] == "19"
        assert result["IvLocation"]["PlatformT"] == "AS SolMan"

    def test_iv_functional_area_group_preserved(self):
        """IvFunctionalArea with PrimaryFunctionalArea must be preserved."""
        data = {"d": {
            "IvDetails": {"Description": "Test"},
            "IvFunctionalArea": {
                "__metadata": {"type": "ZCHM_RFC_SRV.IvFunctionalArea"},
                "PrimaryFunctionalArea": "17",
                "PrimaryFunctionalAreaT": "Development",
                "SfaDevelopment": "",
            },
        }}
        result = _parse_odata_response(data, "50174731")
        assert "IvFunctionalArea" in result
        assert result["IvFunctionalArea"]["PrimaryFunctionalArea"] == "17"
        assert result["IvFunctionalArea"]["PrimaryFunctionalAreaT"] == "Development"

    # ── datetime isoformat conversion ─────────────────────────────────────────

    def test_datetime_field_converted_to_iso_string(self):
        """
        If SAP returns a datetime object inside an Iv* group, it must be
        serialised via .isoformat() so the result is JSON-safe.
        """
        import datetime
        dt = datetime.datetime(2026, 6, 9, 15, 13, 13)
        data = {"d": {
            "IvDetails": {
                "Description": "Test",
                "CreatedOn": dt,
            },
        }}
        result = _parse_odata_response(data, "50174731")
        assert result["IvDetails"]["CreatedOn"] == dt.isoformat()

    # ── EvObjectID uppercase-D variant ───────────────────────────────────────

    def test_ev_object_id_uppercase_d_variant_preserved(self):
        """
        The real API returns 'EvObjectID' (capital D). The parser checks both
        variants and stores the value under the canonical 'EvObjectId' key.
        """
        data = {"d": {
            "IvDetails": {"Description": "Test"},
            "EvObjectID": "50174731",
        }}
        result = _parse_odata_response(data, "50174731")
        assert result.get("EvObjectId") == "50174731"

    # ── Full real-world ChangeRequestSet response ────────────────────────────

    def test_full_real_world_cr_50174731(self):
        """
        Parse a realistic ChangeRequestSet GET response (CR 50174731).
        Verifies that all Iv* groups are preserved, key field values are correct,
        $expand navigation properties are excluded, and the template_id is set.
        """
        raw = {
            "d": {
                "__metadata": {
                    "type": "ZCHM_RFC_SRV.ChangeRequest"
                },
                "IvDetails": {
                    "__metadata": {"type": "ZCHM_RFC_SRV.IvDetails"},
                    "TransactionNo": "0050174731",
                    "Description": "Operate Change Admin Workflow",
                    "OperateChange": "X",
                    "Status": "E0023",
                    "StatusDesc": "To be Approved(Non-Standard)",
                    "Priority": "4",
                    "PriorityDesc": "4: Low",
                    "Risk": "004",
                    "RiskT": "Low",
                },
                "IvContext": {
                    "__metadata": {"type": "ZCHM_RFC_SRV.IvContext"},
                    "ChangeCycle": "SolMan D94 3 system - SP09",
                    "ChangeCyclePhase": "Active",
                    "CycleType": "Continual Cycle",
                    "CycleID": "0000653541",
                    "Landscape": "SOLMAN_ECC_D94",
                    "Branch": "Maintenance",
                },
                "IvScope": {
                    "__metadata": {"type": "ZCHM_RFC_SRV.IvScope"},
                    "TransactionType": "ZHAD",
                    "TransactionID": "0050174755",
                    "Description": "Operate Change Admin Workflow",
                    "Status": "Successfully Tested in QA",
                    "ConfigurationItem": "0000000000000000000000000000007100002899",
                    "ConfigurationItemDescr": "D94 0020205066 904",
                    "SID": "D94",
                    "Client": "904",
                },
                "IvLocation": {
                    "__metadata": {"type": "ZCHM_RFC_SRV.IvLocation"},
                    "Platform": "19",
                    "PlatformT": "AS SolMan",
                    "Site": "",
                },
                "IvFunctionalArea": {
                    "__metadata": {"type": "ZCHM_RFC_SRV.IvFunctionalArea"},
                    "PrimaryFunctionalArea": "17",
                    "PrimaryFunctionalAreaT": "Development",
                },
                "IvOthers": {
                    "__metadata": {"type": "ZCHM_RFC_SRV.IvOthers"},
                    "GxPRelevant": "0",
                    "GxPRelevantT": "No",
                    "SOXImpact": "0",
                    "DefectReference": "N/A",
                    "RICEF": "N/A",
                    "DeferredTo": "00.00.0000",
                },
                "IvDocumentation": {
                    "__metadata": {"type": "ZCHM_RFC_SRV.IvDocumentation"},
                    "BCSet": "0",
                    "BCSetT": "No",
                    "CodeReview": "0",
                    "Others1": "N/A",
                },
                "IvTestReq": {
                    "__metadata": {"type": "ZCHM_RFC_SRV.IvTestReq"},
                    "ScreenShotQAS": "1",
                    "ScreenShotQAST": "Yes",
                    "UATQAS": "1",
                    "UATQAST": "Yes",
                    "RegressionTestQAS": "0",
                },
                "IvValidation": {
                    "__metadata": {"type": "ZCHM_RFC_SRV.IvValidation"},
                    "FunctionalDesign": "0",
                    "FunctionalDesignT": "No",
                    "TechincalDesign": "0",
                    "TechincalDesignT": "No",
                },
                # Fields that must be skipped
                "IvRequestor": "",
                "IvTemplateID": "",
                "EvHasError": False,
                "EvMessage": "",
                "EvObjectID": "50174731",
                "toReturn": {"__deferred": {"uri": "https://example/toReturn"}},
                "toPartners": {
                    "results": [
                        {"PartnerFct": "00000001", "PartnerNo": "121733"},
                        {"PartnerFct": "SDCR0001", "PartnerNo": "120914"},
                    ]
                },
                "toTexts": {
                    "results": [
                        {"TdID": "ZDS1", "TdIDDescr": "Digital Signature Log"},
                    ]
                },
            }
        }
        result = _parse_odata_response(raw, "50174731")

        # template_id set
        assert result["template_id"] == "50174731"

        # All Iv* groups preserved
        for grp in ("IvDetails", "IvContext", "IvScope", "IvLocation",
                    "IvFunctionalArea", "IvOthers", "IvDocumentation",
                    "IvTestReq", "IvValidation"):
            assert grp in result, f"{grp} missing from parsed result"

        # Key field values
        assert result["IvDetails"]["Description"] == "Operate Change Admin Workflow"
        assert result["IvContext"]["CycleID"] == "0000653541"
        assert result["IvContext"]["CycleType"] == "Continual Cycle"
        assert result["IvContext"]["Landscape"] == "SOLMAN_ECC_D94"
        assert result["IvScope"]["ConfigurationItem"] == "7100002899"  # zeros stripped
        assert result["IvScope"]["SID"] == "D94"
        assert result["IvLocation"]["Platform"] == "19"
        assert result["IvFunctionalArea"]["PrimaryFunctionalArea"] == "17"
        assert result["IvOthers"]["GxPRelevant"] == "0"
        assert result["IvTestReq"]["UATQAS"] == "1"
        assert result["IvValidation"]["FunctionalDesign"] == "0"

        # EvObjectID (capital D) stored as canonical EvObjectId
        assert result.get("EvObjectId") == "50174731"

        # Navigation properties and control fields excluded
        for excluded in ("toPartners", "toTexts", "toReturn",
                         "EvHasError", "EvMessage", "IvRequestor",
                         "IvTemplateID", "__metadata"):
            assert excluded not in result, f"{excluded} should be excluded"

        # No __metadata inside any group
        for grp in ("IvDetails", "IvContext", "IvScope"):
            assert "__metadata" not in result[grp]
