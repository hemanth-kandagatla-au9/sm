"""
Integration test for the token-tracking design: 
that a callback passed only at the top-level graph.stream(config=...)
call reaches a **bare** LLM `.invoke([...])` call made deep inside a node
function with NO explicit config threaded through.
"""
import os
import sys
from typing import Any, List, Optional, TypedDict

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage
from langchain_core.outputs import ChatGeneration, ChatResult
from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import END, START, StateGraph

from observability import trace_node
from observability.token_tracking import (
    TokenCostCallbackHandler,
    get_token_accumulator,
    reset_token_accumulator,
)


class FakeChatModel(BaseChatModel):
    """Minimal fake chat model that reports usage_metadata like a real one would."""

    @property
    def _llm_type(self) -> str:
        return "fake"

    def _generate(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        run_manager: Any = None,
        **kwargs: Any,
    ) -> ChatResult:
        message = AIMessage(
            content="fake response",
            usage_metadata={"input_tokens": 42, "output_tokens": 7, "total_tokens": 49},
        )
        return ChatResult(
            generations=[ChatGeneration(message=message)],
            llm_output={"model_name": "fake-model"},
        )


class _State(TypedDict):
    x: int


def _node_calls_bare_llm(state: _State) -> dict:
    # .invoke() called with NO explicit `config=` argument.
    llm = FakeChatModel()
    llm.invoke([HumanMessage(content="hi")])
    return {"x": state["x"] + 1}


def test_ambient_callback_reaches_bare_llm_invoke_inside_node():
    builder = StateGraph(_State)
    builder.add_node("node_bare_llm", trace_node("node_bare_llm", _node_calls_bare_llm))
    builder.add_edge(START, "node_bare_llm")
    builder.add_edge("node_bare_llm", END)
    graph = builder.compile(checkpointer=MemorySaver())

    reset_token_accumulator()
    config = {
        "configurable": {"thread_id": "test-thread-1"},
        "callbacks": [TokenCostCallbackHandler()],
    }

    list(graph.stream({"x": 0}, config=config, stream_mode="values"))

    totals = get_token_accumulator()
    assert totals["input_tokens"] == 42
    assert totals["output_tokens"] == 7
    assert totals["call_count"] == 1
