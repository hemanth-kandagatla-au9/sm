import os
import sys
import types
from unittest.mock import MagicMock, patch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


class _DateLike:
    def __init__(self, value):
        self.value = value

    def isoformat(self):
        return self.value


class TestBuildSolmanGetUrls:
    def test_builds_four_candidate_urls(self):
        from tools.tools import _build_solman_get_urls

        with patch("tools.tools.SOLMAN_READ_BASE_URL", "https://sap.example.com"), \
             patch("tools.tools.SOLMAN_ODATA_PATH", "/sap/opu/odata/sap/ZCHM_RFC_SRV/ChangeRequestSet"):
            urls = _build_solman_get_urls(" 50174545 ")

        assert len(urls) == 4
        assert "%2750174545%27" in urls[0]
        assert "('50174545')" in urls[1]
        assert urls[0].startswith("https://sap.example.com/sap/opu/odata/sap/ZCHM_RFC_SRV/ChangeRequestSet")


class TestGetTemplateFromNeo4j:
    def test_returns_error_when_not_found(self):
        from tools.tools import _get_template_from_neo4j

        with patch("tools.tools._run_cypher", return_value=[]):
            result = _get_template_from_neo4j("12345")

        assert "error" in result
        assert result["template_id"] == "12345"

    def test_normalizes_neo4j_props(self):
        from tools.tools import _get_template_from_neo4j

        rows = [{"props": {"created": _DateLike("2026-06-18"), "count": 7, "obj": object()}}]
        with patch("tools.tools._run_cypher", return_value=rows):
            result = _get_template_from_neo4j("12345")

        assert result["template_id"] == "12345"
        assert result["created"] == "2026-06-18"
        assert result["count"] == 7
        assert isinstance(result["obj"], str)


class TestGetTemplateGrouped:
    def _mock_response(self, payload):
        response = MagicMock()
        response.raise_for_status.return_value = None
        response.json.return_value = payload
        return response

    def test_empty_template_id_returns_error(self):
        from tools.tools import get_template_grouped

        assert get_template_grouped("   ")["error"] == "template_id is empty"

    def test_not_configured_returns_error(self):
        from tools.tools import get_template_grouped

        with patch("tools.tools.SOLMAN_READ_BASE_URL", ""), \
             patch("tools.tools.SOLMAN_READ_USERNAME", ""):
            result = get_template_grouped("12345")

        assert result["error"] == "Solman API not configured"
        assert result["TransactionNo"] == "12345"

    def test_success_returns_clean_grouped_data(self):
        from tools.tools import get_template_grouped

        payload = {
            "d": {
                "IvDetails": {"TransactionNo": "12345", "Created": _DateLike("2026-06-18"), "__metadata": {}},
                "IvOthers": {"Flag": 1, "Empty": None, "__metadata": {}},
                "IvFunctionalArea": {"PrimaryFunctionalArea": "Finance"},
                "IvValidation": {},
                "IvLocation": {},
                "IvTestReq": {},
                "IvDocumentation": {},
            }
        }

        with patch("tools.tools.SOLMAN_READ_BASE_URL", "https://sap.example.com"), \
             patch("tools.tools.SOLMAN_READ_USERNAME", "user"), \
             patch("tools.tools.requests.get", return_value=self._mock_response(payload)):
            result = get_template_grouped("12345")

        assert result["error"] is None
        assert result["TransactionNo"] == "12345"
        assert result["IvDetails"]["Created"] == "2026-06-18"
        assert "__metadata" not in result["IvDetails"]
        assert result["IvOthers"]["Flag"] == "1"
        assert result["IvFunctionalArea"]["PrimaryFunctionalArea"] == "Finance"

    def test_http_error_returns_error_dict(self):
        from tools.tools import get_template_grouped

        response = MagicMock()
        response.raise_for_status.side_effect = RuntimeError("boom")

        with patch("tools.tools.SOLMAN_READ_BASE_URL", "https://sap.example.com"), \
             patch("tools.tools.SOLMAN_READ_USERNAME", "user"), \
             patch("tools.tools.requests.get", return_value=response):
            result = get_template_grouped("12345")

        assert result["TransactionNo"] == "12345"
        assert "boom" in result["error"]


class TestGetValidFieldValues:
    def test_platform_values_use_platform_nodes(self):
        from tools.tools import get_valid_field_values

        with patch("tools.tools._run_cypher", return_value=[{"val": "Atlas"}, {"val": "HMD"}]):
            result = get_valid_field_values("platform", limit=2)

        assert result == ["Atlas", "HMD"]

    def test_target_system_values_scoped_to_platform(self):
        from tools.tools import get_valid_field_values

        rows = [{"val": "EJ1 100", "cnt": 10}, {"val": "EJ2 200", "cnt": 5}]
        with patch("tools.tools._run_cypher", return_value=rows):
            result = get_valid_field_values("target_system", platform="cfin")

        assert result == ["EJ1 100 (10)", "EJ2 200 (5)"]

    def test_unknown_field_returns_empty_list(self):
        from tools.tools import get_valid_field_values

        assert get_valid_field_values("unknown-field") == []

    def test_generic_field_uses_field_map(self):
        from tools.tools import get_valid_field_values

        rows = [{"val": "ZMCR"}, {"val": "ZMMJ"}]
        with patch("tools.tools._run_cypher", return_value=rows):
            result = get_valid_field_values("process_type")

        assert result == ["ZMCR", "ZMMJ"]


class TestValidateTargetSystem:
    def test_platform_scoped_exact_match(self):
        from tools.tools import validate_target_system

        with patch("tools.tools._run_cypher", return_value=[{"name": "EJ1 100"}]):
            result = validate_target_system("EJ1 100", platform="cfin")

        assert result == {"valid": True, "resolved_name": "EJ1 100", "error": None}

    def test_platform_scoped_fuzzy_match(self):
        from tools.tools import validate_target_system

        with patch("tools.tools._run_cypher", side_effect=[[], [{"name": "HMD MBOX ---"}]]):
            result = validate_target_system("HMD MBOX", platform="HMD")

        assert result["valid"] is True
        assert result["resolved_name"] == "HMD MBOX ---"

    def test_platform_scoped_change_request_fallback(self):
        from tools.tools import validate_target_system

        with patch("tools.tools._run_cypher", side_effect=[[], [], [{"name": "CFG-123"}]]):
            result = validate_target_system("CFG-123", platform="HMD")

        assert result["valid"] is True
        assert result["resolved_name"] == "CFG-123"

    def test_platform_scoped_not_found_lists_valid_values(self):
        from tools.tools import validate_target_system

        with patch("tools.tools._run_cypher", side_effect=[[], [], [], [{"name": "A"}, {"name": "B"}]]):
            result = validate_target_system("missing", platform="HMD")

        assert result["valid"] is False
        assert "A, B" in result["error"]

    def test_global_exact_match(self):
        from tools.tools import validate_target_system

        with patch("tools.tools._run_cypher", return_value=[{"name": "EJ1 100"}]):
            result = validate_target_system("EJ1 100")

        assert result["valid"] is True
        assert result["resolved_name"] == "EJ1 100"

    def test_global_change_request_fallback(self):
        from tools.tools import validate_target_system

        with patch("tools.tools._run_cypher", side_effect=[[], [{"name": "CFG-1"}]]):
            result = validate_target_system("CFG-1")

        assert result["valid"] is True
        assert result["resolved_name"] == "CFG-1"

    def test_global_related_system_suggests_platform(self):
        from tools.tools import validate_target_system

        with patch("tools.tools._run_cypher", side_effect=[[], []]):
            result = validate_target_system("trax")

        assert result["valid"] is False
        assert result["suggested_platform"] == "Symphony"
        assert "Did you mean" in result["suggestion_message"]

    def test_global_not_found_lists_all_values(self):
        from tools.tools import validate_target_system

        with patch("tools.tools._run_cypher", side_effect=[[], [], [{"name": "X"}, {"name": "Y"}]]):
            result = validate_target_system("missing")

        assert result["valid"] is False
        assert "X, Y" in result["error"]


class TestValidateField:
    def test_unknown_field_returns_error(self):
        from tools.tools import _validate_field

        result = _validate_field("not-a-field", "value")

        assert result == {
            "valid": False,
            "canonical": None,
            "candidates": [],
            "error": "Unknown field: not-a-field",
        }

    def test_exact_match_returns_canonical_and_candidates(self):
        from tools.tools import _validate_field

        with patch("tools.tools._run_cypher", return_value=[{"name": "HMD"}, {"name": "HMD Alt"}]):
            result = _validate_field("platform", "hmd")

        assert result == {
            "valid": True,
            "canonical": "HMD",
            "candidates": ["HMD", "HMD Alt"],
            "error": None,
        }

    def test_partial_match_used_when_exact_match_fails(self):
        from tools.tools import _validate_field

        with patch("tools.tools._run_cypher", side_effect=[[], [{"name": "Central Finance SAP"}]]):
            result = _validate_field("platform", "finance")

        assert result["valid"] is True
        assert result["canonical"] == "Central Finance SAP"
        assert result["candidates"] == ["Central Finance SAP"]

    def test_not_found_returns_sample_values(self):
        from tools.tools import _validate_field

        with patch(
            "tools.tools._run_cypher",
            side_effect=[[], [], [{"name": "Atlas SAP"}, {"name": "HMD"}, {"error": "ignored"}]],
        ):
            result = _validate_field("platform", "missing")

        assert result["valid"] is False
        assert result["canonical"] is None
        assert result["candidates"] == []
        assert "Available values: ['Atlas SAP', 'HMD']" in result["error"]


class TestRunCypher:
    def test_import_error_returns_error_row(self, monkeypatch):
        import builtins
        from tools.tools import _run_cypher

        real_import = builtins.__import__

        def raising_import(name, *args, **kwargs):
            if name == "neo4j":
                raise ImportError("neo4j missing")
            return real_import(name, *args, **kwargs)

        monkeypatch.setattr(builtins, "__import__", raising_import)

        result = _run_cypher("RETURN 1")
        assert result == [{"error": "neo4j import error: neo4j missing"}]

    def test_backend_exception_returns_error_row(self, monkeypatch):
        from tools.tools import _run_cypher

        class _ExplodingGraphDatabase:
            @staticmethod
            def driver(*args, **kwargs):
                raise RuntimeError("connection failed")

        monkeypatch.setitem(sys.modules, "neo4j", types.SimpleNamespace(GraphDatabase=_ExplodingGraphDatabase))

        with patch(
            "tools.tools.get_settings",
            return_value=types.SimpleNamespace(
                neo4j_uri="bolt://localhost",
                neo4j_user="neo4j",
                neo4j_password="secret",
                neo4j_database="neo4j",
            ),
        ):
            result = _run_cypher("RETURN 1")
        assert result == [{"error": "connection failed"}]

    def test_success_returns_rows_and_closes_driver(self, monkeypatch):
        from tools.tools import _run_cypher

        closed = {"value": False}
        session_calls = []

        class _FakeSession:
            def __enter__(self):
                return self

            def __exit__(self, exc_type, exc, tb):
                return False

            def run(self, query, parameters=None):
                session_calls.append((query, parameters))
                return [{"name": "HMD"}, {"name": "Atlas SAP"}]

        class _FakeDriver:
            def session(self, database=None):
                assert database == "neo4j-db"
                return _FakeSession()

            def close(self):
                closed["value"] = True

        class _FakeGraphDatabase:
            @staticmethod
            def driver(uri, auth=None):
                assert uri == "bolt://localhost"
                assert auth == ("neo4j", "secret")
                return _FakeDriver()

        monkeypatch.setitem(sys.modules, "neo4j", types.SimpleNamespace(GraphDatabase=_FakeGraphDatabase))

        with patch(
            "tools.tools.get_settings",
            return_value=types.SimpleNamespace(
                neo4j_uri="bolt://localhost",
                neo4j_user="neo4j",
                neo4j_password="secret",
                neo4j_database="neo4j-db",
            ),
        ):
            result = _run_cypher("RETURN $value AS name", {"value": "HMD"})

        assert result == [{"name": "HMD"}, {"name": "Atlas SAP"}]
        assert session_calls == [("RETURN $value AS name", {"value": "HMD"})]
        assert closed["value"] is True