"""
tests/test_tools_validate_scope.py

Unit tests for tools/validate_change_scope — LLM (AzureChatOpenAI) mocked.

Covers:
  - IN_SCOPE / OUT_OF_SCOPE / UNCLEAR classification pass-through
  - IRIS and Business SOP redirect values
  - Invalid / non-JSON LLM response falls back to UNCLEAR
  - LLM raises exception — always returns UNCLEAR (never crashes caller)
  - raw_response field is always populated
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import json
from unittest.mock import patch, MagicMock
import pytest


def _build_mock_response(content: str) -> MagicMock:
    mock_resp = MagicMock()
    mock_resp.content = content
    return mock_resp


def _run_scope(llm_response_content: str) -> dict:
    """Run validate_change_scope with a fully mocked AzureChatOpenAI.

    validate_change_scope imports AzureChatOpenAI *locally* inside the
    function body, so the correct patch target is the langchain_openai
    module, not tools.tools.
    """
    from tools.tools import validate_change_scope

    mock_resp = _build_mock_response(llm_response_content)
    with patch("langchain_openai.AzureChatOpenAI") as mock_cls:
        mock_llm = MagicMock()
        mock_llm.invoke.return_value = mock_resp
        mock_cls.return_value = mock_llm
        return validate_change_scope("test user message")


# ─────────────────────────────────────────────────────────────────────────────
# Happy-path classifications
# ─────────────────────────────────────────────────────────────────────────────
class TestValidateChangeScopeClassifications:

    def test_in_scope_returned(self):
        raw = json.dumps({"classification": "IN_SCOPE", "reason": "SAP config change", "redirect": None})
        result = _run_scope(raw)
        assert result["classification"] == "IN_SCOPE"

    def test_in_scope_redirect_is_none(self):
        raw = json.dumps({"classification": "IN_SCOPE", "reason": "ok", "redirect": None})
        result = _run_scope(raw)
        assert result["redirect"] is None

    def test_out_of_scope_iris(self):
        raw = json.dumps({"classification": "OUT_OF_SCOPE", "reason": "infra", "redirect": "IRIS"})
        result = _run_scope(raw)
        assert result["classification"] == "OUT_OF_SCOPE"
        assert result["redirect"] == "IRIS"

    def test_out_of_scope_business_sop(self):
        raw = json.dumps({"classification": "OUT_OF_SCOPE", "reason": "master data", "redirect": "Business SOP"})
        result = _run_scope(raw)
        assert result["classification"] == "OUT_OF_SCOPE"
        assert result["redirect"] == "Business SOP"

    def test_unclear_classification(self):
        raw = json.dumps({"classification": "UNCLEAR", "reason": "ambiguous", "redirect": None})
        result = _run_scope(raw)
        assert result["classification"] == "UNCLEAR"

    def test_reason_field_populated(self):
        raw = json.dumps({"classification": "IN_SCOPE", "reason": "SAP security role", "redirect": None})
        result = _run_scope(raw)
        assert result["reason"] == "SAP security role"


# ─────────────────────────────────────────────────────────────────────────────
# Fallback behaviour on bad LLM output
# ─────────────────────────────────────────────────────────────────────────────
class TestValidateChangeScopeFallback:

    def test_invalid_json_falls_back_to_unclear(self):
        result = _run_scope("this is not JSON at all")
        assert result["classification"] == "UNCLEAR"

    def test_empty_string_falls_back_to_unclear(self):
        result = _run_scope("")
        assert result["classification"] == "UNCLEAR"

    def test_json_missing_classification_defaults_unclear(self):
        raw = json.dumps({"reason": "ok", "redirect": None})  # no "classification" key
        result = _run_scope(raw)
        assert result["classification"] == "UNCLEAR"

    def test_raw_response_preserved_on_valid_json(self):
        raw = json.dumps({"classification": "IN_SCOPE", "reason": "ok", "redirect": None})
        result = _run_scope(raw)
        assert result["raw_response"] == raw

    def test_raw_response_preserved_on_bad_json(self):
        bad = "not valid json"
        result = _run_scope(bad)
        assert result["raw_response"] == bad


# ─────────────────────────────────────────────────────────────────────────────
# Exception safety — LLM raises, caller must never crash
# ─────────────────────────────────────────────────────────────────────────────
class TestValidateChangeScopeExceptionSafety:

    def test_llm_runtime_error_returns_unclear(self):
        from tools.tools import validate_change_scope
        with patch("langchain_openai.AzureChatOpenAI") as mock_cls:
            mock_cls.side_effect = RuntimeError("LLM unavailable")
            result = validate_change_scope("test")
        assert result["classification"] == "UNCLEAR"

    def test_llm_invoke_exception_returns_unclear(self):
        from tools.tools import validate_change_scope
        with patch("langchain_openai.AzureChatOpenAI") as mock_cls:
            mock_llm = MagicMock()
            mock_llm.invoke.side_effect = ConnectionError("timeout")
            mock_cls.return_value = mock_llm
            result = validate_change_scope("test")
        assert result["classification"] == "UNCLEAR"
        assert result["raw_response"] == ""

    def test_exception_result_has_all_keys(self):
        from tools.tools import validate_change_scope
        with patch("langchain_openai.AzureChatOpenAI") as mock_cls:
            mock_cls.side_effect = Exception("boom")
            result = validate_change_scope("anything")
        assert set(result.keys()) >= {"classification", "reason", "redirect", "raw_response"}
