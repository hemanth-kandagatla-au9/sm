"""
tests/test_tools_validate_platform.py

Unit tests for tools/validate_platform — Neo4j (_run_cypher) mocked.

Covers:
  - Exact match on canonical platform name
  - Alias resolution via PLATFORM_ALIASES (e.g. "cfin" → "Central Finance")
  - Trailing punctuation stripped before matching
  - Partial / CONTAINS match returns valid with partial_match=True
  - No match at all returns valid=False with error message
  - alias_resolved flag is set correctly
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from unittest.mock import patch
import pytest


def _run(platform: str, *cypher_side_effects) -> dict:
    """Run validate_platform with sequential _run_cypher return values."""
    from tools.tools import validate_platform

    with patch("tools.tools._run_cypher", side_effect=list(cypher_side_effects)):
        return validate_platform(platform)


# ─────────────────────────────────────────────────────────────────────────────
# Exact match
# ─────────────────────────────────────────────────────────────────────────────
class TestValidatePlatformExactMatch:

    def test_canonical_name_returns_valid(self):
        result = _run("Atlas", [{"name": "Atlas"}])
        assert result["valid"] is True
        assert result["resolved_name"] == "Atlas"

    def test_canonical_name_returns_no_error(self):
        result = _run("HMD", [{"name": "HMD"}])
        assert result["error"] is None

    def test_alias_resolved_false_for_canonical(self):
        """When the user types the exact canonical name, alias_resolved must be False."""
        result = _run("Atlas", [{"name": "Atlas"}])
        assert result["alias_resolved"] is False

    def test_partial_match_false_for_exact(self):
        result = _run("Atlas", [{"name": "Atlas"}])
        assert result["partial_match"] is False

    def test_all_matches_list_populated(self):
        result = _run("Atlas", [{"name": "Atlas"}])
        assert "Atlas" in result["all_matches"]


# ─────────────────────────────────────────────────────────────────────────────
# Alias resolution
# ─────────────────────────────────────────────────────────────────────────────
class TestValidatePlatformAliasResolution:

    def test_cfin_alias_resolves(self):
        # "cfin" → "Central Finance" via PLATFORM_ALIASES
        result = _run("cfin", [{"name": "Central Finance"}])
        assert result["valid"] is True

    def test_hmd_alias_resolves(self):
        result = _run("hospital medical devices erp (hmd)", [{"name": "HMD"}])
        assert result["valid"] is True

    def test_alias_resolved_true_for_alias_input(self):
        result = _run("cfin", [{"name": "Central Finance"}])
        assert result["alias_resolved"] is True

    def test_grc_alias_resolves(self):
        result = _run("grc", [{"name": "AS GRC"}])
        assert result["valid"] is True

    def test_ewm_alias_resolves(self):
        result = _run("ewm", [{"name": "WMS EWM"}])
        assert result["valid"] is True

    def test_solman_alias_resolves(self):
        result = _run("solman", [{"name": "AS SolMan"}])
        assert result["valid"] is True


# ─────────────────────────────────────────────────────────────────────────────
# Trailing punctuation handling
# ─────────────────────────────────────────────────────────────────────────────
class TestValidatePlatformPunctuation:

    def test_trailing_period_stripped(self):
        result = _run("Atlas.", [{"name": "Atlas"}])
        assert result["valid"] is True

    def test_trailing_comma_stripped(self):
        result = _run("HMD,", [{"name": "HMD"}])
        assert result["valid"] is True

    def test_leading_whitespace_stripped(self):
        result = _run("  Atlas  ", [{"name": "Atlas"}])
        assert result["valid"] is True


# ─────────────────────────────────────────────────────────────────────────────
# Partial / CONTAINS match
# ─────────────────────────────────────────────────────────────────────────────
class TestValidatePlatformPartialMatch:

    def test_partial_match_returns_valid(self):
        # exact → empty; partial → result
        result = _run(
            "Central",
            [],                              # exact match empty
            [{"name": "Central Finance"}],   # partial match
        )
        assert result["valid"] is True

    def test_partial_match_sets_flag(self):
        result = _run(
            "Central",
            [],
            [{"name": "Central Finance"}],
        )
        assert result["partial_match"] is True

    def test_partial_match_single_hit_resolves(self):
        result = _run(
            "Central",
            [],
            [{"name": "Central Finance"}],
        )
        assert result["valid"] is True
        assert result["resolved_name"] == "Central Finance"

    def test_partial_match_multiple_hits_asks_user(self):
        result = _run(
            "Med",
            [],
            [{"name": "Medtech"}, {"name": "MedTech ERP"}],
        )
        assert result["valid"] is False
        assert result["suggestions"] == ["Medtech", "MedTech ERP"]


# ─────────────────────────────────────────────────────────────────────────────
# Not found
# ─────────────────────────────────────────────────────────────────────────────
class TestValidatePlatformNotFound:

    def test_no_match_returns_invalid(self):
        # "UNKNOWNXYZ" has no alias, so _run_cypher is called 3 times:
        #   1. exact match on resolved name
        #   2. partial match for keyword "UNKNOWNXYZ"
        #   3. all-platforms fallback
        result = _run(
            "UNKNOWNXYZ",
            [],                                      # exact match
            [],                                      # partial match
            [{"name": "Atlas"}, {"name": "HMD"}],  # all-platforms fallback
        )
        assert result["valid"] is False

    def test_no_match_error_message_present(self):
        result = _run(
            "UNKNOWNXYZ",
            [], [],
            [{"name": "Atlas"}],
        )
        assert result.get("error") or result.get("warning")

    def test_no_match_error_contains_valid_options(self):
        result = _run(
            "UNKNOWNXYZ",
            [], [],
            [{"name": "Atlas"}, {"name": "HMD"}],
        )
        error_text = result.get("error", "") + result.get("warning", "")
        assert "Atlas" in error_text or "HMD" in error_text


# ─────────────────────────────────────────────────────────────────────────────
# Fuzzy matching (general scenarios)
# ─────────────────────────────────────────────────────────────────────────────
class TestValidatePlatformFuzzy:

    def test_fuzzy_unambiguous_match_returns_valid(self):
        # exact: empty, partial: empty, fuzzy: AS SolMan should match strongly
        result = _run(
            "AS Solman Platform",
            [],
            [],
            [{"name": "AS SolMan"}, {"name": "AS GRC"}, {"name": "Atlas"}],
        )
        assert result["valid"] is True
        assert result["resolved_name"] == "AS SolMan"
        assert result.get("fuzzy_match") is True

    def test_fuzzy_ambiguous_returns_suggestions(self):
        # Avoid early partial match and force fuzzy tie on short input "AS".
        result = _run(
            "AS",
            [],
            [],
            [{"name": "AS SolMan"}, {"name": "AS GRC"}, {"name": "Atlas"}],
        )
        assert result["valid"] is False
        assert "No exact match found" in (result.get("error") or "")
        assert "AS SolMan" in result.get("suggestions", [])
        assert "AS GRC" in result.get("suggestions", [])

    def test_fuzzy_low_confidence_returns_suggestions(self):
        # Single weak fuzzy candidate should still ask for confirmation
        # instead of auto-resolving.
        result = _run(
            "grcc",
            [],
            [],
            [{"name": "AS GRC"}, {"name": "Atlas"}],
        )
        assert result["valid"] is False
        assert "No exact match found" in (result.get("error") or "")
        assert "AS GRC" in result.get("suggestions", [])
