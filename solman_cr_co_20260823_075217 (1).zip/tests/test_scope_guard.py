"""
tests/test_scope_guard.py
Unit tests for the scope guard logic in node_2_validate_and_gather_data:
  - UNCLEAR / IN_SCOPE always passes through
  - First OUT_OF_SCOPE does NOT end session (scope_out_count=1)
  - Second OUT_OF_SCOPE ends session (end_session=True)
  - scope_confirmed=True skips re-check on subsequent turns
All LLM, Neo4j, SolMan, and JIRA calls are mocked.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from unittest.mock import patch, MagicMock
import pytest
from langchain_core.messages import HumanMessage, AIMessage

from state.state import build_initial_state


def _base_state(**overrides):
    state = build_initial_state("I need to reset a user password")
    for k, v in overrides.items():
        state[k] = v
    return state


def _mock_scope(classification: str, redirect=None):
    return {
        "classification": classification,
        "reason": "test reason",
        "redirect": redirect,
        "raw_response": "{}",
    }


# All the tools node_2 calls that touch external systems
_NODE2_PATCHES = [
    "agents.nodes.nodes_intake.validate_change_scope",
    "agents.nodes.nodes_intake.get_template",
    "agents.nodes.nodes_intake.get_jira_data",
    "agents.nodes.nodes_intake.validate_platform",
    "agents.nodes.nodes_intake.validate_target_system",
    "agents.nodes.nodes_intake.execute_cypher",
]


class TestScopeGuard:

    def _run_node2(self, state, scope_result):
        from agents.nodes import node_2_validate_and_gather_data

        with patch("agents.nodes.nodes_intake.validate_change_scope", return_value=scope_result), \
             patch("agents.nodes.nodes_intake.get_template", return_value={}), \
             patch("agents.nodes.nodes_intake.get_jira_data", return_value={}), \
             patch("agents.nodes.nodes_intake.validate_platform", return_value={"valid": False, "error": "not found"}), \
             patch("agents.nodes.nodes_intake.validate_target_system", return_value={"valid": False, "error": "not found"}), \
             patch("agents.nodes.nodes_intake.execute_cypher", return_value=[]):

            return node_2_validate_and_gather_data(state)

    def test_in_scope_sets_scope_confirmed(self):
        state = _base_state()
        patch_result = _mock_scope("IN_SCOPE")
        patch_value = self._run_node2(state, patch_result)
        assert patch_value.get("scope_confirmed") is True

    def test_unclear_sets_scope_confirmed(self):
        state = _base_state()
        patch_result = _mock_scope("UNCLEAR")
        result = self._run_node2(state, patch_result)
        assert result.get("scope_confirmed") is True

    def test_in_scope_does_not_set_end_session(self):
        state = _base_state()
        result = self._run_node2(state, _mock_scope("IN_SCOPE"))
        assert result.get("end_session") is not True

    def test_first_out_of_scope_does_not_end_session(self):
        """First OUT_OF_SCOPE hit — session should continue, counter incremented."""
        state = _base_state(scope_out_count=0)
        result = self._run_node2(state, _mock_scope("OUT_OF_SCOPE", redirect="IRIS"))
        # Must NOT end session on first hit
        assert result.get("end_session") is not True
        assert result.get("scope_out_count") == 1

    def test_scope_confirmed_skips_validate_call(self):
        """Once scope_confirmed=True, validate_change_scope must NOT be called again."""
        from agents.nodes import node_2_validate_and_gather_data

        state = _base_state(scope_confirmed=True)

        with patch("agents.nodes.nodes_intake.validate_change_scope") as mock_scope, \
             patch("agents.nodes.nodes_intake.get_template", return_value={}), \
             patch("agents.nodes.nodes_intake.get_jira_data", return_value={}), \
             patch("agents.nodes.nodes_intake.validate_platform", return_value={"valid": False, "error": "not found"}), \
             patch("agents.nodes.nodes_intake.validate_target_system", return_value={"valid": False, "error": "not found"}), \
             patch("agents.nodes.nodes_intake.execute_cypher", return_value=[]):

            node_2_validate_and_gather_data(state)
            mock_scope.assert_not_called()

    def test_in_scope_resets_out_count(self):
        """After a previous OUT_OF_SCOPE, an IN_SCOPE response resets the counter."""
        state = _base_state(scope_out_count=1)
        result = self._run_node2(state, _mock_scope("IN_SCOPE"))
        assert result.get("scope_out_count") == 0
