"""
tests/test_tools_generate_cr_fields.py

Unit tests for tools/generate_cr_fields_from_jira — LLM mocked.

Covers:
  - Normal output: reason_for_change and description_of_change returned
  - Empty input: returns error without calling LLM
  - Invalid JSON from LLM: falls back to raw JIRA values
  - LLM exception: falls back to raw JIRA values
  - Hallucination stripping:
      - SAP Note numbers not in source are removed
      - Standalone 7-8 digit numbers not in source are removed
      - Transaction codes (via/using/transaction XXXX) not in source are removed
      - Content that IS in the source is preserved
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import json
from unittest.mock import patch, MagicMock
import pytest


def _make_llm_content(reason: str, doc: str) -> str:
    return json.dumps({"reason_for_change": reason, "description_of_change": doc})


def _run(summary: str, description: str, llm_raw: str) -> dict:
    """Run generate_cr_fields_from_jira with a mocked LLM response."""
    from tools.tools import generate_cr_fields_from_jira

    mock_resp = MagicMock()
    mock_resp.content = llm_raw

    with patch("tools.tools.get_llm_fast") as mock_llm_fn:
        mock_llm = MagicMock()
        mock_llm.invoke.return_value = mock_resp
        mock_llm_fn.return_value = mock_llm
        return generate_cr_fields_from_jira(summary, description)


# ─────────────────────────────────────────────────────────────────────────────
# Normal operation
# ─────────────────────────────────────────────────────────────────────────────
class TestGenerateCrFieldsNormal:

    def test_reason_for_change_returned(self):
        raw = _make_llm_content("Business need to fix auth.", "Technical doc.")
        result = _run("Fix auth", "Add auth object", raw)
        assert result["reason_for_change"] == "Business need to fix auth."

    def test_description_of_change_returned(self):
        raw = _make_llm_content("Why the change.", "What will be done.")
        result = _run("Summary", "Detail", raw)
        assert result["description_of_change"] == "What will be done."

    def test_no_error_on_success(self):
        raw = _make_llm_content("Reason.", "Doc.")
        result = _run("Summary", "Detail", raw)
        assert result["error"] is None

    def test_whitespace_stripped_from_output(self):
        raw = _make_llm_content("  Reason with spaces.  ", "  Doc with spaces.  ")
        result = _run("Summary", "Detail", raw)
        assert result["reason_for_change"] == "Reason with spaces."
        assert result["description_of_change"] == "Doc with spaces."


# ─────────────────────────────────────────────────────────────────────────────
# Empty / missing input
# ─────────────────────────────────────────────────────────────────────────────
class TestGenerateCrFieldsEmptyInput:

    def test_both_empty_returns_error_without_llm(self):
        from tools.tools import generate_cr_fields_from_jira

        with patch("tools.tools.get_llm_fast") as mock_llm_fn:
            result = generate_cr_fields_from_jira("", "")
            mock_llm_fn.assert_not_called()

        assert result["error"] == "No JIRA content to process"

    def test_whitespace_only_treated_as_empty(self):
        from tools.tools import generate_cr_fields_from_jira

        with patch("tools.tools.get_llm_fast") as mock_llm_fn:
            result = generate_cr_fields_from_jira("   ", "  ")
            mock_llm_fn.assert_not_called()

        assert result["error"] == "No JIRA content to process"


# ─────────────────────────────────────────────────────────────────────────────
# Fallback on bad LLM output
# ─────────────────────────────────────────────────────────────────────────────
class TestGenerateCrFieldsFallback:

    def test_invalid_json_falls_back_to_raw_values(self):
        result = _run("Raw summary", "Raw description", "not valid JSON at all")
        assert result["reason_for_change"] == "Raw summary"
        assert result["description_of_change"] == "Raw description"
        assert result["error"] is not None

    def test_empty_json_object_falls_back_to_raw(self):
        result = _run("Summary X", "Detail X", "{}")
        # LLM returned empty fields — should fall back
        assert result["reason_for_change"] == "Summary X" or result["reason_for_change"] == ""

    def test_llm_exception_falls_back_to_raw(self):
        from tools.tools import generate_cr_fields_from_jira

        with patch("tools.tools.get_llm_fast") as mock_llm_fn:
            mock_llm_fn.side_effect = RuntimeError("LLM down")
            result = generate_cr_fields_from_jira("Raw summary", "Raw description")

        assert result["reason_for_change"] == "Raw summary"
        assert result["description_of_change"] == "Raw description"
        assert result["error"] is not None

    def test_llm_invoke_exception_falls_back_to_raw(self):
        from tools.tools import generate_cr_fields_from_jira

        with patch("tools.tools.get_llm_fast") as mock_llm_fn:
            mock_llm = MagicMock()
            mock_llm.invoke.side_effect = ConnectionError("timeout")
            mock_llm_fn.return_value = mock_llm
            result = generate_cr_fields_from_jira("Summary", "Description")

        assert result["reason_for_change"] == "Summary"
        assert result["error"] is not None


# ─────────────────────────────────────────────────────────────────────────────
# Hallucination stripping — SAP Notes
# ─────────────────────────────────────────────────────────────────────────────
class TestHallucinationStrippingSapNotes:

    def test_sap_note_not_in_source_is_removed(self):
        raw = _make_llm_content(
            "Apply SAP Note 2806418 to resolve the issue.",
            "The fix is included in SAP Note 2806418.",
        )
        result = _run("Fix a config problem", "Configuration update needed", raw)
        # 2806418 not in source — must be stripped
        assert "2806418" not in result["reason_for_change"]
        assert "2806418" not in result["description_of_change"]

    def test_note_phrase_not_in_source_removed(self):
        raw = _make_llm_content(
            "Note 1234567 resolves the problem.",
            "Apply the note to fix it.",
        )
        result = _run("Fix issue", "Apply configuration", raw)
        assert "1234567" not in result["reason_for_change"]

    def test_standalone_7digit_not_in_source_removed(self):
        raw = _make_llm_content(
            "The change number is 9999999.",
            "Change reference 9999999 applies here.",
        )
        result = _run("Change request for config", "Update system config", raw)
        assert "9999999" not in result["reason_for_change"]

    def test_note_number_present_in_source_preserved(self):
        """When the SAP Note IS in the JIRA source it must NOT be stripped."""
        summary = "Fix via SAP Note 2806418"
        description = "Apply SAP Note 2806418 to system"
        raw = _make_llm_content(
            "Apply SAP Note 2806418 to resolve the problem.",
            "Use SAP Note 2806418 to fix the configuration.",
        )
        result = _run(summary, description, raw)
        # 2806418 IS in source — must be preserved
        assert "2806418" in result["reason_for_change"] or \
               "2806418" in result["description_of_change"]


# ─────────────────────────────────────────────────────────────────────────────
# Hallucination stripping — Transaction codes
# ─────────────────────────────────────────────────────────────────────────────
class TestHallucinationStrippingTransactionCodes:

    def test_tcode_not_in_source_stripped(self):
        raw = _make_llm_content(
            "The change is needed to fix the problem.",
            "Run transaction SE38 to execute the program.",
        )
        result = _run("Fix a config bug", "Apply a configuration fix", raw)
        assert "SE38" not in result["description_of_change"]

    def test_via_tcode_not_in_source_stripped(self):
        raw = _make_llm_content(
            "The change resolves the issue.",
            "Implement via SNOTE the correction.",
        )
        result = _run("Fix configuration", "Configuration change needed", raw)
        # SNOTE not in source — should be stripped
        assert "SNOTE" not in result.get("description_of_change", "")

    def test_tcode_present_in_source_preserved(self):
        """Transaction code explicitly present in JIRA source must not be stripped."""
        summary = "Apply SNOTE transaction for fix"
        description = "Use SNOTE to apply the correction"
        raw = _make_llm_content(
            "The change is needed. Apply via SNOTE.",
            "Implement using SNOTE.",
        )
        result = _run(summary, description, raw)
        # "SNOTE" IS in source — must be preserved
        combined = result.get("reason_for_change", "") + result.get("description_of_change", "")
        assert "SNOTE" in combined


# ─────────────────────────────────────────────────────────────────────────────
# Narrative splitter (general fallback behavior)
# ─────────────────────────────────────────────────────────────────────────────
class TestGenerateCrFieldsFromNarrative:

    def test_empty_narrative_returns_error_without_llm(self):
        from tools.tools import generate_cr_fields_from_narrative

        with patch("tools.tools.get_llm_fast") as mock_llm_fn:
            result = generate_cr_fields_from_narrative("   ")
            mock_llm_fn.assert_not_called()

        assert result["reason_for_change"] == ""
        assert result["description_of_change"] == ""
        assert result["error"] == "No narrative content to process"

    def test_invalid_json_falls_back_to_original_narrative(self):
        from tools.tools import generate_cr_fields_from_narrative

        mock_resp = MagicMock()
        mock_resp.content = "not-json"
        with patch("tools.tools.get_llm_fast") as mock_llm_fn:
            mock_llm = MagicMock()
            mock_llm.invoke.return_value = mock_resp
            mock_llm_fn.return_value = mock_llm
            result = generate_cr_fields_from_narrative("Need to fix authorization mapping")

        assert result["reason_for_change"] == "Need to fix authorization mapping"
        assert result["description_of_change"] == "Need to fix authorization mapping"
        assert result["error"] is not None

    def test_identical_reason_and_doc_fall_back_to_original_narrative(self):
        from tools.tools import generate_cr_fields_from_narrative

        mock_resp = MagicMock()
        mock_resp.content = json.dumps(
            {
                "reason_for_change": "Same sentence",
                "description_of_change": "Same sentence",
            }
        )
        with patch("tools.tools.get_llm_fast") as mock_llm_fn:
            mock_llm = MagicMock()
            mock_llm.invoke.return_value = mock_resp
            mock_llm_fn.return_value = mock_llm
            result = generate_cr_fields_from_narrative("Original narrative text")

        assert result["reason_for_change"] == "Original narrative text"
        assert result["description_of_change"] == "Original narrative text"
        assert result["error"] is not None

    def test_llm_exception_falls_back_to_original_narrative(self):
        from tools.tools import generate_cr_fields_from_narrative

        with patch("tools.tools.get_llm_fast") as mock_llm_fn:
            mock_llm_fn.side_effect = RuntimeError("LLM unavailable")
            result = generate_cr_fields_from_narrative("Original narrative text")

        assert result["reason_for_change"] == "Original narrative text"
        assert result["description_of_change"] == "Original narrative text"
        assert result["error"] is not None

    def test_valid_distinct_fields_are_returned(self):
        from tools.tools import generate_cr_fields_from_narrative

        mock_resp = MagicMock()
        mock_resp.content = json.dumps(
            {
                "reason_for_change": "  Business compliance update is required.  ",
                "description_of_change": "  Update role mapping and transport sequence.  ",
            }
        )
        with patch("tools.tools.get_llm_fast") as mock_llm_fn:
            mock_llm = MagicMock()
            mock_llm.invoke.return_value = mock_resp
            mock_llm_fn.return_value = mock_llm
            result = generate_cr_fields_from_narrative("Original narrative text")

        assert result["reason_for_change"] == "Business compliance update is required."
        assert result["description_of_change"] == "Update role mapping and transport sequence."
        assert result["error"] is None
