"""
tests/test_schemas.py

Unit tests for utils/schemas.py — Pydantic schema validation.
Zero external calls — pure structural and type tests.

Covers:
  - ExtractedField / ExtractedFields
  - RelevanceCheck
  - RequestInfoOutput
  - BuildDraftOutput / PresentDraftOutput
  - IntentRouterB (Literal validation)
  - IntentRouterC (Literal validation)
  - ParseUpdateIntent (default field_type)
  - ValidateSelectedCR (optional cr_id)
  - GetInformationOutput
  - ApplyUpdateOutput
  - SuggestCRsOutput / PresentRecsOutput
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pytest
from pydantic import ValidationError

from utils.schemas import (
    ExtractedField,
    ExtractedFields,
    RelevanceCheck,
    RequestInfoOutput,
    BuildDraftOutput,
    PresentDraftOutput,
    IntentRouterB,
    IntentRouterC,
    FieldUpdateItem,
    ParseUpdateIntent,
    ValidateSelectedCR,
    GetInformationOutput,
    ApplyUpdateOutput,
    SuggestCRsOutput,
    PresentRecsOutput,
)


# ─────────────────────────────────────────────────────────────────────────────
# ExtractedField
# ─────────────────────────────────────────────────────────────────────────────
class TestExtractedField:

    def test_given_true_with_value(self):
        f = ExtractedField(given=True, value="Atlas")
        assert f.given is True
        assert f.value == "Atlas"

    def test_given_false_empty_value(self):
        f = ExtractedField(given=False, value="")
        assert f.given is False
        assert f.value == ""

    def test_missing_given_raises(self):
        with pytest.raises(ValidationError):
            ExtractedField(value="something")  # type: ignore[call-arg]

    def test_missing_value_raises(self):
        with pytest.raises(ValidationError):
            ExtractedField(given=True)  # type: ignore[call-arg]


# ─────────────────────────────────────────────────────────────────────────────
# ExtractedFields
# ─────────────────────────────────────────────────────────────────────────────
class TestExtractedFields:

    def _field(self, given=False, value="") -> dict:
        return {"given": given, "value": value}

    def _full(self, **overrides) -> dict:
        base = {
            "reason_for_change":     self._field(True, "Some reason"),
            "description_of_change": self._field(True, "Some description"),
            "additional_information": self._field(),
            "target_system":         self._field(True, "EJ1 100"),
            "platform":              self._field(True, "Atlas"),
            "template_id":           self._field(True, "65669"),
            "cr_id":                 self._field(),
            "jira_id":               self._field(),
        }
        base.update(overrides)
        return base

    def test_all_fields_valid(self):
        ef = ExtractedFields(**self._full())
        assert ef.platform.given is True
        assert ef.platform.value == "Atlas"

    def test_platform_field_accessible(self):
        ef = ExtractedFields(**self._full())
        assert ef.platform.value == "Atlas"

    def test_cr_id_defaults_not_given(self):
        ef = ExtractedFields(**self._full())
        assert ef.cr_id.given is False
        assert ef.cr_id.value == ""

    def test_missing_reason_raises(self):
        data = self._full()
        del data["reason_for_change"]
        with pytest.raises(ValidationError):
            ExtractedFields(**data)

    def test_missing_platform_raises(self):
        data = self._full()
        del data["platform"]
        with pytest.raises(ValidationError):
            ExtractedFields(**data)


# ─────────────────────────────────────────────────────────────────────────────
# RelevanceCheck
# ─────────────────────────────────────────────────────────────────────────────
class TestRelevanceCheck:

    def test_relevant_true(self):
        r = RelevanceCheck(is_relevant=True, reasoning="On topic")
        assert r.is_relevant is True
        assert r.reasoning == "On topic"

    def test_relevant_false(self):
        r = RelevanceCheck(is_relevant=False, reasoning="Off topic")
        assert r.is_relevant is False

    def test_missing_is_relevant_raises(self):
        with pytest.raises(ValidationError):
            RelevanceCheck(reasoning="test")  # type: ignore[call-arg]


# ─────────────────────────────────────────────────────────────────────────────
# RequestInfoOutput
# ─────────────────────────────────────────────────────────────────────────────
class TestRequestInfoOutput:

    def test_message_stored(self):
        r = RequestInfoOutput(output_message="Please provide platform")
        assert r.output_message == "Please provide platform"

    def test_empty_message_allowed(self):
        r = RequestInfoOutput(output_message="")
        assert r.output_message == ""


# ─────────────────────────────────────────────────────────────────────────────
# BuildDraftOutput / PresentDraftOutput
# ─────────────────────────────────────────────────────────────────────────────
class TestBuildDraftOutput:

    def test_fields_stored(self):
        b = BuildDraftOutput(draft="Full draft text", draft_html="<p>draft</p>")
        assert b.draft == "Full draft text"
        assert b.draft_html == "<p>draft</p>"

    def test_missing_draft_raises(self):
        with pytest.raises(ValidationError):
            BuildDraftOutput(draft_html="<p>only html</p>")  # type: ignore[call-arg]


class TestPresentDraftOutput:

    def test_fields_stored(self):
        p = PresentDraftOutput(output_text="Review the draft below.", draft_html="<p>x</p>")
        assert p.output_text == "Review the draft below."
        assert p.draft_html == "<p>x</p>"


# ─────────────────────────────────────────────────────────────────────────────
# IntentRouterB
# ─────────────────────────────────────────────────────────────────────────────
class TestIntentRouterB:

    @pytest.mark.parametrize("intent", ["approval", "question", "update", "reject"])
    def test_valid_intents_accepted(self, intent: str):
        r = IntentRouterB(intent=intent, reasoning="test")
        assert r.intent == intent

    def test_invalid_intent_raises(self):
        with pytest.raises(ValidationError):
            IntentRouterB(intent="unknown_action", reasoning="test")

    def test_reasoning_stored(self):
        r = IntentRouterB(intent="approval", reasoning="User said approve")
        assert r.reasoning == "User said approve"


# ─────────────────────────────────────────────────────────────────────────────
# IntentRouterC
# ─────────────────────────────────────────────────────────────────────────────
class TestIntentRouterC:

    @pytest.mark.parametrize("intent", ["approve_cr", "recommend_more", "max_hit"])
    def test_valid_intents_accepted(self, intent: str):
        r = IntentRouterC(intent=intent, selected_cr_id=None, reasoning="test")
        assert r.intent == intent

    def test_invalid_intent_raises(self):
        with pytest.raises(ValidationError):
            IntentRouterC(intent="bad_intent", selected_cr_id=None, reasoning="test")

    def test_selected_cr_id_optional(self):
        r = IntentRouterC(intent="approve_cr", reasoning="user chose")
        assert r.selected_cr_id is None

    def test_selected_cr_id_set(self):
        r = IntentRouterC(intent="approve_cr", selected_cr_id="50412496", reasoning="ok")
        assert r.selected_cr_id == "50412496"


# ─────────────────────────────────────────────────────────────────────────────
# ParseUpdateIntent
# ─────────────────────────────────────────────────────────────────────────────
class TestFieldUpdateItem:

    def test_required_fields_stored(self):
        item = FieldUpdateItem(field_name="reason_for_change", new_value="Updated reason")
        assert item.field_name == "reason_for_change"
        assert item.new_value == "Updated reason"
        assert item.is_locked is False

    def test_default_field_type_is_locked(self):
        item = FieldUpdateItem(field_name="platform", new_value="HMD", is_locked=True)
        assert item.field_type == "locked"

    def test_custom_field_type_stored(self):
        item = FieldUpdateItem(
            field_name="reason_for_change",
            new_value="new reason",
            is_locked=False,
            field_type="text",
        )
        assert item.field_type == "text"


class TestParseUpdateIntent:

    def test_single_update_stored(self):
        p = ParseUpdateIntent(updates=[
            FieldUpdateItem(field_name="reason_for_change", new_value="Updated reason", is_locked=False)
        ])
        assert len(p.updates) == 1
        assert p.updates[0].field_name == "reason_for_change"
        assert p.updates[0].new_value == "Updated reason"

    def test_multiple_updates_stored(self):
        p = ParseUpdateIntent(updates=[
            FieldUpdateItem(field_name="zzfld000001_cus", new_value="yes", field_type="zzfld_writable"),
            FieldUpdateItem(field_name="zzfld00001f_cus", new_value="yes", field_type="zzfld_writable"),
        ])
        assert len(p.updates) == 2
        assert p.updates[0].field_name == "zzfld000001_cus"
        assert p.updates[1].field_name == "zzfld00001f_cus"

    def test_missing_updates_raises(self):
        with pytest.raises(ValidationError):
            ParseUpdateIntent()  # type: ignore[call-arg]


# ─────────────────────────────────────────────────────────────────────────────
# ValidateSelectedCR
# ─────────────────────────────────────────────────────────────────────────────
class TestValidateSelectedCR:

    def test_valid_selection_with_cr_id(self):
        v = ValidateSelectedCR(
            is_valid_selection=True,
            selected_cr_id="50412496",
            reasoning="User picked CR 1",
        )
        assert v.is_valid_selection is True
        assert v.selected_cr_id == "50412496"

    def test_invalid_selection_no_cr_id(self):
        v = ValidateSelectedCR(is_valid_selection=False, reasoning="Invalid pick")
        assert v.is_valid_selection is False
        assert v.selected_cr_id is None

    def test_reasoning_required(self):
        with pytest.raises(ValidationError):
            ValidateSelectedCR(is_valid_selection=True)  # type: ignore[call-arg]


# ─────────────────────────────────────────────────────────────────────────────
# GetInformationOutput
# ─────────────────────────────────────────────────────────────────────────────
class TestGetInformationOutput:

    def test_fields_stored(self):
        g = GetInformationOutput(
            cypher_query="MATCH (c:ChangeRequest) RETURN c LIMIT 5",
            output_text="Here are the results.",
        )
        assert "MATCH" in g.cypher_query
        assert g.output_text == "Here are the results."

    def test_empty_cypher_allowed(self):
        g = GetInformationOutput(cypher_query="", output_text="No query needed")
        assert g.cypher_query == ""


# ─────────────────────────────────────────────────────────────────────────────
# ApplyUpdateOutput
# ─────────────────────────────────────────────────────────────────────────────
class TestApplyUpdateOutput:

    def test_fields_stored(self):
        a = ApplyUpdateOutput(
            updated_draft="New draft text",
            updated_draft_html="<p>New draft</p>",
            update_summary="Changed reason for change",
        )
        assert a.updated_draft == "New draft text"
        assert a.update_summary == "Changed reason for change"

    def test_missing_updated_draft_raises(self):
        with pytest.raises(ValidationError):
            ApplyUpdateOutput(  # type: ignore[call-arg]
                updated_draft_html="<p>x</p>",
                update_summary="x",
            )


# ─────────────────────────────────────────────────────────────────────────────
# SuggestCRsOutput / PresentRecsOutput
# ─────────────────────────────────────────────────────────────────────────────
class TestSuggestCRsOutput:

    def test_fields_stored(self):
        s = SuggestCRsOutput(
            query_text="Find similar CRs about auth",
            cypher_query="MATCH (c:ChangeRequest) RETURN c LIMIT 5",
        )
        assert s.query_text == "Find similar CRs about auth"
        assert "MATCH" in s.cypher_query

    def test_missing_query_text_raises(self):
        with pytest.raises(ValidationError):
            SuggestCRsOutput(cypher_query="MATCH (c) RETURN c")  # type: ignore[call-arg]


class TestPresentRecsOutput:

    def test_fields_stored(self):
        p = PresentRecsOutput(
            output_text="Here are the top 5 CRs.",
            recommendations_html="<div>recs</div>",
        )
        assert p.output_text == "Here are the top 5 CRs."
        assert p.recommendations_html == "<div>recs</div>"
