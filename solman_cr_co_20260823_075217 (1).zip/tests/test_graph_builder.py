import os
import sys
import types

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

fake_checkpoint = types.ModuleType("langgraph_checkpoint_aws")


class _PlaceholderSaver:
    def __init__(self, *args, **kwargs):
        pass


fake_checkpoint.AgentCoreMemorySaver = _PlaceholderSaver
sys.modules.setdefault("langgraph_checkpoint_aws", fake_checkpoint)

import pytest

from graph import builder as builder_module


class DummySaver:
    def __init__(self, memory_id, region_name):
        self.memory_id = memory_id
        self.region_name = region_name


class TestBuildGraph:
    def test_requires_agentcore_memory_flag(self, monkeypatch):
        monkeypatch.delenv("USE_AGENTCORE_MEMORY", raising=False)
        with pytest.raises(RuntimeError, match="USE_AGENTCORE_MEMORY"):
            builder_module.build_graph()

    def test_missing_memory_id_raises(self, monkeypatch):
        monkeypatch.setenv("USE_AGENTCORE_MEMORY", "true")
        monkeypatch.delenv("MEMORY_ID", raising=False)

        with pytest.raises(RuntimeError, match="MEMORY_ID must be set"):
            builder_module.build_graph()

    def test_invalid_memory_id_raises(self, monkeypatch):
        monkeypatch.setenv("USE_AGENTCORE_MEMORY", "true")
        monkeypatch.setenv("MEMORY_ID", "not-a-valid-id")

        with pytest.raises(RuntimeError, match="Invalid AgentCore memory id"):
            builder_module.build_graph()

    def test_build_graph_uses_agentcore_memory(self, monkeypatch):
        monkeypatch.setenv("USE_AGENTCORE_MEMORY", "true")
        monkeypatch.setenv("MEMORY_ID", "arn:aws:bedrock-agentcore:us-east-1:123456789012:memory/dev-crco-a2a-1234567890")
        monkeypatch.setenv("AWS_REGION", "us-west-2")
        monkeypatch.setattr(builder_module, "AgentCoreMemorySaver", DummySaver)
        monkeypatch.setattr(
            builder_module.StateGraph,
            "compile",
            lambda self, checkpointer: {"checkpointer": checkpointer},
        )

        result = builder_module.build_graph()

        assert result["checkpointer"].memory_id == "dev-crco-a2a-1234567890"
        assert result["checkpointer"].region_name == "us-west-2"

    def test_passthrough_nodes_return_empty_dict(self):
        assert builder_module._cond_edge_b_passthrough(object()) == {}
        assert builder_module._cond_edge_c_passthrough(object()) == {}