import os
import sys

import requests

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from unittest.mock import patch


class _FakeResponse:
    def __init__(self, *, headers=None, json_data=None, text="", status_code=200, raise_exc=None):
        self.headers = headers or {}
        self._json_data = json_data
        self.text = text
        self.status_code = status_code
        self._raise_exc = raise_exc

    def raise_for_status(self):
        if self._raise_exc:
            raise self._raise_exc

    def json(self):
        if isinstance(self._json_data, Exception):
            raise self._json_data
        return self._json_data


class _FakeSession:
    def __init__(self, get_responses=None, post_response=None):
        self.get_responses = list(get_responses or [])
        self.post_response = post_response
        self.get_calls = []
        self.post_calls = []
        self.auth = None
        self.verify = None
        self.closed = False

    def get(self, url, **kwargs):
        self.get_calls.append((url, kwargs))
        response = self.get_responses.pop(0)
        if isinstance(response, Exception):
            raise response
        return response

    def post(self, url, **kwargs):
        self.post_calls.append((url, kwargs))
        if isinstance(self.post_response, Exception):
            raise self.post_response
        return self.post_response

    def close(self):
        self.closed = True


class TestSolmanWrite:
    def test_missing_read_configuration_returns_error(self):
        from tools.tools import solman_write

        with patch("tools.tools.SOLMAN_READ_BASE_URL", ""), \
             patch("tools.tools.SOLMAN_READ_USERNAME", ""):
            result = solman_write("draft", {})

        assert result == {
            "success": False,
            "cr_id": None,
            "error": "SOLMAN_READ_BASE_URL or SOLMAN_READ_USERNAME not configured",
        }

    def test_wrong_odata_service_returns_error(self):
        from tools.tools import solman_write

        with patch("tools.tools.SOLMAN_READ_BASE_URL", "https://solman.example.com"), \
             patch("tools.tools.SOLMAN_READ_USERNAME", "user"), \
             patch("tools.tools.SOLMAN_ODATA_PATH", "/wrong/service"):
            result = solman_write("draft", {})

        assert result["success"] is False
        assert "ZCHM_RFC_SRV" in result["error"]

    def test_missing_template_and_cr_id_returns_error(self):
        from tools.tools import solman_write

        with patch("tools.tools.SOLMAN_READ_BASE_URL", "https://solman.example.com"), \
             patch("tools.tools.SOLMAN_READ_USERNAME", "user"), \
             patch("tools.tools.SOLMAN_ODATA_PATH", "/sap/opu/odata/sap/ZCHM_RFC_SRV/ChangeRequestSet"):
            result = solman_write("draft", {})

        assert result == {
            "success": False,
            "cr_id": None,
            "error": "template_id or cr_id is required for CR submission",
        }

    def test_template_fetch_failure_returns_error(self):
        from tools.tools import solman_write

        session = _FakeSession(
            get_responses=[
                _FakeResponse(headers={"X-CSRF-Token": "csrf-token"}),
                RuntimeError("template read boom"),
                RuntimeError("template read boom"),
            ]
        )

        state = {"template_id": {"value": "50339227"}}
        with patch("tools.tools.SOLMAN_READ_BASE_URL", "https://solman.example.com"), \
             patch("tools.tools.SOLMAN_READ_USERNAME", "user"), \
             patch("tools.tools.SOLMAN_READ_PASSWORD", "pass"), \
             patch("tools.tools.SOLMAN_ODATA_PATH", "/sap/opu/odata/sap/ZCHM_RFC_SRV/ChangeRequestSet"), \
             patch("tools.tools.requests.Session", return_value=session), \
             patch("tools.tools._build_solman_get_urls", return_value=["u1", "u2"]):
            result = solman_write("draft", state)

        assert result["success"] is False
        assert "CSRF/template fetch failed" in result["error"]
        assert session.closed is True

    def test_http_error_returns_sap_response_text(self):
        from tools.tools import solman_write

        error_response = _FakeResponse(text="bad request body", status_code=400)
        http_error = requests.HTTPError("400 Client Error")
        http_error.response = error_response

        session = _FakeSession(
            get_responses=[
                _FakeResponse(headers={"X-CSRF-Token": "csrf-token"}),
                _FakeResponse(json_data={"d": {"IsDetails": {}, "IvContext": {}}}),
            ],
            post_response=_FakeResponse(
                headers={"Content-Type": "application/json"},
                json_data={"error": "bad request"},
                text="bad request body",
                status_code=400,
                raise_exc=http_error,
            ),
        )

        state = {
            "template_id": {"value": "50339227"},
            "description_of_change": {"value": "Update role mapping"},
            "reason_for_change": {"value": "Fix auth"},
        }

        with patch("tools.tools.SOLMAN_READ_BASE_URL", "https://solman.example.com"), \
             patch("tools.tools.SOLMAN_READ_USERNAME", "user"), \
             patch("tools.tools.SOLMAN_READ_PASSWORD", "pass"), \
             patch("tools.tools.SOLMAN_ODATA_PATH", "/sap/opu/odata/sap/ZCHM_RFC_SRV/ChangeRequestSet"), \
             patch("tools.tools.requests.Session", return_value=session), \
             patch("tools.tools._build_solman_get_urls", return_value=["u1"]), \
             patch("tools.tools._parse_odata_response", return_value={"IsDetails": {}, "IvContext": {}}):
            result = solman_write("draft", state)

        assert result["success"] is False
        assert result["error"] == "Solution Manager submission failed"
        assert session.closed is True

    # ──────────────────────────────────────────────────────────────────────────
    # SAP error payload variants (release confidence hardening)
    # ──────────────────────────────────────────────────────────────────────────
    def test_http_200_with_evhaserror_x_is_treated_as_failure(self):
        """SAP can return HTTP 200 with EvHasError='X'; this must still fail."""
        from tools.tools import solman_write

        session = _FakeSession(
            get_responses=[
                _FakeResponse(headers={"X-CSRF-Token": "csrf-token"}),
                _FakeResponse(json_data={"d": {"ignored": True}}),
            ],
            post_response=_FakeResponse(
                headers={"Content-Type": "application/json"},
                json_data={"d": {"EvHasError": "X", "EvMessage": "Template is locked by another user"}},
                status_code=200,
            ),
        )

        template_data = {
            "IvDetails": {"Description": "Template title"},
            "IvContext": {},
            "IvScope": {},
        }
        state = {
            "template_id": {"value": "50339227"},
            "description_of_change": {"value": "Doc"},
            "reason_for_change": {"value": "Reason"},
        }

        with patch("tools.tools.SOLMAN_READ_BASE_URL", "https://solman.example.com"), \
             patch("tools.tools.SOLMAN_READ_USERNAME", "user"), \
             patch("tools.tools.SOLMAN_READ_PASSWORD", "pass"), \
             patch("tools.tools.SOLMAN_ODATA_PATH", "/sap/opu/odata/sap/ZCHM_RFC_SRV/ChangeRequestSet"), \
             patch("tools.tools.requests.Session", return_value=session), \
             patch("tools.tools._build_solman_get_urls", return_value=["u1"]), \
             patch("tools.tools._parse_odata_response", return_value=template_data):
            result = solman_write("draft", state)

        assert result["success"] is False
        assert result["is_sap_error"] is True
        assert "Template is locked" in (result.get("error") or "")

    def test_http_200_business_error_combines_evmessage_and_etreturn_dedup(self):
        """EvMessage + EtReturn(E/A) rows should be combined and de-duplicated."""
        from tools.tools import solman_write

        session = _FakeSession(
            get_responses=[
                _FakeResponse(headers={"X-CSRF-Token": "csrf-token"}),
                _FakeResponse(json_data={"d": {"ignored": True}}),
            ],
            post_response=_FakeResponse(
                headers={"Content-Type": "application/json"},
                json_data={
                    "d": {
                        "EvHasError": "TRUE",
                        "EvMessage": "Validation failed",
                        "EtReturn": {
                            "results": [
                                {"Type": "E", "Message": "Cycle is not active"},
                                {"TYPE": "A", "MESSAGE": "Cycle is not active"},  # duplicate (alt key casing)
                                {"Type": "W", "Message": "Ignore warning"},
                            ]
                        },
                    }
                },
                status_code=200,
            ),
        )

        template_data = {
            "IvDetails": {"Description": "Template title"},
            "IvContext": {},
            "IvScope": {},
        }
        state = {
            "template_id": {"value": "50339227"},
            "description_of_change": {"value": "Doc"},
            "reason_for_change": {"value": "Reason"},
        }

        with patch("tools.tools.SOLMAN_READ_BASE_URL", "https://solman.example.com"), \
             patch("tools.tools.SOLMAN_READ_USERNAME", "user"), \
             patch("tools.tools.SOLMAN_READ_PASSWORD", "pass"), \
             patch("tools.tools.SOLMAN_ODATA_PATH", "/sap/opu/odata/sap/ZCHM_RFC_SRV/ChangeRequestSet"), \
             patch("tools.tools.requests.Session", return_value=session), \
             patch("tools.tools._build_solman_get_urls", return_value=["u1"]), \
             patch("tools.tools._parse_odata_response", return_value=template_data):
            result = solman_write("draft", state)

        assert result["success"] is False
        assert result["is_sap_error"] is True
        assert result["error"] == "Validation failed — Cycle is not active"

    def test_http_error_prefers_toreturn_business_error_message(self):
        """On HTTP error, business error fields (EvHasError/ToReturn) should be preferred."""
        from tools.tools import solman_write

        err_json = {
            "d": {
                "EvHasError": "1",
                "EvMessage": "Business validation failed",
                "ToReturn": {
                    "Results": [
                        {"TYPE": "E", "MESSAGE": "Transport route missing"},
                    ]
                },
            }
        }
        error_response = _FakeResponse(json_data=err_json, text="SAP business failure", status_code=400)
        http_error = requests.HTTPError("400 Client Error")
        http_error.response = error_response

        session = _FakeSession(
            get_responses=[
                _FakeResponse(headers={"X-CSRF-Token": "csrf-token"}),
                _FakeResponse(json_data={"d": {"ignored": True}}),
            ],
            post_response=_FakeResponse(
                headers={"Content-Type": "application/json"},
                json_data=err_json,
                text="SAP business failure",
                status_code=400,
                raise_exc=http_error,
            ),
        )

        template_data = {
            "IvDetails": {"Description": "Template title"},
            "IvContext": {},
            "IvScope": {},
        }
        state = {
            "template_id": {"value": "50339227"},
            "description_of_change": {"value": "Doc"},
            "reason_for_change": {"value": "Reason"},
        }

        with patch("tools.tools.SOLMAN_READ_BASE_URL", "https://solman.example.com"), \
             patch("tools.tools.SOLMAN_READ_USERNAME", "user"), \
             patch("tools.tools.SOLMAN_READ_PASSWORD", "pass"), \
             patch("tools.tools.SOLMAN_ODATA_PATH", "/sap/opu/odata/sap/ZCHM_RFC_SRV/ChangeRequestSet"), \
             patch("tools.tools.requests.Session", return_value=session), \
             patch("tools.tools._build_solman_get_urls", return_value=["u1"]), \
             patch("tools.tools._parse_odata_response", return_value=template_data):
            result = solman_write("draft", state)

        assert result["success"] is False
        assert result["is_sap_error"] is True
        assert result["sap_transaction_id"] is None
        assert result["error"] == "Business validation failed — Transport route missing"

    def test_http_error_business_error_without_details_uses_default_message(self):
        """If EvHasError is true but no messages exist, return the default business-error text."""
        from tools.tools import solman_write

        err_json = {"d": {"EvHasError": "TRUE", "EvMessage": "", "EtReturn": []}}
        error_response = _FakeResponse(json_data=err_json, text="SAP business failure", status_code=400)
        http_error = requests.HTTPError("400 Client Error")
        http_error.response = error_response

        session = _FakeSession(
            get_responses=[
                _FakeResponse(headers={"X-CSRF-Token": "csrf-token"}),
                _FakeResponse(json_data={"d": {"ignored": True}}),
            ],
            post_response=_FakeResponse(
                headers={"Content-Type": "application/json"},
                json_data=err_json,
                text="SAP business failure",
                status_code=400,
                raise_exc=http_error,
            ),
        )

        template_data = {
            "IvDetails": {"Description": "Template title"},
            "IvContext": {},
            "IvScope": {},
        }
        state = {
            "template_id": {"value": "50339227"},
            "description_of_change": {"value": "Doc"},
            "reason_for_change": {"value": "Reason"},
        }

        with patch("tools.tools.SOLMAN_READ_BASE_URL", "https://solman.example.com"), \
             patch("tools.tools.SOLMAN_READ_USERNAME", "user"), \
             patch("tools.tools.SOLMAN_READ_PASSWORD", "pass"), \
             patch("tools.tools.SOLMAN_ODATA_PATH", "/sap/opu/odata/sap/ZCHM_RFC_SRV/ChangeRequestSet"), \
             patch("tools.tools.requests.Session", return_value=session), \
             patch("tools.tools._build_solman_get_urls", return_value=["u1"]), \
             patch("tools.tools._parse_odata_response", return_value=template_data):
            result = solman_write("draft", state)

        assert result["success"] is False
        assert result["is_sap_error"] is True
        assert result["error"] == "SAP reported a validation error but did not provide message details"

    def test_success_posts_expected_payload_and_returns_new_cr_id(self):
        from tools.tools import solman_write

        session = _FakeSession(
            get_responses=[
                _FakeResponse(headers={"X-CSRF-Token": "csrf-token"}),
                _FakeResponse(json_data={"d": {"ignored": True}}),
            ],
            post_response=_FakeResponse(
                headers={"Content-Type": "application/json"},
                json_data={"d": {"EvObjectID": "50419999", "Status": "Created"}},
                status_code=201,
            ),
        )

        template_data = {
            "IsDetails": {"TransactionNo": "50339227", "Risk": "Low"},
            "IvContext": {"Landscape": "QA", "CycleID": "OLD"},
        }
        state = {
            "wwid": "alice",
            "template_id": {"value": "50339227"},
            "cr_id": {"value": "50417365", "data": {"IsDetails": {"CycleId": "CYCLE-9"}}},
            "description_of_change": {"value": "Update role mapping"},
            "reason_for_change": {"value": "Fix auth"},
            "jira_id": {"data": {"summary": "Access change"}},
        }

        with patch("tools.tools.SOLMAN_READ_BASE_URL", "https://solman.example.com"), \
             patch("tools.tools.SOLMAN_READ_USERNAME", "user"), \
             patch("tools.tools.SOLMAN_READ_PASSWORD", "pass"), \
             patch("tools.tools.SOLMAN_ODATA_PATH", "/sap/opu/odata/sap/ZCHM_RFC_SRV/ChangeRequestSet"), \
             patch("tools.tools.requests.Session", return_value=session), \
             patch("tools.tools._build_solman_get_urls", return_value=["u1"]), \
             patch("tools.tools._parse_odata_response", return_value=template_data):
            result = solman_write("draft", state)

        assert result["success"] is True
        assert result["cr_id"] == "50419999"
        assert result["response_data"]["EvObjectID"] == "50419999"
        assert session.closed is True
        assert session.auth == ("user", "pass")

        post_url, post_kwargs = session.post_calls[0]
        assert post_url == "https://solman.example.com/sap/opu/odata/sap/ZCHM_RFC_SRV/ChangeRequestSet"
        assert post_kwargs["headers"]["X-CSRF-Token"] == "csrf-token"

        payload_d = post_kwargs["json"]["d"]
        assert payload_d["IvTemplateID"] == "50417365"
        assert payload_d["IvRequestor"] == "alice"
        assert payload_d["IvDetails"]["Description"] == "Access change"
        # IvContext.CycleID is now in _WRITE_ALLOWED_FIELDS (Task 1 — CycleID fix),
        # so IvContext appears in the POST payload when the template has a CycleID.
        assert "IvContext" in payload_d
        assert "CycleID" in payload_d["IvContext"]
        assert payload_d["toTexts"][0]["TdID"] == "CR01"
        assert payload_d["toTexts"][1]["TdID"] == "CR02"

    # ──────────────────────────────────────────────────────────────────────────
    # AprvProc override (node_21 integration)
    # ──────────────────────────────────────────────────────────────────────────
    def _make_session_for_override(self, template_data: dict) -> "_FakeSession":
        """Session that returns a successful POST with cr_id 50419999."""
        return _FakeSession(
            get_responses=[
                _FakeResponse(headers={"X-CSRF-Token": "csrf-token"}),
                _FakeResponse(json_data={"d": {"ignored": True}}),
            ],
            post_response=_FakeResponse(
                headers={"Content-Type": "application/json"},
                json_data={"d": {"EvObjectID": "50419999"}},
                status_code=201,
            ),
        )

    def _base_patches(self, session, template_data):
        return [
            patch("tools.tools.SOLMAN_READ_BASE_URL", "https://solman.example.com"),
            patch("tools.tools.SOLMAN_READ_USERNAME", "user"),
            patch("tools.tools.SOLMAN_READ_PASSWORD", "pass"),
            patch("tools.tools.SOLMAN_ODATA_PATH", "/sap/opu/odata/sap/ZCHM_RFC_SRV/ChangeRequestSet"),
            patch("tools.tools.requests.Session", return_value=session),
            patch("tools.tools._build_solman_get_urls", return_value=["u1"]),
            patch("tools.tools._parse_odata_response", return_value=template_data),
        ]

    def test_aprv_proc_given_sets_iv_details_aprv_proc_code(self):
        """When aprv_proc is given='J&J Approval', payload IvDetails.AprvProc = ZMCR0001."""
        from tools.tools import solman_write

        template_data = {
            "IvDetails": {"StandardChange": "", "OperateChange": ""},
            "IvContext": {"CycleType": "Continual Cycle"},
            "IvScope": {},
        }
        session = self._make_session_for_override(template_data)
        state = {
            "template_id": {"value": "65669"},
            "aprv_proc": {"given": True, "valid": True, "value": "J&J Approval", "data": None, "error": None},
            "transaction_type": {"given": True, "valid": True, "value": "Urgent", "data": None, "error": None},
        }

        captured_payload = {}

        original_post = session.post
        def _capture_post(url, **kwargs):
            import json
            body = kwargs.get("data") or kwargs.get("json") or ""
            if isinstance(body, str):
                try:
                    captured_payload.update(json.loads(body))
                except Exception:
                    pass
            return original_post(url, **kwargs)

        session.post = _capture_post

        with patch("tools.tools.SOLMAN_READ_BASE_URL", "https://solman.example.com"), \
             patch("tools.tools.SOLMAN_READ_USERNAME", "user"), \
             patch("tools.tools.SOLMAN_READ_PASSWORD", "pass"), \
             patch("tools.tools.SOLMAN_ODATA_PATH", "/sap/opu/odata/sap/ZCHM_RFC_SRV/ChangeRequestSet"), \
             patch("tools.tools.requests.Session", return_value=session), \
             patch("tools.tools._build_solman_get_urls", return_value=["u1"]), \
             patch("tools.tools._parse_odata_response", return_value=template_data):
            result = solman_write("draft text", state)

        assert result["success"] is True
        # Verify the POST body contained AprvProc = ZMCR0001
        assert "ZMCR0001" in str(session.post_calls)

    def test_transaction_type_given_sets_iv_scope_transaction_type_code(self):
        """When transaction_type='JnJ-Urgent Change', payload IvScope.TransactionType = YMHF."""
        from tools.tools import solman_write

        template_data = {
            "IvDetails": {"StandardChange": "", "OperateChange": ""},
            "IvContext": {"CycleType": "Continual Cycle"},
            "IvScope": {},
        }
        session = self._make_session_for_override(template_data)
        state = {
            "template_id": {"value": "65669"},
            "aprv_proc": {"given": True, "valid": True, "value": "J&J Approval", "data": None, "error": None},
            "transaction_type": {"given": True, "valid": True, "value": "JnJ-Urgent Change", "data": None, "error": None},
        }

        with patch("tools.tools.SOLMAN_READ_BASE_URL", "https://solman.example.com"), \
             patch("tools.tools.SOLMAN_READ_USERNAME", "user"), \
             patch("tools.tools.SOLMAN_READ_PASSWORD", "pass"), \
             patch("tools.tools.SOLMAN_ODATA_PATH", "/sap/opu/odata/sap/ZCHM_RFC_SRV/ChangeRequestSet"), \
             patch("tools.tools.requests.Session", return_value=session), \
             patch("tools.tools._build_solman_get_urls", return_value=["u1"]), \
             patch("tools.tools._parse_odata_response", return_value=template_data):
            result = solman_write("draft text", state)

        assert result["success"] is True
        # YMHF is the SAP code for "Urgent"
        assert "YMHF" in str(session.post_calls)

    def test_invalid_combination_returns_error_before_post(self):
        """If AprvProc + TransactionType combination is invalid, return error without posting."""
        from tools.tools import solman_write

        template_data = {
            "IvDetails": {"StandardChange": "", "OperateChange": ""},
            "IvContext": {"CycleType": "Continual Cycle"},
            "IvScope": {"TransactionType": "YMHF"},  # YMHF = Urgent — valid
        }
        session = self._make_session_for_override(template_data)
        # JnJ-Emergency Change is only valid with J&J Emergency Approval, not J&J Approval
        state = {
            "template_id": {"value": "65669"},
            "aprv_proc":        {"given": True, "valid": True, "value": "J&J Approval",         "data": None, "error": None},
            "transaction_type": {"given": True, "valid": True, "value": "JnJ-Emergency Change", "data": None, "error": None},
        }

        with patch("tools.tools.SOLMAN_READ_BASE_URL", "https://solman.example.com"), \
             patch("tools.tools.SOLMAN_READ_USERNAME", "user"), \
             patch("tools.tools.SOLMAN_READ_PASSWORD", "pass"), \
             patch("tools.tools.SOLMAN_ODATA_PATH", "/sap/opu/odata/sap/ZCHM_RFC_SRV/ChangeRequestSet"), \
             patch("tools.tools.requests.Session", return_value=session), \
             patch("tools.tools._build_solman_get_urls", return_value=["u1"]), \
             patch("tools.tools._parse_odata_response", return_value=template_data):
            result = solman_write("draft text", state)

        assert result["success"] is False
        assert result["cr_id"] is None
        assert result["error"] is not None
        # No POST should have been made
        assert session.post_calls == []

    def test_aprv_proc_not_in_state_snapshot_does_not_crash(self):
        """Missing aprv_proc key in state_snapshot silently skips the override."""
        from tools.tools import solman_write

        template_data = {
            "IvDetails": {"StandardChange": "X"},
            "IvContext": {},
            "IvScope": {},
        }
        session = self._make_session_for_override(template_data)
        state = {
            "template_id": {"value": "65669"},
            # aprv_proc and transaction_type intentionally absent (node_12 gap)
        }

        with patch("tools.tools.SOLMAN_READ_BASE_URL", "https://solman.example.com"), \
             patch("tools.tools.SOLMAN_READ_USERNAME", "user"), \
             patch("tools.tools.SOLMAN_READ_PASSWORD", "pass"), \
             patch("tools.tools.SOLMAN_ODATA_PATH", "/sap/opu/odata/sap/ZCHM_RFC_SRV/ChangeRequestSet"), \
             patch("tools.tools.requests.Session", return_value=session), \
             patch("tools.tools._build_solman_get_urls", return_value=["u1"]), \
             patch("tools.tools._parse_odata_response", return_value=template_data):
            result = solman_write("draft text", state)

        # Should not crash — submit succeeds without override
        assert result["success"] is True

    # ──────────────────────────────────────────────────────────────────────────
    # CycleID overlay behavior (node_20b → solman_write)
    # ──────────────────────────────────────────────────────────────────────────
    def test_cycle_id_from_ivcontext_overrides_template_cycle_id(self):
        """When node_20b writes IvContext.CycleID in cr_id.data, POST must use that value."""
        from tools.tools import solman_write

        session = _FakeSession(
            get_responses=[
                _FakeResponse(headers={"X-CSRF-Token": "csrf-token"}),
                _FakeResponse(json_data={"d": {"ignored": True}}),
            ],
            post_response=_FakeResponse(
                headers={"Content-Type": "application/json"},
                json_data={"d": {"EvObjectID": "50429991"}},
                status_code=201,
            ),
        )

        template_data = {
            "IvDetails": {"Description": "Template title"},
            "IvContext": {"CycleID": "0000653000", "CycleType": "Continual Cycle"},
            "IvScope": {},
        }
        state = {
            "template_id": {"value": "50174731"},
            "cr_id": {
                "value": "50174731",
                "data": {"IvContext": {"CycleID": "0000653541", "CycleType": "Continual Cycle"}},
            },
            "description_of_change": {"value": "Doc"},
            "reason_for_change": {"value": "Reason"},
        }

        with patch("tools.tools.SOLMAN_READ_BASE_URL", "https://solman.example.com"), \
             patch("tools.tools.SOLMAN_READ_USERNAME", "user"), \
             patch("tools.tools.SOLMAN_READ_PASSWORD", "pass"), \
             patch("tools.tools.SOLMAN_ODATA_PATH", "/sap/opu/odata/sap/ZCHM_RFC_SRV/ChangeRequestSet"), \
             patch("tools.tools.requests.Session", return_value=session), \
             patch("tools.tools._build_solman_get_urls", return_value=["u1"]), \
             patch("tools.tools._parse_odata_response", return_value=template_data):
            result = solman_write("draft", state)

        assert result["success"] is True
        _post_url, post_kwargs = session.post_calls[0]
        payload_d = post_kwargs["json"]["d"]
        assert payload_d["IvContext"]["CycleID"] == "0000653541"

    def test_cycle_id_falls_back_to_isdetails_cycleid_when_ivcontext_missing(self):
        """If IvContext.CycleID is absent in cr_id.data, fallback to IsDetails.CycleId."""
        from tools.tools import solman_write

        session = _FakeSession(
            get_responses=[
                _FakeResponse(headers={"X-CSRF-Token": "csrf-token"}),
                _FakeResponse(json_data={"d": {"ignored": True}}),
            ],
            post_response=_FakeResponse(
                headers={"Content-Type": "application/json"},
                json_data={"d": {"EvObjectID": "50429992"}},
                status_code=201,
            ),
        )

        template_data = {
            "IvDetails": {"Description": "Template title"},
            "IvContext": {"CycleID": "0000653000", "CycleType": "Continual Cycle"},
            "IvScope": {},
        }
        state = {
            "template_id": {"value": "50174731"},
            "cr_id": {
                "value": "50174731",
                "data": {"IsDetails": {"CycleId": "0000653999"}},
            },
            "description_of_change": {"value": "Doc"},
            "reason_for_change": {"value": "Reason"},
        }

        with patch("tools.tools.SOLMAN_READ_BASE_URL", "https://solman.example.com"), \
             patch("tools.tools.SOLMAN_READ_USERNAME", "user"), \
             patch("tools.tools.SOLMAN_READ_PASSWORD", "pass"), \
             patch("tools.tools.SOLMAN_ODATA_PATH", "/sap/opu/odata/sap/ZCHM_RFC_SRV/ChangeRequestSet"), \
             patch("tools.tools.requests.Session", return_value=session), \
             patch("tools.tools._build_solman_get_urls", return_value=["u1"]), \
             patch("tools.tools._parse_odata_response", return_value=template_data):
            result = solman_write("draft", state)

        assert result["success"] is True
        _post_url, post_kwargs = session.post_calls[0]
        payload_d = post_kwargs["json"]["d"]
        assert payload_d["IvContext"]["CycleID"] == "0000653999"

    def test_cycle_id_preserves_template_when_not_selected(self):
        """Without selected CycleID in cr_id.data, keep template IvContext.CycleID unchanged."""
        from tools.tools import solman_write

        session = _FakeSession(
            get_responses=[
                _FakeResponse(headers={"X-CSRF-Token": "csrf-token"}),
                _FakeResponse(json_data={"d": {"ignored": True}}),
            ],
            post_response=_FakeResponse(
                headers={"Content-Type": "application/json"},
                json_data={"d": {"EvObjectID": "50429993"}},
                status_code=201,
            ),
        )

        template_data = {
            "IvDetails": {"Description": "Template title"},
            "IvContext": {"CycleID": "0000653000", "CycleType": "Continual Cycle"},
            "IvScope": {},
        }
        state = {
            "template_id": {"value": "50174731"},
            "cr_id": {
                "value": "50174731",
                "data": {"IvLocation": {"Site": ""}},
            },
            "description_of_change": {"value": "Doc"},
            "reason_for_change": {"value": "Reason"},
        }

        with patch("tools.tools.SOLMAN_READ_BASE_URL", "https://solman.example.com"), \
             patch("tools.tools.SOLMAN_READ_USERNAME", "user"), \
             patch("tools.tools.SOLMAN_READ_PASSWORD", "pass"), \
             patch("tools.tools.SOLMAN_ODATA_PATH", "/sap/opu/odata/sap/ZCHM_RFC_SRV/ChangeRequestSet"), \
             patch("tools.tools.requests.Session", return_value=session), \
             patch("tools.tools._build_solman_get_urls", return_value=["u1"]), \
             patch("tools.tools._parse_odata_response", return_value=template_data):
            result = solman_write("draft", state)

        assert result["success"] is True
        _post_url, post_kwargs = session.post_calls[0]
        payload_d = post_kwargs["json"]["d"]
        assert payload_d["IvContext"]["CycleID"] == "0000653000"