import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pytest

from config import settings as settings_module


@pytest.fixture(autouse=True)
def clear_settings_cache():
    settings_module.get_settings.cache_clear()
    yield
    settings_module.get_settings.cache_clear()


class TestSettingsHelpers:
    def test_get_strips_quotes_and_whitespace(self, monkeypatch):
        monkeypatch.setenv("TRIMMED_VALUE", '  "hello world"  ')
        assert settings_module._get("TRIMMED_VALUE") == "hello world"

    def test_get_uses_default_when_missing(self):
        assert settings_module._get("MISSING_ENV_FOR_TEST", "fallback") == "fallback"

    def test_require_raises_when_missing(self):
        with pytest.raises(ValueError, match="Missing required environment variable"):
            settings_module._require("MISSING_ENV_FOR_TEST")

    @pytest.mark.parametrize("value", ["SAFE_NAME", "safe_name_2", "Name123"])
    def test_require_identifier_accepts_safe_values(self, monkeypatch, value):
        monkeypatch.setenv("SAFE_IDENTIFIER", value)
        assert settings_module._require_identifier("SAFE_IDENTIFIER") == value

    @pytest.mark.parametrize("value", ["bad-name", "123name", "name.with.dot"])
    def test_require_identifier_rejects_invalid_values(self, monkeypatch, value):
        monkeypatch.setenv("SAFE_IDENTIFIER", value)
        with pytest.raises(ValueError, match="Invalid SQL identifier"):
            settings_module._require_identifier("SAFE_IDENTIFIER")


class TestGetSettings:
    def _set_required_env(self, monkeypatch):
        env = {
            "NEO4J_URI": "bolt://localhost:7687",
            "NEO4J_USER": "neo4j",
            "NEO4J_PASSWORD": "secret",
            "AZURE_OPENAI_API_KEY": "chat-key",
            "AZURE_OPENAI_ENDPOINT": "https://example.openai.azure.com/",
            "AZURE_OPENAI_API_VERSION": "2024-02-01",
            "AZURE_OPENAI_DEPLOYMENT": "gpt-4o",
            "AZURE_OPENAI_EMBEDDING_API_KEY": "embed-key",
            "AZURE_OPENAI_EMBEDDING_ENDPOINT": "https://example.openai.azure.com/",
            "AZURE_OPENAI_EMBEDDING_API_VERSION": "2024-02-01",
            "AZURE_OPENAI_EMBEDDING_DEPLOYMENT": "text-embedding-3-large",
        }
        for key, value in env.items():
            monkeypatch.setenv(key, value)

    def test_builds_settings_dataclass(self, monkeypatch):
        self._set_required_env(monkeypatch)

        settings = settings_module.get_settings()
        assert settings.neo4j_uri == "bolt://localhost:7687"
        assert settings.neo4j_user == "neo4j"
        assert settings.neo4j_password == "secret"
        assert settings.neo4j_database == "neo4j"
        assert settings.azure_openai_deployment == "gpt-4o"
        assert settings.azure_embedding_deployment == "text-embedding-3-large"

    def test_get_settings_is_cached(self, monkeypatch):
        self._set_required_env(monkeypatch)

        first = settings_module.get_settings()
        monkeypatch.setenv("NEO4J_USER", "changed-user")
        second = settings_module.get_settings()

        assert first is second
        assert second.neo4j_user == "neo4j"

    def test_missing_required_env_raises(self, monkeypatch):
        self._set_required_env(monkeypatch)
        monkeypatch.delenv("NEO4J_PASSWORD", raising=False)

        with pytest.raises(ValueError, match="NEO4J_PASSWORD"):
            settings_module.get_settings()