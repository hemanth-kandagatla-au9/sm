"""
tests/test_tools_transaction_type.py
Unit tests for:
  - get_transaction_type_options()
  - validate_change_type_combination()
No external calls — pure logic tests, no mocking needed.
"""
import os
import sys
from unittest.mock import patch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pytest
from tools.tools import (
    get_transaction_type_for_cycle,
    get_transaction_type_options,
    resolve_change_type_rule,
    validate_change_type_combination,
)


# ─────────────────────────────────────────────────────────────────────────────
# get_transaction_type_options
# ─────────────────────────────────────────────────────────────────────────────
class TestGetTransactionTypeOptions:
    """
    Rules table (from Transaction Type specification):
    ┌──────────────┬──────────────┬──────────────────────┬──────────────────────┬──────────────────────────────────────────────┐
    │ SC           │ OC           │ AprvProc             │ CycleType            │ Valid TransactionTypes                       │
    ├──────────────┼──────────────┼──────────────────────┼──────────────────────┼──────────────────────────────────────────────┤
    │ X            │ (any)        │ (any)                │ (any)                │ JnJ-Standard Change                          │
    │ (blank)      │ X            │ (any)                │ Continual Cycle      │ JnJ-Operate Change, Operate Emergency Change,│
    │              │              │                      │                      │ JNJ-Admin CO, Operate Emergency Admin   │
    │ (blank)      │ X            │ (any)                │ Release Cycle        │ JnJ-Project Change, JNJ-Admin CO        │
    │ (blank)      │ X            │ (any)                │ (other)              │ [] (empty)                                   │
    │ (blank)      │ (blank)      │ J&J Approval         │ Continual Cycle      │ JnJ-Urgent Change, JnJ-Admin Change          │
    │ (blank)      │ (blank)      │ J&J Approval         │ Phase Cycle          │ JnJ-Normal Change, JnJ-Admin Change          │
    │ (blank)      │ (blank)      │ J&J Approval         │ Release Cycle        │ JnJ-Normal Chg (ToC), JnJ-Admin Change       │
    │ (blank)      │ (blank)      │ J&J Emergency Apprvl │ Continual Cycle      │ JnJ-Emergency Change, JnJ-Emergency Admin    │
    │ (blank)      │ (blank)      │ (other / blank)      │ (any)                │ [] (empty)                                   │
    └──────────────┴──────────────┴──────────────────────┴──────────────────────┴──────────────────────────────────────────────┘
    """

    # SC = X → always "JnJ-Standard Change"
    def test_sc_x_returns_standard_change(self):
        assert get_transaction_type_options("X", "", "J&J Approval", "Continual Cycle") == ["JnJ-Standard Change"]

    def test_sc_x_ignores_oc_and_aprv_proc(self):
        assert get_transaction_type_options("X", "X", "J&J Emergency Approval", "Release Cycle") == ["JnJ-Standard Change"]

    def test_sc_x_lowercase_still_matches(self):
        assert get_transaction_type_options("x", "", "J&J Approval", "Continual Cycle") == ["JnJ-Standard Change"]

    # OC = X, Continual Cycle
    def test_oc_x_continual_returns_four_operate_types(self):
        result = get_transaction_type_options("", "X", "", "Continual Cycle")
        assert result == [
            "JnJ-Operate Change",
            "Operate Emergency Change",
            "JNJ-Admin CO",
            "Operate Emergency Admin Change",
        ]

    def test_oc_x_continual_case_insensitive_cycle_type(self):
        result = get_transaction_type_options("", "X", "", "Continual Release Cycle")
        # "Continual" substring present → same four options
        assert "JnJ-Operate Change" in result

    # OC = X, Release Cycle
    def test_oc_x_release_returns_project_and_admin(self):
        result = get_transaction_type_options("", "X", "", "Release Cycle")
        assert result == ["JnJ-Project Change", "JNJ-Admin CO"]

    def test_oc_x_other_cycle_type_returns_empty(self):
        result = get_transaction_type_options("", "X", "", "Phase Cycle")
        assert result == []

    # SC blank, OC blank, J&J Approval + Continual
    def test_jj_approval_continual_returns_urgent_admin(self):
        result = get_transaction_type_options("", "", "J&J Approval", "Continual Cycle")
        assert result == ["JnJ-Urgent Change", "JnJ-Admin Change"]

    # SC blank, OC blank, J&J Approval + Phase
    def test_jj_approval_phase_returns_normal_admin(self):
        result = get_transaction_type_options("", "", "J&J Approval", "Phase Cycle")
        assert result == ["JnJ-Normal Change", "JnJ-Admin Change"]

    # SC blank, OC blank, J&J Approval + Release
    def test_jj_approval_release_returns_normal_toc_admin(self):
        result = get_transaction_type_options("", "", "J&J Approval", "Release Cycle")
        assert result == ["JnJ-Normal Chg (ToC)", "JnJ-Admin Change"]

    # SC blank, OC blank, J&J Emergency Approval + Continual
    def test_jj_emergency_continual_returns_emergency_types(self):
        result = get_transaction_type_options("", "", "J&J Emergency Approval", "Continual Cycle")
        assert result == ["JnJ-Emergency Change", "JnJ-Emergency Admin"]

    # SAP code normalisation — ZMCR0001 accepted as J&J Approval
    def test_aprv_proc_sap_code_zmcr0001_normalised(self):
        result = get_transaction_type_options("", "", "ZMCR0001", "Continual Cycle")
        assert result == ["JnJ-Urgent Change", "JnJ-Admin Change"]

    # SAP code normalisation — ZMCR0003 accepted as J&J Emergency Approval
    def test_aprv_proc_sap_code_zmcr0003_normalised(self):
        result = get_transaction_type_options("", "", "ZMCR0003", "Continual Cycle")
        assert result == ["JnJ-Emergency Change", "JnJ-Emergency Admin"]

    # No valid combination — returns empty list
    def test_blank_aprv_proc_blank_cycle_returns_empty(self):
        result = get_transaction_type_options("", "", "", "Continual Cycle")
        assert result == []

    def test_unknown_cycle_with_jj_emergency_returns_empty(self):
        result = get_transaction_type_options("", "", "J&J Emergency Approval", "Phase Cycle")
        assert result == []


# ─────────────────────────────────────────────────────────────────────────────
# validate_change_type_combination
# ─────────────────────────────────────────────────────────────────────────────
class TestValidateChangeTypeCombination:

    def test_valid_standard_change(self):
        result = validate_change_type_combination("X", "", "", "JnJ-Standard Change", "")
        assert result["valid"] is True
        assert result["error"] is None

    def test_valid_urgent_for_jj_approval_continual(self):
        result = validate_change_type_combination("", "", "J&J Approval", "JnJ-Urgent Change", "Continual Cycle")
        assert result["valid"] is True

    def test_valid_operate_change_for_oc_continual(self):
        result = validate_change_type_combination("", "X", "", "JnJ-Operate Change", "Continual Cycle")
        assert result["valid"] is True

    def test_invalid_tt_returns_false_with_message(self):
        result = validate_change_type_combination("", "", "J&J Approval", "Emergency", "Continual Cycle")
        assert result["valid"] is False
        assert "Emergency" in result["error"]
        assert "JnJ-Urgent Change" in result["error"] or "JnJ-Admin Change" in result["error"]

    def test_no_valid_options_returns_false(self):
        # blank SC, blank OC, blank AprvProc, no valid table entry
        result = validate_change_type_combination("", "", "", "Normal", "Continual Cycle")
        assert result["valid"] is False
        assert result["error"] is not None

    def test_transaction_type_as_sap_code_is_normalised(self):
        # "YMHF" is the SAP code for "Urgent"
        result = validate_change_type_combination("", "", "J&J Approval", "YMHF", "Continual Cycle")
        assert result["valid"] is True

    def test_empty_transaction_type_returns_valid(self):
        # No TT set yet — combination check is skipped
        result = validate_change_type_combination("", "", "J&J Approval", "", "Continual Cycle")
        assert result["valid"] is True

    def test_aprv_proc_as_sap_code_zmcr0001(self):
        result = validate_change_type_combination("", "", "ZMCR0001", "JnJ-Urgent Change", "Continual Cycle")
        assert result["valid"] is True

    def test_operate_admin_valid_for_release_cycle(self):
        result = validate_change_type_combination("", "X", "", "JNJ-Admin CO", "Release Cycle")
        assert result["valid"] is True

    def test_project_change_invalid_for_continual_cycle(self):
        # "JnJ-Project Change" is only valid for OC=X + Release Cycle
        result = validate_change_type_combination("", "X", "", "JnJ-Project Change", "Continual Cycle")
        assert result["valid"] is False


class TestTransactionTypeResolution:

    def test_cycle_dominant_process_type_returns_admin(self):
        with patch(
            "tools.tools.execute_cypher",
            side_effect=[[{"process_type": "ZMAD", "cr_count": 1190}, {"process_type": "YMAD", "cr_count": 77}]],
        ):
            assert get_transaction_type_for_cycle("000000000654313") == "JnJ-Admin Change"

    def test_cycle_without_process_type_mapping_returns_empty(self):
        with patch("tools.tools.execute_cypher", return_value=[]):
            assert get_transaction_type_for_cycle("656594") == ""

    def test_resolve_urgent_rule(self):
        result = resolve_change_type_rule("JnJ-Urgent Change", "Continual Cycle")
        assert result == {
            "standard_change": "",
            "operate_change": "",
            "approval_process": "J&J Approval",
            "cycle_type": "Continual Cycle",
            "transaction_type": "JnJ-Urgent Change",
        }

    def test_resolve_admin_uses_cycle_type_hint(self):
        result = resolve_change_type_rule("JnJ-Admin Change", "Release Cycle")
        assert result["approval_process"] == "J&J Approval"
        assert result["cycle_type"] == "Continual Cycle"
        assert result["transaction_type"] == "JnJ-Admin Change"
