"""
tests/test_config_helpers.py

Unit tests for config/config.py helper functions and constants.
Zero external calls — all pure in-memory logic.

Covers:
  - get_display_name: known key → human label, unknown key → key itself
  - get_field_section: known key → section name, unknown key → None
  - PLATFORM_ALIASES: spot checks, all values non-empty strings, all keys lowercase
  - BOOL_FIELDS: key compliance fields present
  - LOCKED_FIELDS: session-locked fields present
  - COMPLIANCE_LOCKED_FIELDS: GxP/SOX/Security present
  - FIELD_DISPLAY_NAMES: flat dict matches FIELD_GROUPS exactly (auto-build check)
    - ODATA_FIELD_MAP: spot-check key→value pairs using current Iv* group names
  - ODATA_FIELD_MAP_REVERSE: inverse mapping consistent
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pytest
from config.config import (
    get_display_name,
    get_field_section,
    PLATFORM_ALIASES,
    FIELD_DISPLAY_NAMES,
    FIELD_GROUPS,
    BOOL_FIELDS,
    LOCKED_FIELDS,
    COMPLIANCE_LOCKED_FIELDS,
    ODATA_FIELD_MAP,
    ODATA_FIELD_MAP_REVERSE,
)


# ─────────────────────────────────────────────────────────────────────────────
# get_display_name
# ─────────────────────────────────────────────────────────────────────────────
class TestGetDisplayName:

    def test_description_returns_label(self):
        assert get_display_name("description") == "Description"

    def test_priority_returns_label(self):
        assert get_display_name("priority_adtnl") == "Priority"

    def test_risk_returns_label(self):
        assert get_display_name("risk_adtnl") == "Risk"

    def test_status_returns_label(self):
        assert get_display_name("status_adtnl") == "Status"

    def test_platform_returns_label(self):
        assert get_display_name("platform") == "Platform"

    def test_regression_test_returns_label(self):
        assert get_display_name("zzfld00000v_cus") == "Regression Test (QAS)"

    def test_uat_returns_label(self):
        assert get_display_name("zzfld00000w_cus") == "UAT (QAS)"

    def test_gxp_returns_label(self):
        assert get_display_name("zzfld00000c_cus") == "GxP Relevant"

    def test_sox_returns_label(self):
        assert get_display_name("zzfld00000e_cus") == "SOX Impact"

    def test_security_change_returns_label(self):
        assert get_display_name("zzfld00000b_cus") == "Security Change"

    def test_unknown_key_returns_key_itself(self):
        assert get_display_name("totally_unknown_field_xyz") == "totally_unknown_field_xyz"

    def test_empty_string_returns_empty_string(self):
        assert get_display_name("") == ""


# ─────────────────────────────────────────────────────────────────────────────
# get_field_section
# ─────────────────────────────────────────────────────────────────────────────
class TestGetFieldSection:

    def test_description_in_details(self):
        assert get_field_section("description") == "Details"

    def test_priority_in_details(self):
        assert get_field_section("priority_adtnl") == "Details"

    def test_platform_in_details(self):
        assert get_field_section("platform") == "Details"

    def test_regression_in_testing(self):
        assert get_field_section("zzfld00000v_cus") == "Testing Requirements"

    def test_uat_in_testing(self):
        assert get_field_section("zzfld00000w_cus") == "Testing Requirements"

    def test_config_doc_in_documentation(self):
        assert get_field_section("zzfld000001_cus") == "Documentation Requirements"

    def test_code_review_in_documentation(self):
        assert get_field_section("zzfld000003_cus") == "Documentation Requirements"

    def test_sox_in_others(self):
        assert get_field_section("zzfld00000e_cus") == "Others"

    def test_security_change_in_others(self):
        assert get_field_section("zzfld00000b_cus") == "Others"

    def test_unknown_field_returns_none(self):
        assert get_field_section("nonexistent_field_xyz") is None

    def test_empty_string_returns_none(self):
        assert get_field_section("") is None


# ─────────────────────────────────────────────────────────────────────────────
# PLATFORM_ALIASES
# ─────────────────────────────────────────────────────────────────────────────
class TestPlatformAliases:

    def test_cfin_resolves_to_central_finance(self):
        assert PLATFORM_ALIASES["cfin"] == "Central Finance"

    def test_hmd_alias_resolves(self):
        assert PLATFORM_ALIASES["hospital medical devices erp (hmd)"] == "HMD"

    def test_grc_resolves(self):
        assert PLATFORM_ALIASES["grc"] == "AS GRC"

    def test_ewm_resolves_to_wms_ewm(self):
        assert PLATFORM_ALIASES["ewm"] == "WMS EWM"

    def test_jax_ewm_resolves(self):
        assert PLATFORM_ALIASES["jax ewm"] == "WMS EWM"

    def test_solman_resolves(self):
        assert PLATFORM_ALIASES["solman"] == "AS SolMan"

    def test_atlas_sap_resolves(self):
        assert PLATFORM_ALIASES["atlas sap"] == "Atlas"

    def test_panda_sap_resolves(self):
        assert PLATFORM_ALIASES["panda sap"] == "PandA"

    def test_europe2_resolves(self):
        assert PLATFORM_ALIASES["europe2"] == "E2"

    def test_all_values_non_empty_strings(self):
        for alias, canonical in PLATFORM_ALIASES.items():
            assert isinstance(canonical, str) and canonical.strip(), \
                f"Alias '{alias}' maps to empty/invalid canonical: {canonical!r}"

    def test_all_keys_are_lowercase(self):
        for alias in PLATFORM_ALIASES:
            assert alias == alias.lower(), \
                f"Alias key '{alias}' is not all-lowercase"

    def test_no_duplicate_values_per_alias(self):
        """Each alias should map to exactly one canonical name."""
        for alias, canonical in PLATFORM_ALIASES.items():
            assert isinstance(canonical, str)


# ─────────────────────────────────────────────────────────────────────────────
# BOOL_FIELDS
# ─────────────────────────────────────────────────────────────────────────────
class TestBoolFields:

    def test_regression_test_in_bool_fields(self):
        assert "zzfld00000v_cus" in BOOL_FIELDS

    def test_uat_in_bool_fields(self):
        assert "zzfld00000w_cus" in BOOL_FIELDS

    def test_sox_in_bool_fields(self):
        assert "zzfld00000e_cus" in BOOL_FIELDS

    def test_gxp_in_bool_fields(self):
        assert "zzfld00000c_cus" in BOOL_FIELDS

    def test_security_change_in_bool_fields(self):
        assert "zzfld00000b_cus" in BOOL_FIELDS

    def test_prod_confirm_in_bool_fields(self):
        assert "zzfld000023_cus" in BOOL_FIELDS

    def test_bool_fields_is_a_set(self):
        assert isinstance(BOOL_FIELDS, set)


# ─────────────────────────────────────────────────────────────────────────────
# LOCKED_FIELDS
# ─────────────────────────────────────────────────────────────────────────────
class TestLockedFields:

    def test_template_id_locked(self):
        assert "template_id" in LOCKED_FIELDS

    def test_cr_id_locked(self):
        assert "cr_id" in LOCKED_FIELDS

    def test_platform_locked(self):
        assert "platform" in LOCKED_FIELDS

    def test_target_system_locked(self):
        assert "target_system" in LOCKED_FIELDS

    def test_jira_id_locked(self):
        assert "jira_id" in LOCKED_FIELDS


# ─────────────────────────────────────────────────────────────────────────────
# COMPLIANCE_LOCKED_FIELDS
# ─────────────────────────────────────────────────────────────────────────────
class TestComplianceLockedFields:

    @pytest.mark.skip(reason="COMPLIANCE_LOCKED_FIELDS not yet populated — pending implementation")
    def test_gxp_compliance_locked(self):
        assert "zzfld00000c_cus" in COMPLIANCE_LOCKED_FIELDS

    @pytest.mark.skip(reason="COMPLIANCE_LOCKED_FIELDS not yet populated — pending implementation")
    def test_sox_compliance_locked(self):
        assert "zzfld00000e_cus" in COMPLIANCE_LOCKED_FIELDS

    @pytest.mark.skip(reason="COMPLIANCE_LOCKED_FIELDS not yet populated — pending implementation")
    def test_security_change_compliance_locked(self):
        assert "zzfld00000b_cus" in COMPLIANCE_LOCKED_FIELDS

    @pytest.mark.skip(reason="COMPLIANCE_LOCKED_FIELDS not yet populated — pending implementation")
    def test_ricef_compliance_locked(self):
        assert "zzfld00000d_cus" in COMPLIANCE_LOCKED_FIELDS

    @pytest.mark.skip(reason="COMPLIANCE_LOCKED_FIELDS not yet populated — pending implementation")
    def test_sod_ruleset_compliance_locked(self):
        assert "zzfld000004_cus" in COMPLIANCE_LOCKED_FIELDS


# ─────────────────────────────────────────────────────────────────────────────
# FIELD_DISPLAY_NAMES flat dict consistency
# ─────────────────────────────────────────────────────────────────────────────
class TestFieldDisplayNamesConsistency:

    def test_flat_dict_matches_all_group_fields(self):
        """FIELD_DISPLAY_NAMES must contain every key/label from FIELD_GROUPS."""
        for section, fields in FIELD_GROUPS.items():
            for key, label in fields.items():
                assert key in FIELD_DISPLAY_NAMES, \
                    f"Key '{key}' from section '{section}' missing in FIELD_DISPLAY_NAMES"
                assert FIELD_DISPLAY_NAMES[key] == label, \
                    f"FIELD_DISPLAY_NAMES['{key}'] = {FIELD_DISPLAY_NAMES[key]!r}, " \
                    f"expected {label!r} (section: {section})"

    def test_flat_dict_is_not_empty(self):
        assert len(FIELD_DISPLAY_NAMES) > 0

    def test_all_values_are_strings(self):
        for key, label in FIELD_DISPLAY_NAMES.items():
            assert isinstance(label, str), f"FIELD_DISPLAY_NAMES['{key}'] is not a string"


# ─────────────────────────────────────────────────────────────────────────────
# ODATA_FIELD_MAP and its reverse
# ─────────────────────────────────────────────────────────────────────────────
class TestOdataFieldMap:

    def test_details_description_maps_to_description(self):
        assert ODATA_FIELD_MAP[("IvDetails", "Description")] == "description"

    def test_details_standard_change_maps_correctly(self):
        assert ODATA_FIELD_MAP[("IvDetails", "StandardChange")] == "standard_change_adtnl"

    def test_details_operate_change_maps_correctly(self):
        assert ODATA_FIELD_MAP[("IvDetails", "OperateChange")] == "operate_change_adtnl"

    def test_details_aprv_proc_maps_correctly(self):
        assert ODATA_FIELD_MAP[("IvDetails", "AprvProc")] == "aprv_proc_adtnl"

    def test_scope_transaction_type_maps_correctly(self):
        assert ODATA_FIELD_MAP[("IvScope", "TransactionType")] == "transaction_type_scope"

    def test_scope_configuration_item_maps_correctly(self):
        assert ODATA_FIELD_MAP[("IvScope", "ConfigurationItem")] == "configuration_item_scope"

    def test_validation_user_requirement_maps_correctly(self):
        assert ODATA_FIELD_MAP[("IvValidation", "UserRequirement")] == "zzfld00004p"

    def test_testreq_regression_maps_correctly(self):
        assert ODATA_FIELD_MAP[("IvTestReq", "RegressionTestQAS")] == "zzfld00000v_cus"

    def test_testreq_uat_maps_correctly(self):
        assert ODATA_FIELD_MAP[("IvTestReq", "UATQAS")] == "zzfld00000w_cus"

    def test_others_security_maps_correctly(self):
        assert ODATA_FIELD_MAP[("IvOthers", "SecurityChange")] == "zzfld00000b_cus"

    def test_others_gxp_maps_correctly(self):
        assert ODATA_FIELD_MAP[("IvOthers", "GxPRelevant")] == "zzfld00000c_cus"


class TestOdataFieldMapReverse:

    def test_reverse_is_inverse_of_forward(self):
        for (group, field), internal_key in ODATA_FIELD_MAP.items():
            assert ODATA_FIELD_MAP_REVERSE[internal_key] == (group, field), \
                f"Reverse map mismatch for key '{internal_key}'"

    def test_reverse_has_same_length(self):
        assert len(ODATA_FIELD_MAP_REVERSE) == len(ODATA_FIELD_MAP)

    def test_description_reverse(self):
        assert ODATA_FIELD_MAP_REVERSE["description"] == ("IvDetails", "Description")

    def test_standard_change_reverse(self):
        assert ODATA_FIELD_MAP_REVERSE["standard_change_adtnl"] == ("IvDetails", "StandardChange")

    def test_scope_transaction_type_reverse(self):
        assert ODATA_FIELD_MAP_REVERSE["transaction_type_scope"] == ("IvScope", "TransactionType")

    def test_regression_reverse(self):
        assert ODATA_FIELD_MAP_REVERSE["zzfld00000v_cus"] == ("IvTestReq", "RegressionTestQAS")

    def test_gxp_reverse(self):
        assert ODATA_FIELD_MAP_REVERSE["zzfld00000c_cus"] == ("IvOthers", "GxPRelevant")


# ─────────────────────────────────────────────────────────────────────────────
# FIELD_GROUPS section and field order — regression guard
# ─────────────────────────────────────────────────────────────────────────────
class TestFieldGroupsOrder:
    """Regression tests to lock the exact field insertion order in FIELD_GROUPS.
    These tests fail immediately if any section order is accidentally changed."""

    def _keys(self, section: str) -> list:
        return list(FIELD_GROUPS[section].keys())

    # ── Section sequence ─────────────────────────────────────────────────────
    def test_section_order(self):
        expected = [
            "Details",
            "Request for Change Scope",
            "Approval",
            "Functional Areas",
            "Location",
            "Documentation Requirements",
            "Validation Requirements",
            "Testing Requirements",
            "Others",
            "Parties Involved",
        ]
        assert list(FIELD_GROUPS.keys()) == expected

    def test_details_order(self):
        expected = [
            "object_id",
            "posting_date",
            "description",
            "changed_at",
            "zzfld000026",
            "zzfld000029",
            "zzfld000024_cus",
            "ibase_ctx",
            "ibase_instance_ctx",
            "product_id_ctx",
            "solution_id_ctx",
            "project_title_ctx",
            "current_phase_desc_ctx",
            "slan_name_ctx",
            "sbra_name_ctx",
            "release_type_ctx",
            "status_adtnl",
            "requestor_adtnl",
            "priority_adtnl",
            "risk_adtnl",
            "planned_impl_dt_adtnl",
            "actual_impl_dt_adtnl",
            "support_group_adtnl",
            "platform",
            "approve_status_ctx",
            "process_type_ctx",
            "standard_change_adtnl",
            "operate_change_adtnl",
            "aprv_proc_adtnl",
        ]
        assert self._keys("Details") == expected

    def test_request_for_change_scope_order(self):
        assert self._keys("Request for Change Scope") == [
            "transaction_type_scope",
            "configuration_item_scope",
        ]

    # ── Documentation Requirements ───────────────────────────────────────────
    def test_documentation_requirements_order(self):
        expected = [
            "zzfld000001_cus",   # BC Set
            "zzfld000002_cus",   # Config Doc Update
            "zzfld000053",       # 1. Doc ID with Ver.#
            "zzfld000003_cus",   # Code Review
            "zzfld000004_cus",   # SOD RuleSet
            "zzfld000052",       # 2. Doc ID with Ver.#
            "zzfld000005_cus",   # Training Materials
            "zzfld000006_cus",   # Updates to SOP/WI
            "zzfld000051",       # 3. Doc ID with Ver.#
            "zzfld000007_cus",   # BPML Update
            "zzfld000000_cus",   # Process Decomposition
            "zzfld000050",       # 4. Doc ID with Ver.#
            "zzfld000054",       # Bus Proc Analysis
            "zzfld000055",       # 5. Doc ID with Ver.#
            "zzfld000056",       # Bus Proc Hierarchy
            "zzfld000057",       # 6. Doc ID with Ver.#
            "zzfld000009_cus",   # Others1
            "zzfld000008_cus",   # Others2
            "zzfld00000a_cus",   # Others3
        ]
        assert self._keys("Documentation Requirements") == expected

    # ── Functional Areas ─────────────────────────────────────────────────────
    def test_functional_areas_order(self):
        expected = [
            "zzfld000016_cus",   # Primary Functional Area
            "zzfld000017_cus",   # Secondary Functional Area
            "zzfld00001b_cus",   # OFM
            "zzfld00001c_cus",   # Source
            "zzfld00001d_cus",   # Deliver
            "zzfld00001e_cus",   # Make
            "zzfld00001f_cus",   # Plan
            "zzfld00001g_cus",   # QM
            "zzfld00001h_cus",   # Security
            "zzfld00002c_cus",   # Logistics
            "zzfld00001j_cus",   # IM/WM
            "zzfld00001k_cus",   # MDM
            "zzfld00001l_cus",   # DWMS
            "zzfld00001m_cus",   # BI
            "zzfld00001r_cus",   # Integration
            "zzfld00001s_cus",   # HR
            "zzfld00001t_cus",   # Payroll
            "zzfld00002h_cus",   # Global Trade
            "zzfld00001u_cus",   # CRM
            "zzfld00001w_cus",   # Portal
            "zzfld00001v_cus",   # Development
            "zzfld00001i_cus",   # Basis
        ]
        assert self._keys("Functional Areas") == expected

    # ── Others ───────────────────────────────────────────────────────────────
    def test_others_order(self):
        expected = [
            "zzfld00000c_cus",   # GxP Relevant
            "zzfld00000b_cus",   # Security Change
            "zzfld00000e_cus",   # SOX Impact
            "zzfld00000l_cus",   # Train Users
            "zzfld00000g_cus",   # End User Tran Code
            "zzfld00000f_cus",   # Defect Reference
            "zzfld00000d_cus",   # RICEF
            "zzfld00000i_cus",   # Others1
            "zzfld00000h_cus",   # Others2
            "zzfld00000j_cus",   # Others3
            "zzfld00000m_cus",   # Deferred To
            "zzfld00000k_cus",   # Requirement Number
            "zzfld00002a_cus",   # Add.Description
        ]
        assert self._keys("Others") == expected

    # ── Validation Requirements ──────────────────────────────────────────────
    def test_validation_requirements_order(self):
        expected = [
            "zzfld00004p",       # User Requirements
            "zzfld00004q",       # 7. Doc ID with Ver.#
            "zzfld00004r",       # Functional Requirements
            "zzfld00004s",       # 8. Doc ID with Ver.#
            "zzfld00000o_cus",   # Functional Design
            "zzfld00004t",       # 9. Doc ID with Ver.#
            "zzfld00000n_cus",   # Technical Design
            "zzfld00004u",       # 10. Doc ID with Ver.#
            "zzfld00004v",       # Others1 (Val Req)
            "zzfld00004w",       # Others2 (Val Req)
        ]
        assert self._keys("Validation Requirements") == expected

    # ── Testing Requirements ─────────────────────────────────────────────────
    def test_testing_requirements_order(self):
        expected = [
            "zzfld00000s_cus",   # Functional Unit Test (Dev)
            "zzfld00000r_cus",   # Technical Unit Test (Dev)
            "zzfld00000t_cus",   # Screen Shot (QAS)
            "zzfld00000u_cus",   # System Test (QAS)
            "zzfld00004z",       # 1. Test Reference
            "zzfld00000v_cus",   # Regression Test (QAS)
            "zzfld00004y",       # 2. Test Reference
            "zzfld00000w_cus",   # UAT (QAS)
            "zzfld00004x",       # 3. Test Reference
            "zzfld00000x_cus",   # Test Script
            "zzfld00000y_cus",   # Others1
            "zzfld00000z_cus",   # Others2
            "zzfld000010_cus",   # Others3
            "zzfld000023_cus",   # Prod Confirm
        ]
        assert self._keys("Testing Requirements") == expected

    # ── Location (unchanged — guard against accidental edits) ────────────────
    def test_location_order(self):
        assert self._keys("Location") == ["zzfld000013_cus", "zzfld000028_cus"]

    # ── Approval (unchanged) ─────────────────────────────────────────────────
    def test_approval_order(self):
        assert self._keys("Approval") == ["it_lead_adtnl", "blead_adtnl"]

    # ── Parties Involved (unchanged) ─────────────────────────────────────────
    def test_parties_involved_order(self):
        assert self._keys("Parties Involved") == ["developer_adtnl", "implementer_adtnl"]
