import os
import sys
from types import SimpleNamespace
from unittest.mock import mock_open, patch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pytest
from langchain_core.messages import AIMessage, HumanMessage
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import SimpleSpanProcessor
from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter

from state.state import build_initial_state, empty_field


def _field(given=False, valid=None, value="", data=None, error=None):
    return {
        "given": given,
        "valid": valid,
        "value": value,
        "data": data,
        "error": error,
    }


class TestNodesHelpers:
    def test_load_sop_reads_file(self):
        from agents.nodes import _load_sop

        with patch("builtins.open", mock_open(read_data="SOP body")):
            assert _load_sop() == "SOP body"

    def test_load_sop_missing_file(self):
        from agents.nodes import _load_sop

        with patch("builtins.open", side_effect=FileNotFoundError):
            assert _load_sop() == "(SOP instructions not found)"

    def test_state_summary_lists_key_fields(self):
        from agents.nodes import _state_summary

        state = build_initial_state("Need CR")
        state["platform"] = _field(True, True, "HMD")
        state["target_system"] = _field(True, False, "BAD", error="not found")

        summary = _state_summary(state)
        assert "platform: given=True, valid=True, value='HMD'" in summary
        assert "target_system: given=True, valid=False, value='BAD', error='not found'" in summary


class TestNode1ExtractFieldValues:
    def test_preserves_existing_given_and_value_when_llm_omits_field(self):
        from agents.nodes import node_1_extract_field_values

        state = build_initial_state("Need CR for HMD")
        state["jira_id"] = _field(True, True, "PROJ-123")

        extracted = SimpleNamespace(
            reason_for_change=SimpleNamespace(given=True, value="Business reason"),
            description_of_change=SimpleNamespace(given=True, value="Technical change"),
            additional_information=SimpleNamespace(given=False, value=""),
            target_system=SimpleNamespace(given=True, value="EJ1 100"),
            platform=SimpleNamespace(given=True, value="HMD"),
            template_id=SimpleNamespace(given=False, value=""),
            cr_id=SimpleNamespace(given=False, value=""),
            jira_id=SimpleNamespace(given=False, value=""),
        )

        with patch("agents.nodes.nodes_intake.llm_fast_with_output") as mock_llm:
            mock_llm.return_value.invoke.return_value = extracted
            patch_result = node_1_extract_field_values(state)

        assert patch_result["platform"]["value"] == "HMD"
        assert patch_result["target_system"]["value"] == "EJ1 100"
        assert patch_result["jira_id"]["given"] is True
        assert patch_result["jira_id"]["value"] == "PROJ-123"


class TestNode3RequestInformation:
    def test_platform_target_pending_builds_clickable_options(self):
        from agents.nodes import node_3_request_information

        state = build_initial_state("Need CR")
        state["platform_tgt_pending"] = {
            "platform": "HMD",
            "original_target": "EJ1 100",
            "options": [{"target_system": "EJ1 200"}, {"target_system": "EJ1 300"}],
        }

        result = node_3_request_information(state)

        assert "Platform / Target System mismatch" in result["messages"][0].content
        assert result["exhausted_attempts"] == 0
        assert result["clickable_options"][0]["value"] == "Target system is EJ1 200"
        assert result["clickable_options"][-1]["value"] == "Target system is EJ1 300"

    def test_missing_platform_uses_platform_examples(self):
        from agents.nodes import node_3_request_information

        state = build_initial_state("Need CR")
        state["platform"] = empty_field()

        with patch("agents.nodes.nodes_intake.get_valid_field_values", return_value=["Atlas", "HMD"]), \
             patch("agents.nodes.nodes_intake.llm_fast_with_output") as mock_llm:
            mock_llm.return_value.invoke.return_value = SimpleNamespace(output_message="Please provide platform")
            result = node_3_request_information(state)

        assert "available platforms" in result["messages"][0].content
        assert result["clickable_options"][0] == {"label": "Atlas", "value": "Platform is Atlas"}

    def test_missing_target_uses_target_examples(self):
        from agents.nodes import node_3_request_information

        state = build_initial_state("Need CR")
        state["platform"] = _field(True, True, "HMD", data={"resolved_name": "HMD"})
        state["target_system"] = empty_field()

        with patch("agents.nodes.nodes_intake.get_valid_field_values", side_effect=[["EJ1 100 (5)", "EJ1 200 (4)"]]), \
             patch("agents.nodes.nodes_intake.llm_fast_with_output") as mock_llm:
            mock_llm.return_value.invoke.return_value = SimpleNamespace(output_message="Please provide target")
            result = node_3_request_information(state)

        assert "target systems" in result["messages"][0].content
        assert result["clickable_options"][0]["label"] == "EJ1 100"
        assert result["clickable_options"][0]["value"] == "Target system is EJ1 100"


class TestNodeOutputs:
    def test_node_8_present_draft_builds_summary_and_output(self):
        from agents.nodes import node_8_present_draft

        state = build_initial_state("draft")
        state["platform"] = _field(True, True, "HMD")
        state["target_system"] = _field(True, True, "EJ1 100")
        state["reason_for_change"] = _field(True, True, "Business reason")
        state["description_of_change"] = _field(True, True, "Technical description")
        state["additional_information"] = _field(True, True, "Extra context")
        state["template_id"] = _field(True, True, "65669")
        state["jira_id"] = _field(True, True, "PROJ-123")

        with patch("agents.nodes.nodes_review.llm_fast_with_output") as mock_llm:
            mock_llm.return_value.invoke.return_value = SimpleNamespace(output_message="Draft created. Please review it.")
            result = node_8_present_draft(state)

        content = result["messages"][0].content
        assert "created the CR draft" in content
        assert "Platform" in content
        assert "HMD" in content
        assert "Template 65669" in content
        assert result["draft_ui"]["output_text"] == content
        assert result["exhausted_attempts"] == 0
        assert "expandable_sections" not in result
        assert result["clickable_options"] == [
            {"label": "Submit CR draft to SolMan", "value": "approve"},
        ]

    def test_node_5_gather_metrics_counts_messages(self):
        from agents.nodes import node_5_gather_metrics

        state = build_initial_state("hello")
        state["messages"].append(AIMessage(content="response"))
        state["iteration"] = 3

        result = node_5_gather_metrics(state)
        assert result["metrics"] == {"X": 1, "Y": 1, "Z": 3}

    def test_node_5_gather_metrics_sets_session_metric_span_attributes(self):
        from agents.nodes import node_5_gather_metrics

        provider = TracerProvider()
        exporter = InMemorySpanExporter()
        provider.add_span_processor(SimpleSpanProcessor(exporter))
        tracer = provider.get_tracer(__name__)

        state = build_initial_state("hello")
        state["cycle_id_selection"] = "manual"
        state["cr_recommendation_source"] = "similar_crs"

        with tracer.start_as_current_span("node.node_5"):
            node_5_gather_metrics(state)

        finished_spans = exporter.get_finished_spans()
        assert len(finished_spans) == 1
        attrs = finished_spans[0].attributes
        assert attrs["app.task.cycle_id_selection"] == "manual"
        assert attrs["app.task.cr_recommendation_source"] == "similar_crs"
        assert attrs["app.task.end_without_draft"] == "true"

    @pytest.mark.parametrize(
        "submission_result, expected_status",
        [
            (None, "ended_without_submission"),
            ({"success": True, "cr_id": "50417365", "error": None}, "success"),
            ({"success": False, "cr_id": None, "error": "boom"}, "failed"),
        ],
    )
    def test_node_5_gather_metrics_sets_submission_status(self, submission_result, expected_status):
        from agents.nodes import node_5_gather_metrics

        provider = TracerProvider()
        exporter = InMemorySpanExporter()
        provider.add_span_processor(SimpleSpanProcessor(exporter))
        tracer = provider.get_tracer(__name__)

        state = build_initial_state("hello")
        state["submission_result"] = submission_result

        with tracer.start_as_current_span("node.node_5"):
            node_5_gather_metrics(state)

        finished_spans = exporter.get_finished_spans()
        assert finished_spans[0].attributes["app.task.status"] == expected_status

    def test_node_5_gather_metrics_extracts_pct_from_first_draft_accuracy_dict(self):
        from agents.nodes import node_5_gather_metrics

        provider = TracerProvider()
        exporter = InMemorySpanExporter()
        provider.add_span_processor(SimpleSpanProcessor(exporter))
        tracer = provider.get_tracer(__name__)

        state = build_initial_state("hello")
        state["first_draft_accuracy"] = {
            "total": 113,
            "unchanged": 103,
            "changed": 10,
            "changed_fields": ["zzfld000053"],
            "pct": 91.2,
        }

        with tracer.start_as_current_span("node.node_5"):
            node_5_gather_metrics(state)

        finished_spans = exporter.get_finished_spans()
        attrs = finished_spans[0].attributes
        assert "91.2" in attrs["app.task.first_draft_accuracy"]
        assert attrs["app.task.first_draft_accuracy_pct"] == 91.2

    def test_node_11_get_information_with_graph_results(self):
        from agents.nodes import node_11_get_information

        state = build_initial_state("What is the status?")
        state["messages"].append(AIMessage(content="draft"))

        llm_result = SimpleNamespace(cypher_query="MATCH (n) RETURN n LIMIT 1", output_text="Here is the answer")
        with patch("agents.nodes.nodes_review.llm_with_output") as mock_llm, \
             patch("agents.nodes.nodes_review.execute_cypher", return_value=[{"status": "Open"}]):
            mock_llm.return_value.invoke.return_value = llm_result
            result = node_11_get_information(state)

        content = result["messages"][0].content
        assert "Here is the answer" in content
        assert "knowledge graph" in content
        assert "Open" in content

    def test_node_11_get_information_without_query(self):
        from agents.nodes import node_11_get_information

        state = build_initial_state("Explain this CR")
        llm_result = SimpleNamespace(cypher_query="", output_text="No DB lookup needed")

        with patch("agents.nodes.nodes_review.llm_with_output") as mock_llm:
            mock_llm.return_value.invoke.return_value = llm_result
            result = node_11_get_information(state)

        assert result["messages"][0].content == "No DB lookup needed"

    def test_node_s_output_answer_resets_attempts(self):
        from agents.nodes import node_s_output_answer

        assert node_s_output_answer(build_initial_state("hello")) == {"exhausted_attempts": 0}

    def test_node_10c_handle_rejection_resets_attempts(self):
        from agents.nodes import node_10c_handle_rejection

        result = node_10c_handle_rejection(build_initial_state("reject"))
        assert "what you'd like to change" in result["messages"][0].content
        assert result["exhausted_attempts"] == 0

    def test_node_15_failed_permission_message(self):
        from agents.nodes import node_15_failed

        state = build_initial_state("submit")
        state["submission_result"] = {"error": "Requestor User ID ABC does not exist"}

        result = node_15_failed(state)
        assert "not configured as a valid requestor" in result["messages"][0].content

    def test_node_15_failed_generic_message(self):
        from agents.nodes import node_15_failed

        state = build_initial_state("submit")
        state["submission_result"] = {"error": "Timeout from SAP"}

        result = node_15_failed(state)
        content = result["messages"][0].content
        assert "Submission failed while creating the Change Request in Solution Manager." in content
        assert "**Root Cause:** Timeout from SAP" in content

    def test_node_15_failed_sap_error_shows_reason(self):
        from agents.nodes import node_15_failed

        state = build_initial_state("submit")
        state["submission_result"] = {
            "error": "Field XYZ is invalid",
            "is_sap_error": True,
        }

        result = node_15_failed(state)
        content = result["messages"][0].content
        assert "Submission failed while creating the Change Request in Solution Manager." in content
        assert "**Reason:** Field XYZ is invalid" in content
        assert "**Root Cause:**" not in content

    def test_node_15_failed_sap_error_with_transaction_id(self):
        from agents.nodes import node_15_failed

        state = build_initial_state("submit")
        state["submission_result"] = {
            "error": "Business validation failed",
            "is_sap_error": True,
            "sap_transaction_id": "TX12345",
        }

        result = node_15_failed(state)
        content = result["messages"][0].content
        assert "**Reason:** Business validation failed (Transaction ID: TX12345)" in content

    def test_node_16_success_merges_response_data(self):
        from agents.nodes import node_16_success

        state = build_initial_state("submit")
        state["cr_id"] = _field(True, True, "TEMP-1", data={"IvDetails": {"CycleId": "00001234", "Status": ""}})
        state["submission_result"] = {
            "cr_id": "50417365",
            "response_data": {
                "IvDetails": {"Status": "New", "TransactionNo": "50417365", "__metadata": {"x": 1}},
                "IvOther": {"Ignore": "nope"},
            },
        }

        result = node_16_success(state)

        assert "50417365" in result["messages"][0].content
        assert result["cr_id"]["value"] == "50417365"
        assert result["cr_id"]["data"]["IvDetails"]["CycleId"] == "00001234"
        assert result["cr_id"]["data"]["IvDetails"]["Status"] == "New"
        assert "__metadata" not in result["cr_id"]["data"]["IvDetails"]

    def test_node_12_submit_success_includes_accuracy_summary(self):
        from agents.nodes import node_12_submit

        state = build_initial_state("submit")
        state["cr_id"] = _field(True, True, "50417365", data={"IvDetails": {"Risk": "High"}})
        state["reason_for_change"] = _field(True, True, "Business reason")
        state["description_of_change"] = _field(True, True, "Technical description")
        state["additional_information"] = _field(True, True, "Extra info")
        state["first_draft_snapshot"] = {
            "risk_adtnl": "Low",
            "text.reason_for_change": "Business reason",
        }

        with patch("agents.nodes.nodes_review.execute_cypher", return_value=[{"props": {"risk_adtnl": "Low"}}]), \
             patch("agents.nodes.nodes_review.solman_write", return_value={"success": True, "cr_id": "50419999"}):
            cmd = node_12_submit(state)

        assert cmd.goto == "node_16"
        assert cmd.update["submission_result"]["cr_id"] == "50419999"
        assert cmd.update["first_draft_accuracy"]["total"] == 2
        assert cmd.update["first_draft_accuracy"]["changed"] == 1
        # node_12 no longer emits a user-facing message — success text is emitted by node_16
        assert "messages" not in cmd.update

    def test_node_12_submit_failure_routes_to_node_15(self):
        from agents.nodes import node_12_submit

        state = build_initial_state("submit")

        with patch("agents.nodes.nodes_review.solman_write", return_value={"success": False, "error": "SAP failure"}):
            cmd = node_12_submit(state)

        assert cmd.goto == "node_15"
        assert cmd.update["submission_result"]["error"] == "SAP failure"

    def test_node_13_apply_update_direct_zzfld_patch_and_fieldstate_sync(self):
        from agents import nodes

        state = build_initial_state("update")
        state["messages"].append(
            AIMessage(content='Parsed update intents: [{"field": "zzfld00000v_cus", "value": "1", "type": "zzfld_writable"}]')
        )
        state["cr_id"] = _field(True, True, "50417365", data={"IvValidation": {}})
        state["zzfld00000v_cus"] = _field(True, True, "0")

        result_patch = nodes.node_13_apply_update(state)

        group, api_field = nodes.ODATA_FIELD_MAP_REVERSE["zzfld00000v_cus"]
        assert result_patch["cr_id"]["data"][group][api_field] == "1"
        assert result_patch["zzfld00000v_cus"]["value"] == "1"
        assert result_patch["zzfld00000v_cus"]["valid"] is True
        # zzfld-only updates may include clarification in messages from node_10, but no new messages added by node_13
        # Messages present should be the ones from node_10, not additional success messages
        if "messages" in result_patch:
            # Any existing messages are from node_10 parsing, not new additions from node_13
            for msg in result_patch.get("messages", []):
                # Ensure no new success message is appended (messages should only contain what came from node_10)
                assert "successfully" not in msg.content.lower() or "Parsed update intents" in msg.content

    def test_node_13_apply_update_text_field_uses_llm_and_syncs_state(self):
        from agents.nodes import node_13_apply_update

        state = build_initial_state("update")
        state["messages"].append(
            AIMessage(content='Parsed update intents: [{"field": "description_of_change", "value": "Updated description", "type": "text"}]')
        )
        state["draft"] = "old draft"
        state["draft_ui"] = {"draft_html": "<p>old</p>"}
        state["description_of_change"] = _field(True, True, "old description")

        llm_result = SimpleNamespace(
            updated_draft="new draft",
            updated_draft_html="<p>new</p>",
            update_summary="description updated",
        )

        with patch("agents.nodes.nodes_review.llm_with_output") as mock_llm:
            mock_llm.return_value.invoke.return_value = llm_result
            result_patch = node_13_apply_update(state)

        assert result_patch["draft"] == "new draft"
        assert result_patch["draft_ui"]["draft_html"] == "<p>new</p>"
        assert result_patch["description_of_change"]["value"] == "Updated description"
        assert "description updated" in result_patch["messages"][0].content

    def test_node_10_locked_field_in_multi_update_proceeds_with_valid_fields(self):
        from agents.nodes import node_10_parse_update_intent

        state = build_initial_state("update reason and platform")
        state["messages"].append(
            HumanMessage(content="Set reason to 'Bug fix' and also change platform to HMD2")
        )

        update_result = SimpleNamespace(
            updates=[
                SimpleNamespace(field_name="reason_for_change", new_value="Bug fix", group_hint="", is_locked=False, field_type="text"),
                SimpleNamespace(field_name="platform", new_value="HMD2", group_hint="", is_locked=True, field_type="locked"),
            ]
        )

        with patch("agents.nodes.nodes_review.llm_with_output") as mock_llm:
            mock_llm.return_value.invoke.return_value = update_result
            cmd = node_10_parse_update_intent(state)

        # When there are mixed valid and locked fields, the valid one (reason_for_change)
        # is applied via node_13; the locked one (platform) is reported as an extra message.
        assert cmd.goto == "node_13"
        all_content = " ".join(m.content for m in cmd.update["messages"])
        # Should show messages about the fields (either locked or field updates)
        assert len(cmd.update["messages"]) > 0

    def test_node_10_all_locked_fields_routes_to_node_8(self):
        from agents.nodes import node_10_parse_update_intent

        state = build_initial_state("update platform and template")
        state["messages"].append(
            HumanMessage(content="Change platform to HMD2 and template to 99999")
        )

        update_result = SimpleNamespace(
            updates=[
                SimpleNamespace(field_name="platform", new_value="HMD2", group_hint="", is_locked=True, field_type="locked"),
                SimpleNamespace(field_name="template_id", new_value="99999", group_hint="", is_locked=True, field_type="locked"),
            ]
        )

        with patch("agents.nodes.nodes_review.llm_with_output") as mock_llm:
            mock_llm.return_value.invoke.return_value = update_result
            cmd = node_10_parse_update_intent(state)

        # When ALL fields are locked, nothing can be applied, so re-prompt user
        assert cmd.goto == "node_8"
        all_content = " ".join(m.content for m in cmd.update["messages"])
        # Should show that these fields are locked
        assert "locked" in all_content.lower()

    def test_node_13_invalid_boolean_in_multi_update_applies_valid_fields(self):
        from agents import nodes

        # zzfld00000v_cus → boolean (BOOL_FIELDS), "NOT_A_BOOL" is invalid
        # zzfld00000x_cus → ("IvTestReq", "TestScript"), plain text, accepts any value
        import json as _json
        payload = _json.dumps([
            {"field": "zzfld00000v_cus", "value": "NOT_A_BOOL", "type": "zzfld_writable"},
            {"field": "zzfld00000x_cus", "value": "TS-12345", "type": "zzfld_writable"},
        ])

        state = build_initial_state("update")
        state["messages"].append(
            AIMessage(content=f"Parsed update intents: {payload}")
        )
        state["cr_id"] = _field(True, True, "50417365", data={"IvTestReq": {}})

        result = nodes.node_13_apply_update(state)

        # When there are messages, check for error (invalid boolean field)
        if "messages" in result:
            error_msgs = [m.content for m in result["messages"] if "❌" in m.content]
            assert len(error_msgs) == 1
            assert "NOT_A_BOOL" in error_msgs[0]
            assert "boolean" in error_msgs[0]
            # Note: zzfld-only updates don't generate success messages separately

        # Valid field is patched in cr_id.data
        _group, _api_field = nodes.ODATA_FIELD_MAP_REVERSE["zzfld00000x_cus"]
        assert result["cr_id"]["data"][_group][_api_field] == "TS-12345"

        # Invalid field is NOT patched
        _bool_group, _bool_api_field = nodes.ODATA_FIELD_MAP_REVERSE["zzfld00000v_cus"]
        assert result["cr_id"]["data"].get(_bool_group, {}).get(_bool_api_field) is None

    def test_node_13_all_invalid_boolean_returns_only_errors(self):
        from agents import nodes

        import json as _json
        payload = _json.dumps([
            {"field": "zzfld00000v_cus", "value": "BANANA", "type": "zzfld_writable"},
            {"field": "zzfld00000w_cus", "value": "ORANGE", "type": "zzfld_writable"},
        ])

        state = build_initial_state("update")
        state["messages"].append(
            AIMessage(content=f"Parsed update intents: {payload}")
        )
        state["cr_id"] = _field(True, True, "50417365", data={"IvTestReq": {}})

        result = nodes.node_13_apply_update(state)

        # Two error messages, no success
        error_msgs = [m.content for m in result["messages"] if "❌" in m.content]
        assert len(error_msgs) == 2
        success_msgs = [m.content for m in result["messages"] if "✅" in m.content]
        assert len(success_msgs) == 0

    def test_node_13_maps_approval_and_transaction_labels_to_payload_codes(self):
        from agents import nodes

        import json as _json
        payload = _json.dumps([
            {"field": "aprv_proc_adtnl", "value": "J&J Approval", "type": "zzfld_writable"},
            {"field": "transaction_type_scope", "value": "JnJ-Urgent Change", "type": "zzfld_writable"},
        ])

        state = build_initial_state("update")
        state["messages"].append(AIMessage(content=f"Parsed update intents: {payload}"))
        state["cr_id"] = _field(
            True,
            True,
            "50417365",
            data={
                "IvDetails": {"StandardChange": "", "OperateChange": "", "AprvProc": ""},
                "IvContext": {"CycleType": "Continual Cycle"},
                "IvScope": {},
            },
        )

        result = nodes.node_13_apply_update(state)

        assert result["cr_id"]["data"]["IvDetails"]["AprvProc"] == "ZMCR0001"
        assert result["cr_id"]["data"]["IvScope"]["TransactionType"] == "YMHF"
        assert result["aprv_proc"]["value"] == "J&J Approval"
        assert result["transaction_type"]["value"] == "JnJ-Urgent Change"

    def test_node_13_rejects_invalid_dropdown_values_with_allowed_values(self):
        from agents import nodes

        import json as _json
        payload = _json.dumps([
            {"field": "aprv_proc_adtnl", "value": "Bad Approval", "type": "zzfld_writable"},
            {"field": "transaction_type_scope", "value": "Bad Transaction", "type": "zzfld_writable"},
        ])

        state = build_initial_state("update")
        state["messages"].append(AIMessage(content=f"Parsed update intents: {payload}"))
        state["cr_id"] = _field(
            True,
            True,
            "50417365",
            data={
                "IvDetails": {"StandardChange": "", "OperateChange": "", "AprvProc": ""},
                "IvContext": {"CycleType": "Continual Cycle"},
                "IvScope": {},
            },
        )

        result = nodes.node_13_apply_update(state)

        error_msgs = [m.content for m in result["messages"] if "❌" in m.content]
        assert len(error_msgs) == 2
        assert "Allowed values" in error_msgs[0]
        assert "Allowed values" in error_msgs[1]

    def test_node_17_present_top_5_formats_clickable_options(self):
        from agents.nodes import node_17_present_top_5

        state = build_initial_state("recommend")
        state["baseline_crs"]["cr_1"] = {
            "object_id": "50410001",
            "title": "Cycle A",
            "description": "First recommendation",
            "ranking_score": 0.934,
            "platform_match": True,
            "target_system_match": False,
        }
        state["baseline_crs"]["cr_2"] = {
            "object_id": "50410002",
            "title": "Cycle B",
            "description": "Second recommendation",
            "ranking_score": 0.812,
            "platform_match": False,
            "target_system_match": True,
        }

        llm_result = SimpleNamespace(output_text="Pick one of these CRs.", recommendations_html="<div>recs</div>")
        with patch("agents.nodes.nodes_outcome.llm_fast_with_output") as mock_llm:
            mock_llm.return_value.invoke.return_value = llm_result
            result = node_17_present_top_5(state)

        expected_output_text = (
            "Here are the top matching Change Requests:\n\n"
            "You can choose from the options below or type a CR ID directly.\n"
            "1. Object ID: 50410001 | Change Cycle: Cycle A | Description: First recommendation | Similarity score: 0.934 [Platform match]\n"
            "2. Object ID: 50410002 | Change Cycle: Cycle B | Description: Second recommendation | Similarity score: 0.812 [Target match]"
        )
        assert result["messages"][0].content == expected_output_text
        assert result["draft_ui"]["recommendations_html"] == "<div>recs</div>"
        assert len(result["clickable_options"]) == 2
        assert result["clickable_options"][0]["value"] == "50410001"
        assert "Platform match" in result["clickable_options"][0]["label"]
        assert result["exhausted_attempts"] == 0

    def test_node_19_no_recommendations_mentions_reviewed_count(self):
        from agents.nodes import node_19_no_recommendations

        state = build_initial_state("recommend")
        state["baseline_crs"]["mentioned_object_ids"] = ["1", "2", "3"]

        result = node_19_no_recommendations(state)
        assert "reviewed 3 Change Requests" in result["messages"][0].content

    def test_node_20_cycle_id_check_skips_when_already_confirmed(self):
        from agents.nodes import node_20_cycle_id_check

        state = build_initial_state("cycle")
        state["cycle_confirmed"] = True

        assert node_20_cycle_id_check(state) == {"cycle_id_pending": None}

    def test_node_20_cycle_id_check_builds_options_when_mismatch(self):
        from agents.nodes import node_20_cycle_id_check, cond_edge_20

        state = build_initial_state("cycle")
        state["cr_id"] = _field(True, True, "50417365")
        state["target_system"] = _field(True, True, "EJ1 100")

        with patch(
            "agents.nodes.nodes_outcome.execute_cypher",
            side_effect=[
                [{"cycle_id": "00001234", "cycle": "Current Cycle", "landscape": "QA"}],
                [
                    {"cycle_id": "00009999", "cnt": 7, "cycle": "Better Cycle", "landscape": "PRD"},
                    {"cycle_id": "00008888", "cnt": 3, "cycle": "Other Cycle", "landscape": "DEV"},
                ],
            ],
        ):
            result = node_20_cycle_id_check(state)

        content = result["messages"][0].content
        assert "Cycle ID Confirmation" in content
        assert "EJ1 100" in content
        assert "9999" in content
        assert result["cycle_id_pending"]["draft_cycle_id"] == "00001234"
        assert len(result["clickable_options"]) == 3
        assert result["clickable_options"][-1]["value"] == "yes"
        route_state = dict(state)
        route_state["cycle_id_pending"] = result["cycle_id_pending"]
        assert cond_edge_20(route_state) == "node_20b"

    def test_cond_edge_20_skips_to_node_8_without_pending_cycle(self):
        from agents.nodes import cond_edge_20

        assert cond_edge_20(build_initial_state("cycle")) == "node_8"

    def test_cond_edge_20_routes_to_node_8_when_cycle_autofill_present(self):
        from agents.nodes import cond_edge_20

        state = build_initial_state("cycle")
        state["cycle_change_autofilled"] = True
        assert cond_edge_20(state) == "node_8"

    def test_node_20b_cycle_id_hitl_max_attempts_keeps_current_cycle(self):
        from agents.nodes import node_20b_cycle_id_hitl

        state = build_initial_state("cycle")
        state["cycle_hitl_attempts"] = 3

        cmd = node_20b_cycle_id_hitl(state)
        assert cmd.goto == "node_8"
        assert cmd.update["cycle_confirmed"] is True
        assert cmd.update["cycle_id_pending"] is None
        assert "trouble with the cycle selection" in cmd.update["messages"][0].content

    def test_node_20b_cycle_id_hitl_selects_option_number_and_routes_to_node_6(self):
        from agents.nodes import node_20b_cycle_id_hitl

        state = build_initial_state("cycle")
        state["messages"].append(AIMessage(content="Cycle ID Confirmation"))
        state["cr_id"] = _field(
            True,
            True,
            "50417365",
            data={"IvDetails": {"CycleId": "00001234", "Landscape": "QA", "Risk": "Low"}},
        )
        state["cycle_id_pending"] = {
            "draft_cycle_id": "00001234",
            "options": [
                {"cycle_id": "000656594", "cnt": 7, "landscape": "PRD"},
                {"cycle_id": "00008888", "cnt": 3, "landscape": "DEV"},
            ],
        }

        with patch("agents.nodes.nodes_outcome.interrupt", return_value="1"), \
             patch("agents.nodes.nodes_outcome.execute_cypher", return_value=[{"object_id": "50419999"}]), \
             patch("agents.nodes.nodes_outcome.get_template", return_value={"IvDetails": {"CycleType": "Continual Cycle", "Branch": "BR-1"}}), \
            patch("agents.nodes.nodes_outcome.get_transaction_type_for_cycle", return_value="JnJ-Urgent Change"):
            cmd = node_20b_cycle_id_hitl(state)

        assert cmd.goto == "node_6"
        assert cmd.update["cycle_confirmed"] is True
        assert cmd.update["cycle_id_pending"] is None
        assert cmd.update["cycle_hitl_attempts"] == 0
        iv_details = cmd.update["cr_id"]["data"]["IvDetails"]
        assert iv_details["CycleId"] == "0000656594"  # normalised: lstrip("0").zfill(10)
        assert iv_details["Landscape"] == "PRD"
        assert iv_details["Risk"] == "Low"

    def test_node_20b_cycle_id_hitl_autofills_change_type_fields_when_cycle_mapping_exists(self):
        from agents.nodes import node_20b_cycle_id_hitl

        state = build_initial_state("cycle")
        state["messages"].append(AIMessage(content="Cycle ID Confirmation"))
        state["cr_id"] = _field(
            True,
            True,
            "50417365",
            data={
                "IvDetails": {"CycleId": "00001234", "Landscape": "QA", "Risk": "Low", "StandardChange": "", "OperateChange": ""},
                "IvContext": {"CycleType": "Continual Cycle"},
                "IvScope": {},
            },
        )
        state["cycle_id_pending"] = {
            "draft_cycle_id": "00001234",
            "options": [{"cycle_id": "000656594", "cnt": 7, "landscape": "PRD"}],
        }

        with patch("agents.nodes.nodes_outcome.interrupt", return_value="656594"), \
             patch("agents.nodes.nodes_outcome.execute_cypher", return_value=[{"object_id": "50419999"}]), \
             patch("agents.nodes.nodes_outcome.get_template", return_value={"IvDetails": {"CycleType": "Continual Cycle", "Branch": "BR-1"}}), \
            patch("agents.nodes.nodes_outcome.get_transaction_type_for_cycle", return_value="JnJ-Urgent Change"):
            cmd = node_20b_cycle_id_hitl(state)

        assert cmd.goto == "node_6"
        assert cmd.update["cycle_change_autofilled"] is True
        assert cmd.update["aprv_proc"]["value"] == "J&J Approval"
        assert cmd.update["transaction_type"]["value"] == "JnJ-Urgent Change"
        iv_details = cmd.update["cr_id"]["data"]["IvDetails"]
        iv_context = cmd.update["cr_id"]["data"]["IvContext"]
        iv_scope = cmd.update["cr_id"]["data"]["IvScope"]
        assert iv_details["StandardChange"] == ""
        assert iv_details["OperateChange"] == ""
        assert iv_details["AprvProc"] == "ZMCR0001"
        assert iv_context["CycleType"] == "Continual Cycle"
        assert iv_scope["TransactionType"] == "YMHF"

    def test_node_20b_cycle_id_hitl_yes_keeps_cycle(self):
        from agents.nodes import node_20b_cycle_id_hitl

        state = build_initial_state("cycle")
        state["cycle_id_pending"] = {
            "draft_cycle_id": "00001234",
            "options": [{"cycle_id": "00009999", "cnt": 7, "landscape": "PRD"}],
        }

        with patch("agents.nodes.nodes_outcome.interrupt", return_value="yes"):
            cmd = node_20b_cycle_id_hitl(state)

        assert cmd.goto == "node_8"
        assert cmd.update["cycle_confirmed"] is True
        assert cmd.update["cycle_id_pending"] is None

    def test_node_20b_cycle_id_hitl_irrelevant_input_reprompts(self):
        from agents.nodes import node_20b_cycle_id_hitl

        state = build_initial_state("cycle")
        state["cycle_hitl_attempts"] = 1
        state["cycle_id_pending"] = {
            "draft_cycle_id": "00001234",
            "options": [{"cycle_id": "00009999", "cnt": 7, "landscape": "PRD"}],
        }

        with patch("agents.nodes.nodes_outcome.interrupt", return_value="tell me about scoring"):
            cmd = node_20b_cycle_id_hitl(state)

        assert cmd.goto == "node_20b"
        assert cmd.update["cycle_hitl_attempts"] == 2
        assert "not related to the cycle selection" in cmd.update["messages"][1].content


