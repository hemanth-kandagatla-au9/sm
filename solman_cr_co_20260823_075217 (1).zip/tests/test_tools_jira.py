"""
tests/test_tools_jira.py

Unit tests for tools/get_jira_data — HTTP requests mocked.

Covers:
  - Successful response: all fields parsed correctly
  - HTTP error (4xx/5xx) returns error dict
  - Empty EvResponse falls back to EvDescription
  - Invalid EvResponse JSON falls back to EvDescription
  - All retry sleeps suppressed
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import json
from unittest.mock import patch, MagicMock
import pytest


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────
def _mock_http_response(status_code=200, json_data=None, raise_exc=None) -> MagicMock:
    mock_resp = MagicMock()
    mock_resp.status_code = status_code
    if raise_exc:
        mock_resp.raise_for_status.side_effect = raise_exc
    else:
        mock_resp.raise_for_status.return_value = None
    mock_resp.json.return_value = json_data or {}
    return mock_resp


def _jira_payload(
    summary: str = "Fix auth issue",
    description: str = "Add missing auth object to GFS role",
    due_date: str = "2026-01-15",
    regression_id: str = "RT-001",
    uat_id: str = "UAT-002",
    status: str = "In Progress",
) -> dict:
    """Build a realistic JIRA OData payload."""
    fields = {
        "summary": summary,
        "description": description,
        "duedate": due_date,
        "customfield_10104": regression_id,
        "customfield_10105": uat_id,
    }
    return {
        "d": {
            "EvDescription": summary,
            "EvResponse": json.dumps({"fields": fields}),
            "EvStatus": status,
        }
    }


def _run_jira(jira_id: str, json_data: dict, raise_for_status=None) -> dict:
    """Helper: run get_jira_data with requests.get mocked."""
    from tools.tools import get_jira_data

    mock_resp = _mock_http_response(json_data=json_data, raise_exc=raise_for_status)
    with patch("tools.tools.requests.get", return_value=mock_resp), \
         patch("tools.tools.time.sleep"):  # suppress retry delays
        return get_jira_data(jira_id)


# ─────────────────────────────────────────────────────────────────────────────
# Successful parsing
# ─────────────────────────────────────────────────────────────────────────────
class TestGetJiraDataSuccess:

    def test_summary_returned(self):
        result = _run_jira("PROJ-123", _jira_payload(summary="Fix auth issue"))
        assert result["summary"] == "Fix auth issue"

    def test_description_returned(self):
        result = _run_jira("PROJ-123", _jira_payload(description="Add auth object to GFS"))
        assert result["description"] == "Add auth object to GFS"

    def test_status_returned(self):
        result = _run_jira("PROJ-123", _jira_payload(status="Done"))
        assert result["status"] == "Done"

    def test_due_date_returned(self):
        result = _run_jira("PROJ-123", _jira_payload(due_date="2026-03-01"))
        assert result["due_date"] == "2026-03-01"

    def test_regression_test_id_returned(self):
        result = _run_jira("PROJ-123", _jira_payload(regression_id="RT-999"))
        assert result["regression_test_id"] == "RT-999"

    def test_uat_test_id_returned(self):
        result = _run_jira("PROJ-123", _jira_payload(uat_id="UAT-888"))
        assert result["uat_test_id"] == "UAT-888"

    def test_jira_id_echoed_back(self):
        result = _run_jira("PROJ-456", _jira_payload())
        assert result["jira_id"] == "PROJ-456"

    def test_raw_fields_present(self):
        result = _run_jira("PROJ-123", _jira_payload())
        assert isinstance(result.get("raw"), dict)

    def test_no_error_key_on_success(self):
        result = _run_jira("PROJ-123", _jira_payload())
        assert "error" not in result


# ─────────────────────────────────────────────────────────────────────────────
# Error / fallback paths
# ─────────────────────────────────────────────────────────────────────────────
class TestGetJiraDataErrors:

    def test_http_error_returns_error_dict(self):
        import requests as req_module
        result = _run_jira(
            "PROJ-999",
            {},
            raise_for_status=req_module.exceptions.HTTPError("404 Not Found"),
        )
        assert "error" in result
        assert result["jira_id"] == "PROJ-999"

    def test_connection_error_returns_error_dict(self):
        from tools.tools import get_jira_data
        with patch("tools.tools.requests.get", side_effect=ConnectionError("refused")), \
             patch("tools.tools.time.sleep"):
            result = get_jira_data("PROJ-123")
        assert "error" in result

    def test_invalid_ev_response_json_falls_back_to_ev_description(self):
        """Unparseable EvResponse — should use EvDescription as summary."""
        payload = {
            "d": {
                "EvDescription": "Fallback title from EvDescription",
                "EvResponse": "{{not valid json",
                "EvStatus": "Open",
            }
        }
        result = _run_jira("PROJ-789", payload)
        assert result.get("summary") == "Fallback title from EvDescription"

    def test_missing_ev_response_key_uses_ev_description(self):
        payload = {"d": {"EvDescription": "No EvResponse here", "EvStatus": "Open"}}
        result = _run_jira("PROJ-321", payload)
        # summary should come from EvDescription
        assert "No EvResponse here" in result.get("summary", "") or "error" in result

    def test_empty_jira_id_stripped(self):
        """Whitespace around jira_id is stripped."""
        from tools.tools import get_jira_data

        mock_resp = _mock_http_response(json_data=_jira_payload())
        with patch("tools.tools.requests.get", return_value=mock_resp), \
             patch("tools.tools.time.sleep"):
            result = get_jira_data("  PROJ-100  ")
        assert result.get("jira_id") == "PROJ-100"


# ─────────────────────────────────────────────────────────────────────────────
# Retry behaviour
# ─────────────────────────────────────────────────────────────────────────────
class TestGetJiraDataRetry:

    def test_empty_summary_triggers_retry_then_succeeds(self):
        """First call returns empty EvResponse; second returns valid payload."""
        from tools.tools import get_jira_data

        empty_payload = {"d": {"EvDescription": "", "EvResponse": "", "EvStatus": ""}}
        full_payload = _jira_payload(summary="Retry success")

        mock_empty = _mock_http_response(json_data=empty_payload)
        mock_full = _mock_http_response(json_data=full_payload)

        with patch("tools.tools.requests.get", side_effect=[mock_empty, mock_full]), \
             patch("tools.tools.time.sleep"):
            result = get_jira_data("PROJ-RETRY")

        assert result.get("summary") == "Retry success"

    def test_all_retries_empty_returns_error_or_empty(self):
        """All retry attempts return empty — should return empty/error gracefully."""
        from tools.tools import get_jira_data

        empty_payload = {"d": {"EvDescription": "", "EvResponse": "", "EvStatus": ""}}
        mock_empty = _mock_http_response(json_data=empty_payload)

        with patch("tools.tools.requests.get", return_value=mock_empty), \
             patch("tools.tools.time.sleep"):
            result = get_jira_data("PROJ-EMPTY")

        # Either an error key OR empty summary — must not raise an exception
        assert "error" in result or result.get("summary", "") == ""
