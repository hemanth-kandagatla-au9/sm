import os
import sys
import types

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pytest

from config import ssm_bootstrap


class FakeClientError(Exception):
    def __init__(self, response):
        super().__init__(response)
        self.response = response


class FakeSSMClient:
    def __init__(self, responses=None, error=None):
        self.responses = responses or {}
        self.error = error
        self.calls = []

    def get_parameters(self, Names, WithDecryption):
        self.calls.append((list(Names), WithDecryption))
        if self.error is not None:
            raise self.error
        parameters = []
        invalid = []
        for name in Names:
            if name in self.responses:
                parameters.append({"Name": name, "Value": self.responses[name]})
            else:
                invalid.append(name)
        return {"Parameters": parameters, "InvalidParameters": invalid}


def _install_fake_aws(monkeypatch, client):
    boto3_mod = types.ModuleType("boto3")
    boto3_mod.client = lambda service_name, region_name=None: client
    botocore_mod = types.ModuleType("botocore")
    exceptions_mod = types.ModuleType("botocore.exceptions")
    exceptions_mod.ClientError = FakeClientError
    botocore_mod.exceptions = exceptions_mod
    monkeypatch.setitem(sys.modules, "boto3", boto3_mod)
    monkeypatch.setitem(sys.modules, "botocore", botocore_mod)
    monkeypatch.setitem(sys.modules, "botocore.exceptions", exceptions_mod)


class TestSSMHelpers:
    @pytest.mark.parametrize(
        "value,expected",
        [
            ("/prod/param", True),
            ("arn:aws:ssm:us-east-1:123456789012:parameter/foo", True),
            ("JJYY-parameter-name", True),
            ("plain-text", False),
            ("", False),
        ],
    )
    def test_looks_like_ssm_parameter_name(self, value, expected):
        assert ssm_bootstrap._looks_like_ssm_parameter_name(value) is expected

    def test_mask_hides_secret_values(self):
        assert ssm_bootstrap._mask("AZURE_OPENAI_API_KEY", "secret") == "***"
        assert ssm_bootstrap._mask("NEO4J_URI", "bolt://example") == "bolt://example"

    def test_is_enabled(self, monkeypatch):
        monkeypatch.setenv("RESOLVE_SSM_PARAMS", "true")
        assert ssm_bootstrap.is_enabled() is True
        monkeypatch.setenv("RESOLVE_SSM_PARAMS", "false")
        assert ssm_bootstrap.is_enabled() is False


class TestResolveSSMParameters:
    def test_noop_when_disabled(self, monkeypatch):
        monkeypatch.delenv("RESOLVE_SSM_PARAMS", raising=False)
        monkeypatch.setenv("AZURE_OPENAI_API_KEY", "/prod/chat/key")

        ssm_bootstrap.resolve_ssm_parameters()

        assert os.environ["AZURE_OPENAI_API_KEY"] == "/prod/chat/key"

    def test_noop_when_enabled_but_no_managed_vars_match(self, monkeypatch):
        monkeypatch.setenv("RESOLVE_SSM_PARAMS", "true")
        monkeypatch.setenv("NEO4J_URI", "bolt://localhost:7687")

        ssm_bootstrap.resolve_ssm_parameters()

    def test_resolves_managed_env_vars(self, monkeypatch):
        monkeypatch.setenv("RESOLVE_SSM_PARAMS", "true")
        monkeypatch.setenv("AWS_REGION", "us-west-2")

        responses = {}
        for var in ssm_bootstrap._SSM_MANAGED_VARS:
            ssm_name = f"/params/{var.lower()}"
            monkeypatch.setenv(var, ssm_name)
            responses[ssm_name] = f"value-for-{var.lower()}"

        client = FakeSSMClient(responses=responses)
        _install_fake_aws(monkeypatch, client)

        ssm_bootstrap.resolve_ssm_parameters()

        assert os.environ["AZURE_OPENAI_API_KEY"] == "value-for-azure_openai_api_key"
        assert os.environ["NEO4J_PASSWORD"] == "value-for-neo4j_password"
        assert os.environ["SOLMAN_READ_USERNAME"] == "value-for-solman_read_username"
        assert client.calls and client.calls[0][1] is True

    def test_access_denied_raises_runtime_error(self, monkeypatch):
        monkeypatch.setenv("RESOLVE_SSM_PARAMS", "true")
        monkeypatch.setenv("AZURE_OPENAI_API_KEY", "/params/chat-key")
        client = FakeSSMClient(
            error=FakeClientError({"Error": {"Code": "AccessDeniedException", "Message": "denied"}})
        )
        _install_fake_aws(monkeypatch, client)

        with pytest.raises(RuntimeError, match="PERMISSION DENIED"):
            ssm_bootstrap.resolve_ssm_parameters()