import os
import sys
from types import SimpleNamespace

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pytest
from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import SimpleSpanProcessor
from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter

from observability import token_tracking as tt


@pytest.fixture
def span_exporter():
    """
    Build an isolated TracerProvider + InMemorySpanExporter for this test only.
    """
    provider = TracerProvider()
    exporter = InMemorySpanExporter()
    provider.add_span_processor(SimpleSpanProcessor(exporter))
    yield provider, exporter


@pytest.fixture(autouse=True)
def reset_accumulator():
    tt.reset_token_accumulator()
    yield
    tt.reset_token_accumulator()


def _make_llm_result(input_tokens, output_tokens, model="gpt-4o"):
    message = SimpleNamespace(
        usage_metadata={"input_tokens": input_tokens, "output_tokens": output_tokens},
        response_metadata={"model_name": model},
    )
    generation = SimpleNamespace(message=message)
    return SimpleNamespace(generations=[[generation]], llm_output={"model_name": model})


class TestAccumulator:
    def test_reset_starts_at_zero(self):
        tt.reset_token_accumulator()
        totals = tt.get_token_accumulator()
        assert totals == {
            "input_tokens": 0, "output_tokens": 0, "total_tokens": 0,
            "cost_usd": 0.0, "call_count": 0,
        }

    def test_add_to_accumulator_increments_totals(self):
        tt.reset_token_accumulator()
        tt._add_to_accumulator(10, 20, 0.5)
        tt._add_to_accumulator(5, 5, 0.1)

        totals = tt.get_token_accumulator()
        assert totals["input_tokens"] == 15
        assert totals["output_tokens"] == 25
        assert totals["total_tokens"] == 40
        assert totals["call_count"] == 2
        assert totals["cost_usd"] == pytest.approx(0.6)


class TestExtractUsage:
    def test_extracts_from_usage_metadata(self):
        response = _make_llm_result(100, 50)
        input_tokens, output_tokens, model = tt._extract_usage(response)
        assert (input_tokens, output_tokens, model) == (100, 50, "gpt-4o")

    def test_fallback_to_token_usage_dict(self):
        response = SimpleNamespace(
            generations=[],
            llm_output={"model_name": "gpt-4o-mini", "token_usage": {"prompt_tokens": 30, "completion_tokens": 15}},
        )
        input_tokens, output_tokens, model = tt._extract_usage(response)
        assert (input_tokens, output_tokens, model) == (30, 15, "gpt-4o-mini")


class TestTokenCostCallbackHandler:
    def test_on_llm_end_writes_span_attributes(self, span_exporter):
        provider, exporter = span_exporter
        tracer = provider.get_tracer(__name__)
        handler = tt.TokenCostCallbackHandler()
        response = _make_llm_result(100, 50, model="gpt-4o")

        with tracer.start_as_current_span("node.test"):
            handler.on_llm_end(response)

        finished_spans = exporter.get_finished_spans()
        assert len(finished_spans) == 1
        recorded = finished_spans[0]

        assert recorded.attributes["gen_ai.usage.input_tokens"] == 100
        assert recorded.attributes["gen_ai.usage.output_tokens"] == 50
        assert "gen_ai.usage.total_tokens" not in recorded.attributes
        assert recorded.attributes["gen_ai.usage.cost_usd"] > 0

    def test_on_llm_end_updates_accumulator(self, span_exporter):
        provider, _exporter = span_exporter
        tracer = provider.get_tracer(__name__)
        handler = tt.TokenCostCallbackHandler()
        response = _make_llm_result(10, 20, model="gpt-4o")

        with tracer.start_as_current_span("node.test"):
            handler.on_llm_end(response)

        totals = tt.get_token_accumulator()
        assert totals["input_tokens"] == 10
        assert totals["output_tokens"] == 20
        assert totals["call_count"] == 1
        assert totals["cost_usd"] > 0

    def test_on_llm_end_no_usage_is_noop(self, span_exporter):
        provider, _exporter = span_exporter
        tracer = provider.get_tracer(__name__)
        handler = tt.TokenCostCallbackHandler()
        response = SimpleNamespace(generations=[], llm_output={})

        with tracer.start_as_current_span("node.test"):
            handler.on_llm_end(response)

        totals = tt.get_token_accumulator()
        assert totals["call_count"] == 0

    def test_on_llm_end_never_raises_on_bad_response(self, span_exporter):
        handler = tt.TokenCostCallbackHandler()
        # Missing generations/llm_output entirely — must not raise.
        handler.on_llm_end(object())

    def test_on_llm_error_logs_and_does_not_raise(self):
        handler = tt.TokenCostCallbackHandler()
        handler.on_llm_error(RuntimeError("boom"))
