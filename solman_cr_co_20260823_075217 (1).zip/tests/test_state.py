"""
tests/test_state.py
Unit tests for state/state.py — build_initial_state and helper factories.
No external calls involved — zero mocking needed.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pytest
from state.state import (
    build_initial_state,
    empty_field,
    empty_ui,
    empty_metrics,
    empty_baselines,
)


# ─────────────────────────────────────────────────────────────────────────────
# empty_field
# ─────────────────────────────────────────────────────────────────────────────
class TestEmptyField:
    def test_has_required_keys(self):
        f = empty_field()
        assert set(f.keys()) == {"given", "valid", "value", "data", "error"}

    def test_defaults(self):
        f = empty_field()
        assert f["given"] is False
        assert f["valid"] is None
        assert f["value"] == ""
        assert f["data"] is None
        assert f["error"] is None


# ─────────────────────────────────────────────────────────────────────────────
# empty_ui
# ─────────────────────────────────────────────────────────────────────────────
class TestEmptyUi:
    def test_has_required_keys(self):
        ui = empty_ui()
        assert set(ui.keys()) == {"draft_html", "recommendations_html", "output_text"}

    def test_all_none(self):
        ui = empty_ui()
        assert all(v is None for v in ui.values())


# ─────────────────────────────────────────────────────────────────────────────
# empty_baselines
# ─────────────────────────────────────────────────────────────────────────────
class TestEmptyBaselines:
    def test_has_five_cr_slots(self):
        b = empty_baselines()
        for slot in ["cr_1", "cr_2", "cr_3", "cr_4", "cr_5"]:
            assert slot in b
            assert b[slot] is None

    def test_mentioned_object_ids_is_empty_list(self):
        b = empty_baselines()
        assert b["mentioned_object_ids"] == []

    def test_query_embedding_is_empty_string(self):
        b = empty_baselines()
        assert b["query_embedding"] == ""


# ─────────────────────────────────────────────────────────────────────────────
# build_initial_state
# ─────────────────────────────────────────────────────────────────────────────
class TestBuildInitialState:
    def setup_method(self):
        self.state = build_initial_state("Hello, I need a CR")

    def test_messages_contains_human_message(self):
        from langchain_core.messages import HumanMessage
        assert len(self.state["messages"]) == 1
        assert isinstance(self.state["messages"][0], HumanMessage)
        assert self.state["messages"][0].content == "Hello, I need a CR"

    def test_scope_flags_default(self):
        assert self.state["scope_confirmed"] is False
        assert self.state["scope_out_count"] == 0
        assert self.state["end_session"] is False

    def test_iteration_zero(self):
        assert self.state["iteration"] == 0
        assert self.state["exhausted_attempts"] == 0

    def test_draft_none(self):
        assert self.state["draft"] is None

    def test_all_cr_fields_empty(self):
        for field in [
            "reason_for_change", "description_of_change", "additional_information",
            "target_system", "platform", "template_id", "cr_id", "jira_id",
        ]:
            fs = self.state[field]
            assert fs["given"] is False, f"{field}.given should be False"
            assert fs["value"] == "", f"{field}.value should be empty string"

    def test_cycle_flags_default(self):
        assert self.state["cycle_id_pending"] is None
        assert self.state["cycle_confirmed"] is False

    def test_platform_tgt_flags_default(self):
        assert self.state["platform_tgt_pending"] is None
        assert self.state["platform_tgt_overridden"] is False

    def test_submission_result_none(self):
        assert self.state["submission_result"] is None

    def test_first_draft_fields_none(self):
        assert self.state["first_draft_snapshot"] is None
        assert self.state["first_draft_accuracy"] is None

    def test_jira_derived_fields_empty(self):
        for field in ["planned_impl_dt_adtnl", "zzfld00000v_cus", "zzfld00004y",
                      "zzfld00000w_cus", "zzfld00004x"]:
            fs = self.state[field]
            assert fs["given"] is False, f"{field}.given should be False"

    def test_aprv_proc_field_present_and_empty(self):
        """aprv_proc FieldState must exist and default to the empty sentinel."""
        fs = self.state["aprv_proc"]
        assert fs["given"] is False
        assert fs["valid"] is None
        assert fs["value"] == ""
        assert fs["data"] is None
        assert fs["error"] is None

    def test_transaction_type_field_present_and_empty(self):
        """transaction_type FieldState must exist and default to the empty sentinel."""
        fs = self.state["transaction_type"]
        assert fs["given"] is False
        assert fs["valid"] is None
        assert fs["value"] == ""
        assert fs["data"] is None
        assert fs["error"] is None
