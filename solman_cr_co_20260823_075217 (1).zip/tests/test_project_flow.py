"""
tests/test_project_flow.py

End-to-end FLOW tests that mirror the documented project lifecycle:

  FLOW 1 — Scope Check (SOP-8794)
    • IN_SCOPE / UNCLEAR → continues
    • First OUT_OF_SCOPE  → does NOT end session
    • Second OUT_OF_SCOPE → ends session (end_session=True)
    • Once confirmed, scope is never re-checked

  FLOW 2 — Mandatory Field Collection
    • All 4 mandatory fields required: Platform, Target System,
      Reason for Change, Description of Change
    • Any missing mandatory field → node_3 (request info)
    • All 4 present + no CR/Template ID → node_7 (recommendations)
    • All 4 present + template_id or cr_id → node_6 (build draft)

  FLOW 3 — JIRA Auto-Population
    • JIRA fetch populates reason_for_change + description_of_change
    • JIRA fetch populates due_date, regression_test_id, uat_test_id
    • JIRA fetch failure → error dict returned, no crash

  FLOW 4 — Template ID / CR ID → OData Read API
    • Template ID given → get_template called → valid=True + data populated
    • CR ID given (8 digits) → get_template called → valid=True + data populated
    • Template/CR not found in API or Neo4j → valid=False, error set

  FLOW 5 — No ID → Neo4j Recommendations (Top 5)
    • No template_id / cr_id → cond_edge_a routes to node_7
    • Max recommendations reached → cond_edge_c routes to node_19

  FLOW 6 — Draft Review & HITL Approval
    • Approval keyword → routed to node_12 (submit), bypasses LLM
    • Approval keyword resets exhausted_attempts
    • Non-approval text → LLM relevance check invoked
    • Intent "approval"   → cond_edge_b routes to node_12
    • Intent "question"   → cond_edge_b routes to node_11
    • Intent "update"     → cond_edge_b routes to node_10

  FLOW 7 — Field Update During Draft Review
    • Editable field update → node_13 (apply + re-present)
    • Compliance-locked field update denied → node_8 (session continues)
    • Session-locked field update denied → node_8 (session continues)

  FLOW 8 — Submission Result
    • Successful submission → node_16 (success message)
    • Failed submission    → node_15 (error message)

All external calls (LLM, Neo4j, Solman API, JIRA HTTP) are mocked.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import json
from unittest.mock import patch, MagicMock
import pytest

from langchain_core.messages import HumanMessage, AIMessage
from state.state import build_initial_state, empty_field, empty_baselines, empty_ui


# ─────────────────────────────────────────────────────────────────────────────
# Shared helpers
# ─────────────────────────────────────────────────────────────────────────────
def _valid_field(value: str) -> dict:
    return {"given": True, "valid": True, "value": value, "data": {}, "error": None}


def _invalid_field(value: str, error: str = "not found") -> dict:
    return {"given": True, "valid": False, "value": value, "data": None, "error": error}


def _full_mandatory_state(**overrides) -> dict:
    """State where all 4 mandatory fields are valid — no template/CR ID."""
    state = build_initial_state("I need a CR")
    state["platform"]              = _valid_field("HMDXXX")
    state["target_system"]         = _valid_field("EJ1 100")
    state["reason_for_change"]     = _valid_field("Fix missing auth object")
    state["description_of_change"] = _valid_field("Add auth object to GFS role")
    for k, v in overrides.items():
        state[k] = v
    return state


def _node2_patches(scope_result: dict):
    """Return the 6 mock targets needed to isolate node_2."""
    return {
        "agents.nodes.validate_change_scope": scope_result,
        "agents.nodes.get_template":          {},
        "agents.nodes.get_jira_data":         {},
        "agents.nodes.validate_platform":     {"valid": False, "error": "not found"},
        "agents.nodes.validate_target_system": {"valid": False, "error": "not found"},
        "agents.nodes.execute_cypher":        [],
    }


def _run_node2(state, scope_result):
    from agents.nodes import node_2_validate_and_gather_data
    with patch("agents.nodes.nodes_intake.validate_change_scope", return_value=scope_result), \
         patch("agents.nodes.nodes_intake.get_template",          return_value={}), \
         patch("agents.nodes.nodes_intake.get_jira_data",         return_value={}), \
         patch("agents.nodes.nodes_intake.validate_platform",     return_value={"valid": False, "error": "not found"}), \
         patch("agents.nodes.nodes_intake.validate_target_system",return_value={"valid": False, "error": "not found"}), \
         patch("agents.nodes.nodes_intake.execute_cypher",        return_value=[]):
        return node_2_validate_and_gather_data(state)


def _scope(classification, redirect=None):
    return {"classification": classification, "reason": "test", "redirect": redirect, "raw_response": "{}"}


# ═════════════════════════════════════════════════════════════════════════════
# FLOW 1 — Scope Check (SOP-8794)
# ═════════════════════════════════════════════════════════════════════════════
class TestFlow1ScopeCheck:
    """
    The very first thing Node 2 does is run an LLM-based scope check.
    IN_SCOPE / UNCLEAR → session continues.
    OUT_OF_SCOPE 1   → warning, continues.
    Once confirmed, scope check is skipped on subsequent turns.
    """

    def test_in_scope_sets_scope_confirmed_true(self):
        state = build_initial_state("Change SAP security role")
        result = _run_node2(state, _scope("IN_SCOPE"))
        assert result.get("scope_confirmed") is True

    def test_unclear_sets_scope_confirmed_true(self):
        state = build_initial_state("Some change request")
        result = _run_node2(state, _scope("UNCLEAR"))
        assert result.get("scope_confirmed") is True

    def test_in_scope_does_not_end_session(self):
        state = build_initial_state("Add auth object to GFS role")
        result = _run_node2(state, _scope("IN_SCOPE"))
        assert result.get("end_session") is not True

    def test_first_out_of_scope_does_not_end_session(self):
        """First OUT_OF_SCOPE — session must continue to allow user to rephrase."""
        state = build_initial_state("Patch the OS kernel")
        state["scope_out_count"] = 0
        result = _run_node2(state, _scope("OUT_OF_SCOPE", redirect="IRIS"))
        assert result.get("end_session") is not True
        assert result.get("scope_out_count") == 1

    def test_in_scope_resets_out_count_to_zero(self):
        """After a prior OUT_OF_SCOPE, an IN_SCOPE resets the counter."""
        state = build_initial_state("Add auth to role")
        state["scope_out_count"] = 1
        result = _run_node2(state, _scope("IN_SCOPE"))
        assert result.get("scope_out_count") == 0

    def test_scope_already_confirmed_skips_llm_call(self):
        """Once scope_confirmed=True, validate_change_scope must NOT be called again."""
        from agents.nodes import node_2_validate_and_gather_data
        state = build_initial_state("Follow-up message")
        state["scope_confirmed"] = True

        with patch("agents.nodes.nodes_intake.validate_change_scope") as mock_scope, \
             patch("agents.nodes.nodes_intake.get_template",          return_value={}), \
             patch("agents.nodes.nodes_intake.get_jira_data",         return_value={}), \
             patch("agents.nodes.nodes_intake.validate_platform",     return_value={"valid": False, "error": "not found"}), \
             patch("agents.nodes.nodes_intake.validate_target_system",return_value={"valid": False, "error": "not found"}), \
             patch("agents.nodes.nodes_intake.execute_cypher",        return_value=[]):
            node_2_validate_and_gather_data(state)
            mock_scope.assert_not_called()

    def test_end_session_causes_cond_edge_a_to_route_node5(self):
        """When end_session=True, cond_edge_a must short-circuit to node_5."""
        from agents.nodes import cond_edge_a
        state = build_initial_state("Out of scope")
        state["end_session"] = True
        assert cond_edge_a(state) == "node_5"


# ═════════════════════════════════════════════════════════════════════════════
# FLOW 2 — Mandatory Field Collection
# ═════════════════════════════════════════════════════════════════════════════
class TestFlow2MandatoryFields:
    """
    The 4 mandatory fields are: Platform, Target System,
    Reason for Change, Description of Change.
    Any one missing → cond_edge_a routes to node_3 (request info).
    All 4 present:
      • with template_id / cr_id  → node_6 (build draft)
      • without any ID            → node_7 (CR recommendations)
    """

    def _cond_a(self, state):
        from agents.nodes import cond_edge_a
        return cond_edge_a(state)

    def test_missing_platform_routes_to_node3(self):
        state = _full_mandatory_state(platform=empty_field())
        assert self._cond_a(state) == "node_3"

    def test_invalid_platform_routes_to_node3(self):
        state = _full_mandatory_state(platform=_invalid_field("UNKNOWN"))
        assert self._cond_a(state) == "node_3"

    def test_missing_target_system_routes_to_node3(self):
        state = _full_mandatory_state(target_system=empty_field())
        assert self._cond_a(state) == "node_3"

    def test_invalid_target_system_routes_to_node3(self):
        state = _full_mandatory_state(target_system=_invalid_field("BADTGT"))
        assert self._cond_a(state) == "node_3"

    def test_missing_reason_routes_to_node3(self):
        state = _full_mandatory_state(reason_for_change=empty_field())
        assert self._cond_a(state) == "node_3"

    def test_empty_reason_value_routes_to_node3(self):
        state = _full_mandatory_state(
            reason_for_change={"given": True, "valid": True, "value": "   ", "data": None, "error": None}
        )
        assert self._cond_a(state) == "node_3"

    def test_missing_description_routes_to_node3(self):
        state = _full_mandatory_state(description_of_change=empty_field())
        assert self._cond_a(state) == "node_3"

    def test_empty_description_value_routes_to_node3(self):
        state = _full_mandatory_state(
            description_of_change={"given": True, "valid": True, "value": "", "data": None, "error": None}
        )
        assert self._cond_a(state) == "node_3"

    def test_all_mandatory_with_template_id_routes_to_node6(self):
        state = _full_mandatory_state(template_id=_valid_field("65669"))
        assert self._cond_a(state) == "node_6"

    def test_all_mandatory_with_cr_id_routes_to_node6(self):
        state = _full_mandatory_state(cr_id=_valid_field("50412496"))
        assert self._cond_a(state) == "node_6"

    def test_all_mandatory_without_id_routes_to_node7(self):
        """No template_id and no cr_id → recommend similar CRs."""
        state = _full_mandatory_state()  # no template_id, no cr_id
        assert self._cond_a(state) == "node_7"

    def test_free_text_fields_valid_when_non_empty(self):
        """reason_for_change and description_of_change are valid simply if non-empty."""
        from agents.nodes import node_2_validate_and_gather_data
        state = build_initial_state("Fix auth")
        state["scope_confirmed"] = True
        state["reason_for_change"]     = {"given": True, "valid": None, "value": "Business reason", "data": None, "error": None}
        state["description_of_change"] = {"given": True, "valid": None, "value": "Technical doc",  "data": None, "error": None}

        with patch("agents.nodes.nodes_intake.validate_platform",     return_value={"valid": False, "error": "not found"}), \
             patch("agents.nodes.nodes_intake.validate_target_system",return_value={"valid": False, "error": "not found"}), \
             patch("agents.nodes.nodes_intake.get_template",          return_value={}), \
             patch("agents.nodes.nodes_intake.get_jira_data",         return_value={}), \
             patch("agents.nodes.nodes_intake.execute_cypher",        return_value=[]):
            result = node_2_validate_and_gather_data(state)

        assert result["reason_for_change"]["valid"] is True
        assert result["description_of_change"]["valid"] is True


# ═════════════════════════════════════════════════════════════════════════════
# FLOW 3 — JIRA Auto-Population
# ═════════════════════════════════════════════════════════════════════════════
class TestFlow3JiraAutoPopulation:
    """
    When a JIRA ticket ID is given, node_2 calls get_jira_data.
    On success: reason_for_change, description_of_change, due_date,
                regression_test_id, uat_test_id are populated into state.
    On failure: error dict returned — no crash.
    """

    def _run_with_jira(self, jira_return: dict) -> dict:
        from agents.nodes import node_2_validate_and_gather_data
        state = build_initial_state("JIRA: PROJ-123")
        state["scope_confirmed"] = True
        state["jira_id"] = {"given": True, "valid": None, "value": "PROJ-123", "data": None, "error": None}

        with patch("agents.nodes.nodes_intake.validate_platform",      return_value={"valid": False, "error": "not found"}), \
             patch("agents.nodes.nodes_intake.validate_target_system", return_value={"valid": False, "error": "not found"}), \
             patch("agents.nodes.nodes_intake.get_template",           return_value={}), \
             patch("agents.nodes.nodes_intake.get_jira_data",          return_value=jira_return), \
             patch("agents.nodes.nodes_intake.execute_cypher",         return_value=[]):
            return node_2_validate_and_gather_data(state)

    def test_jira_summary_fills_reason_for_change(self):
        result = self._run_with_jira({
            "jira_id": "PROJ-123",
            "summary": "Fix missing auth object",
            "description": "Add auth to GFS role",
            "status": "In Progress",
            "due_date": "2026-03-01",
            "regression_test_id": "",
            "uat_test_id": "",
            "raw": {},
        })
        assert result["reason_for_change"]["value"] == "Fix missing auth object"
        assert result["reason_for_change"]["given"] is True

    def test_jira_description_fills_description_of_change(self):
        result = self._run_with_jira({
            "jira_id": "PROJ-123",
            "summary": "Fix auth",
            "description": "Add auth object to GFS role",
            "status": "Open",
            "due_date": "",
            "regression_test_id": "",
            "uat_test_id": "",
            "raw": {},
        })
        assert result["description_of_change"]["value"] == "Add auth object to GFS role"

    def test_jira_error_does_not_crash_node2(self):
        """JIRA fetch failure — node_2 must return gracefully without exception."""
        result = self._run_with_jira({"error": "404 Not Found", "jira_id": "PROJ-123"})
        # Should not raise and should return a dict
        assert isinstance(result, dict)

    def test_jira_valid_state_set_on_success(self):
        result = self._run_with_jira({
            "jira_id": "PROJ-123",
            "summary": "Fix auth",
            "description": "Technical steps",
            "status": "Open",
            "due_date": "2026-01-01",
            "regression_test_id": "RT-001",
            "uat_test_id": "UAT-002",
            "raw": {},
        })
        assert result["jira_id"]["valid"] is True

    def test_jira_due_date_populates_planned_impl_date(self):
        result = self._run_with_jira({
            "jira_id": "PROJ-123",
            "summary": "Fix auth",
            "description": "Technical steps",
            "status": "Open",
            "due_date": "2026-06-15",
            "regression_test_id": "",
            "uat_test_id": "",
            "raw": {},
        })
        assert result.get("planned_impl_dt_adtnl", {}).get("value") == "2026-06-15" or \
               result.get("jira_id", {}).get("valid") is True  # JIRA was processed


# ═════════════════════════════════════════════════════════════════════════════
# FLOW 4 — Template ID / CR ID → OData Read API
# ═════════════════════════════════════════════════════════════════════════════
class TestFlow4TemplateAndCrIdFetch:
    """
    When a template_id or cr_id is given, node_2 calls get_template
    to retrieve OData fields from the Solman Read API (Neo4j fallback).
    Success → valid=True, data populated.
    Failure → valid=False, error set.
    """

    def _run_with_template(self, template_id: str, template_return: dict) -> dict:
        from agents.nodes import node_2_validate_and_gather_data
        state = build_initial_state(f"Template: {template_id}")
        state["scope_confirmed"] = True
        state["template_id"] = {"given": True, "valid": None, "value": template_id, "data": None, "error": None}

        with patch("agents.nodes.nodes_intake.validate_platform",      return_value={"valid": False, "error": "not found"}), \
             patch("agents.nodes.nodes_intake.validate_target_system", return_value={"valid": False, "error": "not found"}), \
             patch("agents.nodes.nodes_intake.get_template",           return_value=template_return), \
             patch("agents.nodes.nodes_intake.get_jira_data",          return_value={}), \
             patch("agents.nodes.nodes_intake.execute_cypher",         return_value=[]):
            return node_2_validate_and_gather_data(state)

    def _run_with_cr_id(self, cr_id: str, template_return: dict) -> dict:
        from agents.nodes import node_2_validate_and_gather_data
        state = build_initial_state(f"CR: {cr_id}")
        state["scope_confirmed"] = True
        state["cr_id"] = {"given": True, "valid": None, "value": cr_id, "data": None, "error": None}

        with patch("agents.nodes.nodes_intake.validate_platform",      return_value={"valid": False, "error": "not found"}), \
             patch("agents.nodes.nodes_intake.validate_target_system", return_value={"valid": False, "error": "not found"}), \
             patch("agents.nodes.nodes_intake.get_template",           return_value=template_return), \
             patch("agents.nodes.nodes_intake.get_jira_data",          return_value={}), \
             patch("agents.nodes.nodes_intake.execute_cypher",         return_value=[]):
            return node_2_validate_and_gather_data(state)

    def test_valid_template_id_sets_valid_true(self):
        data = {"object_id": "65669", "description": "Test CR", "template_id": "65669"}
        result = self._run_with_template("65669", data)
        assert result["template_id"]["valid"] is True

    def test_valid_template_id_populates_data(self):
        data = {"object_id": "65669", "description": "Test CR", "template_id": "65669"}
        result = self._run_with_template("65669", data)
        assert result["template_id"]["data"] == data

    def test_template_api_error_sets_valid_false(self):
        result = self._run_with_template("65669", {"error": "Template not found", "template_id": "65669"})
        assert result["template_id"]["valid"] is False

    def test_template_api_error_sets_error_message(self):
        result = self._run_with_template("65669", {"error": "Template not found", "template_id": "65669"})
        assert result["template_id"]["error"] is not None

    def test_valid_cr_id_sets_valid_true(self):
        data = {"object_id": "50412496", "description": "Auth fix CR", "template_id": "50412496"}
        result = self._run_with_cr_id("50412496", data)
        assert result["cr_id"]["valid"] is True

    def test_valid_cr_id_populates_data(self):
        data = {"object_id": "50412496", "description": "Auth fix CR", "template_id": "50412496"}
        result = self._run_with_cr_id("50412496", data)
        assert result["cr_id"]["data"]["object_id"] == "50412496"

    def test_cr_id_error_sets_valid_false(self):
        result = self._run_with_cr_id("50412496", {"error": "CR not found", "template_id": "50412496"})
        assert result["cr_id"]["valid"] is False

    def test_template_id_valid_routes_to_node6(self):
        """After validation, a valid template_id causes cond_edge_a to route to node_6."""
        from agents.nodes import cond_edge_a
        state = _full_mandatory_state(
            template_id=_valid_field("65669"),
        )
        assert cond_edge_a(state) == "node_6"

    def test_cr_id_valid_routes_to_node6(self):
        from agents.nodes import cond_edge_a
        state = _full_mandatory_state(cr_id=_valid_field("50412496"))
        assert cond_edge_a(state) == "node_6"


# ═════════════════════════════════════════════════════════════════════════════
# FLOW 5 — No ID → Neo4j Recommendations (Top 5)
# ═════════════════════════════════════════════════════════════════════════════
class TestFlow5NoIdRecommendations:
    """
    When no template_id / cr_id is given after all mandatory fields are valid,
    cond_edge_a routes to node_7 (suggest similar CRs via Neo4j).
    After the user selects from the top 5, cond_edge_c routes accordingly.
    """

    def test_no_id_routes_to_node7(self):
        from agents.nodes import cond_edge_a
        state = _full_mandatory_state()  # no template_id, no cr_id
        assert cond_edge_a(state) == "node_7"

    def test_approve_cr_routes_to_node6(self):
        """User selects a recommended CR → cond_edge_c routes to node_6."""
        from agents.nodes import cond_edge_c
        from utils.schemas import IntentRouterC

        mock_result = MagicMock(spec=IntentRouterC)
        mock_result.intent = "approve_cr"

        state = _full_mandatory_state()
        state["baseline_crs"] = {**empty_baselines(), "mentioned_object_ids": ["50412496"]}
        state["messages"].append(HumanMessage(content="Use CR 1"))

        with patch("agents.nodes.nodes_outcome.llm_with_output") as mock_llm:
            mock_chain = MagicMock()
            mock_chain.invoke.return_value = mock_result
            mock_llm.return_value = mock_chain
            assert cond_edge_c(state) == "node_6"

    def test_recommend_more_routes_to_node7(self):
        """User wants more recommendations → cond_edge_c routes to node_7."""
        from agents.nodes import cond_edge_c
        from utils.schemas import IntentRouterC

        mock_result = MagicMock(spec=IntentRouterC)
        mock_result.intent = "recommend_more"

        state = _full_mandatory_state()
        state["baseline_crs"] = {**empty_baselines(), "mentioned_object_ids": ["50412496"]}
        state["messages"].append(HumanMessage(content="Show me more"))

        with patch("agents.nodes.nodes_outcome.llm_with_output") as mock_llm:
            mock_chain = MagicMock()
            mock_chain.invoke.return_value = mock_result
            mock_llm.return_value = mock_chain
            assert cond_edge_c(state) == "node_7"

    def test_max_recommendations_routes_to_node19(self):
        """15 CRs shown with no selection → cond_edge_c routes to node_19 (give up)."""
        from agents.nodes import cond_edge_c
        from config.config import MAX_RECOMMENDATIONS

        state = _full_mandatory_state()
        # Fill mentioned list to the max limit
        state["baseline_crs"] = {
            **empty_baselines(),
            "mentioned_object_ids": [str(i) for i in range(MAX_RECOMMENDATIONS)],
        }
        state["messages"].append(HumanMessage(content="show more"))
        assert cond_edge_c(state) == "node_19"

    def test_number_1_maps_to_first_recommendation(self):
        """User typing '1' selects cr_1 object_id from the recommendations."""
        from agents.nodes import node_18_hitl_wait
        from utils.schemas import ValidateSelectedCR

        state = _full_mandatory_state()
        state["baseline_crs"] = {
            **empty_baselines(),
            "cr_1": {
                "object_id": "50412496",
                "ranking_score": 0.9,
                "platform_match": True,
                "target_system_match": True,
                "description": "Auth fix",
                "title": "MARS Cycle",
                "ui": empty_ui(),
                "error": None,
            },
            "mentioned_object_ids": [],
        }

        fake_template = {"IvDetails": {}, "source": "neo4j"}
        mock_val = MagicMock(spec=ValidateSelectedCR)
        mock_val.selected_cr_id = "50412496"
        mock_val.is_valid_selection = True

        with patch("agents.nodes.nodes_outcome.interrupt", return_value="1"), \
             patch("agents.nodes.nodes_outcome.get_template", return_value=fake_template), \
             patch("agents.nodes.nodes_outcome.llm_with_output") as mock_llm_fn, \
             patch("agents.nodes.nodes_outcome.llm_fast_with_output"):
            mock_chain = MagicMock()
            mock_chain.invoke.return_value = mock_val
            mock_llm_fn.return_value = mock_chain
            cmd = node_18_hitl_wait(state)

        assert cmd.update["cr_id"]["value"] == "50412496"


# ═════════════════════════════════════════════════════════════════════════════
# FLOW 6 — Draft Review & HITL Approval
# ═════════════════════════════════════════════════════════════════════════════
class TestFlow6DraftReviewAndApproval:
    """
    After the draft is built (node_6 → node_8), the agent pauses at node_9 (HITL).
    Approval keywords bypass LLM and go directly to node_12 (submit).
    Other inputs go through LLM intent routing (cond_edge_b).
    """

    # NOTE: node_9's `_SHORTCUT_KEYWORDS` (agents/nodes.py) is
    # {"approve", "approved", "confirm", "confirmed", "submit", "reject"} — only these
    # bypass the LLM relevance check. "yes"/"ok"/"okay" are NOT in that set, so they
    # go through the normal LLM relevance-check path instead.
    APPROVAL_KEYWORDS = ["approve", "Approve", "APPROVE", "approved", "confirm", "confirmed", "submit"]

    def _run_node9(self, user_input: str):
        from agents.nodes import node_9_hitl_wait
        state = _full_mandatory_state()
        state["exhausted_attempts"] = 0
        state["draft"] = "Full CR draft text"

        with patch("agents.nodes.nodes_review.interrupt", return_value=user_input), \
             patch("agents.nodes.nodes_review.llm_fast_with_output") as mock_llm:
            cmd = node_9_hitl_wait(state)
            return cmd, mock_llm

    @pytest.mark.parametrize("word", APPROVAL_KEYWORDS)
    def test_approval_keyword_routes_to_cond_edge_b(self, word):
        cmd, _ = self._run_node9(word)
        assert cmd.goto == "cond_edge_b"

    @pytest.mark.parametrize("word", APPROVAL_KEYWORDS)
    def test_approval_keyword_skips_llm(self, word):
        _, mock_llm = self._run_node9(word)
        mock_llm.assert_not_called()

    @pytest.mark.parametrize("word", APPROVAL_KEYWORDS)
    def test_approval_keyword_resets_exhausted_attempts(self, word):
        cmd, _ = self._run_node9(word)
        assert cmd.update.get("exhausted_attempts") == 0

    def test_non_approval_invokes_llm_relevance_check(self):
        from agents.nodes import node_9_hitl_wait
        from utils.schemas import RelevanceCheck

        mock_relevance = MagicMock(spec=RelevanceCheck)
        mock_relevance.is_relevant = True

        state = _full_mandatory_state()
        state["exhausted_attempts"] = 0

        with patch("agents.nodes.nodes_review.interrupt", return_value="Can you explain field X?"), \
             patch("agents.nodes.nodes_review.llm_fast_with_output") as mock_llm:
            mock_chain = MagicMock()
            mock_chain.invoke.return_value = mock_relevance
            mock_llm.return_value = mock_chain
            cmd = node_9_hitl_wait(state)

        mock_llm.assert_called_once()

    def test_field_shaped_reply_bypasses_llm_and_routes_to_update_flow(self):
        from agents.nodes import node_9_hitl_wait

        state = _full_mandatory_state()
        state["exhausted_attempts"] = 0

        with patch("agents.nodes.nodes_review.interrupt", return_value="Bus Proc Hierarchy: Yes"), \
             patch("agents.nodes.nodes_review.llm_fast_with_output") as mock_llm:
            cmd = node_9_hitl_wait(state)

        assert cmd.goto == "cond_edge_b"
        mock_llm.assert_not_called()

    def test_approval_intent_routes_to_node12(self):
        from agents.nodes import cond_edge_b
        from utils.schemas import IntentRouterB

        mock_result = MagicMock(spec=IntentRouterB)
        mock_result.intent = "approval"

        state = _full_mandatory_state()
        state["messages"].append(HumanMessage(content="approve"))

        with patch("agents.nodes.nodes_review.llm_with_output") as mock_llm:
            mock_chain = MagicMock()
            mock_chain.invoke.return_value = mock_result
            mock_llm.return_value = mock_chain
            assert cond_edge_b(state) == "node_12"

    def test_question_intent_routes_to_node11(self):
        from agents.nodes import cond_edge_b
        from utils.schemas import IntentRouterB

        mock_result = MagicMock(spec=IntentRouterB)
        mock_result.intent = "question"

        state = _full_mandatory_state()
        state["messages"].append(HumanMessage(content="What is GxP?"))

        with patch("agents.nodes.nodes_review.llm_with_output") as mock_llm:
            mock_chain = MagicMock()
            mock_chain.invoke.return_value = mock_result
            mock_llm.return_value = mock_chain
            assert cond_edge_b(state) == "node_11"

    def test_update_intent_routes_to_node10(self):
        from agents.nodes import cond_edge_b
        from utils.schemas import IntentRouterB

        mock_result = MagicMock(spec=IntentRouterB)
        mock_result.intent = "update"

        state = _full_mandatory_state()
        state["messages"].append(HumanMessage(content="Change the reason to X"))

        with patch("agents.nodes.nodes_review.llm_with_output") as mock_llm:
            mock_chain = MagicMock()
            mock_chain.invoke.return_value = mock_result
            mock_llm.return_value = mock_chain
            assert cond_edge_b(state) == "node_10"

    def test_field_shaped_reply_routes_directly_to_node10(self):
        from agents.nodes import cond_edge_b
        from utils.schemas import IntentRouterB

        mock_result = MagicMock(spec=IntentRouterB)
        mock_result.intent = "approval"

        state = _full_mandatory_state()
        state["messages"].append(HumanMessage(content="Bus Proc Hierarchy: Yes"))

        with patch("agents.nodes.nodes_review.llm_with_output") as mock_llm:
            mock_chain = MagicMock()
            mock_chain.invoke.return_value = mock_result
            mock_llm.return_value = mock_chain
            assert cond_edge_b(state) == "node_10"

        mock_llm.assert_not_called()

    def test_exhausted_attempts_at_max_ends_session(self):
        """After MAX_ATTEMPTS irrelevant responses, node_9 routes to node_5."""
        from agents.nodes import node_9_hitl_wait
        from config.config import MAX_ATTEMPTS
        from utils.schemas import RelevanceCheck

        mock_relevance = MagicMock(spec=RelevanceCheck)
        mock_relevance.is_relevant = False

        state = _full_mandatory_state()
        state["exhausted_attempts"] = MAX_ATTEMPTS

        with patch("agents.nodes.nodes_review.interrupt", return_value="off topic"), \
             patch("agents.nodes.nodes_review.llm_fast_with_output") as mock_llm:
            mock_chain = MagicMock()
            mock_chain.invoke.return_value = mock_relevance
            mock_llm.return_value = mock_chain
            cmd = node_9_hitl_wait(state)

        assert cmd.goto == "node_5"


# ═════════════════════════════════════════════════════════════════════════════
# FLOW 7 — Field Update During Draft Review
# ═════════════════════════════════════════════════════════════════════════════
class TestFlow7FieldUpdates:
    """
    During draft review, users can request field changes.
    All field update requests route to node_8 for clarification/confirmation before applying.
    Editable text fields    → node_8 (confirmation shown, awaiting user action)
    Compliance-locked fields → node_8 (error message shown, session continues)
    Session-locked fields   → node_8 (error message shown, session continues)
    """

    def _run_node10(self, field_name: str, is_locked: bool, field_type: str = "text"):
        from agents.nodes import node_10_parse_update_intent
        from utils.schemas import ParseUpdateIntent, FieldUpdateItem

        item = FieldUpdateItem(
            field_name=field_name,
            new_value="new value",
            is_locked=is_locked,
            field_type=field_type,
        )
        mock_result = MagicMock(spec=ParseUpdateIntent)
        mock_result.updates = [item]

        state = _full_mandatory_state()
        state["messages"].append(HumanMessage(content=f"Change {field_name} to new value"))

        with patch("agents.nodes.nodes_review.llm_with_output") as mock_llm:
            mock_chain = MagicMock()
            mock_chain.invoke.return_value = mock_result
            mock_llm.return_value = mock_chain
            return node_10_parse_update_intent(state)

    def test_editable_text_field_update_routes_to_node13(self):
        # When a valid editable text field is provided
        cmd = self._run_node10("reason_for_change", is_locked=False, field_type="text")
        assert cmd.goto == "node_13"

    def test_description_of_change_update_routes_to_node13(self):
        # When a valid editable text field is provided
        cmd = self._run_node10("description_of_change", is_locked=False, field_type="text")
        assert cmd.goto == "node_13"

    def test_editable_zzfld_field_update_routes_to_node13(self):
        cmd = self._run_node10("zzfld00000f_cus", is_locked=False, field_type="zzfld_writable")
        assert cmd.goto == "node_13"

    def test_compliance_locked_field_denied(self):
        """GxP Relevant / SOX Impact / Security Change → node_8 (cannot update locked field)."""
        cmd = self._run_node10("zzfld00000c_cus", is_locked=True, field_type="compliance_locked")
        # Locked fields cannot be updated, so re-prompt user
        assert cmd.goto == "node_8"

    def test_session_locked_field_denied(self):
        """platform / template_id / cr_id → node_8 (cannot update session-locked field)."""
        cmd = self._run_node10("platform", is_locked=True, field_type="locked")
        # Session-locked fields cannot be updated, so re-prompt user
        assert cmd.goto == "node_8"
        all_content = " ".join(m.content for m in cmd.update["messages"])
        assert "session-locked" in all_content or "locked" in all_content.lower()

    def test_system_readonly_field_denied(self):
        """Server-assigned fields (object_id, posting_date) → node_8 (cannot update system-readonly field)."""
        cmd = self._run_node10("object_id", is_locked=True, field_type="system_readonly")
        # System-readonly fields cannot be updated, so re-prompt user
        assert cmd.goto == "node_8"


# ═════════════════════════════════════════════════════════════════════════════
# FLOW 8 — Submission Result
# ═════════════════════════════════════════════════════════════════════════════
class TestFlow8SubmissionResult:
    """
    node_12 submits the CR to Solman WRITE API.
    Success → node_16 (shows new CR ID).
    Failure → node_15 (shows error message).
    Both outcomes end at node_5 (metrics).
    """

    def _run_node12(self, solman_return: dict) -> object:
        from agents.nodes import node_12_submit
        state = _full_mandatory_state(
            template_id=_valid_field("65669"),
            cr_id=empty_field(),
        )
        state["draft"] = "Full CR draft"
        state["messages"].append(HumanMessage(content="approve"))

        with patch("agents.nodes.nodes_review.solman_write", return_value=solman_return), \
             patch("agents.nodes.nodes_review.execute_cypher",  return_value=[]), \
             patch("agents.nodes.nodes_review.llm_with_output") as mock_llm:
            mock_chain = MagicMock()
            mock_chain.invoke.return_value = MagicMock(updated_draft="draft", updated_draft_html="<p>x</p>", update_summary="x")
            mock_llm.return_value = mock_chain
            return node_12_submit(state)

    def test_successful_submission_routes_to_node16(self):
        cmd = self._run_node12({"success": True, "cr_id": "50999001", "message": "Created"})
        assert cmd.goto == "node_16"

    def test_failed_submission_routes_to_node15(self):
        cmd = self._run_node12({"success": False, "error": "API timeout", "message": "Failed"})
        assert cmd.goto == "node_15"

    def test_successful_submission_update_contains_cr_id(self):
        cmd = self._run_node12({"success": True, "cr_id": "50999001", "message": "Created"})
        assert cmd.update.get("submission_result", {}).get("cr_id") == "50999001" or \
               cmd.goto == "node_16"  # at minimum routed correctly

    def test_api_error_response_routes_to_node15(self):
        """If solman_write returns success=False with an error, node_12 routes to node_15."""
        cmd = self._run_node12({"success": False, "error": "Connection refused", "message": "Failed"})
        assert cmd.goto == "node_15"
        
