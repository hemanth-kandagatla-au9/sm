"""
tests/test_tools_get_template.py

Unit tests for tools/get_template — Solman OData API and Neo4j both mocked.

Covers:
  - Empty / whitespace template_id returns error immediately
  - API success: props returned with template_id field
  - API returns error key: falls back to Neo4j
  - API raises exception: falls back to Neo4j
  - Both API and Neo4j fail: returns error
  - Neo4j success when API not configured
  - _parse_odata_response integration via _get_template_from_api mock
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from unittest.mock import patch, MagicMock
import pytest


# ─────────────────────────────────────────────────────────────────────────────
# Helper
# ─────────────────────────────────────────────────────────────────────────────
def _run(
    template_id: str,
    api_return=None,
    api_raises=None,
    neo4j_return=None,
    neo4j_raises=None,
    api_configured: bool = True,
) -> dict:
    """
    Run get_template with internal helpers fully mocked.

    api_configured=False simulates SOLMAN_READ_BASE_URL / USERNAME not set.
    """
    from tools.tools import get_template

    base_url = "https://solman.example.com" if api_configured else ""
    username = "user" if api_configured else ""

    with patch("tools.tools.SOLMAN_READ_BASE_URL", base_url), \
         patch("tools.tools.SOLMAN_READ_USERNAME", username):

        api_kwargs = {}
        if api_raises:
            api_kwargs["side_effect"] = api_raises
        elif api_return is not None:
            api_kwargs["return_value"] = api_return
        else:
            api_kwargs["side_effect"] = Exception("API not configured")

        neo4j_kwargs = {}
        if neo4j_raises:
            neo4j_kwargs["side_effect"] = neo4j_raises
        elif neo4j_return is not None:
            neo4j_kwargs["return_value"] = neo4j_return
        else:
            neo4j_kwargs["return_value"] = {"error": "not found", "template_id": template_id}

        with patch("tools.tools._get_template_from_api", **api_kwargs), \
             patch("tools.tools._get_template_from_neo4j", **neo4j_kwargs):
            return get_template(template_id)


# ─────────────────────────────────────────────────────────────────────────────
# Input validation
# ─────────────────────────────────────────────────────────────────────────────
class TestGetTemplateInputValidation:

    def test_empty_string_returns_error(self):
        from tools.tools import get_template
        result = get_template("")
        assert "error" in result

    def test_whitespace_only_returns_error(self):
        from tools.tools import get_template
        result = get_template("   ")
        assert "error" in result

    def test_empty_preserves_template_id_key(self):
        from tools.tools import get_template
        result = get_template("")
        assert "template_id" in result


# ─────────────────────────────────────────────────────────────────────────────
# API success path
# ─────────────────────────────────────────────────────────────────────────────
class TestGetTemplateApiSuccess:

    def test_api_props_returned(self):
        props = {"object_id": "50339227", "description": "Test CR", "template_id": "50339227"}
        result = _run("50339227", api_return=props)
        assert result["object_id"] == "50339227"
        assert result["description"] == "Test CR"

    def test_template_id_present_in_result(self):
        props = {"object_id": "65669", "template_id": "65669"}
        result = _run("65669", api_return=props)
        assert result["template_id"] == "65669"

    def test_no_error_key_on_api_success(self):
        props = {"object_id": "65669", "description": "ok", "template_id": "65669"}
        result = _run("65669", api_return=props)
        assert "error" not in result


# ─────────────────────────────────────────────────────────────────────────────
# API failure → Neo4j fallback
# ─────────────────────────────────────────────────────────────────────────────
class TestGetTemplateApiFallback:

    def test_api_exception_falls_back_to_neo4j(self):
        neo4j_props = {"object_id": "50339227", "description": "From Neo4j", "template_id": "50339227"}
        result = _run(
            "50339227",
            api_raises=ConnectionError("timeout"),
            neo4j_return=neo4j_props,
        )
        assert result["description"] == "From Neo4j"

    def test_api_error_key_falls_back_to_neo4j(self):
        """API dict has 'error' key — treated as failure, should fall back."""
        neo4j_props = {"object_id": "65669", "description": "Neo4j data", "template_id": "65669"}
        result = _run(
            "65669",
            api_return={"error": "Template not found", "template_id": "65669"},
            neo4j_return=neo4j_props,
        )
        assert result.get("description") == "Neo4j data"

    def test_api_not_configured_uses_neo4j_directly(self):
        """When SOLMAN_READ_BASE_URL is empty, Neo4j is used without trying API."""
        neo4j_props = {"object_id": "99999", "description": "Direct Neo4j", "template_id": "99999"}
        result = _run(
            "99999",
            neo4j_return=neo4j_props,
            api_configured=False,
        )
        assert result["description"] == "Direct Neo4j"


# ─────────────────────────────────────────────────────────────────────────────
# Both fail
# ─────────────────────────────────────────────────────────────────────────────
class TestGetTemplateBothFail:

    def test_both_fail_returns_error(self):
        result = _run(
            "99999",
            api_raises=Exception("API down"),
            neo4j_raises=Exception("Neo4j down"),
        )
        assert "error" in result

    def test_both_fail_error_contains_exception_message(self):
        result = _run(
            "99999",
            api_raises=Exception("API down"),
            neo4j_raises=Exception("Neo4j completely unreachable"),
        )
        assert result.get("error") or "error" in result

    def test_neo4j_returns_error_key_propagated(self):
        result = _run(
            "99999",
            api_raises=Exception("API down"),
            neo4j_return={"error": "No CR found", "template_id": "99999"},
        )
        assert "error" in result


class TestGetTemplateFromApi:

    def test_missing_configuration_raises_value_error(self):
        from tools.tools import _get_template_from_api

        with patch("tools.tools.SOLMAN_READ_BASE_URL", ""), \
             patch("tools.tools.SOLMAN_READ_USERNAME", ""):
            with pytest.raises(ValueError, match="not configured"):
                _get_template_from_api("50339227")

    def test_json_response_parses_and_keeps_csrf_token(self):
        from tools.tools import _get_template_from_api

        response = MagicMock()
        response.raise_for_status.return_value = None
        response.headers = {"X-CSRF-Token": "csrf-123"}
        response.json.return_value = {"d": {"TransactionNo": "50339227"}}

        with patch("tools.tools.SOLMAN_READ_BASE_URL", "https://solman.example.com"), \
             patch("tools.tools.SOLMAN_READ_USERNAME", "user"), \
             patch("tools.tools.SOLMAN_READ_PASSWORD", "pass"), \
             patch("tools.tools.requests.get", return_value=response) as mock_get, \
             patch("tools.tools._parse_odata_response", return_value={"template_id": "50339227", "object_id": "50339227"}) as mock_parse:
            result = _get_template_from_api("50339227")

        assert result == {
            "template_id": "50339227",
            "object_id": "50339227",
            "_csrf_token": "csrf-123",
        }
        mock_parse.assert_called_once_with({"d": {"TransactionNo": "50339227"}}, "50339227")
        assert mock_get.call_count == 1

    def test_non_json_response_returns_raw_text(self):
        from tools.tools import _get_template_from_api

        response = MagicMock()
        response.raise_for_status.return_value = None
        response.headers = {"X-CSRF-Token": "csrf-raw"}
        response.text = "<html>not json</html>"
        response.json.side_effect = ValueError("invalid json")

        with patch("tools.tools.SOLMAN_READ_BASE_URL", "https://solman.example.com"), \
             patch("tools.tools.SOLMAN_READ_USERNAME", "user"), \
             patch("tools.tools.SOLMAN_READ_PASSWORD", "pass"), \
             patch("tools.tools.requests.get", return_value=response):
            result = _get_template_from_api("50339227")

        assert result == {
            "raw_response": "<html>not json</html>",
            "template_id": "50339227",
            "_csrf_token": "csrf-raw",
        }

    def test_all_candidate_urls_fail_raises_runtime_error(self):
        from tools.tools import _get_template_from_api

        response = MagicMock()
        response.raise_for_status.side_effect = RuntimeError("boom")

        with patch("tools.tools.SOLMAN_READ_BASE_URL", "https://solman.example.com"), \
             patch("tools.tools.SOLMAN_READ_USERNAME", "user"), \
             patch("tools.tools.SOLMAN_READ_PASSWORD", "pass"), \
             patch("tools.tools.requests.get", return_value=response) as mock_get:
            with pytest.raises(RuntimeError, match="all ChangeRequestSet GET URL attempts failed"):
                _get_template_from_api("50339227")

        assert mock_get.call_count == 4
