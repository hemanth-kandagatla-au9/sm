"""
generate_diagram.py
-------------------
Generates a complete flow diagram of the CR Agent LangGraph
including Cond Edge A as an explicit diamond node.

Usage (run from inside cr_agent folder):
    python generate_diagram.py

Outputs:
    cr_agent_diagram.html  -- Open in any browser (best option)
    cr_agent_diagram.md    -- Paste into https://mermaid.live
    cr_agent_diagram.png   -- PNG via Mermaid.ink (needs internet)
"""
from __future__ import annotations

import base64
import os
import sys
import urllib.request

# ── Path fix ──────────────────────────────────────────────────────────────────
_HERE   = os.path.dirname(os.path.abspath(__file__))
_PARENT = os.path.dirname(_HERE)
for _p in (_PARENT, _HERE):
    if _p not in sys.path:
        sys.path.insert(0, _p)

os.environ.setdefault("AZURE_OPENAI_API_KEY",     "stub-key")
os.environ.setdefault("AZURE_OPENAI_ENDPOINT",    "https://stub.openai.azure.com/")
os.environ.setdefault("AZURE_OPENAI_API_VERSION", "2024-02-01")
os.environ.setdefault("CR_MODEL",                 "gpt-4o")

try:
    from dotenv import load_dotenv
    _env = os.path.join(_HERE, ".env")
    if os.path.exists(_env):
        load_dotenv(_env)
except ImportError:
    pass
# ─────────────────────────────────────────────────────────────────────────────

print("Building graph...")
from graph.builder import build_graph
graph = build_graph()
print("[OK] Graph built successfully")

# ─────────────────────────────────────────────────────────────────────────────
# Full hand-crafted Mermaid diagram
# Includes Cond Edge A as an explicit diamond ({{...}}) with all 3 branches,
# plus Cond Edge B, Cond Edge C, and every node from the architecture.
# ─────────────────────────────────────────────────────────────────────────────
MERMAID = """---
config:
  flowchart:
    curve: linear
    rankSpacing: 60
    nodeSpacing: 30
---
graph TD

    START(["START"])
    END1(["END"])
    END2(["END"])
    END3(["END"])
    END4(["END"])
    END5(["END"])

    N1["Node 1\\nExtract field values"]
    N2["Node 2\\nValidate + gather data"]

    CONDA{{"Cond Edge A\\nrule-based"}}

    N3["Node 3\\nRequest information"]
    N4["Node 4\\nHITL wait"]
    N5a["Node 5\\nGather metrics"]

    N6["Node 6\\nBuild draft"]
    N8["Node 8\\nPresent draft"]
    N9["Node 9\\nHITL wait"]

    CONDB{{"Cond Edge B\\nintent router"}}

    N12["Node 12\\nSubmit to Solman"]
    N11["Node 11\\nGet information"]
    NS["Node S\\nOutput answer"]
    N10["Node 10\\nParse update intent"]
    N16["Node 16\\nSuccess"]
    N15["Node 15\\nFailed"]
    N5b["Node 5\\nGather metrics"]
    N5c["Node 5\\nGather metrics"]
    N5d["Node 5\\nGather metrics"]
    N13["Node 13\\nApply update"]
    N14["Node 14\\nDeny update"]
    N5e["Node 5\\nGather metrics"]

    N7["Node 7\\nSuggest similar CRs"]
    N17["Node 17\\nPresent top 5 recs"]
    N18["Node 18\\nHITL wait"]

    CONDC{{"Cond Edge C\\nintent router"}}

    N19["Node 19\\nNo recs found"]
    N5f["Node 5\\nGather metrics"]
    N5g["Node 5\\nGather metrics"]

    %% ── Main flow ──────────────────────────────────────────────────────────
    START --> N1
    N1 --> N2
    N2 --> CONDA

    %% ── Cond Edge A branches ────────────────────────────────────────────────
    CONDA -->|platform not given| N3
    CONDA -->|template_id given| N6
    CONDA -->|no template_id| N7

    %% ── Left branch: Node 3 → HITL 4 ───────────────────────────────────────
    N3 --> N4
    N4 -->|relevant response| N1
    N4 -->|exhausted x3| N5a
    N5a --> END1

    %% ── Centre branch: Node 6 → draft review loop ───────────────────────────
    N6 --> N8
    N8 --> N9
    N9 -->|exhausted x3| N5b
    N5b --> END2
    N9 -->|relevant| CONDB

    CONDB -->|approval| N12
    CONDB -->|question| N11
    CONDB -->|update| N10

    N12 -->|success| N16
    N12 -->|fail| N15
    N16 --> N5c
    N15 --> N5c
    N5c --> END3

    N11 --> NS
    NS --> N9

    N10 -->|not locked| N13
    N10 -->|locked field| N14
    N13 --> N8
    N14 --> N5d
    N5d --> END4

    %% ── Right branch: Node 7 → recommendations loop ─────────────────────────
    N7 --> N17
    N17 --> N18
    N18 -->|exhausted x3| N5g
    N5g --> END5
    N18 -->|relevant| CONDC

    CONDC -->|approve CR| N6
    CONDC -->|recommend more| N7
    CONDC -->|max recs hit| N19
    N19 --> N5f
    N5f -.-> END5

    %% ── Styles ──────────────────────────────────────────────────────────────
    classDef llmNode     fill:#dbeafe,stroke:#3b82f6,color:#1e3a5f,rx:6
    classDef hitlNode    fill:#d1fae5,stroke:#10b981,color:#064e3b,rx:6
    classDef commandNode fill:#fef3c7,stroke:#f59e0b,color:#451a03,rx:6
    classDef toolNode    fill:#ede9fe,stroke:#8b5cf6,color:#2e1065,rx:6
    classDef metricsNode fill:#f1f5f9,stroke:#94a3b8,color:#334155,rx:6
    classDef condStyle   fill:#fce7f3,stroke:#ec4899,color:#500724
    classDef termStyle   fill:#e2e8f0,stroke:#64748b,color:#1e293b

    class N1,N3,N6,N7,N8,N11,N13,N14,N15,N16,N17,N19,NS llmNode
    class N4,N9,N18 hitlNode
    class N10,N12 commandNode
    class N2 toolNode
    class N5a,N5b,N5c,N5d,N5e,N5f,N5g metricsNode
    class CONDA,CONDB,CONDC condStyle
    class START,END1,END2,END3,END4,END5 termStyle
"""

# ── Save Markdown file ────────────────────────────────────────────────────────
md_path = os.path.join(_HERE, "cr_agent_diagram.md")
with open(md_path, "w", encoding="utf-8") as f:
    f.write("# CR Agent — LangGraph Flow Diagram\n\n")
    f.write("Paste the block below into **https://mermaid.live** to view interactively.\n\n")
    f.write("```mermaid\n")
    f.write(MERMAID.strip())
    f.write("\n```\n")
print(f"[OK] Markdown : {md_path}")

# ── Save HTML file ────────────────────────────────────────────────────────────
html_path = os.path.join(_HERE, "cr_agent_diagram.html")
html = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>CR Agent — LangGraph Flow Diagram</title>
<script src="https://cdn.jsdelivr.net/npm/mermaid@11/dist/mermaid.min.js"></script>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: system-ui, sans-serif; background: #f8fafc; padding: 24px; color: #1e293b; }
  h1 { font-size: 20px; font-weight: 600; margin-bottom: 4px; }
  p  { font-size: 13px; color: #64748b; margin-bottom: 16px; }
  .legend { display: flex; gap: 10px; flex-wrap: wrap; margin-bottom: 20px; }
  .chip { padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: 500; border: 1px solid rgba(0,0,0,.08); }
  .wrap { background: white; border-radius: 12px; padding: 24px;
          box-shadow: 0 1px 4px rgba(0,0,0,.08); overflow: auto; }
  .mermaid svg { max-width: 100%; height: auto; }
</style>
</head>
<body>
<h1>CR Agent — LangGraph Flow Diagram</h1>
<p>All 21 nodes + Cond Edge A / B / C. Generated from your live graph code.</p>
<div class="legend">
  <span class="chip" style="background:#dbeafe;color:#1e3a5f">LLM node</span>
  <span class="chip" style="background:#d1fae5;color:#064e3b">HITL interrupt</span>
  <span class="chip" style="background:#fef3c7;color:#451a03">Command node</span>
  <span class="chip" style="background:#ede9fe;color:#2e1065">Tool node</span>
  <span class="chip" style="background:#fce7f3;color:#500724">Cond. edge (diamond)</span>
  <span class="chip" style="background:#f1f5f9;color:#334155">Gather metrics</span>
  <span class="chip" style="background:#e2e8f0;color:#1e293b">Start / End</span>
</div>
<div class="wrap">
  <div class="mermaid">
""" + MERMAID.strip() + """
  </div>
</div>
<script>
  mermaid.initialize({
    startOnLoad: true,
    theme: 'default',
    flowchart: { htmlLabels: true, curve: 'linear' }
  });
</script>
</body>
</html>
"""
with open(html_path, "w", encoding="utf-8") as f:
    f.write(html)
print(f"[OK] HTML     : {html_path}")
print("      --> Double-click cr_agent_diagram.html to open in your browser")

# ── Fetch PNG from Mermaid.ink ────────────────────────────────────────────────
print("\nFetching PNG from mermaid.ink (needs internet)...")
try:
    payload = MERMAID.strip().encode("utf-8")
    encoded = base64.urlsafe_b64encode(payload).decode("utf-8").rstrip("=")
    url = f"https://mermaid.ink/img/{encoded}?type=png&width=1400"
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=20) as resp:
        png_bytes = resp.read()
    png_path = os.path.join(_HERE, "cr_agent_diagram.png")
    with open(png_path, "wb") as f:
        f.write(png_bytes)
    print(f"[OK] PNG      : {png_path}")
except Exception as e:
    print(f"[WARN] PNG fetch failed: {e}")
    print("       Use the HTML file instead — it works offline.")

print("""
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 Files saved in your cr_agent\\ folder:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  cr_agent_diagram.html  <-- open in browser  (BEST)
  cr_agent_diagram.md    <-- paste to mermaid.live
  cr_agent_diagram.png   <-- PNG image (if internet ok)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
""")