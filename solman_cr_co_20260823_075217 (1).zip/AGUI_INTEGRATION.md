# AG-UI Integration — CR/CO Agent

## The model

The agent **never ships UI**. The frontend registers a fixed set of React components by name; the agent picks one and supplies JSON props. Anything not in the registry cannot be rendered — that is the point, and it is what the platform team asked for.

```
  Agent (LangGraph)                    Frontend (platform app)
  ─────────────────                    ───────────────────────
  ui_contract.draft_review(...)  ──►   COMPONENT_REGISTRY["draftReview"]
    { version, name, props }             renders <DraftReviewCard props={...} />
                                                   │
  Command(resume=value)          ◄──────────────────┘  respond(value)
```

State channel: `AgentState["ui_component"] = {"version": 1, "name": str, "props": {...}}`.
It rides the AG-UI `STATE_SNAPSHOT` / `STATE_DELTA` stream — no extra transport.

## What the platform team needs

Three things, all machine-readable:

| Artifact | Where |
|---|---|
| Component names + JSON Schemas + example payloads | `GET /api/ui-contract`, or `python -m agui.ui_contract` |
| TypeScript prop interfaces | `frontend/src/agent-ui/types.ts` |
| The registry to merge into their app | `frontend/src/agent-ui/registry.tsx` |

`assertRegistryMatchesContract()` runs in dev and logs any component the agent can emit that the app cannot render, and vice versa. Drift shows up in the console immediately rather than as a blank card in QA.

## Registered components

| Name | Screen | Emitted by |
|---|---|---|
| `crModeChoice` | Single vs Bulk | `GET /api/entry` |
| `featureComingSoon` | "Feature available soon" | `POST /api/cr-mode` (bulk) |
| `crIntakeForm` | Screen 1 — Create Change Request | `POST /api/cr-mode` (single) |
| `templateOrCrPicker` | Screen 2 — Template ID / Reference CR | `node_17_present_top_5` |
| `cycleIdPicker` | Screen 3 — deployment cycle | `node_20_cycle_id_check` |
| `draftReview` | Screen 4 — approval checkpoint | `node_8_present_draft` |
| `fieldPrompt` | Generic ask (missing platform, etc.) | `node_3_request_information` |
| `submissionResult` | Terminal success/failure | `node_15_failed`, `node_16_success` |

## Expandable rows

The designs show collapsed states. Both list-style cards expand, and **the expansion data is supplied by the agent** — the frontend never fetches or derives it.

### Reference CRs (`templateOrCrPicker`)

Each recommended CR expands to its own data: similarity score, platform, target system, change cycle, description. Built by `ui_contract.reference_options_from_baseline()` from `baseline_crs`.

```json
{ "label": "CR ID 654678", "value": "654678", "badge": "Galaxy",
  "details": [
    { "label": "Similarity score", "value": "0.912", "tone": "neutral" },
    { "label": "Platform", "value": "Galaxy", "tone": "positive" },
    { "label": "Description", "value": "…", "wide": true }
  ] }
```

`tone` is set by the agent, never inferred client-side — `positive` on Platform means *the agent matched it against the user's platform*. A row with no `details` renders no disclosure control at all.

**Expanding and selecting are separate actions.** The chevron toggles the panel; the row body selects. Picking a baseline CR determines every field of the resulting draft, so it must not be possible to select one as a side effect of trying to read it.

### Draft fields (`draftReview`)

Two levels: **section → field list → field detail**. Built by `ui_contract.enrich_field_row()`, which reads the same `config.get_field_metadata` / `DROPDOWN_FIELDS` that `node_10` validates edits against — so what the user reads when they expand a field is the ruleset that will actually accept or reject their change.

```json
{ "key": "zzfld00000v_cus", "label": "Risk", "value": "Low",
  "editable": true, "lock_type": null, "field_type": "dropdown",
  "allowed_values": ["Low", "Medium", "High"],
  "section": "Details", "empty": false }
```

Locked fields carry a `lock_reason`:

```json
{ "key": "status_adtnl", "label": "Status", "value": "In Development",
  "editable": false, "lock_type": "system_readonly",
  "lock_reason": "Set by SolMan and cannot be changed through this agent." }
```

That sentence matters on a regulated form. A field that silently refuses to change reads as a bug; a stated reason makes it a visible control. Fields living on `AgentState` rather than `FIELD_GROUPS` (`reason_for_change` and friends) have no SolMan metadata and degrade to plain editable text.

Sections show a `filled/total` count so a user can see at a glance where values are missing without opening everything, and there is an Expand all / Collapse all toggle.

These props are **additive and optional**, so `CONTRACT_VERSION` stays at 1 — a frontend that ignores them still renders correctly. (Bumping the version for an additive change would make older frontends reject the payload outright, which is the opposite of what you want.)

## Single vs Bulk

Bulk is **not** blocked client-side. The tile stays clickable and posts `{"mode":"bulk"}`; the backend answers with the `featureComingSoon` card.

```python
# agui_server.py
BULK_CR_ENABLED = False
```

Flipping that flag is the only change needed here when bulk ships. No frontend change.

## Jira ID behaviour

1. User types — nothing fires.
2. 600 ms after the last keystroke, **or immediately on blur** (leaving the field means they are done), the value is tested against `^[A-Za-z][A-Za-z0-9]+-\d+$`.
3. Only a matching key calls `GET /api/jira-lookup`. A half-typed key produces no request and no error — it is not a mistake yet.
4. On success, Reason and Description are filled **only where the user has not typed their own text**. Hand edits are never overwritten by a later lookup.

Requests are sequence-numbered, so a slow response for an old key cannot overwrite a newer one. The server re-validates the regex rather than trusting the client, and the same pattern is defined on both sides (`JIRA_KEY_PATTERN` in `agui_server.py`, `JIRA_KEY_RE` in `CrIntakeForm.tsx`) so they can be asserted identical in a test.

**IRIS** has no API yet. The field renders per the design but is disabled until `iris_enabled` flips server-side. No frontend change needed then either.

## Running locally

**Windows VM + VS Code → see [RUNNING_ON_WINDOWS.md](RUNNING_ON_WINDOWS.md).**
Short version: `. .\set_env.ps1` then `.\run_agui.ps1`, or the VS Code task
`AG-UI: Run all`.

### Linux / macOS / Git Bash / WSL

```bash
source set_env.sh          # SSM-backed credentials, as usual
./run_agui.sh              # brings up all three processes
```

Then open **http://localhost:8005**.

Three processes, because CopilotKit's React client speaks its own protocol while
`agui_server.py` speaks AG-UI over SSE:

```
  frontend  :8005  (Vite)          the cards
      ↓
  agui_runtime  :8006  (Node)      CopilotKit runtime bridge
      ↓
  agui_server.py  :8084  (Python)  the agent, over AG-UI
```

`run_agui.sh` installs npm deps on first run, waits for the Python backend to
answer `/api/ui-contract` before starting the bridge (a bridge pointed at a dead
backend fails every request with an opaque error), and tears all three down on
Ctrl-C. Logs land in `.agui-logs/`.

### Ports

| Process | Port | Env var |
|---|---|---|
| Vite frontend | 8005 | `FRONTEND_PORT` |
| CopilotKit bridge | 8006 | `AGUI_RUNTIME_PORT` |
| AG-UI backend | 8084 | `AGUI_PORT` |
| *(main.py, unchanged)* | 8081 | `PORT` |

`agui_server.py` reads **`AGUI_PORT`, not `PORT`** — `set_env.sh` sets `PORT=8081`
for `main.py`, and sharing it would make the two servers collide.

### Skipping the bridge

Newer CopilotKit versions can point `runtimeUrl` straight at the Python endpoint.
If that works on your version:

```bash
VITE_AGUI_RUNTIME_URL=http://localhost:8084/copilotkit npm run dev
```

and don't start `agui_runtime`. The bridge is included because it is the
configuration known to work with the pinned `@copilotkit` 1.67.x in
`frontend/package.json`.

### Health checks

```bash
curl localhost:8084/api/ui-contract   # backend + the component contract
curl localhost:8006/health            # bridge → backend wiring
```

In dev the browser console also logs whether the frontend registry matches the
backend contract.

## Adding a component

1. Name + prop schema + builder in `agui/ui_contract.py`
2. Props interface + union member in `frontend/src/agent-ui/types.ts`
3. Component + registry entry in `frontend/src/agent-ui/registry.tsx`

All three must agree. The dev-time check catches 1↔3; the compiler catches 2↔3.

## Notes for review

**Frontend does no stage-sniffing.** The previous iteration inferred which screen to show by inspecting state (`labels.includes("Similarity score:")`, `options.some(o => o.value === "approve")`). All of that is gone — the backend names the component. If a heuristic reappears in `App.tsx`, the fix belongs in `ui_contract.py`.

**Placeholder recommendations are filtered server-side.** `reference_options_from_baseline` skips any `baseline_crs` slot carrying an `error`. `node_7` writes fabricated `object_id`s (`CR_0`…`CR_4`) on embedding failure, and those must never be offered to a user as real change requests. This is a guard, not a fix — the underlying `node_7` behaviour is tracked separately in the code review.

**Draft approval emits literal tokens.** The action buttons send `approve` / `reject`, never prose. `cond_edge_b`'s approval guard is a substring test that free text trips.

**Submitted-with-no-CR-ID renders as an error,** not a success. `solman_write` can return `success:true` with `cr_id:null`; telling a user their CR was created with no identifier to reconcile against is worse than telling them to check.

**Unknown component / unknown version / malformed envelope** all degrade to a visible fallback card. On a regulated approval path a user must never be left staring at a blank panel wondering whether their CR went through.

**Superseded files were deleted,** not left in place: `CRForm.tsx`, `DraftReview.tsx`, `CrRecommendations.tsx`, `CycleIdSuggestions.tsx`, and the old `HitlInterrupt.tsx` (replaced by the slimmed `agent-ui/useHitlInterrupt.tsx`).

## What this branch changes

**New files** — nothing existing depends on them:

```
agui/ui_contract.py            the contract: names, schemas, builders, adapters
agui_server.py                 FastAPI AG-UI host + /api/* helpers
agui_runtime/                  CopilotKit runtime bridge (Node)
frontend/                      React cards + registry
run_agui.sh                    local dev launcher
AGUI_INTEGRATION.md            this file
```

**Modified files** — small and additive:

| File | Change |
|---|---|
| `state/state.py` | `ui_component` channel + its initial value |
| `agents/nodes/nodes_intake.py` | `ui_contract` import; `ui_component` on node_3's return |
| `agents/nodes/nodes_review.py` | `ui_contract` + `_build_draft_field_groups` imports; `ui_component` on node_8's patch |
| `agents/nodes/nodes_outcome.py` | `ui_contract` import; `ui_component` on node_15, node_16, node_17, node_20 |
| `agents/nodes/_helpers.py` | `_build_current_field_values` + `_build_draft_field_groups` (see below) |
| `requirements.txt` | `fastapi`, `copilotkit`, `ag-ui-langgraph` |
| `.gitignore` | `node_modules/`, `.agui-logs/`, Vite output |

`main.py` is untouched and imports none of this — the AgentCore runtime behaves
exactly as before.

### Why `_build_draft_field_groups` came back

This refactor removed `field_groups` / `update_notices` / `submission_result` from
`UIState`, so there was no longer a structured view of the draft for a UI to
render — only the markdown blob in `draft_html`.

`_helpers._build_draft_field_groups(state)` rebuilds it from the **merged API
payload** (`template_id.data` overlaid with `cr_id.data`), which is exactly what
`solman_write` overlays onto the baseline at submit time. That choice is
deliberate: deriving the review card from any other source would let a user
approve one set of values while a different set is submitted.

It does no DB round-trip — it runs on every draft render, and Neo4j is a drafting
fallback, not the record of what will be sent.

## Notes from integration

Two things worth a look, neither introduced here:

**`COMPLIANCE_LOCKED_FIELDS` does not include the GxP fields.** It currently holds
`standard_change_adtnl`, `operate_change_adtnl`, `aprv_proc_adtnl`,
`release_type_ctx`, `transaction_type_scope`. The five tests in
`TestComplianceLockedFields` that assert GxP Relevant, SOX Impact, Security
Change, RICEF and SoD Ruleset are locked are all `@pytest.mark.skip`-ed with
*"pending implementation"*. Until that lands, those five fields render in the
draft review card as **editable, with no lock reason** — which is what the config
currently says they are.

**Placeholder recommendations are filtered at the UI boundary.**
`reference_options_from_baseline` skips any `baseline_crs` slot carrying an
`error`, because `node_7` writes fabricated `object_id`s (`CR_0`…`CR_4`) on
embedding failure. That is a guard, not a fix — the `node_7` behaviour is still
there and is tracked in the code review.
