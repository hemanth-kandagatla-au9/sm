"""
tools/tools.py
--------------
Tool layer — all external integrations for CR Agent nodes.

FIELD MAPPING (derived from actual Neo4j ChangeRequest properties):
  CR agent field    | Neo4j property        | Example value from DB
  ──────────────────┼───────────────────────┼──────────────────────────────
  platform          | platform              | "HMD", "Central Finance SAP"
  target_system     | configuration_descr   | "EJ1 0020230804 100"
  template_id       | object_id             | "50339227"
  configuration     | configuration_descr   | "EJ1 0020230804 100"
  process_type      | process_type_ctx      | "ZMCR"
  logical_system    | logical_system        | "CONSSMP230"
  project_title     | project_title_ctx     | "MARS SDDC ECC Landscape"

  NOTE: platform is joined from solmancr.platform via fetch_merged_crhd JOIN.
        Entity nodes: Platform, TargetSystem, ChangeType, Priority, Status, Project.

  Confirmed from: MATCH (c:ChangeRequest) RETURN properties(c) LIMIT 1
"""
from __future__ import annotations

import json
import os
import re as _re
import difflib as _difflib
from observability import get_logger
import time
from typing import Optional

import requests

import urllib3
from langchain_core.messages import HumanMessage, SystemMessage
from config.config import (
    JIRA_BASE_URL,
    JIRA_RESOURCE_PATH,
    JIRA_API_TOKEN,
    JIRA_USERNAME,
    JIRA_PASSWORD,
    TRANSACTION_TYPE_RULES,
    TRANSACTION_TYPE_OPTIONS_MATRIX,
    DROPDOWN_FIELDS,
    PLATFORM_ALIASES,
    TARGET_SYSTEM_PLATFORM_MAP,
    SOLMAN_BASE_URL,
    SOLMAN_API_KEY,
    SOLMAN_READ_BASE_URL,
    SOLMAN_READ_USERNAME,
    SOLMAN_READ_PASSWORD,
    SOLMAN_READ_VERIFY_SSL,
    SOLMAN_ODATA_PATH,
    ODATA_FIELD_MAP,
    ODATA_FIELD_MAP_REVERSE,
    SOP_PATH,
    get_settings,
)
from utils.llm import get_llm_fast

# Suppress SSL warnings for SAP environments with self-signed certs
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

logger = get_logger(__name__)

# ── Load SOP out-of-scope paragraph (Section 2.1) at module level ─────────────
def _load_sop_text() -> str:
    try:
        with open(SOP_PATH, encoding="utf-8") as _f:
            return _f.read().strip()
    except OSError:
        logger.debug("validate_change_scope: SOP file not found at %s", SOP_PATH)
        return ""

_SOP_TEXT: str = _load_sop_text()


# ─────────────────────────────────────────────────────────────────────────────
# Tool 0 (Node 2): validate_change_scope
# LLM-based scope classifier — fires before all other validation.
# ─────────────────────────────────────────────────────────────────────────────
_SCOPE_SYSTEM_PROMPT_TEMPLATE = """
You are a SAP Solution Manager scope validator following SOP-8794 
(J&J Enterprise Resource Planning Systems Change Management SOP).

Your job is to classify whether a user's change request is in scope 
for SAP Solution Manager or not.

IN SCOPE (Section 2):
- Changes to SAP ERP platforms: Back to Basics SAP, Crossroads SAP, 
  USROTC, Atlas SAP, Concourse ATTP, MARS SAP, PandA SAP, Vista LATAM,
  Enterprise Solution Manager, Taishan SAP, Central Finance SAP, 
  Hospital Medical Devices ERP, Surgical Vision SAP, Fusion SAP, 
  Innovative Medicine (TIME), ABIOMED, MedTech, WMS EWM, Europe2, 
  Galaxy, SNC, Sustain, eWM GMED, Symphony Treasury
- Change types in scope: configuration, security/role design, reports, 
  forms, enhancements, conversions, SAP Notes, interfaces, workflows, 
  batch jobs, SAP profile parameters
- Environments: Development, Quality, Production

OUT OF SCOPE — use the following verbatim SOP paragraph as your authority:

{sop_out_of_scope}

Rules:
- If the change is about infrastructure, OS, database/network patches, SAN, 
  SAP kernel/executables, or Basis changes → OUT_OF_SCOPE, redirect to IRIS
- If the change is about Master Data managed by business data owners, 
  business SOPs/WIs, or Winshuttle uploads for Production support → 
  OUT_OF_SCOPE, redirect to Business SOP
- Otherwise → IN_SCOPE

Respond ONLY in this exact JSON format with no extra text, 
no markdown, no code blocks:
{{
  "classification": "IN_SCOPE" or "OUT_OF_SCOPE" or "UNCLEAR",
  "reason": "one sentence explanation",
  "redirect": "IRIS" or "Business SOP" or null
}}
"""

_SCOPE_SYSTEM_PROMPT: str = _SCOPE_SYSTEM_PROMPT_TEMPLATE.format(
    sop_out_of_scope=_SOP_TEXT if _SOP_TEXT else "(SOP text unavailable — use general knowledge)"
)


def validate_change_scope(user_message: str) -> dict:
    """
    Classify whether user_message describes an in-scope Solution Manager change.

    Returns dict with keys: classification, reason, redirect, raw_response.
    Never raises — on any failure returns classification=UNCLEAR so the caller
    can continue with normal flow.
    """
    try:
        from langchain_openai import AzureChatOpenAI
        from config.config import (
            AZURE_OPENAI_API_KEY, AZURE_OPENAI_ENDPOINT,
            AZURE_OPENAI_API_VERSION, MODEL_NAME,
        )
        # temperature=0 for deterministic scope classification
        llm = AzureChatOpenAI(
            azure_deployment=MODEL_NAME,
            azure_endpoint=AZURE_OPENAI_ENDPOINT,
            api_key=AZURE_OPENAI_API_KEY,
            api_version=AZURE_OPENAI_API_VERSION,
            #temperature=0,
            streaming=False,
        )
        response = llm.invoke([
            SystemMessage(content=_SCOPE_SYSTEM_PROMPT),
            HumanMessage(content=user_message),
        ])
        raw = response.content if hasattr(response, "content") else str(response)
        try:
            parsed = json.loads(raw)
            return {
                "classification": parsed.get("classification", "UNCLEAR"),
                "reason":         parsed.get("reason", ""),
                "redirect":       parsed.get("redirect"),
                "raw_response":   raw,
            }
        except (json.JSONDecodeError, ValueError):
            logger.warning("validate_change_scope: JSON parse failed — raw: %s", raw)
            return {
                "classification": "UNCLEAR",
                "reason":         "Could not classify request",
                "redirect":       None,
                "raw_response":   raw,
            }
    except Exception as exc:
        logger.warning("validate_change_scope: LLM call failed: %s", exc)
        return {
            "classification": "UNCLEAR",
            "reason":         "Scope check unavailable",
            "redirect":       None,
            "raw_response":   "",
        }


# ─────────────────────────────────────────────────────────────────────────────
# FIELD MAP — exact Neo4j property names from your ChangeRequest nodes
# Source: MATCH (c:ChangeRequest) RETURN properties(c) LIMIT 1
# ─────────────────────────────────────────────────────────────────────────────
FIELD_MAP = {
    # CR agent concept   →  actual Neo4j property name
    "platform":           "platform",              # e.g. "HMD", "Central Finance"
    "target_system":      "configuration_descr",   # e.g. "EJ1 0020230804 100"
    "template_id":        "object_id",             # e.g. "50339227"
    "configuration":      "configuration_descr",   # e.g. "EJ1 0020230804 100"
    "process_type":       "process_type_ctx",      # e.g. "ZMCR"
    "logical_system":     "logical_system",        # e.g. "CONSSMP230"
    "project_title":      "project_title_ctx",     # e.g. "MARS SDDC ECC Landscape"
    "slan_name":          "slan_name_ctx",         # e.g. "MARS_ECC_SDDC_EJ1"
    "description":        "description",           # e.g. "Add Missing auth in GFS role"
    "priority":           "priority_adtnl",        # e.g. "4: Low"
    "risk":               "risk_adtnl",            # e.g. "Low"
}

# These are the searchable fields the agent exposes to the user
SEARCHABLE_FIELDS = [
    "platform",       # platform
    "target_system",  # configuration_descr
    "configuration",  # configuration_descr
    "process_type",   # process_type_ctx
    "logical_system", # logical_system
    "project_title",  # project_title_ctx
]


# ─────────────────────────────────────────────────────────────────────────────
# Internal helper — shared Cypher executor
# ─────────────────────────────────────────────────────────────────────────────

def _run_cypher(query: str, params: dict | None = None) -> list[dict]:
    """Execute Cypher and return rows. Returns [{"error":...}] on failure."""
    try:
        from neo4j import GraphDatabase
        s = get_settings()
        driver = GraphDatabase.driver(
            s.neo4j_uri,
            auth=(s.neo4j_user, s.neo4j_password),
        )
        with driver.session(database=s.neo4j_database) as session:
            result = session.run(query, parameters=params or {})
            rows = [dict(record) for record in result]
        driver.close()
        return rows
    except ImportError as ie:
        logger.warning("neo4j import error: %s", ie)
        return [{"error": f"neo4j import error: {ie}"}]
    except Exception as exc:
        logger.warning("cypher error: %s", exc)
        return [{"error": str(exc)}]


def _validate_field(
    field_name: str,
    user_value: str,
) -> dict:
    """
    Generic validator — queries ChangeRequest nodes for a given field.

    Tries exact match first, then partial (CONTAINS) match.
    Returns available sample values in the error message if no match found.
    """
    neo4j_prop = FIELD_MAP.get(field_name)
    if not neo4j_prop:
        return {
            "valid": False,
            "canonical": None,
            "candidates": [],
            "error": f"Unknown field: {field_name}",
        }

    # ── 1. Exact match ────────────────────────────────────────────────────────
    exact_q = f"""
    MATCH (c:ChangeRequest)
    WHERE c.{neo4j_prop} IS NOT NULL
      AND toLower(toString(c.{neo4j_prop})) = toLower($val)
    RETURN DISTINCT toString(c.{neo4j_prop}) AS name
    LIMIT 5
    """
    rows = _run_cypher(exact_q, {"val": user_value})
    names = [r["name"] for r in rows if r.get("name") and not r.get("error")]

    if not names:
        # ── 2. Partial / CONTAINS match ───────────────────────────────────────
        partial_q = f"""
        MATCH (c:ChangeRequest)
        WHERE c.{neo4j_prop} IS NOT NULL
          AND toLower(toString(c.{neo4j_prop})) CONTAINS toLower($val)
        RETURN DISTINCT toString(c.{neo4j_prop}) AS name
        LIMIT 5
        """
        rows = _run_cypher(partial_q, {"val": user_value})
        names = [r["name"] for r in rows if r.get("name") and not r.get("error")]

    if names:
        logger.info("validate %s: '%s' → %s", field_name, user_value, names)
        return {
            "valid":      True,
            "canonical":  names[0],
            "candidates": names,
            "error":      None,
        }

    # ── 3. Not found — return helpful sample values ───────────────────────────
    sample_q = f"""
    MATCH (c:ChangeRequest)
    WHERE c.{neo4j_prop} IS NOT NULL
      AND toString(c.{neo4j_prop}) <> ''
      AND toString(c.{neo4j_prop}) <> 'None'
      AND toString(c.{neo4j_prop}) <> 'N/A'
    RETURN DISTINCT toString(c.{neo4j_prop}) AS name
    ORDER BY name
    LIMIT 15
    """
    sample_rows = _run_cypher(sample_q)
    samples = [
        r["name"] for r in sample_rows
        if r.get("name") and not r.get("error")
    ]

    logger.warning(
        "validate %s: no match for '%s'. Samples: %s",
        field_name, user_value, samples
    )
    return {
        "valid":      False,
        "canonical":  None,
        "candidates": [],
        "error": (
            f"'{user_value}' not found in Neo4j for {field_name} "
            f"(property: {neo4j_prop}). "
            f"Available values: {samples}"
        ),
    }


# ─────────────────────────────────────────────────────────────────────────────
# Tool 1 (Node 2): get_template
#
# Fetch order:
#   1. Solman OData READ API (primary — most current data)
#   2. Neo4j fallback (if API fails or not configured)
#
# OData endpoint:
#   GET /sap/opu/odata/sap/zchm1_srv/inputfieldSet('{template_id}')
#   Auth: Basic (SOLMAN_READ_USERNAME / SOLMAN_READ_PASSWORD)
#   SSL:  verify=SOLMAN_READ_VERIFY_SSL (false for self-signed certs)
#
# Response handling — both OData formats supported:
#   Format A (single record): {"d": {"object_id": ..., "description": ...}}
#   Format B (collection):    {"d": {"results": [{"object_id": ..., ...}]}}
# ─────────────────────────────────────────────────────────────────────────────
def _parse_odata_response(data: dict, template_id: str) -> dict:
    """
    Parse OData response from ZCHM_RFC_SRV ChangeRequestSet.

    Handles two formats:
      Format A — ZCHM_RFC_SRV nested groups (IvDetails, IvOthers, etc.)
                 → Returns nested structure preserving Iv* group names
      Format B — legacy flat single record or collection with results array
                 → Returns flat dict

    Returns dict with nested groups or flat dict or error dict.
    """
    if not isinstance(data, dict):
        return {"error": f"Unexpected response type: {type(data)}", "template_id": template_id}

    # Unwrap OData "d" envelope
    d = data.get("d", data)

    if not isinstance(d, dict):
        return {"error": "OData 'd' field is not a dict", "template_id": template_id}

    # Format B — legacy collection with results array
    results = d.get("results")
    if isinstance(results, list):
        if not results:
            return {"error": f"No results found for template_id '{template_id}'", "template_id": template_id}
        record = dict(results[0])
        record.pop("__metadata", None)
        record["template_id"] = template_id
        return record

    # Format A — ZCHM_RFC_SRV nested groups
    # Detect by presence of any known Iv* group key
    known_groups = {
        "IvDetails", "IvOthers", "IvValidation", "IvFunctionalArea",
        "IvDocumentation", "IvTestReq", "IvLocation", "IvScope", "IvContext",
    }
    
    if known_groups.intersection(d.keys()):
        # Return nested structure preserving original API group names
        # This allows both UI rendering (app.py handles name mapping)
        # AND correct SAP submission (payload has IsX group names)
        result: dict = {}
        
        for api_group_name, group_data in d.items():
            if api_group_name in (
                "__metadata",
                "IvTemplateId", "IvTemplateID",
                "EvMessage", "EvObjectId", "EvObjectID",
                "IvRequestor", "EvHasError",
                "toTexts", "toReturn", "toPartners",
            ):
                continue
            if not isinstance(group_data, dict):
                continue
            
            # Clean the group data (remove __metadata, convert datetimes)
            clean_group = {}
            for field_key, field_val in group_data.items():
                if field_key == "__metadata":
                    continue
                # Convert datetime objects to ISO strings for JSON serialization
                if hasattr(field_val, "isoformat"):
                    clean_group[field_key] = field_val.isoformat()
                elif field_val is None:
                    clean_group[field_key] = ""
                else:
                    clean_group[field_key] = field_val
            
            # Strip leading zeros from ConfigurationItem at parse time so the value
            # stored in state is already clean (e.g. "7100002899" not "0000...7100002899").
            if api_group_name == "IvScope" and "ConfigurationItem" in clean_group:
                _raw_ci = str(clean_group["ConfigurationItem"]).strip()
                clean_group["ConfigurationItem"] = _raw_ci.lstrip("0") or _raw_ci

            # Keep original API group name so submission payloads work correctly with SAP
            result[api_group_name] = clean_group

        # Add top-level EvObjectId as a reference
        ev_object_id = d.get("EvObjectID", "") or d.get("EvObjectId", "")
        if ev_object_id:
            result["EvObjectId"] = ev_object_id

        result["template_id"] = template_id
        
        total_fields = sum(len(g) for g in result.values() if isinstance(g, dict) and g not in (result.get("template_id"), result.get("EvObjectId")))
        logger.info(
            "_parse_odata_response: preserved nested structure with %d groups (Format A) for template_id=%s",
            len([x for x in result.keys() if x.startswith("Is") or x.startswith("Iv")]), template_id
        )
        return result

    # Fallback — plain flat single record in "d"
    props = dict(d)
    props.pop("__metadata", None)
    props["template_id"] = template_id
    return props


def _build_solman_get_urls(object_id: str) -> list[str]:
    """Build candidate ChangeRequestSet GET URLs for SAP service variants.

    Primary form uses URL-encoded quotes (%27) as required by ZCHM_RFC_SRV:
      ChangeRequestSet(%2750174545%27)?$expand=toTexts,toPartners&$format=json
    Fallbacks try plain quotes and without $expand for older services.
    """
    base = f"{SOLMAN_READ_BASE_URL}{SOLMAN_ODATA_PATH}"
    oid = str(object_id).strip()
    return [
        f"{base}(%27{oid}%27)?$expand=toTexts,toPartners&$format=json",
        f"{base}('{oid}')?$expand=toTexts,toPartners&$format=json",
        f"{base}(%27{oid}%27)?$format=json",
        f"{base}('{oid}')?$format=json",
    ]


def _get_template_from_api(template_id: str) -> dict:
    """
    Fetch CR from Solman OData ChangeRequestSet with text/partner expansion.
    Also captures the CSRF token for subsequent POST calls.
    Returns parsed props dict (with '_csrf_token' key) or raises on failure.
    """
    if not SOLMAN_READ_BASE_URL or not SOLMAN_READ_USERNAME:
        raise ValueError("SOLMAN_READ_BASE_URL or SOLMAN_READ_USERNAME not configured")

    logger.info("get_template: calling ChangeRequestSet for template_id=%s", template_id)
    logger.info("get_template: SOLMAN_ODATA_PATH=%s", SOLMAN_ODATA_PATH)

    last_exc: Exception | None = None
    for idx, url in enumerate(_build_solman_get_urls(template_id), start=1):
        logger.info("get_template: GET URL attempt %d=%s", idx, url)
        try:
            response = requests.get(
                url,
                auth=(SOLMAN_READ_USERNAME, SOLMAN_READ_PASSWORD),
                headers={
                    "Accept": "application/json",
                    "X-CSRF-Token": "Fetch",
                },
                verify=SOLMAN_READ_VERIFY_SSL,
                timeout=30,
            )
            response.raise_for_status()

            # Capture CSRF token returned by SAP in the response header
            csrf_token = response.headers.get("X-CSRF-Token", "")

            try:
                data = response.json()
                logger.info("get_template: ChangeRequestSet returned JSON for template_id=%s", template_id)
            except ValueError:
                logger.warning("get_template: non-JSON response, returning raw text")
                return {"raw_response": response.text, "template_id": template_id, "_csrf_token": csrf_token}

            props = _parse_odata_response(data, template_id)
            props["_csrf_token"] = csrf_token
            return props
        except Exception as exc:
            last_exc = exc
            logger.warning("get_template: GET URL attempt %d failed: %s", idx, exc)

    raise RuntimeError(f"all ChangeRequestSet GET URL attempts failed for template_id={template_id}: {last_exc}")



def _get_template_from_neo4j(template_id: str) -> dict:
    """
    Fallback: fetch CR properties from Neo4j by object_id.
    Returns parsed props dict or error dict.
    """
    logger.info("get_template: falling back to Neo4j for template_id=%s", template_id)

    rows = _run_cypher(
        "MATCH (c:ChangeRequest {object_id: $oid}) "
        "RETURN properties(c) AS props LIMIT 1",
        {"oid": template_id},
    )

    if not rows or rows[0].get("error") or not rows[0].get("props"):
        return {
            "error": f"No CR found with template_id '{template_id}' in Neo4j",
            "template_id": template_id,
        }

    props = dict(rows[0]["props"])

    # Convert DateTime objects to strings
    for k, v in list(props.items()):
        if v is None:
            continue
        if hasattr(v, "isoformat"):
            props[k] = v.isoformat()
        elif not isinstance(v, (str, int, float, bool, list, dict)):
            props[k] = str(v)

    props["template_id"] = template_id
    logger.info(
        "get_template: Neo4j returned %d fields for template_id=%s",
        len(props), template_id,
    )
    return props


def get_template(template_id: str) -> dict:
    """
    Fetch CR template data for the given template_id.

    Fetch order:
      1. Solman OData READ API  (primary — live data)
      2. Neo4j                  (fallback — if API fails or not configured)

    Returns all CR properties as a flat dict, or error dict on failure.
    """
    tid = str(template_id).strip()
    if not tid:
        return {"error": "template_id is empty", "template_id": template_id}

    # ── Step 1: Try Solman OData API ─────────────────────────────────────────
    if SOLMAN_READ_BASE_URL and SOLMAN_READ_USERNAME:
        try:
            props = _get_template_from_api(tid)
            if "error" not in props:
                logger.info(
                    "get_template: SUCCESS via Solman API for template_id=%s (%d fields)",
                    tid, len(props),
                )
                return props
            logger.warning("get_template: API returned error — %s", props.get("error"))
        except Exception as exc:
            logger.warning(
                "get_template: Solman API failed for %s: %s — falling back to Neo4j",
                tid, exc,
            )
    else:
        logger.info(
            "get_template: Solman API not configured — using Neo4j directly"
        )

    # ── Step 2: Fallback to Neo4j ─────────────────────────────────────────────
    try:
        props = _get_template_from_neo4j(tid)
        if "error" not in props:
            logger.info(
                "get_template: SUCCESS via Neo4j fallback for template_id=%s (%d fields)",
                tid, len(props),
            )
            return props
        return props
    except Exception as exc:
        logger.warning("get_template: Neo4j fallback also failed for %s: %s", tid, exc)
        return {"error": str(exc), "template_id": tid}


# ─────────────────────────────────────────────────────────────────────────────
# Tool 2 (Node 2): get_jira_data — Jira REST (no DB equivalent)
# ─────────────────────────────────────────────────────────────────────────────
def get_jira_data(jira_id: str) -> dict:
    """
    Fetch Jira ticket via SAP Solman OData proxy (zjira_srv).

    Endpoint: {JIRA_BASE_URL}/{JIRA_RESOURCE_PATH}('{jira_id}')
    Auth:     Basic auth using SOLMAN_READ_USERNAME / SOLMAN_READ_PASSWORD

    Response structure:
            d.EvDescription  — ticket title/summary (legacy service)
            d.EvMessage      — status/message (ZJIRA_SRV)
      d.EvResponse     — full Jira fields as a JSON *string* (needs json.loads)
        fields.summary               → used as reason_for_change
        fields.description           → used as description_of_change
        fields.duedate               → used as planned_impl_dt_adtnl
        fields.customfield_10104     → System - Regression Test ID
        fields.customfield_10105     → UAT Test ID
      d.EvStatus       — ticket status

    Returns a clean dict:
      {
        "jira_id":              str,
        "summary":              str,   ← maps to reason_for_change
        "description":          str,   ← maps to description_of_change
        "status":               str,
        "due_date":             str,   ← maps to planned_impl_dt_adtnl (ISO date or "")
        "regression_test_id":   str,   ← maps to zzfld00000v_cus / zzfld00004y
        "uat_test_id":          str,   ← maps to zzfld00000w_cus / zzfld00004x
        "raw":                  dict,  ← full parsed EvResponse fields
      }
    or on error: {"error": str, "jira_id": str}
    """
    jira_id = str(jira_id).strip()
    encoded_id = f"'{jira_id}'"
    url = f"{JIRA_BASE_URL}/{JIRA_RESOURCE_PATH}({encoded_id})?$format=json"

    logger.info("get_jira_data: fetching %s → %s", jira_id, url)

    max_attempts = 3
    retry_delay  = 2  # seconds between retries

    last_exc: Exception | None = None
    for attempt in range(1, max_attempts + 1):
        try:
            resp = requests.get(
                url,
                auth=(JIRA_USERNAME, JIRA_PASSWORD),
                headers={"Accept": "application/json"},
                verify=SOLMAN_READ_VERIFY_SSL,
                timeout=15,
            )
            logger.info("get_jira_data: HTTP %s for %s (attempt %d)", resp.status_code, jira_id, attempt)
            resp.raise_for_status()

            outer = resp.json()
            logger.debug("get_jira_data: raw outer keys = %s", list(outer.get("d", {}).keys()))

            d = outer.get("d", {})

            # ZJIRA_SRV returns EvMessage/EvResponse; older proxy returned
            # EvDescription/EvStatus as separate fields.
            ev_description: str = d.get("EvDescription", "").strip()
            ev_message: str = d.get("EvMessage", "").strip()

            # EvResponse is the full Jira payload as a *JSON string* — must parse it
            ev_response_raw: str = (d.get("EvResponse", "") or "").strip()
            ev_status: str = d.get("EvStatus", "").strip() or ev_message

            fields: dict = {}
            if ev_response_raw:
                try:
                    ev_parsed = json.loads(ev_response_raw)
                    fields = ev_parsed.get("fields", {})
                    logger.info(
                        "get_jira_data: EvResponse parsed — summary=%r, description_len=%d",
                        fields.get("summary", "")[:80],
                        len(fields.get("description") or ""),
                    )
                except (json.JSONDecodeError, TypeError) as parse_err:
                    logger.warning("get_jira_data: failed to parse EvResponse for %s: %s", jira_id, parse_err)

            # Prefer fields.summary; fall back to EvDescription
            summary: str = (fields.get("summary") or ev_description or "").strip()
            description: str = (fields.get("description") or "").strip()

            # If both are still empty, retry — the SAP JIRA proxy sometimes returns
            # a valid HTTP 200 with an empty EvResponse on the first call.
            if not summary and not description:
                logger.warning(
                    "get_jira_data: no summary or description found for %s (attempt %d/%d)%s",
                    jira_id, attempt, max_attempts,
                    " — retrying" if attempt < max_attempts else " — giving up",
                )
                if attempt < max_attempts:
                    time.sleep(retry_delay)
                    continue

            # New fields
            due_date: str = (fields.get("duedate") or "").strip()
            regression_test_id: str = str(fields.get("customfield_10104") or "").strip()
            uat_test_id: str = str(fields.get("customfield_10105") or "").strip()

            result = {
                "jira_id":            jira_id,
                "summary":            summary,
                "description":        description,
                "status":             ev_status,
                "due_date":           due_date,
                "regression_test_id": regression_test_id,
                "uat_test_id":        uat_test_id,
                "raw":                fields,
            }
            logger.info(
                "get_jira_data: ✓ jira_id=%s summary=%r description=%r status=%r "
                "due_date=%r regression_test_id=%r uat_test_id=%r",
                jira_id, summary[:80], description[:80], ev_status,
                due_date, regression_test_id, uat_test_id,
            )
            logger.info("get_jira_data: FULL description = %r", description)
            return result

        except Exception as exc:
            logger.warning("get_jira_data: ✗ failed for %s (attempt %d/%d): %s", jira_id, attempt, max_attempts, exc)
            last_exc = exc
            if attempt < max_attempts:
                time.sleep(retry_delay)

    return {"error": str(last_exc) if last_exc else "empty response after retries", "jira_id": jira_id}


# ─────────────────────────────────────────────────────────────────────────────
# Tool 2b: generate_cr_fields_from_jira
# LLM transformation — converts raw JIRA summary + description into formal
# SAP Solution Manager Reason for Change and Description of Change.
# ─────────────────────────────────────────────────────────────────────────────
_JIRA_TO_CR_SYSTEM_PROMPT = """
You are an SAP Solution Manager Change Request writer.
Given a JIRA ticket's summary and description, generate two formal CR fields
in clear, professional SAP CR language.

CRITICAL RULE — NO HALLUCINATION:
You must ONLY use information that is explicitly present in the JIRA input provided.
NEVER invent, assume, or infer any of the following unless they appear word-for-word in the input:
  - SAP Note numbers (e.g. do NOT write "SAP Note 1234567")
  - Transaction codes (e.g. do NOT write "SNOTE", "SE38", "SM30" unless in input)
  - Table names (e.g. do NOT write "ZTABLE" unless in input)
  - Program names (e.g. do NOT write "ZPROGRAM" unless in input)
  - Any specific technical identifiers not present in the input
If the JIRA input lacks technical detail, describe the change in general terms only.

Additional rules:
- Reason for Change: explain WHY the change is needed — the problem, its impact,
  and justification. 2-4 sentences. No bullet points.
- Description of Change: explain WHAT will technically be done based strictly
  on information in the JIRA input. 2-4 sentences. No bullet points.
- Keep language simple, formal, and concise.
- Do NOT copy the JIRA text verbatim — rewrite it in CR language.

Respond ONLY in this exact JSON format with no extra text:
{
  "reason_for_change": "...",
  "description_of_change": "..."
}
"""


def generate_cr_fields_from_jira(summary: str, description: str) -> dict:
    """
    Use LLM to generate formal SAP CR fields from raw JIRA ticket content.

    Args:
        summary:     fields.summary from JIRA (short title)
        description: fields.description from JIRA (informal problem text)

    Returns:
        {
            "reason_for_change":     str,  ← formal WHY
            "description_of_change": str,  ← formal WHAT
            "error":                 str | None,
        }
    Falls back to raw values on LLM failure.
    """
    import re

    def _strip_hallucinated_identifiers(text: str, jira_source: str) -> str:
        """
        Remove SAP Note numbers and transaction codes from LLM output
        if they are not present in the original JIRA input.

        Patterns removed if not in jira_source:
          - SAP Note numbers: 7-digit standalone numbers (e.g. 2806418)
          - "SAP Note XXXXXXX" / "Note XXXXXXX" phrases
          - Transaction codes: 2-10 uppercase alphanumeric words preceded by
            "transaction" keyword (e.g. "transaction SNOTE", "via SNOTE")
        """
        source_lower = jira_source.lower()

        # Remove "SAP Note XXXXXXX" / "Note XXXXXXX" if note number not in source
        def _remove_note_phrase(m: re.Match) -> str:
            note_num = m.group(2)
            if note_num not in jira_source:
                logger.warning(
                    "generate_cr_fields_from_jira: stripped hallucinated SAP Note %s", note_num
                )
                return ""
            return m.group(0)

        text = re.sub(
            r"\b(SAP\s+Note|Note)\s+(\d{7,8})\b",
            _remove_note_phrase,
            text,
            flags=re.IGNORECASE,
        )

        # Remove standalone 7-8 digit numbers not in source (likely note numbers)
        def _remove_standalone_number(m: re.Match) -> str:
            num = m.group(0)
            if num not in jira_source:
                logger.warning(
                    "generate_cr_fields_from_jira: stripped hallucinated number %s", num
                )
                return ""
            return num

        text = re.sub(r"\b\d{7,8}\b", _remove_standalone_number, text)

        # Remove "transaction XXXX" / "via XXXX" / "using XXXX" where XXXX is
        # an uppercase-only token not found in source
        def _remove_tcode_phrase(m: re.Match) -> str:
            tcode = m.group(2)
            if tcode.lower() not in source_lower:
                logger.warning(
                    "generate_cr_fields_from_jira: stripped hallucinated tcode %s", tcode
                )
                return m.group(1)  # keep the verb, drop the tcode
            return m.group(0)

        text = re.sub(
            r"\b(transaction|via|using)\s+([A-Z][A-Z0-9_]{1,9})\b",
            _remove_tcode_phrase,
            text,
        )

        # Clean up double spaces or leading commas left by removals
        text = re.sub(r"\s{2,}", " ", text).strip()
        text = re.sub(r"\s+\.", ".", text)
        return text

    summary = (summary or "").strip()
    description = (description or "").replace("\r\n", "\n").replace("\r", "\n").strip()
    jira_source = f"{summary} {description}"

    if not summary and not description:
        return {
            "reason_for_change":     "",
            "description_of_change": "",
            "error":                 "No JIRA content to process",
        }

    user_content = f"JIRA Summary: {summary}\n\nJIRA Description: {description}"

    try:
        llm = get_llm_fast()
        response = llm.invoke([
            SystemMessage(content=_JIRA_TO_CR_SYSTEM_PROMPT),
            HumanMessage(content=user_content),
        ])
        raw = response.content if hasattr(response, "content") else str(response)

        try:
            parsed = json.loads(raw)
            reason = (parsed.get("reason_for_change") or "").strip()
            doc    = (parsed.get("description_of_change") or "").strip()

            # ── Post-processing: strip any hallucinated identifiers ────────────
            reason = _strip_hallucinated_identifiers(reason, jira_source)
            doc    = _strip_hallucinated_identifiers(doc, jira_source)

            if reason or doc:
                logger.info(
                    "generate_cr_fields_from_jira: ✓ reason_len=%d doc_len=%d",
                    len(reason), len(doc),
                )
                logger.info("generate_cr_fields_from_jira: reason_for_change = %s", reason)
                logger.info("generate_cr_fields_from_jira: description_of_change = %s", doc)
                return {
                    "reason_for_change":     reason,
                    "description_of_change": doc,
                    "error":                 None,
                }
        except (json.JSONDecodeError, ValueError):
            logger.warning("generate_cr_fields_from_jira: JSON parse failed — raw: %s", raw)

    except Exception as exc:
        logger.warning("generate_cr_fields_from_jira: LLM call failed: %s", exc)

    # Fallback — use raw JIRA values as-is
    logger.warning("generate_cr_fields_from_jira: falling back to raw JIRA values")
    return {
        "reason_for_change":     summary,
        "description_of_change": description,
        "error":                 "LLM generation failed — raw values used",
    }


# ─────────────────────────────────────────────────────────────────────────────
# Tool 2c: generate_cr_fields_from_narrative
# ─────────────────────────────────────────────────────────────────────────────
_NARRATIVE_TO_CR_SYSTEM_PROMPT = """
You are an SAP Solution Manager Change Request writer.
The user described a change request in a single narrative statement that covers
both the business reason AND the technical detail together. Split it into two
distinct, formal CR fields.

CRITICAL RULE — NO HALLUCINATION:
Only use information explicitly present in the narrative provided. NEVER invent
SAP Note numbers, transaction codes, table names, program names, system names,
or any other technical identifier that is not present word-for-word in the input.

Rules:
- Reason for Change: explain WHY the change is needed — the underlying problem,
  its business impact, and justification. 1-3 sentences. No bullet points.
- Description of Change: explain WHAT will technically be done, based strictly on
  the narrative. 1-3 sentences. No bullet points.
- The two fields MUST be worded differently from each other — do not repeat the
  same sentence verbatim in both fields.
- Keep language simple, formal, and concise. Do not add facts beyond the narrative.

Respond ONLY in this exact JSON format with no extra text:
{
  "reason_for_change": "...",
  "description_of_change": "..."
}
"""


def generate_cr_fields_from_narrative(narrative: str) -> dict:
    """
    Use LLM to split a single user narrative sentence (that covers both why
    and what) into distinct reason_for_change and description_of_change fields.

    Args:
        narrative: the raw text the user provided, duplicated into both fields
                   by node_1 extraction.

    Returns:
        {
            "reason_for_change":     str,
            "description_of_change": str,
            "error":                 str | None,
        }
    Falls back to the original narrative in both fields on LLM failure.
    """
    narrative = (narrative or "").strip()

    if not narrative:
        return {
            "reason_for_change":     "",
            "description_of_change": "",
            "error":                 "No narrative content to process",
        }

    try:
        llm = get_llm_fast()
        response = llm.invoke([
            SystemMessage(content=_NARRATIVE_TO_CR_SYSTEM_PROMPT),
            HumanMessage(content=f"Narrative: {narrative}"),
        ])
        raw = response.content if hasattr(response, "content") else str(response)

        try:
            parsed = json.loads(raw)
            reason = (parsed.get("reason_for_change") or "").strip()
            doc    = (parsed.get("description_of_change") or "").strip()

            if reason and doc and reason.strip().lower() != doc.strip().lower():
                logger.info(
                    "generate_cr_fields_from_narrative: ✓ reason_len=%d doc_len=%d",
                    len(reason), len(doc),
                )
                return {
                    "reason_for_change":     reason,
                    "description_of_change": doc,
                    "error":                 None,
                }
            logger.warning(
                "generate_cr_fields_from_narrative: LLM returned identical/empty fields — falling back"
            )
        except (json.JSONDecodeError, ValueError):
            logger.warning("generate_cr_fields_from_narrative: JSON parse failed — raw: %s", raw)

    except Exception as exc:
        logger.warning("generate_cr_fields_from_narrative: LLM call failed: %s", exc)

    # Fallback — keep the original narrative in both fields
    logger.warning("generate_cr_fields_from_narrative: falling back to original narrative")
    return {
        "reason_for_change":     narrative,
        "description_of_change": narrative,
        "error":                 "LLM generation failed — original narrative used in both fields",
    }


# ─────────────────────────────────────────────────────────────────────────────
# get_template_grouped
# Fetches CR fields from Solman OData API organized by group
# Groups: Others, Textarea, FunctionalArea, ValidationRequirements,
#         Location, TestingRequirement, Details, DocumentationRequirement
# ─────────────────────────────────────────────────────────────────────────────
def get_template_grouped(template_id: str) -> dict:
    """
    Fetch CR template from Solman OData API and return fields
    organized by group exactly as returned by the API.

    Returns dict with keys:
      TransactionNo, Details, Others, Textarea, FunctionalArea,
      ValidationRequirements, Location, TestingRequirement,
      DocumentationRequirement, error
    """
    tid = str(template_id).strip()
    if not tid:
        return {"error": "template_id is empty"}

    if not SOLMAN_READ_BASE_URL or not SOLMAN_READ_USERNAME:
        return {"error": "Solman API not configured", "TransactionNo": tid}

    try:
        encoded_value = f"'{tid}'"
        path = f"/sap/opu/odata/sap/zchm1_srv/inputfieldSet({encoded_value})"
        url  = f"{SOLMAN_READ_BASE_URL}{path}"

        response = requests.get(
            url,
            auth=(SOLMAN_READ_USERNAME, SOLMAN_READ_PASSWORD),
            headers={"Accept": "application/json", "Content-Type": "application/json"},
            verify=SOLMAN_READ_VERIFY_SSL,
            timeout=30,
        )
        response.raise_for_status()
        data = response.json()
        d    = data.get("d", data)

        result = {"TransactionNo": tid, "error": None}

        # Group keys match the ZCHM_RFC_SRV OData API response keys (Iv-prefixed)
        KNOWN_GROUPS = [
            "IvDetails",
            "IvOthers",
            "IvFunctionalArea",
            "IvValidation",
            "IvLocation",
            "IvTestReq",
            "IvDocumentation",
        ]

        for group in KNOWN_GROUPS:
            group_data = d.get(group, {})
            if isinstance(group_data, dict):
                clean = {k: v for k, v in group_data.items() if k != "__metadata"}
                clean = {
                    k: (v.isoformat() if hasattr(v, "isoformat")
                        else str(v) if v is not None else "")
                    for k, v in clean.items()
                }
                result[group] = clean
            else:
                result[group] = {}

        logger.info(
            "get_template_grouped: %d groups for template_id=%s",
            len(KNOWN_GROUPS), tid,
        )
        return result

    except Exception as exc:
        logger.warning("get_template_grouped failed for %s: %s", tid, exc)
        return {"error": str(exc), "TransactionNo": tid}


# ─────────────────────────────────────────────────────────────────────────────
# Tool 3 (Node 2): validate_platform
# Queries Platform nodes by official SOP-8794 name, with alias resolution.
# ─────────────────────────────────────────────────────────────────────────────
# ─────────────────────────────────────────────────────────────────────────────
# Tool 3 (Node 2): validate_platform
# Queries Platform nodes by official SOP-8794 name, with alias resolution.
# ─────────────────────────────────────────────────────────────────────────────
def _normalize_platform_text(s: str) -> str:
    """
    Normalize free-form platform text for robust comparison:
    - lowercase
    - replace punctuation/slashes/extra symbols with spaces
    - drop generic filler words the user commonly appends
      (e.g. "AS Solman Platform" -> "as solman")
    - collapse whitespace
    """
    s = (s or "").strip().lower()
    s = _re.sub(r"[^a-z0-9]+", " ", s)
    _FILLER_WORDS = {
        "platform", "system", "erp", "sap", "instance", "instances",
        "the", "a", "an", "for", "of",
    }
    words = [w for w in s.split() if w not in _FILLER_WORDS]
    return " ".join(words)


def validate_platform(platform: str) -> dict:
    """
    Validate platform against Platform nodes in Neo4j.

    Step 1 — Exact match using the alias-resolved name.
    Step 2 — Partial (CONTAINS) match using both the original user input
             and the resolved alias as keywords.
    Step 3 — Normalized fuzzy match: strips punctuation/slashes/filler words
             (e.g. "Platform", "ERP", "System") from both the user input and
             every DB platform name, then scores candidates using word-overlap
             AND left-to-right sequence similarity so near-matches (extra
             words, missing words, slashes, minor typos) are still resolved.
    Step 4 — Nothing found — return full platform list (or close suggestions
             if any were found but below the confidence threshold).

    Returns all_matches when multiple platforms match so the agent can
    ask the user to confirm which one they meant.
    """
    # Strip trailing/leading punctuation (e.g. "MITEK SAP." → "MITEK SAP")
    platform = platform.strip().rstrip(".,:;!?")
    resolved = PLATFORM_ALIASES.get(platform.strip().lower(), platform.strip())

    # ── Step 1: exact match on resolved name ─────────────────────────────────
    rows = _run_cypher(
        "MATCH (p:Platform {name: $name}) RETURN p.name AS name LIMIT 1",
        {"name": resolved},
    )
    names = [r["name"] for r in rows if r.get("name") and not r.get("error")]

    if names:
        return {
            "valid":          True,
            "resolved_name":  names[0],
            "all_matches":    names,
            "original_input": platform,
            "alias_resolved": resolved != platform.strip(),
            "partial_match":  False,
            "error":          None,
        }

    # ── Step 2: partial/contains match — try both original input and alias ────
    keywords: list[str] = []
    if platform.strip():
        keywords.append(platform.strip())
    if resolved != platform.strip():
        # Also try the first word of the resolved alias (e.g. "Innovative" from
        # "Innovative Medicine (TIME ERP Instances)") and the original keyword
        keywords.append(resolved)
        first_word = resolved.split()[0] if resolved.split() else resolved
        if first_word not in keywords:
            keywords.append(first_word)

    partial_matches: list[str] = []
    seen: set[str] = set()
    for kw in keywords:
        kw_rows = _run_cypher(
            "MATCH (p:Platform) "
            "WHERE toLower(p.name) CONTAINS toLower($keyword) "
            "RETURN p.name AS name ORDER BY p.name",
            {"keyword": kw},
        )
        for r in kw_rows:
            n = r.get("name")
            if n and not r.get("error") and n not in seen:
                partial_matches.append(n)
                seen.add(n)

    if len(partial_matches) == 1:
        logger.info(
            "validate_platform: unambiguous partial match for '%s' → %s",
            platform, partial_matches,
        )
        return {
            "valid":          True,
            "resolved_name":  partial_matches[0],
            "all_matches":    partial_matches,
            "original_input": platform,
            "alias_resolved": resolved != platform.strip(),
            "partial_match":  True,
            "error":          None,
        }

    if len(partial_matches) > 1:
        logger.info(
            "validate_platform: multiple partial matches for '%s' → %s — asking user to select",
            platform, partial_matches,
        )
        _suggest_msg = (
            f"These are the top matched platforms for '{platform}'. "
            f"Please select one: {', '.join(partial_matches)}"
        )
        return {
            "valid":       False,
            "warning":     _suggest_msg,
            "error":       _suggest_msg,
            "suggestions": partial_matches[:5],
        }

    # ── Step 3: normalized fuzzy match against every DB platform name ────────
    # Handles phrasing the user might type in ANY format:
    #   "AS Solman Platform", "AS/Solman", "AS-SolMan ERP", "solman sys", etc.
    # Uses WORD-LEVEL recall/precision (F1) as the primary signal — this correctly
    # distinguishes "AS SolMan" from "AS GRC" when the user only types "AS", and
    # avoids false positives like "AS" coincidentally matching "Atlas" by raw
    # character sequence similarity. Sequence similarity is only used as a
    # secondary/typo-tolerance signal, and only trusted for non-trivial input
    # (avoids short abbreviations matching unrelated longer names by chance).
    all_rows = _run_cypher(
        "MATCH (p:Platform) RETURN p.name AS name ORDER BY p.name",
    )
    all_platforms = [
        r["name"] for r in all_rows if r.get("name") and not r.get("error")
    ]

    norm_input = _normalize_platform_text(platform)
    input_words = [w for w in norm_input.split() if w]
    input_words_set = set(input_words)

    scored: list[tuple[str, float, float]] = []  # (name, combined_score, recall)
    if input_words_set:
        for name in all_platforms:
            norm_name = _normalize_platform_text(name)
            if not norm_name:
                continue
            name_words_set = set(norm_name.split())

            common = input_words_set & name_words_set
            recall = len(common) / len(input_words_set) if input_words_set else 0.0
            precision = len(common) / len(name_words_set) if name_words_set else 0.0
            f1 = (2 * recall * precision / (recall + precision)) if (recall + precision) else 0.0

            seq_ratio = _difflib.SequenceMatcher(None, norm_name, norm_input).ratio()
            # Only trust pure character-sequence similarity when there's ALSO at
            # least one real word match, OR the input is long enough (>=4 chars)
            # to be a meaningful partial/typo match on its own.
            if recall == 0.0 and len(norm_input) < 4:
                seq_ratio = 0.0

            combined = max(f1, seq_ratio)
            if combined >= 0.5:
                scored.append((name, combined, recall))

    if scored:
        scored.sort(key=lambda x: x[1], reverse=True)
        best_name, best_score, _best_recall = scored[0]
        # Ties within a small margin of the best score are considered ambiguous —
        # e.g. input "AS" matches "AS SolMan" AND "AS GRC" equally.
        ties = [n for n, s, _r in scored if s >= best_score - 0.05]

        if len(ties) == 1 and best_score >= 0.75:
            top_matches = [n for n, s, _r in scored if s >= best_score - 0.1]
            logger.info(
                "validate_platform: fuzzy match '%s' -> '%s' (score=%.2f, candidates=%s)",
                platform, best_name, best_score, top_matches,
            )
            return {
                "valid":          True,
                "resolved_name":  best_name,
                "all_matches":    top_matches,
                "original_input": platform,
                "alias_resolved": False,
                "partial_match":  True,
                "fuzzy_match":    True,
                "error":          None,
            }

        # Ambiguous (multiple close candidates) OR low-confidence — suggest
        # close candidates instead of guessing a single (possibly wrong) one.
        suggestions = [n for n, _s, _r in scored[:5]]
        logger.info(
            "validate_platform: ambiguous/low-confidence fuzzy matches for '%s' -> %s",
            platform, suggestions,
        )
        _suggest_msg = (
            f"No exact match found for '{platform}'. Did you mean one of: "
            f"{', '.join(suggestions)}?"
        )
        return {
            "valid":       False,
            "warning":     _suggest_msg,
            "error":       _suggest_msg,
            "suggestions": suggestions,
        }

    # ── Step 4: nothing found at all — return full platform list ─────────────
    valid_list = ", ".join(all_platforms) if all_platforms else "(none found in database)"
    return {
        "valid":   False,
        "warning": (
            f"No matching platform found for '{platform}'. "
            f"These are the valid platforms you can choose from: {valid_list}"
        ),
        "error": (
            f"No matching platform found for '{platform}'. "
            f"These are the valid platforms you can choose from: {valid_list}"
        ),
    }


# ─────────────────────────────────────────────────────────────────────────────
# Tool 4 (Node 2): validate_target_system
# Queries TargetSystem nodes, optionally scoped to a Platform.
# ─────────────────────────────────────────────────────────────────────────────
def validate_target_system(target: str, platform: Optional[str] = None) -> dict:
    """
    Validate target system against TargetSystem nodes in Neo4j.

    If platform is given, resolves alias and queries:
      MATCH (p:Platform {name: $platform})-[:HAS_SYSTEM]->(ts:TargetSystem {name: $target})
    If no platform given, does a global TargetSystem lookup.

    Returns resolved name on success, or list of valid target systems on failure.
    """
    if platform:
        resolved_platform = PLATFORM_ALIASES.get(platform.strip().lower(), platform.strip())
        raw_platform = platform.strip()
        logger.info(
            "validate_target_system: target=%r platform_raw=%r platform_resolved=%r",
            target.strip(), raw_platform, resolved_platform,
        )
        rows = _run_cypher(
            "MATCH (p:Platform)-[:HAS_SYSTEM]->(ts:TargetSystem {name: $target}) "
            "WHERE p.name = $resolved OR toLower(p.name) CONTAINS toLower($raw) "
            "RETURN ts.name AS name LIMIT 1",
            {"resolved": resolved_platform, "raw": raw_platform, "target": target.strip()},
        )
        names = [r["name"] for r in rows if r.get("name") and not r.get("error")]
        logger.info("validate_target_system: exact TargetSystem match rows=%r → names=%r", rows, names)

        if names:
            return {
                "valid":         True,
                "resolved_name": names[0],
                "error":         None,
            }

        # Exact match failed — try prefix/contains match (e.g. "HMD MBOX" → "HMD MBOX ---")
        # Bidirectional fuzzy match: covers both directions of truncation —
        # DB value longer than target (e.g. target "HMD MBOX" → DB "HMD MBOX ----")
        # AND target longer than DB value (e.g. target ".WMBTBP" → DB "WMBTBP").
        # NOTE: collect ALL distinct matches (no LIMIT 1) so we can detect ambiguity —
        # e.g. target "PJS" matching BOTH "PJS 0021237113" and "PJS 0021237113 100" —
        # instead of silently picking whichever row Neo4j happens to return first.
        fuzzy_rows = _run_cypher(
            "MATCH (p:Platform)-[:HAS_SYSTEM]->(ts:TargetSystem) "
            "WHERE (p.name = $resolved OR toLower(p.name) CONTAINS toLower($raw)) "
            "AND (toLower(ts.name) STARTS WITH toLower($target) "
            "     OR toLower(ts.name) CONTAINS toLower($target) "
            "     OR toLower($target) STARTS WITH toLower(ts.name) "
            "     OR toLower($target) CONTAINS toLower(ts.name)) "
            "RETURN DISTINCT ts.name AS name ORDER BY ts.name",
            {"resolved": resolved_platform, "raw": raw_platform, "target": target.strip()},
        )
        fuzzy_names = [r["name"] for r in fuzzy_rows if r.get("name") and not r.get("error")]
        logger.info("validate_target_system: fuzzy TargetSystem match rows=%r → names=%r", fuzzy_rows, fuzzy_names)

        if len(fuzzy_names) == 1:
            return {
                "valid":         True,
                "resolved_name": fuzzy_names[0],
                "error":         None,
            }

        if len(fuzzy_names) > 1:
            logger.info(
                "validate_target_system: multiple fuzzy matches for '%s' → %s — asking user to select",
                target, fuzzy_names,
            )
            _suggest_msg = (
                f"These are the top matched target systems for '{target}'. "
                f"Please select one: {', '.join(fuzzy_names[:5])}"
            )
            return {
                "valid":       False,
                "warning":     _suggest_msg,
                "error":       _suggest_msg,
                "suggestions": fuzzy_names[:5],
            }

        # Fallback: check ChangeRequest.configuration_descr (same source as clickable options).
        # Uses bidirectional fuzzy matching (not exact `=`) because this field can hold values
        # with extra punctuation/prefixes not captured by the TargetSystem graph above, in
        # EITHER direction:
        #   - DB longer than target:  target "HMD MBOX"  → DB "HMD MBOX ----"
        #   - target longer than DB:  target ".WMBTBP"    → DB "WMBTBP"
        # Same distinct-collection approach — do not silently guess when the
        # configuration_descr fallback also has multiple candidate matches.
        cr_rows = _run_cypher(
            "MATCH (c:ChangeRequest) "
            "WHERE (c.platform = $resolved OR toLower(c.platform) CONTAINS toLower($raw)) "
            "AND c.configuration_descr IS NOT NULL AND c.configuration_descr <> '' "
            "AND (toLower(c.configuration_descr) = toLower($target) "
            "     OR toLower(c.configuration_descr) STARTS WITH toLower($target) "
            "     OR toLower(c.configuration_descr) CONTAINS toLower($target) "
            "     OR toLower($target) STARTS WITH toLower(c.configuration_descr) "
            "     OR toLower($target) CONTAINS toLower(c.configuration_descr)) "
            "RETURN DISTINCT c.configuration_descr AS name ORDER BY name",
            {"resolved": resolved_platform, "raw": raw_platform, "target": target.strip()},
        )
        cr_names = [r["name"] for r in cr_rows if r.get("name") and not r.get("error")]
        logger.info("validate_target_system: ChangeRequest.configuration_descr fallback rows=%r → names=%r", cr_rows, cr_names)
        if len(cr_names) == 1:
            return {
                "valid":         True,
                "resolved_name": cr_names[0],
                "error":         None,
            }

        if len(cr_names) > 1:
            logger.info(
                "validate_target_system: multiple configuration_descr matches for '%s' → %s — asking user to select",
                target, cr_names,
            )
            _suggest_msg = (
                f"These are the top matched target systems for '{target}'. "
                f"Please select one: {', '.join(cr_names[:5])}"
            )
            return {
                "valid":       False,
                "warning":     _suggest_msg,
                "error":       _suggest_msg,
                "suggestions": cr_names[:5],
            }

        logger.info("validate_target_system: NOT FOUND for target=%r platform=%r", target.strip(), resolved_platform)
        # Not found — list valid target systems for this platform
        ts_rows = _run_cypher(
            "MATCH (p:Platform)-[:HAS_SYSTEM]->(ts:TargetSystem) "
            "WHERE p.name = $resolved OR toLower(p.name) CONTAINS toLower($raw) "
            "RETURN ts.name AS name ORDER BY ts.name",
            {"resolved": resolved_platform, "raw": raw_platform},
        )
        ts_list = [r["name"] for r in ts_rows if r.get("name") and not r.get("error")]
        valid_list = ", ".join(ts_list) if ts_list else "(none found for this platform)"
        return {
            "valid":   False,
            "warning": (
                f"No matching target system found for '{target}'. "
                f"Valid target systems for this platform are: {valid_list}"
            ),
            "error": (
                f"No matching target system found for '{target}'. "
                f"Valid target systems for this platform are: {valid_list}"
            ),
        }

    # No platform — global lookup
    rows = _run_cypher(
        "MATCH (ts:TargetSystem {name: $name}) RETURN ts.name AS name LIMIT 1",
        {"name": target.strip()},
    )
    names = [r["name"] for r in rows if r.get("name") and not r.get("error")]

    if names:
        return {
            "valid":         True,
            "resolved_name": names[0],
            "error":         None,
        }

    # Fallback: check ChangeRequest.configuration_descr globally. Fuzzy STARTS WITH/CONTAINS
    # (not exact `=`) for the same reason as the platform-scoped fallback above.
    # Collect ALL distinct matches (no LIMIT 1) so ambiguity can be detected here too.
    cr_rows_global = _run_cypher(
        "MATCH (c:ChangeRequest) WHERE toLower(c.configuration_descr) = toLower($name) "
        "   OR toLower(c.configuration_descr) STARTS WITH toLower($name) "
        "   OR toLower(c.configuration_descr) CONTAINS toLower($name) "
        "RETURN DISTINCT c.configuration_descr AS name ORDER BY name",
        {"name": target.strip()},
    )
    cr_global = [r["name"] for r in cr_rows_global if r.get("name") and not r.get("error")]
    if len(cr_global) == 1:
        return {
            "valid":         True,
            "resolved_name": cr_global[0],
            "error":         None,
        }

    if len(cr_global) > 1:
        logger.info(
            "validate_target_system: multiple global configuration_descr matches for '%s' → %s — asking user to select",
            target, cr_global,
        )
        _suggest_msg = (
            f"These are the top matched target systems for '{target}'. "
            f"Please select one: {', '.join(cr_global[:5])}"
        )
        return {
            "valid":       False,
            "warning":     _suggest_msg,
            "error":       _suggest_msg,
            "suggestions": cr_global[:5],
        }

    # Not found globally — check TARGET_SYSTEM_PLATFORM_MAP for a platform suggestion
    platform_key = TARGET_SYSTEM_PLATFORM_MAP.get(target.strip().lower())
    if platform_key:
        suggested_platform = PLATFORM_ALIASES.get(platform_key, platform_key)
        return {
            "valid":              False,
            "suggested_platform": suggested_platform,
            "suggestion_message": (
                f"'{target}' appears to be a related system that belongs to "
                f"the '{suggested_platform}' platform per SOP-8794 Section 2. "
                f"Did you mean to use that platform?"
            ),
            "warning": (
                f"'{target}' appears to be a related system that belongs to "
                f"the '{suggested_platform}' platform per SOP-8794 Section 2. "
                f"Did you mean to use that platform?"
            ),
            "error": (
                f"'{target}' appears to be a related system that belongs to "
                f"the '{suggested_platform}' platform per SOP-8794 Section 2. "
                f"Did you mean to use that platform?"
            ),
        }

    # No suggestion either — return all target systems
    all_rows = _run_cypher(
        "MATCH (ts:TargetSystem) RETURN ts.name AS name ORDER BY ts.name",
    )
    all_ts = [r["name"] for r in all_rows if r.get("name") and not r.get("error")]
    valid_list = ", ".join(all_ts) if all_ts else "(none found in database)"
    return {
        "valid":   False,
        "warning": (
            f"No matching target system found for '{target}'. "
            f"These are the valid platforms you can choose from: {valid_list}"
        ),
        "error": (
            f"No matching target system found for '{target}'. "
            f"These are the valid platforms you can choose from: {valid_list}"
        ),
    }


# ─────────────────────────────────────────────────────────────────────────────
# Tool 5 (Nodes 7, 11): execute_cypher — public Cypher executor
# ─────────────────────────────────────────────────────────────────────────────
def execute_cypher(query: str, params: Optional[dict] = None) -> list[dict]:
    """
    Execute any Cypher query against Neo4j.
    Returns rows as list-of-dicts. Returns [{"error":...}] on failure.
    """
    return _run_cypher(query, params)


# ─────────────────────────────────────────────────────────────────────────────
# Utility: get_valid_field_values
# Called by agent/UI to show user what values are accepted for each field.
# ─────────────────────────────────────────────────────────────────────────────
def get_valid_field_values(field_name: str, limit: int = 20, platform: Optional[str] = None) -> list[str]:
    """
    Return distinct accepted values for a CR field from Neo4j.

    Args:
        field_name: one of "platform", "target_system", "configuration",
                    "process_type", "logical_system", "project_title"
        limit:      max values to return
        platform:   optional platform name to scope target_system lookup

    Returns sorted list of distinct non-null string values.
    """
    # Entity node fields — query dedicated nodes for canonical, up-to-date values
    if field_name == "platform":
        rows = _run_cypher(
            f"MATCH (p:Platform) RETURN p.name AS val ORDER BY val LIMIT {limit}"
        )
        return [r["val"] for r in rows if r.get("val") and not r.get("error")]
    if field_name == "target_system":
        if platform:
            # Scoped to platform — ALL target systems with count, sorted by occurrence count DESC
            resolved_platform = PLATFORM_ALIASES.get(platform.strip().lower(), platform.strip())
            raw_platform = platform.strip()
            rows = _run_cypher(
                f"""
                MATCH (c:ChangeRequest)
                WHERE (c.platform = $resolved OR toLower(c.platform) CONTAINS toLower($raw))
                  AND c.configuration_descr IS NOT NULL
                  AND c.configuration_descr <> ''
                WITH c.configuration_descr AS val, count(*) AS cnt
                RETURN val, cnt
                ORDER BY cnt DESC, val ASC
                LIMIT {limit}
                """,
                {"resolved": resolved_platform, "raw": raw_platform},
            )
            # Format as "value (count)"
            return [f"{r['val']} ({r['cnt']})" for r in rows if r.get("val") and not r.get("error")]
        else:
            # Global lookup — ALL target systems with count, sorted by occurrence
            rows = _run_cypher(
                f"""
                MATCH (c:ChangeRequest)
                WHERE c.configuration_descr IS NOT NULL
                  AND c.configuration_descr <> ''
                WITH c.configuration_descr AS val, count(*) AS cnt
                RETURN val, cnt
                ORDER BY cnt DESC, val ASC
                LIMIT {limit}
                """
            )
            # Format as "value (count)"
            return [f"{r['val']} ({r['cnt']})" for r in rows if r.get("val") and not r.get("error")]

    neo4j_prop = FIELD_MAP.get(field_name)
    if not neo4j_prop:
        return []

    query = f"""
    MATCH (c:ChangeRequest)
    WHERE c.{neo4j_prop} IS NOT NULL
      AND toString(c.{neo4j_prop}) <> ''
      AND toString(c.{neo4j_prop}) <> 'None'
      AND toString(c.{neo4j_prop}) <> 'N/A'
      AND toString(c.{neo4j_prop}) <> '0'
    RETURN DISTINCT toString(c.{neo4j_prop}) AS val
    ORDER BY val
    LIMIT {limit}
    """
    rows = _run_cypher(query)
    return [r["val"] for r in rows if r.get("val") and not r.get("error")]


# ─────────────────────────────────────────────────────────────────────────────
# Transaction Type Rules helpers (node_21 / node_22 + solman_write cross-check)
# ─────────────────────────────────────────────────────────────────────────────

_APRV_PROC_DESC_TO_CODE: dict[str, str] = {
    **DROPDOWN_FIELDS.get("aprv_proc_adtnl", {}),
    # Aliases returned by SAP AprvProcDesc in the read API — must map to the same codes
    "Johnson & Johnson Approval Procedure": "ZMCR0001",
    "Johnson & Johnson Emergency AP":       "ZMCR0003",
}

def _dropdown_desc_to_code_map(field_key: str) -> dict[str, str]:
    return dict(DROPDOWN_FIELDS.get(field_key, {}))


def _dropdown_code_to_desc_map(field_key: str) -> dict[str, str]:
    return {
        code: desc
        for desc, code in DROPDOWN_FIELDS.get(field_key, {}).items()
        if code
    }


def approval_process_to_code(value: str) -> str:
    """Map Approval Process description/code input to SAP code when known."""
    raw = str(value or "").strip()
    if not raw:
        return ""
    lower_raw = raw.lower()
    for desc, code in _APRV_PROC_DESC_TO_CODE.items():
        if raw == desc or lower_raw == desc.lower() or raw == code:
            return code
    return ""


def approval_process_to_display(value: str) -> str:
    """Map Approval Process code/description input to display description when known."""
    raw = str(value or "").strip()
    if not raw:
        return ""
    for desc, code in _APRV_PROC_DESC_TO_CODE.items():
        if raw == desc or raw == code:
            return desc
    return raw


def valid_approval_process_values() -> list[str]:
    """Return supported Approval Process display values for user prompts."""
    return [k for k in _APRV_PROC_DESC_TO_CODE.keys() if k]


def transaction_type_to_code(value: str) -> str:
    """Map Transaction Type description/code input to SAP code when known."""
    raw = str(value or "").strip()
    if not raw:
        return ""

    transaction_type_map = _dropdown_desc_to_code_map("transaction_type_scope")
    transaction_type_reverse_map = _dropdown_code_to_desc_map("transaction_type_scope")

    # Exact description match first.
    for desc, code in transaction_type_map.items():
        if raw == desc:
            return code

    # Accept SAP code as-is if recognized.
    if raw in transaction_type_reverse_map:
        return raw

    # Case-insensitive description match.
    lower_raw = raw.lower()
    for desc, code in transaction_type_map.items():
        if lower_raw == desc.lower():
            return code

    return ""


def transaction_type_to_display(value: str) -> str:
    """Map Transaction Type code/description input to display description when known."""
    raw = str(value or "").strip()
    if not raw:
        return ""
    transaction_type_reverse_map = _dropdown_code_to_desc_map("transaction_type_scope")
    if raw in transaction_type_reverse_map:
        return transaction_type_reverse_map[raw]
    return raw


def valid_transaction_type_values() -> list[str]:
    """Return supported Transaction Type display values for user prompts."""
    return [k for k in DROPDOWN_FIELDS.get("transaction_type_scope", {}).keys() if k]


def _normalize_transaction_type(value: str) -> str:
    raw = str(value or "").strip()
    if not raw:
        return ""

    display = transaction_type_to_display(raw)
    if display != raw:
        return display

    lower_raw = raw.lower()
    for option in valid_transaction_type_values():
        if lower_raw == option.lower():
            return option

    return ""


def _normalize_process_type_code(value: str) -> str:
    return str(value or "").strip().upper()


def _transaction_type_from_process_type_code(process_type_code: str) -> str:
    normalized_code = _normalize_process_type_code(process_type_code)
    display = transaction_type_to_display(normalized_code)
    return display if display != normalized_code else ""


def get_transaction_type_for_cycle(cycle_id: str) -> str:
    """Return the cycle's dominant transaction type display from ProcessType code only."""
    raw_cycle = str(cycle_id or "").strip()
    if not raw_cycle:
        return ""

    normalized_cycle = raw_cycle.lstrip("0") or "0"
    padded_cycle_10 = normalized_cycle.zfill(10)
    padded_cycle_15 = normalized_cycle.zfill(15)

    # Use only the top-ranked process type for the selected cycle.
    rows = execute_cypher(
        """
        MATCH (c:ChangeRequest)-[:BELONGS_TO_CYCLE]->(cy:CycleID)
        WHERE toString(cy.id) IN [$cycle_id_raw, $cycle_id_normalized, $cycle_id_padded_10, $cycle_id_padded_15]
          AND c.co_process_type IS NOT NULL
          AND toString(c.co_process_type) <> ''
        RETURN toString(c.co_process_type) AS process_type,
               count(DISTINCT coalesce(c.object_id, elementId(c))) AS cr_count
        ORDER BY cr_count DESC, process_type ASC
        LIMIT 5
        """,
        {
            "cycle_id_raw": raw_cycle,
            "cycle_id_normalized": normalized_cycle,
            "cycle_id_padded_10": padded_cycle_10,
            "cycle_id_padded_15": padded_cycle_15,
        },
    )

    for row in rows:
        if row.get("error"):
            continue
        return _transaction_type_from_process_type_code(row.get("process_type"))

    return ""


def resolve_change_type_rule(transaction_type: str, cycle_type_hint: str = "") -> dict[str, str]:
    """Resolve one transaction type into SC/OC/AprvProc/CycleType/TransactionType."""
    resolved_transaction_type = _normalize_transaction_type(transaction_type)
    resolved_transaction_type_code = transaction_type_to_code(transaction_type)
    transaction_type_code = resolved_transaction_type_code or resolved_transaction_type
    cycle_type_hint = str(cycle_type_hint or "").strip()

    rule = TRANSACTION_TYPE_RULES.get(transaction_type_code)
    if rule is None:
        return {}

    # Rules with cycle_type=None require runtime resolution from cycle_type_hint
    if rule["cycle_type"] is None:
        hints = rule.get("cycle_type_hints", {})
        resolved_cycle_type = next(
            (v for k, v in hints.items() if k in cycle_type_hint), None
        )
        if resolved_cycle_type is None:
            return {}
        return {
            "standard_change": rule["standard_change"],
            "operate_change":  rule["operate_change"],
            "approval_process": rule["approval_process"],
            "cycle_type":       resolved_cycle_type,
            "transaction_type": rule["transaction_type"],
        }

    return {
        "standard_change": rule["standard_change"],
        "operate_change":  rule["operate_change"],
        "approval_process": rule["approval_process"],
        "cycle_type":       rule["cycle_type"],
        "transaction_type": rule["transaction_type"],
    }


def risk_to_code(value: str) -> str:
    """Map Risk display label or SAP code to SAP code."""
    raw = str(value or "").strip()
    if not raw:
        return ""

    risk_map = _dropdown_desc_to_code_map("risk_adtnl")
    risk_reverse_map = _dropdown_code_to_desc_map("risk_adtnl")

    if raw in risk_reverse_map:
        return raw
    lower = raw.lower()
    for desc, code in risk_map.items():
        if lower == desc.lower():
            return code
    return ""


def risk_to_display(value: str) -> str:
    """Map Risk SAP code or display label to user-facing display label."""
    raw = str(value or "").strip()
    if not raw:
        return ""
    risk_reverse_map = _dropdown_code_to_desc_map("risk_adtnl")
    if raw in risk_reverse_map:
        return risk_reverse_map[raw]
    return raw


def valid_risk_values() -> list[str]:
    """Return supported Risk display values for user prompts."""
    return list(DROPDOWN_FIELDS.get("risk_adtnl", {}).keys())


# ─────────────────────────────────────────────────────────────────────────────
# Priority code↔display helpers
# ─────────────────────────────────────────────────────────────────────────────
def priority_to_code(value: str) -> str:
    """Map Priority display label or SAP code to SAP code."""
    raw = str(value or "").strip()
    if not raw:
        return ""

    priority_map = _dropdown_desc_to_code_map("priority_adtnl")
    priority_reverse_map = _dropdown_code_to_desc_map("priority_adtnl")

    if raw in priority_reverse_map:
        return raw
    lower = raw.lower()
    for desc, code in priority_map.items():
        if lower == desc.lower():
            return code
    return ""


def priority_to_display(value: str) -> str:
    """Map Priority SAP code or display label to user-facing display label."""
    raw = str(value or "").strip()
    if not raw:
        return ""
    priority_reverse_map = _dropdown_code_to_desc_map("priority_adtnl")
    if raw in priority_reverse_map:
        return priority_reverse_map[raw]
    return raw


def valid_priority_values() -> list[str]:
    """Return supported Priority display values for user prompts."""
    return list(DROPDOWN_FIELDS.get("priority_adtnl", {}).keys())


# ─────────────────────────────────────────────────────────────────────────────
# Platform ID code↔display helpers  (zzfld000013_cus)
# ─────────────────────────────────────────────────────────────────────────────
def platform_id_to_code(value: str) -> str:
    """Map Platform display label or SAP code to SAP code."""
    raw = str(value or "").strip()
    if not raw:
        return ""

    platform_id_map = _dropdown_desc_to_code_map("zzfld000013_cus")
    platform_id_reverse_map = _dropdown_code_to_desc_map("zzfld000013_cus")

    if raw in platform_id_reverse_map:
        return raw
    for desc, code in platform_id_map.items():
        if raw.lower() == desc.lower():
            return code
    return ""


def platform_id_to_display(value: str) -> str:
    """Map Platform SAP code or display label to user-facing display label."""
    raw = str(value or "").strip()
    if not raw:
        return ""
    platform_id_reverse_map = _dropdown_code_to_desc_map("zzfld000013_cus")
    if raw in platform_id_reverse_map:
        return platform_id_reverse_map[raw]
    return raw


# ─────────────────────────────────────────────────────────────────────────────
# Primary Functional Area code↔display helpers  (zzfld000016_cus)
# ─────────────────────────────────────────────────────────────────────────────
def primary_fa_to_code(value: str) -> str:
    """Map Primary Functional Area display label or SAP code to SAP code."""
    raw = str(value or "").strip()
    if not raw:
        return ""

    primary_fa_map = _dropdown_desc_to_code_map("zzfld000016_cus")
    primary_fa_reverse_map = _dropdown_code_to_desc_map("zzfld000016_cus")

    if raw in primary_fa_reverse_map:
        return raw
    for desc, code in primary_fa_map.items():
        if raw.lower() == desc.lower():
            return code
    return ""


def primary_fa_to_display(value: str) -> str:
    """Map Primary Functional Area SAP code or display label to user-facing display label."""
    raw = str(value or "").strip()
    if not raw:
        return ""
    primary_fa_reverse_map = _dropdown_code_to_desc_map("zzfld000016_cus")
    if raw in primary_fa_reverse_map:
        return primary_fa_reverse_map[raw]
    return raw


def dropdown_to_code(field_key: str, value: str) -> str:
    """Map a dropdown field value to its SAP code when known."""
    if field_key == "risk_adtnl":
        return risk_to_code(value)
    if field_key == "priority_adtnl":
        return priority_to_code(value)
    if field_key == "zzfld000013_cus":
        return platform_id_to_code(value)
    if field_key == "zzfld000016_cus":
        return primary_fa_to_code(value)
    if field_key == "aprv_proc_adtnl":
        return approval_process_to_code(value)
    if field_key == "transaction_type_scope":
        return transaction_type_to_code(value)
    return str(value or "").strip()


def dropdown_to_display(field_key: str, value: str) -> str:
    """Map a dropdown field value to its display label when known."""
    if field_key == "risk_adtnl":
        return risk_to_display(value)
    if field_key == "priority_adtnl":
        return priority_to_display(value)
    if field_key == "zzfld000013_cus":
        return platform_id_to_display(value)
    if field_key == "zzfld000016_cus":
        return primary_fa_to_display(value)
    if field_key == "aprv_proc_adtnl":
        return approval_process_to_display(value)
    if field_key == "transaction_type_scope":
        return transaction_type_to_display(value)
    return str(value or "").strip()


def get_transaction_type_options(
    sc: str, oc: str, aprv_proc: str, cycle_type: str
) -> list[str]:
    """
    Return valid TransactionType display descriptions based on the rules table.

    Args:
        sc:         StandardChange value from template ("X" or "")
        oc:         OperateChange  value from template ("X" or "")
        aprv_proc:  selected Approval Process description or SAP code
        cycle_type: CycleType from template (e.g. "Continual Cycle")

    Returns list of valid display descriptions the user can choose from.
    """
    sc = sc.strip().upper()
    oc = oc.strip().upper()
    ct = cycle_type.strip()
    # Normalise aprv_proc — accept both description and SAP code
    ap = aprv_proc.strip()
    if ap == "ZMCR0001":
        ap = "J&J Approval"
    elif ap == "ZMCR0003":
        ap = "J&J Emergency Approval"

    if sc == "X":
        return list(TRANSACTION_TYPE_OPTIONS_MATRIX.get("sc_x", {}).get("options", []))

    if oc == "X":
        oc_options_by_cycle = TRANSACTION_TYPE_OPTIONS_MATRIX.get("oc_x_by_cycle", {})
        for cycle_hint, options in oc_options_by_cycle.items():
            if cycle_hint in ct:
                return list(options)
        return []

    # SC=blank, OC=blank
    options_by_approval = TRANSACTION_TYPE_OPTIONS_MATRIX.get(
        "blank_sc_oc_by_approval_and_cycle", {}
    )
    options_by_cycle = options_by_approval.get(ap, {})
    for cycle_hint, options in options_by_cycle.items():
        if cycle_hint in ct:
            return list(options)

    return []


def validate_change_type_combination(
    sc: str,
    oc: str,
    aprv_proc: str,
    transaction_type: str,
    cycle_type: str,
) -> dict:
    """
    Cross-check all five fields against the Transaction Type Rules table.

    Values may be SAP codes or display descriptions — both are accepted.
    Returns {"valid": bool, "error": str | None}.
    """
    # Normalise codes → descriptions for uniform comparison
    ap = aprv_proc.strip()
    if ap == "ZMCR0001":
        ap = "J&J Approval"
    elif ap == "ZMCR0003":
        ap = "J&J Emergency Approval"

    tt = transaction_type.strip()
    # Convert SAP code → description if needed
    tt_desc = _dropdown_code_to_desc_map("transaction_type_scope").get(tt, tt)

    valid_options = get_transaction_type_options(sc, oc, ap, cycle_type)
    if not valid_options:
        return {
            "valid": False,
            "error": (
                f"No valid Transaction Type found for "
                f"StandardChange={sc!r}, OperateChange={oc!r}, "
                f"AprvProc={ap!r}, CycleType={cycle_type!r}"
            ),
        }

    if tt_desc and tt_desc not in valid_options:
        return {
            "valid": False,
            "error": (
                f"Transaction Type '{tt_desc}' is not valid for this combination. "
                f"Valid options: {valid_options}"
            ),
        }

    return {"valid": True, "error": None}


# ─────────────────────────────────────────────────────────────────────────────
# Tool 6 (Node 12): solman_write — SAP Solution Manager REST submission
# ─────────────────────────────────────────────────────────────────────────────
def _extract_sap_bapiret_errors(data: dict) -> tuple[bool, str | None]:
    """
    Check ZCHM_RFC_SRV-style inline business-error fields that SAP may return
    EVEN ON HTTP 200 OK (and sometimes also on HTTP error bodies):
      - EvHasError : BOOLEAN, "X" when there is a validation error
      - EvMessage  : single-line friendly message — meant for front-end display
      - ET_RETURN  : BAPIRET2_T table of detailed messages (Type/Message rows)

    Returns (has_error, friendly_message). friendly_message combines EvMessage
    with the Error/Abort (Type E/A) rows from ET_RETURN, de-duplicated.
    """
    d = data.get("d", data) if isinstance(data, dict) else {}
    if not isinstance(d, dict):
        return False, None

    has_error = str(d.get("EvHasError") or "").strip().upper() in ("X", "TRUE", "1")
    if not has_error:
        return False, None

    ev_message = str(d.get("EvMessage") or "").strip()

    return_rows = d.get("EtReturn") or d.get("ToReturn") or d.get("EvReturn") or []
    if isinstance(return_rows, dict):
        return_rows = return_rows.get("results") or return_rows.get("Results") or []
    if not isinstance(return_rows, list):
        return_rows = []

    detail_lines: list[str] = []
    for row in return_rows:
        if not isinstance(row, dict):
            continue
        _type = str(row.get("Type") or row.get("TYPE") or "").strip().upper()
        _msg = str(row.get("Message") or row.get("MESSAGE") or "").strip()
        if _msg and _type in ("E", "A"):
            detail_lines.append(_msg)

    combined = ev_message
    if detail_lines:
        unique_details = list(dict.fromkeys(detail_lines))
        details_str = "; ".join(unique_details)
        combined = f"{combined} — {details_str}" if combined else details_str

    return True, (combined or "SAP reported a validation error but did not provide message details")


def solman_write(draft: str, state_snapshot: dict) -> dict:
    """
    Push CR draft to SAP Solution Manager via ZCHM_RFC_SRV OData POST.

    Flow:
      1. Guard: template_id must be present.
      2. Open a single requests.Session() shared across GET and POST so SAP
         binds the CSRF token to the same session cookie.
      3. GET ChangeRequestSet('{template_id}') with X-CSRF-Token: Fetch —
         captures the full template JSON (with __metadata on every group)
         AND the CSRF token from the response header.
      4. Use the full GET response as the base payload — this preserves all
         required fields and __metadata type annotations SAP expects.
         Overlay only the user-specified fields from state_snapshot on top.
      5. POST to ChangeRequestSet (bare collection, no ID) with Basic Auth
         and X-CSRF-Token header.
      6. Extract EvObjectId from the response as the new CR ID.

    Returns {"success": bool, "cr_id": str | None, "error": str | None}
    """
    if not SOLMAN_READ_BASE_URL or not SOLMAN_READ_USERNAME:
        return {"success": False, "cr_id": None, "error": "SOLMAN_READ_BASE_URL or SOLMAN_READ_USERNAME not configured"}

    if "ZCHM_RFC_SRV" not in (SOLMAN_ODATA_PATH or ""):
        err = (
            "SOLMAN_ODATA_PATH must point to ZCHM_RFC_SRV/ChangeRequestSet "
            "for create flow"
        )
        logger.warning("solman_write: %s (current path=%s)", err, SOLMAN_ODATA_PATH)
        return {"success": False, "cr_id": None, "error": err}

    # Guard: template_id OR cr_id must not be empty (cr_id is fallback)
    template_id = state_snapshot.get("template_id", {}).get("value", "") if isinstance(
        state_snapshot.get("template_id"), dict
    ) else str(state_snapshot.get("template_id", "") or "")
    
    cr_id = state_snapshot.get("cr_id", {}).get("value", "") if isinstance(
        state_snapshot.get("cr_id"), dict
    ) else str(state_snapshot.get("cr_id", "") or "")
    
    # Priority: cr_id (original user selection) > template_id
    # Node_20b updates cycle fields (CycleID, Landscape) in cr_id.data, but does NOT override the CR ID itself.
    # Use the original cr_id to ensure we POST to the correct CR that user selected.
    baseline_id = cr_id or template_id
    if not baseline_id:
        return {"success": False, "cr_id": None, "error": "template_id or cr_id is required for CR submission"}

    logger.info("solman_write: using baseline_id=%s (template_id=%s, cr_id=%s)", baseline_id, template_id, cr_id)

    # Shared session so SAP cookie is preserved across GET + POST
    session = requests.Session()
    session.auth = (SOLMAN_READ_USERNAME, SOLMAN_READ_PASSWORD)
    session.verify = SOLMAN_READ_VERIFY_SSL

    get_urls = _build_solman_get_urls(baseline_id)
    post_url = f"{SOLMAN_READ_BASE_URL}{SOLMAN_ODATA_PATH}"

    logger.info("solman_write: SOLMAN_ODATA_PATH=%s", SOLMAN_ODATA_PATH)
    for idx, _u in enumerate(get_urls, start=1):
        logger.info("solman_write: GET URL attempt %d=%s", idx, _u)
    logger.info("solman_write: POST URL=%s", post_url)

    # ── Step 1: GET CSRF token + template structure ──
    # Extract the chosen cycle ID from cr_id.data (set by node_20b after user selection)
    # We'll overlay this onto the original template structure below.
    chosen_cycle_id = None
    cr_id_state = state_snapshot.get("cr_id", {})
    if isinstance(cr_id_state, dict) and cr_id_state.get("data"):
        _cr_data = cr_id_state["data"]
        # IvContext is the primary source (written by node_20b); IvDetails/IsDetails are fallbacks
        _ctx = _cr_data.get("IvContext") or {}
        if isinstance(_ctx, dict):
            chosen_cycle_id = str(_ctx.get("CycleID") or "").strip() or None
        if not chosen_cycle_id:
            _details = _cr_data.get("IvDetails") or _cr_data.get("IsDetails") or {}
            if isinstance(_details, dict):
                chosen_cycle_id = str(_details.get("CycleId") or "").strip() or None
        logger.info("solman_write: extracted chosen_cycle_id=%s from cr_id.data", chosen_cycle_id)

    try:
        # Fetch CSRF token from collection endpoint (GET without entity key)
        csrf_get_url = f"{SOLMAN_READ_BASE_URL}{SOLMAN_ODATA_PATH}"
        token_resp = session.get(
            csrf_get_url,
            headers={"X-CSRF-Token": "Fetch", "Accept": "application/json"},
            timeout=30,
        )
        csrf_token = token_resp.headers.get("X-CSRF-Token", "")
        if not csrf_token:
            logger.warning("solman_write: SAP returned empty CSRF token — proceeding anyway")
        logger.info("solman_write: obtained CSRF token for POST")

        # Read template values from API and use them as payload source values.
        template_data: dict | None = None
        last_template_exc: Exception | None = None
        for idx, get_url in enumerate(get_urls, start=1):
            try:
                logger.info("solman_write: template GET URL attempt %d=%s", idx, get_url)
                read_resp = session.get(
                    get_url,
                    headers={"Accept": "application/json"},
                    timeout=30,
                )
                read_resp.raise_for_status()
                parsed = _parse_odata_response(read_resp.json(), baseline_id)
                if isinstance(parsed, dict) and not parsed.get("error"):
                    template_data = parsed
                    logger.info("solman_write: template read succeeded on attempt %d", idx)
                    break
                last_template_exc = RuntimeError(str(parsed.get("error", "unknown template parse error")))
            except Exception as exc:
                last_template_exc = exc
                logger.warning("solman_write: template GET URL attempt %d failed: %s", idx, exc)

        if not isinstance(template_data, dict):
            raise RuntimeError(f"template read API failed for baseline_id={baseline_id}: {last_template_exc}")
    except Exception as exc:
        logger.warning("solman_write: CSRF/template fetch failed: %s", exc)
        session.close()
        return {"success": False, "cr_id": None, "error": f"CSRF/template fetch failed: {exc}"}

    # ── Step 1.5: Overlay state updates on top of template ──────────────────
    # When node_13 updates fields (e.g., SfaDeliver: "X"), those changes are stored
    # in state["cr_id"]["data"]. We must merge them into template_data so they
    # appear in the final payload instead of being lost.
    cr_id_state = state_snapshot.get("cr_id", {})
    logger.info("solman_write: Step 1.5 overlay — cr_id_state type=%s, keys=%s", 
                type(cr_id_state).__name__, list(cr_id_state.keys()) if isinstance(cr_id_state, dict) else "N/A")
    
    if isinstance(cr_id_state, dict) and isinstance(cr_id_state.get("data"), dict):
        _updates = cr_id_state["data"]
        logger.warning("solman_write: OVERLAY: cr_id.data has %d top-level keys to merge", len(_updates))
        logger.warning("solman_write: OVERLAY: template_data before merge has keys: %s", list(template_data.keys()))
        
        for _group_name, _group_data in _updates.items():
            if not isinstance(_group_data, dict):
                continue
            if not _group_name.startswith(("Iv", "Is")):
                continue
                
            # Count non-empty fields in this group
            _non_empty_fields = {k: v for k, v in _group_data.items() if v not in (None, "")}
            if _non_empty_fields:
                logger.warning("solman_write: OVERLAY: found %d non-empty fields in %s: %s", 
                              len(_non_empty_fields), _group_name, list(_non_empty_fields.keys()))
            
            # Merge user updates on top of template values
            if _group_name not in template_data:
                logger.warning("solman_write: OVERLAY: creating new group %s (didn't exist in template)", _group_name)
                template_data[_group_name] = {}
            
            if isinstance(template_data[_group_name], dict):
                logger.warning("solman_write: OVERLAY: merging %d fields into group %s", 
                              len(_group_data), _group_name)
                # Show before/after for key fields like SfaDeliver
                if _group_name == "IvFunctionalArea" and "SfaDeliver" in _group_data:
                    logger.warning("solman_write: OVERLAY: SfaDeliver BEFORE=%r, AFTER=%r", 
                                  template_data[_group_name].get("SfaDeliver"), _group_data.get("SfaDeliver"))
                template_data[_group_name].update(_group_data)
                logger.warning("solman_write: OVERLAY: confirmed update for group=%s", _group_name)
            else:
                logger.warning("solman_write: OVERLAY: FAILED — template_data[%s] is not a dict, type=%s", 
                              _group_name, type(template_data[_group_name]).__name__)
    else:
        logger.warning("solman_write: OVERLAY: SKIPPED — cr_id_state.data is empty or missing. cr_id_state=%s", cr_id_state)

    # ── Step 2: Build Iv* payload from read API values (keys can be hardcoded; values are not) ──
    # New API (ZCHM_RFC_SRV) uses Iv* groups exclusively for both GET and POST.
    payload_d: dict = {}

    _GROUP_MAPPINGS = {
        "IvDetails": ["IvDetails"],
        "IvOthers": ["IvOthers"],
        "IvValidation": ["IvValidation"],
        "IvFunctionalArea": ["IvFunctionalArea"],
        "IvDocumentation": ["IvDocumentation"],
        "IvTestReq": ["IvTestReq"],
        "IvLocation": ["IvLocation"],
        "IvScope": ["IvScope"],
        "IvContext": ["IvContext"],
    }

    _REQUIRED_GROUP_KEYS = {
        "IvDetails": [
            "Description", "Impact", "Urgency", "Risk", "PlannedImplementationDate", "Status",
            "StatusDesc", "ImpactDesc", "UrgencyDesc", "RecPriority", "RecPriorityT", "Priority",
            "PriorityDesc", "CreatedOn", "ChangedOn", "ActualImplementationDate", "RiskT",
            "RelatedIRISNumber", "Team", "TeamT", "SupportGroup", "AprvProc", "AprvProcDesc",
            "CatAspID", "CatID", "CatConcatenatedDescr", "TransactionNo",
        ],
        "IvValidation": [
            "UserRequirement", "UserRequirementT", "DocIDwVer7", "FunctionalReq", "FunctionalReqT",
            "DocIDwVer8", "FunctionalDesign", "FunctionalDesignT", "DocIDwVer9", "TechnicalDesign",
            "TechnicalDesignT", "DocIDwVer10", "Others1ValReq", "Others2ValReq",
        ],
        "IvFunctionalArea": [
            "PrimaryFunctionalArea", "PrimaryFunctionalAreaT", "SfaOFM", "SfaSource", "SfaDeliver",
            "SfaMake", "SfaPlan", "SfaQM", "SfaSecurity", "SfaLogistics", "SfaIMWM", "SfaMDM",
            "SfaDWMS", "SfaBI", "SfaIntegration", "SfaHR", "SfaPayroll", "SfaGlobalTrade", "SfaCRM",
            "SfaPortal", "SfaDevelopment", "SfaBasis",
        ],
        "IvDocumentation": [
            "BCSet", "BCSetT", "ConfigDocUpdate", "ConfigDocUpdateT", "DocIDwVer1", "CodeReview",
            "CodeReviewT", "SodRuleset", "SodRulesetT", "DocIDwVer2", "TrainingMaterials",
            "TrainingMaterialsT", "UpdateToSopWI", "UpdateToSopWIT", "DocIDwVer3", "BPMLUpdate",
            "BPMLUpdateT", "ProcessDecomposition", "DocIDwVer4", "BusProcAnalysis", "BusProcAnalysisT",
            "DocIDwVer5", "BusProcHierarchy", "BusProcHierarchyT", "DocIDwVer6", "Others1", "Others2",
            "Others3",
        ],
        "IvOthers": [
            "GxPRelevant", "GxPRelevantT", "SecurityChange", "SecurityChangeT", "SOXImpact", "SOXImpactT",
            "TrainUsers", "TrainUsersT", "EndUserTcode", "DefectReference", "RICEF", "Others1", "Others2",
            "Others3", "DeferredTo", "RequirementNo", "AdditionalDescr",
        ],
        "IvTestReq": [
            "FunctionUnitTestDev", "FunctionUnitTestDevT", "TechnicalUnitTestDev", "TechnicalUnitTestDevT",
            "ScreenShotQAS", "ScreenShotQAST", "SystemTestQAS", "SystemTestQAST", "TestReference1",
            "RegressionTestQAS", "RegressionTestQAST", "TestReference2", "UATQAS", "UATQAST",
            "TestReference3", "TestScript", "Others1", "Others2", "Others3", "ProdConfirm", "ProdConfirmT",
        ],
        "IvLocation": ["Platform", "PlatformT", "Site"],
        "IvScope": [
            "TransactionType", "TransactionID", "Description", "Status", "ConfigurationItem",
            "ConfigurationItemDescr", "IBase", "IBaseDescr", "Component", "ComponentDescr", "LogicalSys",
            "SysType", "SID", "Client",
        ],
        "IvContext": ["ChangeCycle", "ChangeCyclePhase", "CycleType", "CycleID", "Landscape", "Branch"],
    }

    for iv_group, candidate_names in _GROUP_MAPPINGS.items():
        source_group = {}
        for name in candidate_names:
            candidate = template_data.get(name)
            if isinstance(candidate, dict):
                source_group = dict(candidate)
                break

        normalized_group = {
            k: ("" if v is None else v)
            for k, v in source_group.items()
            if k != "__metadata"
        }

        # Keep required keys for SAP payload structure; do not inject non-empty defaults.
        for req_key in _REQUIRED_GROUP_KEYS.get(iv_group, []):
            normalized_group.setdefault(req_key, "")

        payload_d[iv_group] = normalized_group

    # ZCHM_RFC_SRV expects IvTemplateID
    payload_d["IvTemplateID"] = baseline_id
    logger.info("solman_write: RFC mode — building Iv* payload from read API template values")
    
    # DEBUG: Check if SfaDeliver made it into payload after overlay
    _sfa_deliver_in_payload = payload_d.get("IvFunctionalArea", {}).get("SfaDeliver", "")
    logger.warning("solman_write: DEBUG — SfaDeliver in payload_d after overlay=%r", _sfa_deliver_in_payload)

    # Strip leading zeros from ConfigurationItem (SAP stores it zero-padded up to 40 chars;
    # POST must use plain numeric value, e.g. "7100002899" not "000...7100002899").
    _iv_scope = payload_d.get("IvScope")
    if isinstance(_iv_scope, dict) and _iv_scope.get("ConfigurationItem"):
        _raw_ci = str(_iv_scope["ConfigurationItem"]).strip()
        _stripped_ci = _raw_ci.lstrip("0") or _raw_ci  # preserve "0" if value is all zeros
        if _stripped_ci != _raw_ci:
            logger.info("solman_write: stripped ConfigurationItem %r → %r", _raw_ci, _stripped_ci)
        _iv_scope["ConfigurationItem"] = _stripped_ci

    # Requestor WWID
    _requestor = (
        str(state_snapshot.get("wwid") or "").strip()
        or os.environ.get("SOLMAN_REQUESTOR_ID", "").strip()
    )
    if _requestor:
        payload_d["IvRequestor"] = _requestor
        logger.info("solman_write: set IvRequestor=%s", _requestor)
    else:
        logger.warning("solman_write: wwid not in request and SOLMAN_REQUESTOR_ID not set")

    # Resolve description and reason values
    doc_val = state_snapshot.get("description_of_change", {})
    doc_val = doc_val.get("value", "") if isinstance(doc_val, dict) else str(doc_val or "")
    roc_val = state_snapshot.get("reason_for_change", {})
    roc_val = roc_val.get("value", "") if isinstance(roc_val, dict) else str(roc_val or "")

    # JIRA summary used as CR title
    jira_state = state_snapshot.get("jira_id", {})
    jira_data = (jira_state.get("data") or {}) if isinstance(jira_state, dict) else {}
    cr_title = (
        str(jira_data.get("summary", "") or "").strip()
        or str(jira_data.get("title", "") or "").strip()
        or (doc_val[:100] if doc_val else "CR from AgentCore API")
    )

    payload_d.setdefault("IvDetails", {})
    payload_d["IvDetails"]["Description"] = cr_title
    logger.info("solman_write: set IvDetails.Description=%r", cr_title[:80])

    # Override CycleID only when a cycle was explicitly chosen; otherwise preserve template value.
    payload_d.setdefault("IvContext", {})
    if chosen_cycle_id:
        payload_d["IvContext"]["CycleID"] = chosen_cycle_id
        logger.info("solman_write: set IvContext.CycleID=%s", chosen_cycle_id)
    else:
        logger.info("solman_write: preserving template IvContext.CycleID=%s",
                    payload_d["IvContext"].get("CycleID", ""))

    # ── Override AprvProc with user-selected value (from node_21) ──────────────
    _aprv_state = state_snapshot.get("aprv_proc") or {}
    if isinstance(_aprv_state, dict) and _aprv_state.get("given"):
        _aprv_desc = str(_aprv_state.get("value") or "").strip()
        _aprv_code = approval_process_to_code(_aprv_desc) or _aprv_desc
        payload_d.setdefault("IvDetails", {})["AprvProc"] = _aprv_code
        logger.info("solman_write: set IvDetails.AprvProc=%r (from '%s')", _aprv_code, _aprv_desc)

    # ── Override TransactionType with user-selected value (from node_22) ──────
    _tt_state = state_snapshot.get("transaction_type") or {}
    if isinstance(_tt_state, dict) and _tt_state.get("given"):
        _tt_desc = str(_tt_state.get("value") or "").strip()
        _tt_code = transaction_type_to_code(_tt_desc)
        if _tt_code:
            payload_d.setdefault("IvScope", {})["TransactionType"] = _tt_code
            logger.info("solman_write: set IvScope.TransactionType=%r (from '%s')", _tt_code, _tt_desc)
        else:
            logger.info("solman_write: TransactionType '%s' — no SAP code mapping, preserving template value", _tt_desc)

    # ── Cross-check combination before POST ───────────────────────────────────
    _sc_chk  = str(payload_d.get("IvDetails", {}).get("StandardChange", "")).strip()
    _oc_chk  = str(payload_d.get("IvDetails", {}).get("OperateChange",  "")).strip()
    _ap_chk  = str(payload_d.get("IvDetails", {}).get("AprvProc",       "")).strip()
    _tt_chk  = str(payload_d.get("IvScope",   {}).get("TransactionType","")).strip()
    _ct_chk  = str(payload_d.get("IvContext", {}).get("CycleType",      "")).strip()
    if _tt_chk:
        _combo = validate_change_type_combination(_sc_chk, _oc_chk, _ap_chk, _tt_chk, _ct_chk)
        if not _combo["valid"]:
            logger.error("solman_write: combination validation failed — %s", _combo["error"])
            session.close()
            return {"success": False, "cr_id": None, "error": _combo["error"]}
        logger.info("solman_write: combination check passed SC=%r OC=%r AprvProc=%r TT=%r CT=%r",
                    _sc_chk, _oc_chk, _ap_chk, _tt_chk, _ct_chk)

    # Keep POST body aligned with QA Create API contract (expected payload shape).
    _WRITE_ALLOWED_FIELDS = {
        "IvDetails": {"Description", "Impact", "Urgency", "Risk",
                      "StandardChange", "OperateChange", "AprvProc"},
        "IvScope":   {"TransactionType", "ConfigurationItem"},
        "IvLocation": {"Platform"},
        "IvContext": {"CycleID", "ChangeCycle", "ChangeCyclePhase", "CycleType", "Landscape", "Branch"},
        "IvValidation": {
            "UserRequirement", "DocIDwVer7", "FunctionalReq", "DocIDwVer8",
            "FunctionalDesign", "DocIDwVer9", "DocIDwVer10",
            "Others1ValReq", "Others2ValReq",
        },
        "IvFunctionalArea": {
            "PrimaryFunctionalArea", "SfaOFM", "SfaSource", "SfaDeliver",
            "SfaMake", "SfaPlan", "SfaQM", "SfaSecurity", "SfaLogistics",
            "SfaIMWM", "SfaMDM", "SfaDWMS", "SfaBI", "SfaIntegration",
            "SfaHR", "SfaPayroll", "SfaGlobalTrade", "SfaCRM", "SfaPortal",
            "SfaDevelopment", "SfaBasis",
        },
        "IvDocumentation": {
            "BCSet", "ConfigDocUpdate", "DocIDwVer1", "CodeReview", "SodRuleset",
            "DocIDwVer2", "TrainingMaterials", "UpdateToSopWI", "DocIDwVer3",
            "BPMLUpdate", "ProcessDecomposition", "DocIDwVer4", "BusProcAnalysis",
            "DocIDwVer5", "BusProcHierarchy", "DocIDwVer6", "Others1", "Others2", "Others3",
        },
        "IvOthers": {
            "GxPRelevant", "SecurityChange", "SOXImpact", "TrainUsers", "EndUserTcode",
            "DefectReference", "RICEF", "Others1", "Others2", "Others3", "RequirementNo",
        },
        "IvTestReq": {
            "FunctionUnitTestDev", "TechnicalUnitTestDev", "ScreenShotQAS", "SystemTestQAS",
            "TestReference1", "RegressionTestQAS", "TestReference2", "UATQAS", "TestReference3",
            "TestScript", "Others1", "Others2", "Others3",
        },
    }
    _WRITE_ALLOWED_GROUPS = set(_WRITE_ALLOWED_FIELDS.keys()) | {"IvTemplateID", "IvRequestor", "toTexts"}

    # Remove groups not part of Create contract (e.g., IvContext/IvScope/IvLocation).
    for _grp_name in list(payload_d.keys()):
        if _grp_name not in _WRITE_ALLOWED_GROUPS:
            del payload_d[_grp_name]
            logger.info("solman_write: removed unsupported group %s", _grp_name)

    # Keep only allowed fields within each group.
    for _grp_name, _allowed_fields in _WRITE_ALLOWED_FIELDS.items():
        _grp = payload_d.get(_grp_name)
        if not isinstance(_grp, dict):
            payload_d[_grp_name] = {}
            continue
        for _field in list(_grp.keys()):
            if _field not in _allowed_fields:
                del _grp[_field]
                logger.info("solman_write: removed unsupported field %s from %s", _field, _grp_name)

    # Build toTexts as flat array (not wrapped in {"results": ...})
    out_results = []
    if doc_val:
        out_results.append({
            "TdID": "CR01",
            "TdIDDescr": "Description of Change",
            "TextLines": doc_val,
        })
    if roc_val:
        out_results.append({
            "TdID": "CR02",
            "TdIDDescr": "Reason for Change",
            "TextLines": roc_val,
        })
    if out_results:
        payload_d["toTexts"] = out_results
        logger.info("solman_write: prepared toTexts payload rows=%d (flat array)", len(out_results))

    # Normalize only sample-payload boolean sections to SAP 1/0 format.
    # Intentionally scoped to requested sections to avoid changing other groups.
    _POST_BOOL_01_FIELDS = {
        "IvValidation": {
            "UserRequirement", "FunctionalReq", "FunctionalDesign",
        },
        "IvDocumentation": {
            "BCSet", "ConfigDocUpdate", "CodeReview", "SodRuleset",
            "TrainingMaterials", "UpdateToSopWI", "BPMLUpdate",
            "BusProcAnalysis", "BusProcHierarchy",
        },
        "IvOthers": {
            "GxPRelevant", "SecurityChange", "SOXImpact", "TrainUsers",
        },
        "IvTestReq": {
            "FunctionUnitTestDev", "TechnicalUnitTestDev", "ScreenShotQAS",
            "SystemTestQAS", "RegressionTestQAS", "UATQAS", "ProdConfirm",
        },
    }

    _VALID_BOOL_VALUES = {"1", "0", "YES", "NO", "Y", "N", "TRUE", "FALSE", "T", "F", "X"}

    def _to_01(v: object) -> str:
        s = str(v or "").strip().upper()
        if s in {"1", "YES", "Y", "TRUE", "T", "X"}:
            return "1"
        if s in {"0", "NO", "N", "FALSE", "F"}:
            return "0"
        return str(v or "").strip()

    # ── VALIDATION: Boolean fields — reject invalid values ──────────────────
    for _group, _fields in _POST_BOOL_01_FIELDS.items():
        _grp = payload_d.get(_group)
        if not isinstance(_grp, dict):
            continue
        for _f in _fields:
            if _f in _grp and _grp[_f] not in (None, ""):
                _val = str(_grp[_f]).strip().upper()
                # REJECT invalid boolean values
                if _val not in _VALID_BOOL_VALUES:
                    error_msg = (
                        f"Invalid value '{_grp[_f]}' for boolean field '{_f}'. "
                        f"Please choose: Yes/No (or 1/0, True/False)"
                    )
                    logger.error("solman_write: VALIDATION FAILED - %s", error_msg)
                    session.close()
                    return {"success": False, "cr_id": None, "error": error_msg}
                # Convert to 1/0
                _grp[_f] = _to_01(_grp[_f])

    # Functional area flags use SAP X/blank semantics (not 1/0).
    # Apply only to IvFunctionalArea Sfa* fields.
    _POST_FUNCTIONALAREA_X_FIELDS = {
        "SfaOFM", "SfaSource", "SfaDeliver", "SfaMake", "SfaPlan", "SfaQM",
        "SfaSecurity", "SfaLogistics", "SfaIMWM", "SfaMDM", "SfaDWMS", "SfaBI",
        "SfaIntegration", "SfaHR", "SfaPayroll", "SfaGlobalTrade", "SfaCRM",
        "SfaPortal", "SfaDevelopment", "SfaBasis",
    }

    _VALID_CHECKBOX_VALUES = {"1", "0", "YES", "NO", "Y", "N", "TRUE", "FALSE", "T", "F", "X", ""}

    def _to_x_blank(v: object) -> str:
        s = str(v or "").strip().upper()
        if s in {"1", "YES", "Y", "TRUE", "T", "X"}:
            return "X"
        if s in {"0", "NO", "N", "FALSE", "F", ""}:
            return ""
        return str(v or "").strip()

    # ── VALIDATION: Checkbox fields — reject invalid values ───────────────────
    _fa_group = payload_d.get("IvFunctionalArea")
    if isinstance(_fa_group, dict):
        for _f in _POST_FUNCTIONALAREA_X_FIELDS:
            if _f in _fa_group and _fa_group[_f] not in (None, ""):
                _val = str(_fa_group[_f]).strip().upper()
                # REJECT invalid checkbox values
                if _val not in _VALID_CHECKBOX_VALUES:
                    error_msg = (
                        f"Invalid value '{_fa_group[_f]}' for functional area '{_f}'. "
                        f"Please choose: Yes/No (or 1/0, True/False, X for checked)"
                    )
                    logger.error("solman_write: VALIDATION FAILED - %s", error_msg)
                    session.close()
                    return {"success": False, "cr_id": None, "error": error_msg}
                # Convert to X/blank
                _fa_group[_f] = _to_x_blank(_fa_group[_f])

    payload = {"d": payload_d}

    # ── Log full payload before sending ──────────────────────────────────────
    try:
        _payload_json = json.dumps(payload, indent=2, default=str)
        logger.info("solman_write: POST URL = %s", post_url)
        logger.info("solman_write: FULL PAYLOAD BEING SENT TO SAP CR API:\n%s", _payload_json)
    except Exception as _log_exc:
        logger.warning("solman_write: could not serialize payload for logging: %s", _log_exc)

    try:
        resp = session.post(
            post_url,
            headers={
                "Content-Type": "application/json",
                "Accept": "application/json",
                "X-CSRF-Token": csrf_token,
            },
            json=payload,
            timeout=30,
        )
        logger.info(
            "solman_write: POST status=%s content-type=%s",
            resp.status_code,
            resp.headers.get("Content-Type", ""),
        )

        # Always print full POST API response in readable form for cross-verification
        _resp_json = None
        try:
            _resp_json = resp.json()
            logger.info(
                "solman_write: POST API RESPONSE (pretty JSON):\n%s",
                json.dumps(_resp_json, indent=2, default=str),
            )
        except Exception:
            logger.info(
                "solman_write: POST API RESPONSE (raw):\n%s",
                resp.text,
            )

        resp.raise_for_status()
        data = _resp_json if isinstance(_resp_json, dict) else resp.json()
        try:
            logger.info(
                "solman_write: FULL RESPONSE PAYLOAD FROM SAP CR API:\n%s",
                json.dumps(data, indent=2, default=str)[:12000],
            )
        except Exception as _resp_log_exc:
            logger.warning("solman_write: could not serialize response payload for logging: %s", _resp_log_exc)

        # ── Check for SAP business/validation error inline in a 200 OK body ──
        # ZCHM_RFC_SRV can return HTTP 200 while still signaling a real failure
        # via EvHasError="X" (with EvMessage / ET_RETURN carrying the root
        # cause). Without this check, such failures would be silently reported
        # as success. Route it through the same is_sap_error path as an HTTP
        # error so node_15_failed shows the actual SAP reason to the user.
        _has_business_error, _business_message = _extract_sap_bapiret_errors(data)
        if _has_business_error:
            logger.warning(
                "solman_write: SAP returned 200 OK but EvHasError=X — treating as failure: %s",
                _business_message,
            )
            return {
                "success": False,
                "cr_id": None,
                "error": _business_message,
                "sap_transaction_id": None,
                "is_sap_error": True,
            }

        new_cr_id = (
            data.get("d", {}).get("EvObjectID")
            or data.get("d", {}).get("EvObjectId")
            or data.get("EvObjectID")
            or data.get("EvObjectId")
            or data.get("id")
            or data.get("cr_id")
        )
        logger.info("solman_write: CR created successfully, EvObjectID=%s", new_cr_id)
        return {"success": True, "cr_id": new_cr_id, "error": None, "response_data": data.get("d", {})}
    except requests.HTTPError as exc:
        # Keep full technical SAP details in logs only.
        try:
            sap_body = exc.response.text[:2000]
        except Exception:
            sap_body = "(no response body)"
        logger.warning("solman_write HTTP error %s — SAP body: %s", exc, sap_body)

        # Extract the SAP business error message + transaction ID so a
        # friendly, traceable message can be shown to the user downstream
        # (node_15_failed) without leaking the full technical SAP payload.
        sap_message = None
        sap_transaction_id = None
        try:
            _err_json = exc.response.json()
            # Prefer ZCHM_RFC_SRV's own business-error fields (EvHasError /
            # EvMessage / ET_RETURN) when present — they carry the real root
            # cause. Fall back to the standard OData error envelope otherwise.
            _has_business_error, _business_message = _extract_sap_bapiret_errors(_err_json)
            if _has_business_error:
                sap_message = _business_message
            else:
                _err_obj = _err_json.get("error", {}) if isinstance(_err_json, dict) else {}
                _msg_obj = _err_obj.get("message", {})
                sap_message = (
                    _msg_obj.get("value") if isinstance(_msg_obj, dict) else (str(_msg_obj) or None)
                )
                sap_transaction_id = (_err_obj.get("innererror") or {}).get("transactionid")
        except Exception as parse_exc:
            logger.warning("solman_write: could not parse SAP error JSON: %s", parse_exc)

        return {
            "success": False,
            "cr_id": None,
            "error": sap_message or "Solution Manager submission failed",
            "sap_transaction_id": sap_transaction_id,
            # Marks this as a genuine SAP API failure (HTTP error returned by
            # SAP itself), as opposed to agent-side errors (config, CSRF fetch,
            # field validation, etc.) — used by node_15_failed to decide
            # whether to show the SAP reason/transaction ID to the user.
            "is_sap_error": True,
        }
    except Exception as exc:
        logger.warning("solman_write failed: %s", exc)
        return {"success": False, "cr_id": None, "error": str(exc)}
    finally:
        session.close()