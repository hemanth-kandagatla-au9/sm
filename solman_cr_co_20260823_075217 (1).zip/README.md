# CR Agent

CR Agent is a LangGraph-based assistant for drafting and submitting SAP Solution Manager Change Requests. It validates scope against SOP-8794, resolves platforms and target systems from Neo4j, fetches Jira and Solman data, builds a draft, and submits the final payload after user approval.

The repository supports below runtime entry point:

- `main.py` for the AgentCore HTTP runtime used in the EC2/QA deployment.

## What the agent does

The agent runs a guided CR lifecycle from intake to submission:

1. **Understands user input**
	- Extracts CR-relevant fields such as platform, target system, template ID, CR ID, Jira ID, reason, and description.
	- Tracks whether each field is missing, provided, validated, or needs user correction.

2. **Applies scope and policy guardrails**
	- Validates whether the change request is in scope for SOP-8794.
	- Routes out-of-scope requests to the correct channel instead of drafting a CR that cannot be processed.

3. **Validates platform and system context**
	- Resolves platform aliases to canonical platform names.
	- Validates target system compatibility with the selected platform.
	- Uses Neo4j-backed lookups to reduce invalid combinations.

4. **Pulls live source data**
	- Fetches Solman template details from the OData read API.
	- Fetches Jira ticket data through the Solman Jira proxy.
	- Uses these values to prefill draft fields and reduce manual entry.

5. **Builds and presents a draft CR**
	- Fetches CR template structure from Solman OData read API as the primary source.
	- Falls back to Neo4j if Solman fetch fails or returns incomplete data.
	- Generates a structured draft by merging template data, user input, and Jira data.
	- Presents the draft in a review-friendly format.
	- Preserves key server-managed values while allowing eligible user updates.

6. **Supports human-in-the-loop decisions**
	- Pauses for user review at key checkpoints.
	- Accepts approval, questions, and update requests.
	- Enforces locked-field rules and asks for clarification when needed.

7. **Handles recommendation-based flow when template is missing**
	- Suggests similar historical CRs from Neo4j.
	- Lets users pick and continue from a recommended baseline.

8. **Submits only after approval**
	- Builds the final Solman write payload using allowed SAP groups and fields.
	- Removes unsupported groups/fields before POST.
	- Submits to Solman and returns success/failure with CR ID when available.

9. **Captures operational outcomes**
	- Tracks submission result and flow metrics.
	- Keeps state across interaction turns to support resume/review workflows.

## Repository layout

```text
.
├── main.py
├── set_env.sh
├── config/
├── state/
├── tools/
├── agents/
├── graph/
├── utils/
├── tests/
├── _scm_config/
├── _scm_iac/
└── _scm_jenkins/
```

## Runtime model

### AgentCore / EC2

`main.py` loads `agentcore/.env.local` first when present, then `.env`, and resolves SSM parameter names before importing runtime configuration. This is the path used by the QA deployment.

## Prerequisites

- Python 3.10 or newer.
- Azure OpenAI access.
- Neo4j 5.x with `Platform`, `TargetSystem`, and `ChangeRequest` data.
- SAP Solution Manager read access.
- SAP Solution Manager submit access.
- Jira access through the Solman proxy endpoint.

## Installation

```powershell
cd solman_cr_co
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

## Configuration

For local development, use a `.env` file. For the current QA runtime, use `set_env.sh` and the `_scm_config` files.

### Local `.env`

```env
AZURE_OPENAI_API_KEY=your-key
AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com/
AZURE_OPENAI_API_VERSION=2024-10-21
AZURE_OPENAI_DEPLOYMENT=gpt-5.4-mini-global
AZURE_OPENAI_EMBEDDING_API_VERSION=2024-10-21
AZURE_OPENAI_EMBEDDING_DEPLOYMENT=text-embedding-3-large

SOLMAN_READ_BASE_URL=https://your-solman-host.com
SOLMAN_READ_USERNAME=your-username
SOLMAN_READ_PASSWORD=your-password
SOLMAN_READ_VERIFY_SSL=false
SOLMAN_ODATA_PATH=/sap/opu/odata/sap/ZCHM_RFC_SRV/ChangeRequestSet

JIRA_BASE_URL=https://your-solman-host.com/sap/opu/odata/sap/ZJIRA_SRV
JIRA_RESOURCE_PATH=JIRAIssueSet
JIRA_USERNAME=your-jira-proxy-username
JIRA_PASSWORD=your-jira-proxy-password

NEO4J_URI=bolt://localhost:7687
NEO4J_USER=neo4j
NEO4J_PASSWORD=your-password
NEO4J_DATABASE=neo4j

SOP_PATH=sop_instructions.txt
RESOLVE_SSM_PARAMS=false
USE_AGENTCORE_MEMORY=true
```

### QA runtime variables

The current QA runtime uses `set_env.sh` with SSM-backed parameter names. The important values are:

- `RESOLVE_SSM_PARAMS=true`
- `SOLMAN_READ_BASE_URL=https://solman-qa.jnj.com`
- `SOLMAN_READ_USERNAME=JJYY-CRCO-DEV-SOLMAN_READ_USERNAME_QA`
- `SOLMAN_READ_PASSWORD=JJYY-CRCO-DEV-SOLMAN_READ_PASSWORD_QA`
- `JIRA_BASE_URL=https://solman-qa.jnj.com/sap/opu/odata/sap/ZJIRA_SRV`
- `JIRA_USERNAME=JJYY-CRCO-DEV-SOLMAN_READ_USERNAME_QA`
- `JIRA_PASSWORD=JJYY-CRCO-DEV-SOLMAN_READ_PASSWORD_QA`

## Running the application

### AgentCore HTTP runtime

```powershell
python main.py
```

When `set_env.sh` is sourced, the runtime uses port `8081`.

### AG-UI runtime (3 terminals)

The AG-UI stack (chat + generative UI in the browser) runs as three separate processes: the Python agent, the CopilotKit bridge, and the React frontend.

**Terminal 1 — Python AG-UI agent (`agui_server.py`, port 8084)**
```bash
cd solman_cr_co
source set_env.sh
python agui_server.py
```

**Terminal 2 — CopilotKit bridge (`agui_runtime/`, port 8006)**
```bash
cd solman_cr_co
export AGUI_BACKEND_URL="http://localhost:8084/copilotkit"
cd agui_runtime
node server.mjs
```

**Terminal 3 — Frontend (`frontend/`, port 8005)**
```bash
cd solman_cr_co/frontend
export VITE_AGUI_API_BASE="http://localhost:8084"
export VITE_AGUI_RUNTIME_URL="http://localhost:8006/api/copilotkit"
npm run dev
```

Start Terminal 1 first and wait until `curl http://localhost:8084/api/ui-contract` returns JSON before starting Terminal 2 — the bridge does not retry a dead backend. Start Terminal 3 last, then open `http://localhost:8005`.

A single-script alternative that starts all three at once: `source set_env.sh && ./run_agui.sh`.

## Operational flow

- `validate_change_scope()` performs the SOP-8794 scope check.
- `get_jira_data()` fetches Jira proxy data using `JIRA_USERNAME` and `JIRA_PASSWORD`.
- `get_template()` reads Solman template data from the OData read API.
- `solman_write()` builds the final SAP payload and submits it with the Solman read credentials.
- `execute_cypher()` is used for Neo4j lookups and recommendations.

The write payload is built from the allowed SAP groups only: `IvDetails`, `IvValidation`, `IvFunctionalArea`, `IvDocumentation`, `IvOthers`, and `IvTestReq`. Unsupported groups are removed before POST.

## Node map

The graph registers **26 nodes total**: **24 operational nodes** and **2 passthrough routing helpers**.

| Node | Role |
|------|------|
| `node_1` | Extracts CR fields from the conversation and marks which values the user has already provided. |
| `node_2` | Validates scope, fetches Jira/Solman data, and resolves platform or target-system values. |
| `node_3` | Asks the user for missing information when required fields are still incomplete. |
| `node_4` | HITL pause for missing data review and resume. |
| `node_5` | Collects metrics and ends the flow on terminal paths. |
| `node_6` | Builds the CR draft from Solman OData template data (primary) or Neo4j fallback, plus Jira data and SOP instructions. |
| `node_7` | Suggests similar CRs when no template ID is provided. |
| `node_8` | Presents the draft back to the user for review. |
| `node_9` | HITL pause for draft review, approval, update, or question handling. |
| `node_10` | Parses update intent and routes the user’s request to confirm, reject, or apply a field change. |
| `node_10b` | Confirms a field update when the requested change is allowed and unambiguous. |
| `node_10c` | Handles rejection or clarification when the update cannot be applied as requested. |
| `node_11` | Answers user questions using LLM reasoning plus Neo4j data lookup. |
| `node_s` | Returns the generated answer text and resumes the review loop. |
| `node_12` | Submits the finalized CR to Solman. |
| `node_13` | Applies user-approved draft updates and re-renders the draft. |
| `node_14` | Denies updates for locked fields. |
| `node_15` | Returns a submission-failed message after a Solman write error. |
| `node_16` | Returns a submission-success message with the new CR ID. |
| `node_17` | Presents the top 5 similar CR recommendations. |
| `node_18` | HITL pause for recommendation selection and resume. |
| `node_19` | Ends the recommendation branch when no suitable match is available. |
| `node_20` | Checks whether the draft cycle ID matches the selected CR/template and decides the next step. |
| `node_20b` | HITL pause for cycle ID confirmation when the draft cycle does not match the selected option. |
| `cond_edge_b` | Passthrough routing node that allows the approval/question/update decision branch to work with `Command.goto`. |
| `cond_edge_c` | Passthrough routing node that allows the recommendation branch decision logic to work with `Command.goto`. |

### Main path at a glance

1. `node_1` extracts fields.
2. `node_2` validates scope and gathers data.
3. `node_6` or `node_7` starts the draft or recommendation branch.
4. `node_8` and `node_9` manage draft review.
5. `node_12` submits the final CR when approved.

## External integrations

### Azure OpenAI

Used for scope classification, field extraction, draft generation, and intent routing.

### SAP Solution Manager

- `get_template(template_id)` fetches the CR template.
- `get_template_grouped(template_id)` returns the grouped template structure for UI rendering.
- `solman_write(draft, state)` submits the final CR.

### Jira

- `get_jira_data(jira_id)` fetches ticket summary, description, due date, and test IDs from the proxy endpoint.

### Neo4j

- `validate_platform(platform)` resolves platform names.
- `validate_target_system(target, platform?)` resolves target systems.
- `execute_cypher(query, params)` runs Cypher queries.

## Human-in-the-loop flow

Three nodes pause for user input:

- Node 4 asks for missing information.
- Node 9 asks the user to review the draft.
- Node 18 asks the user to choose from recommendations.

## Testing

Run the automated tests with:

```powershell
pytest tests -v
```

## Troubleshooting

- If credentials are not resolving, check `RESOLVE_SSM_PARAMS` and the parameter names in `set_env.sh`.
- If Jira or Solman auth fails, confirm the QA SSM-backed names are being sourced before startup.
- If Neo4j lookups fail, confirm the database is reachable and contains the expected nodes.
- If Azure OpenAI calls fail, confirm the deployment name in `AZURE_OPENAI_DEPLOYMENT` matches the Azure resource exactly.
