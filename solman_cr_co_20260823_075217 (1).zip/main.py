"""
main.py — AgentCore HTTP server for the CR Agent.
"""

from __future__ import annotations
import argparse
import json
import os
import sys
import time
import uuid
from typing import Any
from http.server import BaseHTTPRequestHandler, HTTPServer

from opentelemetry import trace
from opentelemetry.context import detach
from opentelemetry.trace import Status, StatusCode

# ── Path fix (same as original main.py) ──────────────────────────────────────
_THIS_FILE  = os.path.abspath(__file__)
_PACKAGE_DIR = os.path.dirname(_THIS_FILE)
_PARENT_DIR  = os.path.dirname(_PACKAGE_DIR)

for _p in (_PARENT_DIR, _PACKAGE_DIR):
    if _p not in sys.path:
        sys.path.insert(0, _p)

# ── Load .env automatically ───────────────────────────────────────────────────
try:
    from dotenv import load_dotenv
    # Load agentcore/.env.local first (SSM parameter names for dev/prod via agentcore)
    _env_local = os.path.join(_PACKAGE_DIR, "agentcore", ".env.local")
    if os.path.exists(_env_local):
        load_dotenv(_env_local, override=True)
        print(f"[INFO] Loaded agentcore/.env.local from {_env_local}")
    # Also load .env if present (plain local dev without agentcore)
    _env_path = os.path.join(_PACKAGE_DIR, ".env")
    if os.path.exists(_env_path):
        load_dotenv(_env_path)
        print(f"[INFO] Loaded .env from {_env_path}")
except ImportError:
    pass

# ── SSM secret resolution (MUST run before any config/graph import) ──────────
# When RESOLVE_SSM_PARAMS=true, env vars hold SSM parameter *names* which are
# resolved to their real values here before config modules read them at import time.
from config.ssm_bootstrap import resolve_ssm_parameters
resolve_ssm_parameters()

# ── Your existing imports (unchanged) ────────────────────────────────────────
from langchain_core.messages import AIMessage, HumanMessage
from langgraph.types import Command

from graph.builder import build_graph
from state.state import build_initial_state
from config.config import FIELD_GROUPS, ODATA_FIELD_MAP, BOOL_FIELDS
from tools.tools import approval_process_to_display, transaction_type_to_display, dropdown_to_display
from observability import (
    configure_logging,
    get_logger,
    set_request_context,
    set_task_context,
    get_business_trace_values,
    set_span_attributes,
    attach_business_baggage,
    log_business_trace_context,
    patch_otel_callback_handler,
    TokenCostCallbackHandler,
    reset_token_accumulator,
    get_token_accumulator,
    derive_task_status,
)

# ── Logging setup ─────────────────────────────────────────────────────────────
# /app is read-only in AgentCore runtime — write logs to /tmp instead
_log_file = os.path.join(os.environ.get("AGENT_LOG_DIR", "/tmp"), "agent.log")
configure_logging(_log_file)
patch_otel_callback_handler()
logger = get_logger("cr_agent.main")
logger.info("agent.log started — %s", _log_file)


tracer = trace.get_tracer(__name__)


# ── Helpers (same logic as original) ─────────────────────────────────────────

def _collect_messages(event: dict, seen_ids: set) -> list[str]:
    """
    Collect new AIMessage content from a single streaming event.
    Uses seen_ids (mutated in place) to deduplicate across events —
    stream_mode='values' re-emits the full message list on every node,
    so without dedup the same message appears once per subsequent node.
    Strips the [AGENT]: prefix — callers receive clean text for chat_text.
    """
    collected = []
    for msg in event.get("messages", []):
        if not isinstance(msg, AIMessage) or not msg.content:
            continue
        # Use LangChain message id when available, fall back to content hash
        msg_key = getattr(msg, "id", None) or str(msg.content)[:120]
        if msg_key in seen_ids:
            continue
        seen_ids.add(msg_key)
        # Skip internal node-to-node handoff messages — never shown to users
        if str(msg.content).startswith("Parsed update intents:"):
            continue
        collected.append(str(msg.content).strip())
    return collected


def _deep_merge_dict(base: dict[str, Any], overlay: dict[str, Any]) -> dict[str, Any]:
    """Recursively merge nested dictionaries while preserving sibling keys."""
    merged = dict(base)
    for key, value in overlay.items():
        existing = merged.get(key)
        if isinstance(existing, dict) and isinstance(value, dict):
            merged[key] = _deep_merge_dict(existing, value)
        else:
            merged[key] = value
    return merged


def _build_draft_document(state_values: dict) -> "dict | None":
    """
    Build the CR draft document as native Tiptap / ProseMirror JSON.

    Returns None when no draft has been created yet.
    Returns {"type": "doc", "content": [...]} when a draft exists —
    directly consumable by Tiptap's editor.setContent().
    All fields are always included; empty values render as an em-dash.
    """
    if not state_values.get("draft"):
        return None

    # ── Build flat {edl_key: value} from API state data ────────────────────
    # Source precedence is intentional:
    #   template_id.data (base) < cr_id.data (override)
    # so template-only flows populate fields while CR flows remain unchanged.
    template_state = state_values.get("template_id", {})
    cr_id_state = state_values.get("cr_id", {})
    api_data: dict = {}

    if isinstance(template_state, dict):
        d = template_state.get("data")
        if isinstance(d, dict):
            api_data = dict(d)

    if isinstance(cr_id_state, dict):
        d = cr_id_state.get("data")
        if isinstance(d, dict):
            api_data = _deep_merge_dict(api_data, d)

    flat: dict[str, str] = {}
    _GROUP_ALIASES = {
        "IvDetails": ["IvDetails"],
        "IvValidation": ["IvValidation"],
        "IvTestReq": ["IvTestReq"],
        "IvDocumentation": ["IvDocumentation"],
        "IvOthers": ["IvOthers"],
        "IvLocation": ["IvLocation"],
        "IvFunctionalArea": ["IvFunctionalArea"],
    }
    for (grp, api_field), edl_key in ODATA_FIELD_MAP.items():
        _candidates = _GROUP_ALIASES.get(grp, [grp])
        for _cand in _candidates:
            grp_data = api_data.get(_cand, {})
            if not isinstance(grp_data, dict):
                continue
            val = grp_data.get(api_field)
            if val is not None and str(val).strip() != "":
                flat[edl_key] = str(val).strip()
                break

    # ── Overlay context-like fields from details (when present) ──
    _DETAILS_TO_EDL = {
        "CycleId":           "solution_id_ctx",
        "CycleType":         "release_type_ctx",
        "Landscape":         "slan_name_ctx",
        "ChangeCycle":       "project_title_ctx",
        "ChangeCyclePhase":  "current_phase_desc_ctx",
        "Branch":            "sbra_name_ctx",
        "ApprovalProcedure": "approve_status_ctx",
        "Risk":              "risk_adtnl",
        "Priority":          "priority_adtnl",
        "Status":            "status_adtnl",
        "ProcessType":       "process_type_ctx",
        "TransactionNo":     "object_id",
        "PostingDate":       "posting_date",
        "ChangedAt":         "changed_at",
    }
    for _details_grp in ("IvDetails",):
        is_details = api_data.get(_details_grp, {})
        if isinstance(is_details, dict):
            for api_f, edl_f in _DETAILS_TO_EDL.items():
                v = is_details.get(api_f)
                if v is not None and str(v).strip():
                    flat[edl_f] = str(v).strip()

    # ── Overlay cycle/context fields from context group (primary source) ──
    _CONTEXT_TO_EDL = {
        "CycleID":          "solution_id_ctx",
        "ChangeCycle":      "project_title_ctx",
        "ChangeCyclePhase": "current_phase_desc_ctx",
        "Landscape":        "slan_name_ctx",
        "Branch":           "sbra_name_ctx",
        "CycleType":        "release_type_ctx",
    }
    for _ctx_grp in ("IvContext",):
        _ctx_data = api_data.get(_ctx_grp, {})
        if isinstance(_ctx_data, dict):
            for api_f, edl_f in _CONTEXT_TO_EDL.items():
                v = _ctx_data.get(api_f)
                if v is not None and str(v).strip():
                    flat[edl_f] = str(v).strip()

    # ── Overlay user-provided state fields (always most up-to-date) ──
    for sf in ("platform", "target_system"):
        fs = state_values.get(sf, {})
        if isinstance(fs, dict) and fs.get("value"):
            flat[sf] = str(fs["value"]).strip()

    # ── Overlay Jira-derived EDL fields stored directly in state ──
    for sf in ("zzfld00000v_cus", "zzfld00004y", "zzfld00000w_cus", "zzfld00004x"):
        fs = state_values.get(sf, {})
        if isinstance(fs, dict) and fs.get("value"):
            flat[sf] = str(fs["value"]).strip()

    # Explicit overlay for Functional Areas from RFC response shape.
    # This ensures Sfa* values from IvFunctionalArea are shown in the draft
    # even when upstream state contains mixed Is*/Iv* payload variants.
    _fa_data = api_data.get("IvFunctionalArea") or {}
    if isinstance(_fa_data, dict):
        _FA_DIRECT_MAP = {
            "PrimaryFunctionalArea": "zzfld000016_cus",
            "SecondaryFunctionalArea": "zzfld000017_cus",
            "SfaLogistics": "zzfld00002c_cus",
            "SfaOFM": "zzfld00001b_cus",
            "SfaSource": "zzfld00001c_cus",
            "SfaDeliver": "zzfld00001d_cus",
            "SfaMake": "zzfld00001e_cus",
            "SfaPlan": "zzfld00001f_cus",
            "SfaQM": "zzfld00001g_cus",
            "SfaSecurity": "zzfld00001h_cus",
            "SfaBasis": "zzfld00001i_cus",
            "SfaIMWM": "zzfld00001j_cus",
            "SfaMDM": "zzfld00001k_cus",
            "SfaDWMS": "zzfld00001l_cus",
            "SfaBI": "zzfld00001m_cus",
            "SfaIntegration": "zzfld00001r_cus",
            "SfaHR": "zzfld00001s_cus",
            "SfaPayroll": "zzfld00001t_cus",
            "SfaCRM": "zzfld00001u_cus",
            "SfaDevelopment": "zzfld00001v_cus",
            "SfaPortal": "zzfld00001w_cus",
            "SfaGlobalTrade": "zzfld00002h_cus",
        }
        for _api_f, _edl_f in _FA_DIRECT_MAP.items():
            _v = _fa_data.get(_api_f)
            if _v is not None and str(_v).strip() != "":
                flat[_edl_f] = str(_v).strip()

    # If SAP does not populate explicit Secondary Functional Area, derive it
    # from selected Sfa* flags so the generated draft is not blank.
    if not flat.get("zzfld000017_cus"):
        _derived_secondary: list[str] = []
        _fa_keys = FIELD_GROUPS.get("Functional Areas", {})
        for _k, _label in _fa_keys.items():
            if _k in {"zzfld000016_cus", "zzfld000017_cus"}:
                continue
            _v = str(flat.get(_k, "")).strip().upper()
            if _v in {"X", "1", "YES", "TRUE"}:
                _derived_secondary.append(_label)
        if _derived_secondary:
            flat["zzfld000017_cus"] = ", ".join(_derived_secondary)

    # Status has no deterministic code→display helper (workflow-controlled by SAP) —
    # use StatusDesc from the API response as fallback for display only.
    _DISPLAY_FALLBACK_FROM_TEMPLATE: dict[str, str] = {}
    _iv_details_fb = api_data.get("IvDetails") or {}
    if isinstance(_iv_details_fb, dict) and str(_iv_details_fb.get("StatusDesc") or "").strip():
        _DISPLAY_FALLBACK_FROM_TEMPLATE["status_adtnl"] = str(_iv_details_fb.get("StatusDesc") or "").strip()

    # ── ProseMirror node helpers ──────────────────────────────────────────────
    def _heading(text: str, level: int = 1) -> dict:
        return {
            "type": "heading",
            "attrs": {"level": level},
            "content": [{"type": "text", "marks": [{"type": "bold"}], "text": text}],
        }

    def _field_paragraph(label: str, value: str) -> dict:
        display_value = value if value else "\u2014"
        return {
            "type": "paragraph",
            "content": [
                {
                    "type": "text",
                    "marks": [{"type": "bold"}],
                    "text": f"{label}: ",
                },
                {
                    "type": "text",
                    "text": display_value,
                },
            ],
        }

    def _format_display_value(edl_key: str, value: str) -> str:
        """Render user-facing labels for dropdown/boolean fields in draft output."""
        v = str(value or "").strip()
        if edl_key == "aprv_proc_adtnl":
            if v:
                return approval_process_to_display(v)
            if _DISPLAY_FALLBACK_FROM_TEMPLATE.get(edl_key):
                return _DISPLAY_FALLBACK_FROM_TEMPLATE[edl_key]
            return ""
        if edl_key == "transaction_type_scope":
            if v:
                return transaction_type_to_display(v)
            if _DISPLAY_FALLBACK_FROM_TEMPLATE.get(edl_key):
                return _DISPLAY_FALLBACK_FROM_TEMPLATE[edl_key]
            return ""
        if edl_key in {"risk_adtnl", "priority_adtnl", "zzfld000013_cus", "zzfld000016_cus"}:
            if v:
                return dropdown_to_display(edl_key, v)
            if _DISPLAY_FALLBACK_FROM_TEMPLATE.get(edl_key):
                return _DISPLAY_FALLBACK_FROM_TEMPLATE[edl_key]
            return ""

        if edl_key in _DISPLAY_FALLBACK_FROM_TEMPLATE and _DISPLAY_FALLBACK_FROM_TEMPLATE[edl_key]:
            return _DISPLAY_FALLBACK_FROM_TEMPLATE[edl_key]

        if not v:
            return ""

        if edl_key == "aprv_proc_adtnl":
            return approval_process_to_display(v)

        if edl_key in BOOL_FIELDS:
            vu = v.upper()
            if vu in {"1", "X", "TRUE", "YES"}:
                return "Yes"
            if vu in {"0", "FALSE", "NO"}:
                return "No"
        return v

    # ── Build ProseMirror content nodes ──────────────────────────────────────
    content: list = []

    # "Change Request" section — 3 AI-written text fields
    _TEXT_FIELDS = [
        ("reason_for_change",      "Reason for Change"),
        ("description_of_change",  "Description of Change"),
        ("additional_information", "Additional Information"),
    ]
    _change_request_inserted = False

    # Remaining FIELD_GROUPS sections
    for group_name, field_dict in FIELD_GROUPS.items():
        if group_name == "Details" and not _change_request_inserted:
            content.append(_heading("Change Request"))
            for state_key, label in _TEXT_FIELDS:
                fs = state_values.get(state_key, {})
                val = (fs.get("value") or "") if isinstance(fs, dict) else ""
                content.append(_field_paragraph(label, str(val).strip()))
            _change_request_inserted = True

        content.append(_heading(group_name))
        for edl_key, display_label in field_dict.items():
            raw_value = flat.get(edl_key, "")
            display_value = _format_display_value(edl_key, raw_value)
            content.append(_field_paragraph(display_label, display_value))

    # Fallback in case Details is not present for any reason.
    if not _change_request_inserted:
        content.append(_heading("Change Request"))
        for state_key, label in _TEXT_FIELDS:
            fs = state_values.get(state_key, {})
            val = (fs.get("value") or "") if isinstance(fs, dict) else ""
            content.append(_field_paragraph(label, str(val).strip()))

    return {"type": "doc", "content": content}


def _build_expandable_document(state_values: dict) -> "list[dict] | None":
    """
    Build expandable field sections for accordion-style UI rendering.
    
    Returns None when no draft has been created yet.
    Returns a list of section dicts when a draft exists, each with:
      - id: section identifier (slugified title)
      - title: display name
      - fields: list of {"label": str, "value": str} field objects
    - default_expanded: bool (True for "Change Request" section, False for others)
    
    All sections and fields are always included; empty values render as em-dash.
    """
    if not state_values.get("draft"):
        return None

    # ── Build flat {edl_key: value} from API state data (same logic as _build_draft_document) ──
    template_state = state_values.get("template_id", {})
    cr_id_state = state_values.get("cr_id", {})
    api_data: dict = {}

    if isinstance(template_state, dict):
        d = template_state.get("data")
        if isinstance(d, dict):
            api_data = dict(d)

    if isinstance(cr_id_state, dict):
        d = cr_id_state.get("data")
        if isinstance(d, dict):
            api_data = _deep_merge_dict(api_data, d)

    flat: dict[str, str] = {}
    _GROUP_ALIASES = {
        "IvDetails": ["IvDetails"],
        "IvValidation": ["IvValidation"],
        "IvTestReq": ["IvTestReq"],
        "IvDocumentation": ["IvDocumentation"],
        "IvOthers": ["IvOthers"],
        "IvLocation": ["IvLocation"],
        "IvFunctionalArea": ["IvFunctionalArea"],
    }
    for (grp, api_field), edl_key in ODATA_FIELD_MAP.items():
        _candidates = _GROUP_ALIASES.get(grp, [grp])
        for _cand in _candidates:
            grp_data = api_data.get(_cand, {})
            if not isinstance(grp_data, dict):
                continue
            val = grp_data.get(api_field)
            if val is not None:
                flat[edl_key] = str(val).strip()
                break

    # ── Details and context overlays ──
    _DETAILS_TO_EDL = {
        "ObjectId":       "object_id",
        "PostingDate":    "posting_date",
        "Description":    "description",
        "ChangedAt":      "changed_at",
    }
    for _details_grp in ("IvDetails",):
        is_details = api_data.get(_details_grp, {})
        if isinstance(is_details, dict):
            for api_f, edl_f in _DETAILS_TO_EDL.items():
                v = is_details.get(api_f)
                if v is not None and str(v).strip():
                    flat[edl_f] = str(v).strip()

    _CONTEXT_TO_EDL = {
        "CycleID":          "solution_id_ctx",
        "ChangeCycle":      "project_title_ctx",
        "ChangeCyclePhase": "current_phase_desc_ctx",
        "Landscape":        "slan_name_ctx",
        "Branch":           "sbra_name_ctx",
        "CycleType":        "release_type_ctx",
    }
    for _ctx_grp in ("IvContext",):
        _ctx_data = api_data.get(_ctx_grp, {})
        if isinstance(_ctx_data, dict):
            for api_f, edl_f in _CONTEXT_TO_EDL.items():
                v = _ctx_data.get(api_f)
                if v is not None and str(v).strip():
                    flat[edl_f] = str(v).strip()

    # ── Overlay user-provided and Jira fields ──
    for sf in ("platform", "target_system"):
        fs = state_values.get(sf, {})
        if isinstance(fs, dict) and fs.get("value"):
            flat[sf] = str(fs["value"]).strip()

    for sf in ("zzfld00000v_cus", "zzfld00004y", "zzfld00000w_cus", "zzfld00004x"):
        fs = state_values.get(sf, {})
        if isinstance(fs, dict) and fs.get("value"):
            flat[sf] = str(fs["value"]).strip()

    # ── Functional Areas overlay ──
    _fa_data = api_data.get("IvFunctionalArea") or {}
    if isinstance(_fa_data, dict):
        _FA_DIRECT_MAP = {
            "PrimaryFunctionalArea": "zzfld000016_cus",
            "SecondaryFunctionalArea": "zzfld000017_cus",
            "SfaLogistics": "zzfld00002c_cus",
            "SfaOFM": "zzfld00001b_cus",
            "SfaSource": "zzfld00001c_cus",
            "SfaDeliver": "zzfld00001d_cus",
            "SfaMake": "zzfld00001e_cus",
            "SfaPlan": "zzfld00001f_cus",
            "SfaQM": "zzfld00001g_cus",
            "SfaSecurity": "zzfld00001h_cus",
            "SfaBasis": "zzfld00001i_cus",
            "SfaIMWM": "zzfld00001j_cus",
            "SfaMDM": "zzfld00001k_cus",
            "SfaDWMS": "zzfld00001l_cus",
            "SfaBI": "zzfld00001m_cus",
            "SfaIntegration": "zzfld00001r_cus",
            "SfaHR": "zzfld00001s_cus",
            "SfaPayroll": "zzfld00001t_cus",
            "SfaCRM": "zzfld00001u_cus",
            "SfaDevelopment": "zzfld00001v_cus",
            "SfaPortal": "zzfld00001w_cus",
            "SfaGlobalTrade": "zzfld00002h_cus",
        }
        for _api_f, _edl_f in _FA_DIRECT_MAP.items():
            _v = _fa_data.get(_api_f)
            if _v is not None and str(_v).strip() != "":
                flat[_edl_f] = str(_v).strip()

    # Status has no deterministic code→display helper (workflow-controlled by SAP) —
    # use StatusDesc from the API response as fallback for display only.
    _DISPLAY_FALLBACK_FROM_TEMPLATE: dict[str, str] = {}
    _iv_details_fb = api_data.get("IvDetails") or {}
    if isinstance(_iv_details_fb, dict) and str(_iv_details_fb.get("StatusDesc") or "").strip():
        _DISPLAY_FALLBACK_FROM_TEMPLATE["status_adtnl"] = str(_iv_details_fb.get("StatusDesc") or "").strip()

    def _format_display_value(edl_key: str, value: str) -> str:
        """Render user-facing labels for dropdown/boolean fields in UI output."""
        v = str(value or "").strip()
        if edl_key == "aprv_proc_adtnl":
            if v:
                return approval_process_to_display(v)
            if _DISPLAY_FALLBACK_FROM_TEMPLATE.get(edl_key):
                return _DISPLAY_FALLBACK_FROM_TEMPLATE[edl_key]
            return ""
        if edl_key == "transaction_type_scope":
            if v:
                return transaction_type_to_display(v)
            if _DISPLAY_FALLBACK_FROM_TEMPLATE.get(edl_key):
                return _DISPLAY_FALLBACK_FROM_TEMPLATE[edl_key]
            return ""
        if edl_key in {"risk_adtnl", "priority_adtnl", "zzfld000013_cus", "zzfld000016_cus"}:
            if v:
                return dropdown_to_display(edl_key, v)
            if _DISPLAY_FALLBACK_FROM_TEMPLATE.get(edl_key):
                return _DISPLAY_FALLBACK_FROM_TEMPLATE[edl_key]
            return ""

        if edl_key in _DISPLAY_FALLBACK_FROM_TEMPLATE and _DISPLAY_FALLBACK_FROM_TEMPLATE[edl_key]:
            return _DISPLAY_FALLBACK_FROM_TEMPLATE[edl_key]

        if not v:
            return ""

        if edl_key == "aprv_proc_adtnl":
            return approval_process_to_display(v)

        if edl_key in BOOL_FIELDS:
            vu = v.upper()
            if vu in {"1", "X", "TRUE", "YES"}:
                return "Yes"
            if vu in {"0", "FALSE", "NO"}:
                return "No"
        return v

    def _slugify(text: str) -> str:
        """Convert section title to lowercase slug (e.g., 'Validation Requirements' → 'validation_requirements')."""
        return text.lower().replace(" ", "_")

    sections: list[dict] = []

    # ── "Change Request" section fields ──
    _TEXT_FIELDS = [
        ("reason_for_change", "Reason for Change"),
        ("description_of_change", "Description of Change"),
        ("additional_information", "Additional Information"),
    ]
    cr_fields = []
    for state_key, label in _TEXT_FIELDS:
        fs = state_values.get(state_key, {})
        val = (fs.get("value") or "") if isinstance(fs, dict) else ""
        display_value = str(val).strip() if str(val).strip() else "\u2014"
        cr_fields.append({"label": label, "value": display_value})

    _change_request_inserted = False

    # ── Remaining FIELD_GROUPS sections ──
    for group_name, field_dict in FIELD_GROUPS.items():
        if group_name == "Details" and not _change_request_inserted:
            sections.append({
                "id": "change_request",
                "title": "Change Request",
                "default_expanded": True,
                "fields": cr_fields,
            })
            _change_request_inserted = True

        section_fields = []
        for edl_key, display_label in field_dict.items():
            raw_value = flat.get(edl_key, "")
            display_value = _format_display_value(edl_key, raw_value)
            display_value = display_value if display_value else "\u2014"
            section_fields.append({
                "label": display_label,
                "value": display_value,
            })

        sections.append({
            "id": _slugify(group_name),
            "title": group_name,
            "default_expanded": False,
            "fields": section_fields,
        })

    # Fallback in case Details is not present for any reason.
    if not _change_request_inserted:
        sections.append({
            "id": "change_request",
            "title": "Change Request",
            "default_expanded": True,
            "fields": cr_fields,
        })

    return sections


def _get_interrupt_message(snapshot) -> str:
    """Extract the interrupt prompt string from a graph snapshot."""
    if snapshot is None:
        return ""
    for task in getattr(snapshot, "tasks", []):
        for intr in getattr(task, "interrupts", []):
            val = getattr(intr, "value", None) or str(intr)
            if val:
                return str(val)
    return ""


def _build_waiting_output(messages_out: list[str], interrupt_msg: str) -> str:
    """Combine this-turn AI messages with the interrupt prompt (deduplicated)."""
    parts = [m.strip() for m in messages_out if isinstance(m, str) and m and m.strip()]
    intr = (interrupt_msg or "Waiting for your input...").strip()
    already_covered = any(intr.startswith(p) or p.startswith(intr) for p in parts)
    if not already_covered:
        parts.append(intr)
    elif not parts:
        parts.append(intr)
    return "\n\n".join(parts)


# ── Shared graph instance ────────────────────────────────────────────────────
_graph = build_graph()

# Maps AgentCore sessionId → active LangGraph thread_id
# Persisted to disk so the mapping survives uvicorn reloads / restarts.
# Without persistence: after restart, the same session_id gets a new random
# thread_id, so AgentCoreMemorySaver can never find the saved checkpoint.
import uuid as _uuid
import re as _re
import datetime as _datetime

# /app is read-only in AgentCore runtime — persist state files to /tmp
_STATE_DIR = os.environ.get("AGENT_STATE_DIR", "/tmp")
_THREADS_FILE = os.path.join(_STATE_DIR, ".session_threads.json")

def _load_session_threads() -> dict:
    try:
        if os.path.exists(_THREADS_FILE):
            with open(_THREADS_FILE, encoding="utf-8") as _f:
                return json.load(_f)
    except Exception:
        pass
    return {}

def _save_session_threads() -> None:
    try:
        with open(_THREADS_FILE, "w", encoding="utf-8") as _f:
            json.dump(_session_threads, _f)
    except Exception as _e:
        logger.warning("Could not persist session_threads: %s", _e)

_session_threads: dict[str, str] = _load_session_threads()
logger.info("session_threads loaded: %d active sessions", len(_session_threads))

# ── Actor submissions log ─────────────────────────────────────────────
# After each successful CR submission the new CR ID + description are appended
# here under the actor_id so future sessions can recall them.

_SUBMISSIONS_FILE = os.path.join(_STATE_DIR, ".actor_submissions.json")

def _load_submissions() -> dict:
    try:
        if os.path.exists(_SUBMISSIONS_FILE):
            with open(_SUBMISSIONS_FILE, encoding="utf-8") as _f:
                return json.load(_f)
    except Exception:
        pass
    return {}

def _record_submission(actor_id: str, state_values: dict) -> None:
    """Called after a session completes. Writes CR ID + description to the log."""
    result = state_values.get("submission_result") or {}
    cr_id  = result.get("cr_id") or (state_values.get("cr_id") or {}).get("value") or ""
    if not cr_id or str(cr_id).strip() in ("", "UNKNOWN"):
        return
    jira_fs  = state_values.get("jira_id") or {}
    jira_id  = (jira_fs.get("value") or "") if isinstance(jira_fs, dict) else ""
    desc_fs  = state_values.get("description_of_change") or {}
    desc     = (desc_fs.get("value") or "") if isinstance(desc_fs, dict) else ""
    plat_fs  = state_values.get("platform") or {}
    platform = (plat_fs.get("value") or "") if isinstance(plat_fs, dict) else ""
    data = _load_submissions()
    if actor_id not in data:
        data[actor_id] = []
    data[actor_id].append({
        "cr_id":    cr_id,
        "jira_id":  jira_id,
        "platform": platform,
        "desc":     desc[:200],
        "ts":       _datetime.datetime.utcnow().isoformat(),
    })
    data[actor_id] = data[actor_id][-20:]  # keep last 20 per actor
    try:
        with open(_SUBMISSIONS_FILE, "w", encoding="utf-8") as _f:
            json.dump(data, _f, indent=2)
        logger.info("_record_submission: saved CR %s for actor=%s", cr_id, actor_id)
    except Exception as _e:
        logger.warning("_record_submission: could not write log: %s", _e)

# ── Memory recall interceptor ───────────────────────────────────────────────
# Questions about past CRs are answered directly from the log without running
# the full agent graph (which would try to collect platform/JIRA fields instead).

_RECALL_RE = _re.compile(
    r'\b(last|latest|recent|previous|most recent)\b.{0,40}\b(cr|change\s*request)\b'
    r'|\b(cr|change\s*request)\b.{0,40}\b(last|latest|recent|previous|submit|creat)\w*\b'
    r'|\b(what|which|show).{0,30}\b(cr|change\s*request)\b.{0,40}\b(submit|creat|made|sent)\b'
    r'|\b(did i|have i|i have).{0,30}\b(submit|creat)\w*\b',
    _re.IGNORECASE,
)

def _answer_recall(prompt: str, actor_id: str) -> "str | None":
    """Return a pre-built answer if the prompt is a recall question, else None."""
    if not _RECALL_RE.search(prompt):
        return None
    data  = _load_submissions()
    items = data.get(actor_id) or []
    if not items:
        return (
            "I don't have any previously submitted change requests on record for your account. "
            "Would you like to create a new one?"
        )
    last  = items[-1]
    lines = [f"The last change request I submitted for you was **CR {last['cr_id']}**."]
    if last.get("jira_id"):
        lines.append(f"- JIRA: {last['jira_id']}")
    if last.get("platform"):
        lines.append(f"- Platform: {last['platform']}")
    if last.get("desc"):
        lines.append(f"- Description: {last['desc']}")
    if last.get("ts"):
        lines.append(f"- Submitted at: {last['ts'][:19].replace('T', ' ')} UTC")
    if len(items) > 1:
        lines.append(f"\nYou have {len(items)} submission(s) on record in total.")
    return "\n".join(lines)

def _get_thread_id(session_id: str) -> str:
    if session_id not in _session_threads:
        _session_threads[session_id] = f"{session_id}-{_uuid.uuid4().hex[:8]}"
        _save_session_threads()
    return _session_threads[session_id]

def _reset_thread_id(session_id: str) -> str:
    new_thread = f"{session_id}-{_uuid.uuid4().hex[:8]}"
    _session_threads[session_id] = new_thread
    _save_session_threads()
    return new_thread

# ── Core agent runner (adapted from original run()) ──────────────────────────

def run_agent(user_input: str, session_id: str = "cr-session-1", thread_id: str | None = None, actor_id: str | None = None, wwid: str = "", task_id: str | None = None) -> dict:
    """
    Start a new agent session.
    Returns either:
      {"status": "waiting",  "session_id": ..., "message": <interrupt prompt>}
      {"status": "complete", "session_id": ..., "message": <final output>}
    """
    initial_state = build_initial_state(user_input, wwid=wwid, task_id=task_id)
    config        = {
        "configurable": {"thread_id": thread_id or session_id, "actor_id": actor_id or session_id},
        "callbacks": [TokenCostCallbackHandler()],
    }
    reset_token_accumulator()

    seen_ids: set = set()
    messages_out: list[str] = []

    # Stream until first interrupt or completion
    try:
        for event in _graph.stream(initial_state, config=config, stream_mode="values"):
            messages_out.extend(_collect_messages(event, seen_ids))
    except Exception as exc:
        exc_type = type(exc).__name__
        if "NodeInterrupt" in exc_type or "GraphInterrupt" in exc_type:
            pass  # expected — graph paused at interrupt
        else:
            logger.exception("Unexpected error during initial graph stream")
            raise

    # Check if graph is waiting for human input
    try:
        snapshot = _graph.get_state(config)
    except Exception as e:
        logger.error("get_state failed: %s", e)
        snapshot = None

    # Fallback: AgentCoreCheckpointer may silence streaming; read from snapshot directly.
    if not messages_out and snapshot and snapshot.values:
        for _msg in (snapshot.values.get("messages") or []):
            if isinstance(_msg, AIMessage) and _msg.content:
                _key = getattr(_msg, "id", None) or str(_msg.content)[:120]
                if _key not in seen_ids:
                    seen_ids.add(_key)
                    messages_out.append(str(_msg.content).strip())

    if snapshot and snapshot.next:
        interrupt_msg = _get_interrupt_message(snapshot)
        return {
            "status":     "waiting",
            "session_id": session_id,
            "message":    _build_waiting_output(messages_out, interrupt_msg),
        }

    return {
        "status":     "complete",
        "session_id": session_id,
        "message":    "\n".join(messages_out) if messages_out else "Session complete.",
    }


def resume_agent(human_input: str, session_id: str = "cr-session-1", thread_id: str | None = None, actor_id: str | None = None) -> dict:
    """
    Resume a paused agent session with human input.
    Returns same structure as run_agent().
    """
    config = {
        "configurable": {"thread_id": thread_id or session_id, "actor_id": actor_id or session_id},
        "callbacks": [TokenCostCallbackHandler()],
    }
    reset_token_accumulator()

    seen_ids: set = set()
    messages_out: list[str] = []

    # Pre-seed seen_ids with all messages already in state before this resume.
    # stream_mode="values" re-emits the full message list on every node event,
    # so without this, AIMessages from previous turns (e.g. mismatch alert) get
    # collected again and incorrectly appear in the current turn's chat_text.
    try:
        _pre_snap = _graph.get_state(config)
        if _pre_snap and _pre_snap.values:
            for _msg in (_pre_snap.values.get("messages") or []):
                if isinstance(_msg, AIMessage) and _msg.content:
                    _msg_key = getattr(_msg, "id", None) or str(_msg.content)[:120]
                    seen_ids.add(_msg_key)
    except Exception:
        pass

    try:
        for event in _graph.stream(
            Command(resume=human_input),
            config=config,
            stream_mode="values",
        ):
            messages_out.extend(_collect_messages(event, seen_ids))
    except Exception as exc:
        exc_type = type(exc).__name__
        if "NodeInterrupt" in exc_type or "GraphInterrupt" in exc_type:
            pass  # another interrupt — loop continues
        else:
            logger.exception("Unexpected error during graph resume")
            raise

    # Check if still waiting
    try:
        snapshot = _graph.get_state(config)
    except Exception as e:
        logger.error("get_state failed: %s", e)
        snapshot = None

    # Fallback: AgentCoreCheckpointer may silence streaming; read from snapshot directly.
    # seen_idd with prior-turn messages, so only this turn's messages pass.
    if not messages_out and snapshot and snapshot.values:
        for _msg in (snapshot.values.get("messages") or []):
            if isinstance(_msg, AIMessage) and _msg.content:
                _key = getattr(_msg, "id", None) or str(_msg.content)[:120]
                if _key not in seen_ids:
                    seen_ids.add(_key)
                    messages_out.append(str(_msg.content).strip())

    if snapshot and snapshot.next:
        interrupt_msg = _get_interrupt_message(snapshot)
        return {
            "status":     "waiting",
            "session_id": session_id,
            "message":    _build_waiting_output(messages_out, interrupt_msg),
        }

    return {
        "status":     "complete",
        "session_id": session_id,
        "message":    "\n".join(messages_out) if messages_out else "Session complete.",
    }


# ── AgentCore HTTP Handler ────────────────────────────────────────────────────

class AgentHandler(BaseHTTPRequestHandler):

    def do_POST(self):
        if self.path == "/invocations":
            length = int(self.headers.get("Content-Length", 0))
            body   = json.loads(self.rfile.read(length))

            business_values = get_business_trace_values(body)
            baggage_token = attach_business_baggage(business_values)

            try:

                prompt      = body.get("prompt", "")
                session_id  = body.get("session_id", "cr-session-1")
                human_input = body.get("human_input")  # present only on resume calls
                wwid = str(body.get("wwid", "") or "").strip()

                set_request_context(session_id, wwid)
                log_business_trace_context(logger, body, session_id, wwid)

                with tracer.start_as_current_span("app.prepare_request") as span:
                    set_span_attributes(span, business_values)
                    span.set_attribute("session.id", session_id)
                    span.set_attribute("app.workflow_step", "prepare_request")
                    span.set_attribute("app.prompt_present", bool(prompt))
                    span.set_attribute("app.status", "success")

                with tracer.start_as_current_span("app.agent_execution") as span:
                    set_span_attributes(span, business_values)
                    span.set_attribute("session.id", session_id)
                    span.set_attribute("app.workflow_step", "agent_execution")
                    span.set_attribute("app.agent_name", "cr-agent")

                    try:
                        if human_input is not None:
                            # Resume an existing HITL session
                            result = resume_agent(human_input, session_id)
                        else:
                            # Start a new session
                            result = run_agent(prompt, session_id, wwid=wwid)
                        span.set_attribute("app.status", "success")
                    except Exception as exc:
                        span.record_exception(exc)
                        span.set_status(Status(StatusCode.ERROR, str(exc)))
                        span.set_attribute("app.status", "error")
                        span.set_attribute("app.error", True)
                        span.set_attribute("app.error_type", type(exc).__name__)
                        raise

                self._send_json(200, result)

            except Exception as exc:
                logger.exception("Agent error")
                self._send_json(500, {"error": str(exc)})
            finally:
                if baggage_token is not None:
                    detach(baggage_token)

        elif self.path == "/ping":
            # Health check — AgentCore calls this to verify server is up
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"OK")

        else:
            self.send_response(404)
            self.end_headers()

    def _send_json(self, status: int, data: dict):
        payload = json.dumps(data).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def log_message(self, format, *args):
        pass  # suppress noisy access logs


# ── Raw ASGI app — no FastAPI needed, uvicorn finds this for AgentCore ─────
# AgentCore HTTP protocol runs: uvicorn main:app
# This is pure ASGI (no framework), handles /invocations and /ping.

async def app(scope, receive, send):
    if scope["type"] != "http":
        return

    # Read full request body
    body_chunks = []
    while True:
        msg = await receive()
        body_chunks.append(msg.get("body", b""))
        if not msg.get("more_body", False):
            break
    raw_body = b"".join(body_chunks)

    path = scope.get("path", "")

    if path == "/ping":
        await _asgi_respond(send, 200, b"OK", content_type="text/plain")
        return

    # Log all headers on every /invocations call so we can find the real session header
    if path == "/invocations":
        headers = {k.decode(): v.decode() for k, v in scope.get("headers", [])}
        # Seed session_id from the AgentCore runtime header as early as possible so
        # the HEADERS/BODY debug lines below already carry it.
        _early_session_id = headers.get("x-amzn-bedrock-agentcore-runtime-session-id", "")
        if _early_session_id:
            set_request_context(_early_session_id)
        logger.info("HEADERS: %s", json.dumps(headers, indent=2))
        logger.info("BODY: %s", raw_body.decode(errors="replace"))

    if path == "/invocations" and scope["method"] == "POST":
        body = json.loads(raw_body) if raw_body else {}
        business_values = get_business_trace_values(body)
        baggage_token = attach_business_baggage(business_values)

        with tracer.start_as_current_span("POST /invocations") as root_span:
            set_span_attributes(root_span, business_values)
            root_span.set_attribute("http.method", "POST")
            root_span.set_attribute("http.route", "/invocations")

            try:
                prompt = (
                    body.get("prompt")
                    or (body.get("task") or {}).get("instruction")
                    or (body.get("inputs") or {}).get("text")
                    or body.get("inputText", "")
                )

                # Use the AgentCore runtime session header as the stable session ID.
                # The body 'sessionId' is absent on turn 1 and present on turn 2+,
                # so it cannot be used alone. The header is always consistent.
                headers    = {k.decode(): v.decode() for k, v in scope.get("headers", [])}
                session_id = (
                    headers.get("x-amzn-bedrock-agentcore-runtime-session-id")
                    or body.get("sessionId")
                    or body.get("workflow_id")
                    or body.get("session_id", "cr-session-1")
                )
                wwid = str(body.get("wwid", "") or "").strip()

                set_request_context(session_id, wwid)
                log_business_trace_context(logger, body, session_id, wwid)

                with tracer.start_as_current_span("app.prepare_request") as span:
                    set_span_attributes(span, business_values)
                    span.set_attribute("session.id", session_id)
                    span.set_attribute("app.workflow_step", "prepare_request")
                    span.set_attribute("app.prompt_present", bool(prompt))
                    span.set_attribute("app.status", "success")

                # Use session_id directly as thread_id — stable across all containers
                thread_id = session_id

                # AgentCoreMemorySaver requires 'actor_id' in the config.
                # In the real AgentCore runtime it is injected automatically.
                # Locally: prefer the runtime header, then fall back to the
                # body 'memoryId' (same value in every request = stable user identity),
                # then body 'actorId', then session_id as last resort.
                actor_id = (
                    headers.get("x-amzn-bedrock-agentcore-actor-id")
                    or body.get("memoryId")
                    or body.get("actorId")
                    or session_id
                )
                config    = {"configurable": {"thread_id": thread_id, "actor_id": actor_id}}

                # Decide fresh-vs-resume BEFORE the agent_execution span so the
                # task_id can be tagged on spans from the start.
                try:
                    _pre_snapshot = _graph.get_state(config)
                except Exception:
                    _pre_snapshot = None
                _is_resume = bool(_pre_snapshot and _pre_snapshot.next)
                if _is_resume:
                    task_id = (_pre_snapshot.values or {}).get("task_id", "")
                else:
                    task_id = uuid.uuid4().hex
                root_span.set_attribute("app.task.id", task_id)
                set_task_context(task_id)

                with tracer.start_as_current_span("app.agent_execution") as span:
                    set_span_attributes(span, business_values)
                    span.set_attribute("session.id", session_id)
                    span.set_attribute("app.task.id", task_id)
                    span.set_attribute("app.workflow_step", "agent_execution")
                    span.set_attribute("app.agent_name", "cr-agent")

                    try:
                        # Check graph state — if a HITL interrupt is pending, resume it
                        # Do NOT rely on a special 'humanInput' field; AgentCore just sends 'prompt'
                        snapshot = _pre_snapshot

                        if snapshot and snapshot.next:
                            # Graph is paused at a HITL interrupt — resume with the user's message
                            result = resume_agent(prompt, session_id, thread_id=thread_id, actor_id=actor_id)
                        else:
                            # Fresh conversation
                            result = run_agent(prompt, session_id, thread_id=thread_id, actor_id=actor_id, wwid=wwid, task_id=task_id)

                        span.set_attribute("app.status", "success")

                        # Roll up this turn's LLM token/cost totals (accumulated across
                        # all node.* spans during run_agent/resume_agent) onto this span.
                        _token_totals = get_token_accumulator()
                        span.set_attribute("gen_ai.usage.input_tokens", _token_totals["input_tokens"])
                        span.set_attribute("gen_ai.usage.output_tokens", _token_totals["output_tokens"])
                        span.set_attribute("gen_ai.usage.cost_usd", _token_totals["cost_usd"])
                        span.set_attribute("gen_ai.usage.call_count", _token_totals["call_count"])
                        root_span.set_attribute("gen_ai.usage.input_tokens", _token_totals["input_tokens"])
                        root_span.set_attribute("gen_ai.usage.output_tokens", _token_totals["output_tokens"])
                        root_span.set_attribute("gen_ai.usage.cost_usd", _token_totals["cost_usd"])
                        root_span.set_attribute("gen_ai.usage.call_count", _token_totals["call_count"])
                    except Exception as exc:
                        span.record_exception(exc)
                        span.set_status(Status(StatusCode.ERROR, str(exc)))
                        span.set_attribute("app.status", "error")
                        span.set_attribute("app.error", True)
                        span.set_attribute("app.error_type", type(exc).__name__)
                        raise

                with tracer.start_as_current_span("app.postprocess_response") as span:
                    set_span_attributes(span, business_values)
                    span.set_attribute("session.id", session_id)
                    span.set_attribute("app.workflow_step", "postprocess_response")

                    # Normalise to AgentCore expected shape
                    done = result.get("status") == "complete"

                    # Use per-turn aggregated message built by run_agent/resume_agent.
                    # This preserves feedback + draft ordering from the current turn
                    # instead of collapsing to only the last AI message.
                    output = result.get("message", "")
                    if not output:
                        # Defensive fallback: if aggregation is empty for any reason,
                        # fall back to the latest visible AI message.
                        try:
                            _cur_snap = _graph.get_state(config)
                            if _cur_snap and _cur_snap.values:
                                output = next(
                                    (
                                        m.content
                                        for m in reversed(_cur_snap.values.get("messages", []))
                                        if isinstance(m, AIMessage)
                                        and m.content
                                        and not str(m.content).startswith("Parsed update intents:")
                                    ),
                                    "",
                                )
                        except Exception:
                            pass

                    # Build structured draft document from current graph state
                    try:
                        _cur = _graph.get_state(config)
                        _sv  = (_cur.values or {}) if _cur else {}
                    except Exception:
                        _sv = {}

                    # ── Task-level completion status + duration ─────────
                    _is_still_waiting = bool(_cur.next) if _cur else False
                    span.set_attribute("app.task.id", task_id)
                    if _is_still_waiting:
                        task_status = "in_progress"
                        span.set_attribute("app.task.status", task_status)
                        root_span.set_attribute("app.task.status", task_status)
                    else:
                        task_status = derive_task_status(_sv.get("submission_result"))
                        span.set_attribute("app.task.status", task_status)
                        root_span.set_attribute("app.task.status", task_status)
                        _task_start_ts = _sv.get("task_start_ts")
                        if _task_start_ts:
                            task_duration_ms = (time.time() - _task_start_ts) * 1000
                            span.set_attribute("app.task.duration_ms", task_duration_ms)
                            root_span.set_attribute("app.task.duration_ms", task_duration_ms)

                    document = _build_draft_document(_sv)
                    expandable_sections = _build_expandable_document(_sv)

                    # Include clickable_options when graph is paused at a HITL interrupt
                    _cur_snap = None
                    try:
                        _cur_snap = _graph.get_state(config)
                    except Exception:
                        pass
                    _clickable: list = []
                    if _cur_snap and _cur_snap.next and _cur_snap.values:
                        _raw_opts = _cur_snap.values.get("clickable_options") or []
                        for _opt in _raw_opts:
                            if isinstance(_opt, dict):
                                _clickable.append(_opt)
                            elif _opt:
                                _clickable.append({"label": str(_opt), "value": str(_opt)})
                    span.set_attribute("app.status", "success")

                payload = json.dumps({
                    "chat_text":        output,
                    "document":         document,
                    "clickable_options": _clickable or None,
                    "expandable_document": expandable_sections or None,
                }, indent=2, ensure_ascii=False).encode()
                await _asgi_respond(send, 200, payload)
            except Exception as exc:
                logger.exception("Agent error")
                root_span.record_exception(exc)
                root_span.set_status(Status(StatusCode.ERROR, str(exc)))
                err = json.dumps({"error": str(exc)}).encode()
                await _asgi_respond(send, 500, err)
            finally:
                if baggage_token is not None:
                    detach(baggage_token)
        return

    await _asgi_respond(send, 404, b"Not found", content_type="text/plain")


async def _asgi_respond(send, status: int, body: bytes, content_type: str = "application/json"):
    await send({
        "type": "http.response.start",
        "status": status,
        "headers": [
            [b"content-type", content_type.encode()],
            [b"content-length", str(len(body)).encode()],
        ],
    })
    await send({"type": "http.response.body", "body": body})


# ── CLI mode (original behaviour preserved) ──────────────────────────────────

def cli_mode():
    """Original interactive CLI — run with: python main.py --cli"""
    parser = argparse.ArgumentParser(description="CR Agent CLI")
    parser.add_argument("--input", "-i", type=str, default=None,
                        help="Initial user input (if omitted, will prompt interactively)")
    args = parser.parse_args()

    if args.input:
        user_input = args.input
    else:
        print("CR Agent [CR Change Request Assistant]")
        print("=" * 40)
        try:
            user_input = input("[YOU]: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nExiting.")
            sys.exit(0)

    if not user_input:
        print("No input provided. Exiting.")
        sys.exit(1)

    # Use the original streaming loop for CLI
    graph         = build_graph()
    initial_state = build_initial_state(user_input)
    config        = {"configurable": {"thread_id": "cr-session-1"}}

    print(f"\n[USER]: {user_input}\n")

    try:
        for event in graph.stream(initial_state, config=config, stream_mode="values"):
            for msg in event.get("messages", []):
                if isinstance(msg, AIMessage) and msg.content:
                    print(f"[AGENT]: {msg.content}\n")
    except Exception as exc:
        exc_type = type(exc).__name__
        if "NodeInterrupt" not in exc_type and "GraphInterrupt" not in exc_type:
            raise

    while True:
        try:
            snapshot = graph.get_state(config)
        except Exception as e:
            logger.error("get_state failed: %s", e)
            break

        if not snapshot or not snapshot.next:
            print("\n[SESSION COMPLETE]")
            break

        interrupt_msg = _get_interrupt_message(snapshot)
        if interrupt_msg:
            print(f"\n[HITL PROMPT]: {interrupt_msg}")
        else:
            print("\n[HITL]: Waiting for your input...")

        try:
            human_input = input("[YOU]: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n[SESSION ENDED by user]")
            break

        if not human_input:
            continue

        try:
            for event in graph.stream(
                Command(resume=human_input),
                config=config,
                stream_mode="values",
            ):
                for msg in event.get("messages", []):
                    if isinstance(msg, AIMessage) and msg.content:
                        print(f"[AGENT]: {msg.content}\n")
        except Exception as exc:
            exc_type = type(exc).__name__
            if "NodeInterrupt" not in exc_type and "GraphInterrupt" not in exc_type:
                raise


# ── Entrypoint ────────────────────────────────────────────────────────────────

def main() -> None:
    # If --cli flag passed, run original interactive CLI
    if "--cli" in sys.argv:
        sys.argv.remove("--cli")
        cli_mode()
        return

    # Otherwise start AgentCore HTTP server via uvicorn (ASGI)
    # This serves the async app() which returns the correct
    # {chat_text, document, clickable_options} format expected by AgentCore.
    import uvicorn
    port = int(os.environ.get("PORT", 8080))
    print(f"[INFO] CR Agent HTTP server starting on http://0.0.0.0:{port}")
    print("[INFO] POST /invocations  — invoke agent")
    print("[INFO] GET  /ping         — health check")
    print("[INFO] Pass --cli to run in interactive CLI mode instead")
    uvicorn.run(app, host="0.0.0.0", port=port, log_level="warning")


if __name__ == "__main__":
    main()
